<template>
    <div class="main-container max-w-[1280px] mx-auto">

        <!-- Top Header -->
        <HeaderTop :scrollDown="scrollDown" />

        <!-- Top Header -->
        <HeaderTopMenu :scrollDown="scrollDown" />
        <slot />
        <FooterContent />
    </div>
    <!-- <AdsBottom :scrollDown="scrollDown" /> -->
</template>

<script setup>
const scrollDown = ref(false)
// const adsBottomStatus = ref(false)
const scrollPostion = ref(120)

onMounted(() => {
    window.addEventListener("scroll", function () {
        if (document.documentElement.scrollTop >= scrollPostion.value) {
            scrollDown.value = true
            adsBottomStatus.value = true
        }
        else {
            scrollDown.value = false
            // const adsBottomStatus = ref(false)
        }
    })

})
</script>

<style lang="scss" scoped></style>