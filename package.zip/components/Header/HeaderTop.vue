<template>
    <div class=" flex gap-1 py-5 px-2 justify-between items-center">
        <div class="flex gap-4 flex-col">
            <div class="flex gap-3 items-center">
                <div>
                    <Icon v-if="!desktopMenuStatus" @click="desktopMenuOpenHandler" class="text-3xl cursor-pointer hover:bg-[#f7f7f7]" name="ic:outline-menu" />
                    <Icon v-else @click="desktopMenuCloseHandler" name="material-symbols:close" class="text-3xl cursor-pointer hover:bg-[#f7f7f7]" />
                </div>
                <div>
                    <Icon class="text-2xl cursor-pointer" name="tabler:search" />
                </div>
            </div>
            <div class="today_date text-sm">
            
                {{  todayDate }}
    
            </div>
        </div>
        <div class="header_logo">
            <nuxt-img src="/assets/img/logo.png" height="56" alt="Dhaka Prokash"
                :placeholder="img('/assets/img/logo.png', { h: 56, blur: 2, q: 50 })" />
        </div>
        <div class="flex gap-4 flex-col">
            <div class="flex gap-4 items-center place-self-end">
                <NuxtLink to="">
                    <Icon class="text-2xl cursor-pointer" name="bi:facebook" />
                </NuxtLink>
                <NuxtLink to="">
                    <Icon class="text-2xl cursor-pointer" name="ri:twitter-x-fill" />
                </NuxtLink>
                <NuxtLink to="">
                    <Icon class="text-2xl cursor-pointer" name="bi:instagram" />
                </NuxtLink>
                <NuxtLink to="">
                    <Icon class="text-2xl cursor-pointer" name="bi:youtube" />
                </NuxtLink>
            </div>
            <div class="today_date place-self-end flex gap-2">
                <div class="px-3 py-1 border cursor-pointer">ইপেপার</div>
                <div class="px-3 py-1 border cursor-pointer">English</div>
            </div>
        </div>
        <HeaderDesktopSideMenu :desktopMenuStatus="desktopMenuStatus" />
    </div>
</template>

<script setup>
   const {scrollDown} = defineProps(['scrollDown'])
// ================ Get Bangla Date ============== //
const getDate = new Intl.DateTimeFormat('bn-bd', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })
const todayDate = getDate.format(new Date())
// ================ Get Bangla Date ============== //
const img = useImage()

const desktopMenuStatus = ref(false)
const desktopMenuOpenHandler = () => {
    desktopMenuStatus.value = true
}
const desktopMenuCloseHandler = () => {
    desktopMenuStatus.value = false
}
 
</script>

<style lang="scss" scoped></style>