<template>
    <div class="main-footer py-8 border-t mt-10">
        <FooterTop />
        <FooterMiddle />
        <FooterBottom />
    </div>
</template>

<script setup>

</script>

<style lang="scss" scoped>

</style>