<template>
    <div class="footerTop flex flex-col gap-5 pb-8">
        <NuxtLink to="/">
            <nuxt-img class="mx-auto" src="/assets/img/logo.png" />
        </NuxtLink>
        <div class="footerLink">
            <div class=" content-center grid grid-cols-5 px-6 md:px-0 md:grid-cols-6 gap-5 text-sm">
                <NuxtLink to="/">গোলটেবিল</NuxtLink>
                <NuxtLink to="/">বিশেষ সংখ্যা</NuxtLink>
                <NuxtLink to="/">কিশোর আলো</NuxtLink>
                <NuxtLink to="/">চিরন্তন ১৯৭১</NuxtLink>
                <NuxtLink to="/">বিজ্ঞানচিন্তা</NuxtLink>
                <NuxtLink to="/">প্রতিচিন্তা</NuxtLink>
                <NuxtLink to="/">গোলটেবিল</NuxtLink>
                <NuxtLink to="/">বিশেষ সংখ্যা</NuxtLink>
                <NuxtLink to="/">কিশোর আলো</NuxtLink>
                <NuxtLink to="/">চিরন্তন ১৯৭১</NuxtLink>
                <NuxtLink to="/">বিজ্ঞানচিন্তা</NuxtLink>
                <NuxtLink to="/">প্রতিচিন্তা</NuxtLink>
            </div>
           
        </div>

    </div>
</template>

<script setup>

</script>

<style lang="scss" scoped>

</style>