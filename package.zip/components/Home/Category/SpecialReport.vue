<template>
    <div class="home-special-report-category mb-6">
        <div class="category-header border-b-4 border-b-[#3375af] my-3">
            <NuxtLink :to="`/${specialreports[0]?.category?.cat_slug}`" class="flex gap-3 items-center">
                <span class="w-3 h-3 bg-[#3375af]"></span>
                <h2 class="text-[#3375af] text-[18px] font-semibold">বিশেষ প্রতিবেদন</h2>
            </NuxtLink>
        </div>

        <div class=" grid grid-cols-12 gap-4">
            <!-- Loop Item -->
            <div class=" col-span-12 md:col-span-3" v-for="hspecialreport in specialreports" :key="hspecialreport.content_id">
                <NuxtLink :to="`/category/${hspecialreport?.category?.cat_slug}/${hspecialreport?.content_id}`" class="flex flex-col gap-2 group">
                    <div class=" overflow-hidden">
                        <nuxt-img :src="`${siteUrl.site_url}/media/content/images/${hspecialreport?.img_bg_path}`"
                            class="mx-auto w-full group-hover:scale-110 duration-300"
                            :placeholder="img(`${siteUrl?.site_url}/logo/placeholder.jpg`)" />
                    </div>
                    <h3 class="text-[19px] leading-tight group-hover:text-[#ff0000]">{{ hspecialreport?.content_heading
                        }}</h3>
                </NuxtLink>
            </div>
            <!-- Loop Item -->

        </div>
    </div>
</template>

<script setup>

const img = useImage()

const siteUrl = siteUrlState()
const specialreports = useState(() => [])
const { data: hsreport } = await useFetch('/api/home/specialreports', {
    method: 'GET'
})
specialreports.value = hsreport
</script>

<style lang="scss" scoped></style>