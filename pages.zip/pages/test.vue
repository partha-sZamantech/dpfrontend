<template>
    <div>
        <div class=" fixed bg-white h-screen inset-0  flex items-center justify-center">
            <div class="flex items-center gap-1">
                <img width="60" src="/assets/img/loader.gif" alt="">
                <h3 class="text-2xl text-black">লোড হচ্ছে...</h3>
            </div>
        </div>
        <!-- <div class="bg-white h-screen ">
            <div class="flex justify-center items-center pt-32">
                <img width="60" src="/assets/img/loader.gif" alt="">
                <h3 class="text-2xl text-black">লোড হচ্ছে...</h3>
            </div>
        </div> -->
    </div>
</template>

<script setup>

</script>

<style lang="scss" scoped>

</style>