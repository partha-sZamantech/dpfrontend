<template>
    <div>
        Photo 
    </div>
</template>

<script setup>
    navigateTo('/')
</script>

<style lang="scss" scoped>

</style>