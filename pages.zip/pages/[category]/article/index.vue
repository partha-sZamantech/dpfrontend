<template>
    <div>
        <h2>Article Page</h2>
    </div>
</template>

<script setup>
    navigateTo('/')
</script>

<style lang="scss" scoped>

</style>