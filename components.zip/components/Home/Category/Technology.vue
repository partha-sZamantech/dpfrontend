<template>
    <div class="home-technology-category">
        <div class="category-header border-b-4 border-b-[#3375af] my-3">
            <NuxtLink to="/" class="flex gap-3 items-center">
                <span class="w-3 h-3 bg-[#3375af]"></span>
                <h2 class="text-[#3375af] text-[18px] font-semibold">বিজ্ঞান-তথ্যপ্রযুক্তি</h2>
            </NuxtLink>
        </div>
        <div class="flex flex-col gap-4">
            <div class="">
                <NuxtLink to="/" class="grid grid-cols-1 md:grid-cols-2 group gap-2">
                    <div class="intertainment-feature-image overflow-hidden">
                        <nuxt-img
                            src="https://www.dhakaprokash24.com/media/content/images/2023October/SM/gaja-2-20231008122635.jpg"
                            class="mx-auto w-full group-hover:scale-110 duration-300"
                            :placeholder="img('https://www.dhakaprokash24.com/media/common/logo1672518180.png', { height: 300 })" />
                    </div>
                    <div class="intertainment-feature-description flex flex-col gap-1">
                        <h3 class="text-[25px] leading-tight group-hover:text-[#ff0000]">পদ্মা সেতু দিয়ে ছুটবে ট্রেন
                            দক্ষিণাঞ্চলে, উচ্ছ্বসিত সর্বস্তরের মানুষ</h3>
                        <p class="text-md">সব জল্পনা-কল্পনার অবসান ঘটিয়ে গত বছরের ২৬ জুন সকাল ৬টা থেকে স্বপ্নের পদ্মা সেতু
                            দিয়ে যান চলাচল শুরু হয়েছে। বাকি  </p>
                    </div>
                </NuxtLink>
            </div>
            <div class="col-span-12 md:col-span-6">
                <div class="home-intertainment-category-except-post grid grid-cols-2 gap-4">
                    <!-- Loop Item -->
                    <div class="flex flex-col gap-4 group h-sports-excpt">
                        <div class=" col-span-5 overflow-hidden">
                            <NuxtLink to="/">
                                <nuxt-img
                                    src="https://www.dhakaprokash24.com/media/content/images/2023October/SM/gaja-2-20231008122635.jpg"
                                    class="mx-auto w-full group-hover:scale-110 duration-300"
                                    :placeholder="img('https://www.dhakaprokash24.com/media/common/logo1672518180.png', { height: 300 })" />
                            </NuxtLink>
                        </div>
                        <div class=" col-span-7">
                            <NuxtLink to="/">
                                <h4 class="text-[18px] leading-tight group-hover:text-[#ff0000]">শাহজালাল বিমানবন্দরের তৃতীয়
                                    টার্মিনালের আংশিক উদ্বোধন করলেন প্রধানমন্ত্রী</h4>
                            </NuxtLink>
                        </div>
                    </div>
                    <!--/ Loop Item -->
                    <!-- Loop Item -->
                    <div class="flex flex-col gap-4 group h-sports-excpt">
                        <div class=" col-span-5 overflow-hidden">
                            <NuxtLink to="/">
                                <nuxt-img
                                    src="https://www.dhakaprokash24.com/media/content/images/2023October/SM/gaja-2-20231008122635.jpg"
                                    class="mx-auto w-full group-hover:scale-110 duration-300"
                                    :placeholder="img('https://www.dhakaprokash24.com/media/common/logo1672518180.png', { height: 300 })" />
                            </NuxtLink>
                        </div>
                        <div class=" col-span-7">
                            <NuxtLink to="/">
                                <h4 class="text-[18px] leading-tight group-hover:text-[#ff0000]">শাহজালাল বিমানবন্দরের তৃতীয়
                                    টার্মিনালের আংশিক উদ্বোধন করলেন প্রধানমন্ত্রী</h4>
                            </NuxtLink>
                        </div>
                    </div>
                    <!--/ Loop Item -->
                    <!-- Loop Item -->
                    <div class="flex flex-col gap-4 group h-sports-excpt">
                        <div class=" col-span-5 overflow-hidden">
                            <NuxtLink to="/">
                                <nuxt-img
                                    src="https://www.dhakaprokash24.com/media/content/images/2023October/SM/gaja-2-20231008122635.jpg"
                                    class="mx-auto w-full group-hover:scale-110 duration-300"
                                    :placeholder="img('https://www.dhakaprokash24.com/media/common/logo1672518180.png', { height: 300 })" />
                            </NuxtLink>
                        </div>
                        <div class=" col-span-7">
                            <NuxtLink to="/">
                                <h4 class="text-[18px] leading-tight group-hover:text-[#ff0000]">শাহজালাল বিমানবন্দরের তৃতীয়
                                    টার্মিনালের আংশিক উদ্বোধন করলেন প্রধানমন্ত্রী</h4>
                            </NuxtLink>
                        </div>
                    </div>
                    <!--/ Loop Item -->
                    <!-- Loop Item -->
                    <div class="flex flex-col gap-4 group h-sports-excpt">
                        <div class=" col-span-5 overflow-hidden">
                            <NuxtLink to="/">
                                <nuxt-img
                                    src="https://www.dhakaprokash24.com/media/content/images/2023October/SM/gaja-2-20231008122635.jpg"
                                    class="mx-auto w-full group-hover:scale-110 duration-300"
                                    :placeholder="img('https://www.dhakaprokash24.com/media/common/logo1672518180.png', { height: 300 })" />
                            </NuxtLink>
                        </div>
                        <div class=" col-span-7">
                            <NuxtLink to="/">
                                <h4 class="text-[18px] leading-tight group-hover:text-[#ff0000]">শাহজালাল বিমানবন্দরের তৃতীয়
                                    টার্মিনালের আংশিক উদ্বোধন করলেন প্রধানমন্ত্রী</h4>
                            </NuxtLink>
                        </div>
                    </div>
                    <!--/ Loop Item -->

                </div>
            </div>
        </div>
    </div>
</template>

<script setup>
    const img = useImage()
</script>

<style lang="scss" scoped></style>