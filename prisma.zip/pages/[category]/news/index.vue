<template>
    <div>
        <h2>News Page</h2>
    </div>
</template>

<script setup>
   
</script>

<style lang="scss" scoped>

</style>