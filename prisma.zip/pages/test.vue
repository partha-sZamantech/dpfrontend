<template>
    <div>
        <header
            class="bg-[#3375af] sticky top-0 z-50 dark:bg-[color:var(--brand-color)] print:border-none print:static print:!bg-white">
            <div class="max-w-[1280px] px-4 mx-auto print:px-0">
                <div class="flex items-center justify-between">
                    <nav class="flex-nowrap  lg:flex-wrap hidden lg:block print:!hidden">
                        <div class="flex flex-wrap items-center lg:justify-center">
                            <ul class="flex gap-2 whitespace-nowrap lg:overflow-hidden text-white mainmenu">
                                <li>
                                    <NuxtLink to="/"
                                        class=" py-2 px-3 block hover:bg-[#284f81] hover:border-b-2 hover:border-b-white border-b-2 border-b-transparent duration-500">
                                        <Icon name="material-symbols:house-rounded" class="text-xl" />
                                    </NuxtLink>
                                </li>
                                <li class="hover:bg-[#314e5b]  "><a
                                        class="flex items-center gap-1 py-2 px-3 text-lg text-white"
                                        href="/latest-news">সর্বশেষ</a></li>
                                <li class="hover:bg-[#314e5b]  "><a
                                        class="flex items-center gap-1 py-2 px-3 text-lg text-white"
                                        href="/national">জাতীয়</a></li>
                                <li class="hover:bg-[#314e5b]  "><a
                                        class="flex items-center gap-1 py-2 px-3 text-lg text-white"
                                        href="/politics">রাজনীতি</a></li>
                                <li class="hover:bg-[#314e5b]  "><a
                                        class="flex items-center gap-1 py-2 px-3 text-lg text-white"
                                        href="/economy">অর্থনীতি</a></li>
                                <li class="hover:bg-[#314e5b]  "><a
                                        class="flex items-center gap-1 py-2 px-3 text-lg text-white"
                                        href="/international">আন্তর্জাতিক</a></li>

                                <li class="hover:bg-[#314e5b]  lg:hidden xl:block"><a
                                        class="flex items-center gap-1 py-2 px-3 text-lg text-white"
                                        href="/sports">খেলা</a></li>
                                <li class="hover:bg-[#314e5b]  lg:hidden xl:block"><a
                                        class="flex items-center gap-1 py-[11px] px-3 text-lg text-white"
                                        href="/entertainment">বিনোদন</a></li>
                                <li class="hover:bg-[#314e5b]  lg:hidden xl:block"><a
                                        class="flex items-center gap-1 py-[11px] px-3 text-lg text-white"
                                        href="/jobs-career">জবস</a></li>
                            </ul>
                        </div>
                    </nav>
                    <div class="icon flex items-center justify-center print:hidden">
                        <div class="p-3 last:pr-0 hidden md:block"><button class="flex" aria-label="theme">
                                <div class="moon cursor-pointer"><svg xmlns="http://www.w3.org/2000/svg" fill="none"
                                        viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"
                                        class="w-6 h-6 stroke-white">
                                        <path stroke-linecap="round" stroke-linejoin="round"
                                            d="M21.752 15.002A9.718 9.718 0 0118 15.75c-5.385 0-9.75-4.365-9.75-9.75 0-1.33.266-2.597.748-3.752A9.753 9.753 0 003 11.25C3 16.635 7.365 21 12.75 21a9.753 9.753 0 009.002-5.998z">
                                        </path>
                                    </svg></div>
                            </button></div><button class="p-3 last:pr-0" aria-label="notification"><svg
                                xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5"
                                stroke="currentColor" class="w-6 h-6 stroke-white">
                                <path stroke-linecap="round" stroke-linejoin="round"
                                    d="M14.857 17.082a23.848 23.848 0 005.454-1.31A8.967 8.967 0 0118 9.75v-.7V9A6 6 0 006 9v.75a8.967 8.967 0 01-2.312 6.022c1.733.64 3.56 1.085 5.455 1.31m5.714 0a24.255 24.255 0 01-5.714 0m5.714 0a3 3 0 11-5.714 0">
                                </path>
                            </svg></button><button class="p-3 last:pr-0" aria-label="search"><svg
                                xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5"
                                stroke="currentColor" class="w-6 h-6 stroke-white">
                                <path stroke-linecap="round" stroke-linejoin="round"
                                    d="M21 21l-5.197-5.197m0 0A7.5 7.5 0 105.196 5.196a7.5 7.5 0 0010.607 10.607z"></path>
                            </svg></button><button class="p-3 last:pr-0" type="button" aria-label="menu"><svg
                                xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5"
                                stroke="currentColor" class="w-6 h-6 stroke-white">
                                <path stroke-linecap="round" stroke-linejoin="round"
                                    d="M3.75 6.75h16.5M3.75 12h16.5m-16.5 5.25h16.5"></path>
                            </svg></button>
                    </div>
                </div>
            </div>
        </header>
    </div>
</template>

<script setup>

</script>

<style lang="scss" scoped></style>