<template>
    <div class="footer-bottom bg-[#07254b]">
       
        <div class="footer-copyright text-center py-3">
            <p class="copyright text-[#ffffff] text-[14px]">&copy; ২০২৪ সর্বস্বত্ব সংরক্ষিত | ঢাকাপ্রকাশ</p>
        </div>
    </div>
</template>

<script setup>

</script>

<style scoped>
/* .footer-bottom a:after {
    content: '\2022';
    padding-left: 6px;
    padding-top:4px;
    font-size:20px;
    color:#ccc;
} */
/* .copyright:after {
    content: '|';
    padding-left:7px;
    padding-right:7px;
    display:inline-block
} */
/* .footer-bottom a:last-child:after {
    content: ''; 
} */
</style>