<template>
    <div>
        <Head>
            <Title>Ok</Title>
            <!-- <Meta property="og:type" content="website" />
            <Meta property="og:site_name" content="ঢাকা প্রকাশ -খবরের কাগজ" />
            <Meta property="og:url" content="https://www.khaborerkagoj.com/national/791172" />
            <Meta property="og:title" content="লুর চিঠি: ধোঁয়াশায় সংলাপ | খবরের কাগজ" />
            <Meta property="og:description" content=" নির্বাচনের তফসিল ঘোষণার আগে সংলাপের আহ্বান জানিয়ে যুক্তরাষ্ট্রের দেওয়া " /> 
            <Meta property="og:image" content="public/uploads/2023/11/15/1700034640.Dialaugue.jpg"/>
            <Meta name="twitter:card" content="summary_large_image" />
            <Meta name="twitter:title" content="ঢাকা প্রকাশ । বাংলা নিউজ পেপার । অনলাইন ভার্সন" />
            <Meta name="twitter:description" content=" নির্বাচনের তফসিল ঘোষণার আগে সংলাপের আহ্বান জানিয়ে যুক্তরাষ্ট্রের " />
            <Meta property="twitter:image" content="public/uploads/2023/11/15/1700034640.Dialaugue.jpg" />
            <Meta name="twitter:domain" content="https://dhakaprokash24.com" />
            <Meta name="twitter:site" content="@dhakaprokash24" />
            <Meta name="twitter:domain" content="https://dhakaprokash24.com" />
            <Meta name="robots" content="index, follow" />
            <Link rel="canonical" href="post link" /> -->
        </Head>
      

        
    </div>
</template>

<script setup>

</script>

<style lang="scss" scoped>

</style>