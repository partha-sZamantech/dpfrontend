
import { updateAppConfig } from '#app'
import { defuFn } from 'C:/Users/partha.deb/Desktop/NUXTAPP/node_modules/defu/dist/defu.mjs'

const inlineConfig = {
  "nuxt": {
    "buildId": "b37c3b41-816b-4991-af8f-a02d35878ec0"
  }
}

// Vite - webpack is handled directly in #app/config
if (import.meta.hot) {
  import.meta.hot.accept((newModule) => {
    updateAppConfig(newModule.default)
  })
}



export default /* #__PURE__ */ defuFn(inlineConfig)
