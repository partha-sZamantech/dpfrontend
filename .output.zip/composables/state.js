
export const desktopMenuState = () => {
    return useState(()=> false)
}

export const globalPopupState = () => {
    return useState(() => false)
}

export const allCategoryState = () => {
    return useState(() => [])
}
export const specialTopContentState = () => {
    return useState(() => [])
}

export const NationalHomeContentState = () => {
    return useState(() => [])
}

export const singlePageStickyState = () => {
    return useState(() => false)
}

export const siteUrlState = () => {
    return useState(() => ({
        site_url: 'https://dhakaprokash24.com'
    }))
}
export const websiteUrlState = () => {
    return useState(() => ({
        website_url: 'https://newtest.dhakaprokash24.com'
    }))
}


