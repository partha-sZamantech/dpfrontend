import{_ as e,c,o}from"./entry.4662ce49.js";const t={};function _(n,r){return o(),c("div",null," album ")}const s=e(t,[["render",_]]);export{s as default};
