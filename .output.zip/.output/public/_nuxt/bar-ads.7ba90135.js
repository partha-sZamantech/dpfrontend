import"./entry.4662ce49.js";const i=""+globalThis.__publicAssetsURL("assets/img/bar-ads.gif");export{i as _};
