import { d as defineEventHandler, u as useRuntimeConfig } from './nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'ipx';

const specialarticle_get = defineEventHandler(async (event) => {
  const config = useRuntimeConfig();
  const data = await $fetch(`${config.public.apiUrl}/api/specialarticlecontent`, {
    method: "GET"
  });
  return data;
});

export { specialarticle_get as default };
//# sourceMappingURL=specialarticle.get.mjs.map
