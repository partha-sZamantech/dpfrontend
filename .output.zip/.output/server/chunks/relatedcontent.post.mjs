import { d as defineEventHandler, u as useRuntimeConfig, r as readBody } from './nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'ipx';

const relatedcontent_post = defineEventHandler(async (event) => {
  const config = useRuntimeConfig();
  const getBody = await readBody(event);
  const data = await $fetch(`${config.public.apiUrl}/api/relatedcontdetl`, {
    method: "POST",
    body: {
      readedIds: getBody == null ? void 0 : getBody.readedIds,
      detailId: getBody == null ? void 0 : getBody.detailId
    }
  });
  return data;
});

export { relatedcontent_post as default };
//# sourceMappingURL=relatedcontent.post.mjs.map
