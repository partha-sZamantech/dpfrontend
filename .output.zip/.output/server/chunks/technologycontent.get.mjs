import { d as defineEventHandler, u as useRuntimeConfig } from './nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'ipx';

const technologycontent_get = defineEventHandler(async (event) => {
  const config = useRuntimeConfig();
  const data = await $fetch(`${config.public.apiUrl}/api/technologycontent`, {
    method: "GET"
  });
  return data;
});

export { technologycontent_get as default };
//# sourceMappingURL=technologycontent.get.mjs.map
