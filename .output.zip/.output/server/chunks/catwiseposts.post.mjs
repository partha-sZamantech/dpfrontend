import { d as defineEventHandler, u as useRuntimeConfig, r as readBody } from './nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'ipx';

const catwiseposts_post = defineEventHandler(async (event) => {
  const config = useRuntimeConfig();
  const getBody = await readBody(event);
  const data = await $fetch(`${config.public.apiUrl}/api/dtpost/catws/${getBody.cat_id}/${getBody.content_id}`, {
    method: "get"
  });
  return data;
});

export { catwiseposts_post as default };
//# sourceMappingURL=catwiseposts.post.mjs.map
