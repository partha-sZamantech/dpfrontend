import { d as defineEventHandler, u as useRuntimeConfig, r as readBody } from './nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'ipx';

const getads_post = defineEventHandler(async (event) => {
  const config = useRuntimeConfig();
  const getBody = await readBody(event);
  const data = await $fetch(`${config.public.apiUrl}/api/common/get/ads`, {
    method: "POST",
    body: {
      page: getBody == null ? void 0 : getBody.page,
      position: getBody == null ? void 0 : getBody.position
    }
  });
  return data;
});

export { getads_post as default };
//# sourceMappingURL=getads.post.mjs.map
