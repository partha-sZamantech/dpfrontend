import { d as defineEventHandler, u as useRuntimeConfig, r as readBody } from './nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'ipx';

const subcatcontent_post = defineEventHandler(async (event) => {
  const config = useRuntimeConfig();
  const getBody = await readBody(event);
  const data = await $fetch(`${config.public.apiUrl}/api/subcategorycontent/${getBody == null ? void 0 : getBody.cat_slug}/${getBody == null ? void 0 : getBody.subcat_slug}/${getBody == null ? void 0 : getBody.take}`, {
    method: "GET"
  });
  return data;
});

export { subcatcontent_post as default };
//# sourceMappingURL=subcatcontent.post.mjs.map
