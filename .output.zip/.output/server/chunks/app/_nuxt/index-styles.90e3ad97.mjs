const index_vue_vue_type_style_index_0_scoped_45f2cca3_lang = '.subcategory .subcategoryLink[data-v-45f2cca3]:not(:last-child):after{background:#3375af;border-radius:100%;content:"";display:inline-block;height:7px;margin-bottom:3px;margin-left:10px;width:7px}.cat-box[data-v-45f2cca3]:last-child{border-right:0!important}.lead-overly[data-v-45f2cca3]{background:linear-gradient(180deg,hsla(0,0%,100%,0) 0,rgba(53,50,50,.9) 75%,#000)}';

const indexStyles_90e3ad97 = [index_vue_vue_type_style_index_0_scoped_45f2cca3_lang, index_vue_vue_type_style_index_0_scoped_45f2cca3_lang];

export { indexStyles_90e3ad97 as default };
//# sourceMappingURL=index-styles.90e3ad97.mjs.map
