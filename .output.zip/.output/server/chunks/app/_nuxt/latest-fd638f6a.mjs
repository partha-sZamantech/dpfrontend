import { H as Head, T as Title } from './components-5bc40629.mjs';
import { _ as __nuxt_component_0 } from './nuxt-link-c659c711.mjs';
import { u as useImage, s as siteUrlState, a as singlePageStickyState, b as useFetch, _ as __nuxt_component_1 } from './state-7a7e2860.mjs';
import { _ as __nuxt_component_4 } from './client-only-0841c2aa.mjs';
import { _ as __nuxt_component_6 } from './Tabs-8fde547c.mjs';
import { computed, ref, withAsyncContext, mergeProps, withCtx, createTextVNode, createVNode, unref, toDisplayString, useSSRContext } from 'vue';
import { u as useState } from './state-b54abad0.mjs';
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderAttr, ssrInterpolate, ssrRenderList } from 'vue/server-renderer';
import { _ as _imports_0 } from './bar-ads-359c1719.mjs';
import { _ as _export_sfc } from '../server.mjs';
import './index-6a088328.mjs';
import '@unhead/shared';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'ipx';
import '../../handlers/renderer.mjs';
import 'vue-bundle-renderer/runtime';
import 'devalue';
import '@unhead/ssr';
import 'unhead';
import 'vue-router';

const _sfc_main = {
  __name: "latest",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    const getDate = new Intl.DateTimeFormat("bn-bd", { year: "numeric", month: "long", day: "numeric", hour: "numeric", minute: "numeric" });
    const postCreatedDate = (date) => {
      if (date) {
        return getDate.format(new Date(date)).replace("\u098F", "|").replace("PM", "\u09AA\u09BF\u098F\u09AE").replace("AM", "\u098F\u098F\u09AE");
      }
    };
    const img = useImage();
    const siteurl = siteUrlState();
    const singlePageSticky = singlePageStickyState();
    const stickyScroll = computed(
      () => singlePageSticky.value
    );
    const latestPosts = useState(() => [], "$HfxJB8WoIV");
    const latestPostContentExcept = useState(() => [], "$vg96BejtBP");
    const take = ref(15);
    const { data: lcpt } = ([__temp, __restore] = withAsyncContext(() => useFetch("/api/collection/latestpost", {
      method: "POST",
      body: {
        take: take.value
      }
    }, "$OyZpTP8pMw")), __temp = await __temp, __restore(), __temp);
    latestPosts.value = lcpt;
    latestPostContentExcept.value = lcpt.value.slice(5, take.value);
    return (_ctx, _push, _parent, _attrs) => {
      var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j, _k, _l, _m, _n, _o, _p;
      const _component_Head = Head;
      const _component_Title = Title;
      const _component_NuxtLink = __nuxt_component_0;
      const _component_nuxt_img = __nuxt_component_1;
      const _component_ClientOnly = __nuxt_component_4;
      const _component_Tabs = __nuxt_component_6;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "category-page" }, _attrs))} data-v-2438688d>`);
      _push(ssrRenderComponent(_component_Head, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_Title, null, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`\u0986\u099C\u0995\u09C7\u09B0 \u0996\u09AC\u09B0, \u0986\u09AA\u09A1\u09C7\u099F \u09A8\u09BF\u0989\u099C`);
                } else {
                  return [
                    createTextVNode("\u0986\u099C\u0995\u09C7\u09B0 \u0996\u09AC\u09B0, \u0986\u09AA\u09A1\u09C7\u099F \u09A8\u09BF\u0989\u099C")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_Title, null, {
                default: withCtx(() => [
                  createTextVNode("\u0986\u099C\u0995\u09C7\u09B0 \u0996\u09AC\u09B0, \u0986\u09AA\u09A1\u09C7\u099F \u09A8\u09BF\u0989\u099C")
                ]),
                _: 1
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<div class="category-ads-section border-b border-b-[#dee2e6] py-4" data-v-2438688d><div class="bg-[#f7f7f7]" data-v-2438688d><a target="_blank" href="/" data-v-2438688d><img class="mx-auto"${ssrRenderAttr("src", _imports_0)} alt="" data-v-2438688d></a></div></div><div class="max-w-[1280px] mx-auto category-content px-4 md:px-2 py-4 relative" data-v-2438688d><div class="breadcrump border-b border-b-[#dee2e6] pb-2 mb-5 flex flex-col gap-2 md:gap-4" data-v-2438688d><div class="flex gap-1 justify-start items-center" data-v-2438688d>`);
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: `/collection/latest`,
        class: "text-[#3375af] font-semibold"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<h1 class="text-xl md:text-3xl" data-v-2438688d${_scopeId}>\u09B8\u09B0\u09CD\u09AC\u09B6\u09C7\u09B7 \u0996\u09AC\u09B0</h1>`);
          } else {
            return [
              createVNode("h1", { class: "text-xl md:text-3xl" }, "\u09B8\u09B0\u09CD\u09AC\u09B6\u09C7\u09B7 \u0996\u09AC\u09B0")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div><div class="grid grid-cols-12 gap-8 md:gap-3" data-v-2438688d><div class="col-span-12 md:col-span-9 md:border-r md:pr-3" data-v-2438688d><div class="grid grid-cols-12 border-b border-b-[#dee2e6] pb-4" data-v-2438688d><div class="col-span-12 md:col-span-8 md:pr-3 mb-1 md:mb-0" data-v-2438688d><div class="lead-post md:h-[328px] group overflow-hidden" data-v-2438688d>`);
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: `/category/${(_b = (_a = unref(latestPosts)[0]) == null ? void 0 : _a.category) == null ? void 0 : _b.cat_slug}/${(_c = unref(latestPosts)[0]) == null ? void 0 : _c.content_id}`,
        class: "relative"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          var _a2, _b2, _c2, _d2;
          if (_push2) {
            _push2(ssrRenderComponent(_component_nuxt_img, {
              src: `${unref(siteurl).site_url}/media/content/images/${(_a2 = unref(latestPosts)[0]) == null ? void 0 : _a2.img_bg_path}`,
              class: "mx-auto w-full group-hover:scale-110 duration-300 md:h-full",
              placeholder: unref(img)(`${unref(siteurl).site_url}/logo/placeholder.jpg`)
            }, null, _parent2, _scopeId));
            _push2(`<div class="lead-overly absolute h-full w-full block top-0" data-v-2438688d${_scopeId}><h5 class="img-title leading-8 text-white group-hover:text-[#ff0000] text-[18px] md:text-[24px] absolute bottom-4 left-6" data-v-2438688d${_scopeId}>${ssrInterpolate((_b2 = unref(latestPosts)[0]) == null ? void 0 : _b2.content_heading)}</h5></div>`);
          } else {
            return [
              createVNode(_component_nuxt_img, {
                src: `${unref(siteurl).site_url}/media/content/images/${(_c2 = unref(latestPosts)[0]) == null ? void 0 : _c2.img_bg_path}`,
                class: "mx-auto w-full group-hover:scale-110 duration-300 md:h-full",
                placeholder: unref(img)(`${unref(siteurl).site_url}/logo/placeholder.jpg`)
              }, null, 8, ["src", "placeholder"]),
              createVNode("div", { class: "lead-overly absolute h-full w-full block top-0" }, [
                createVNode("h5", { class: "img-title leading-8 text-white group-hover:text-[#ff0000] text-[18px] md:text-[24px] absolute bottom-4 left-6" }, toDisplayString((_d2 = unref(latestPosts)[0]) == null ? void 0 : _d2.content_heading), 1)
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div>`);
      if (unref(latestPosts)[1]) {
        _push(`<div class="col-span-12 md:col-span-4 border-t mt-2 md:mt-0 pt-3 md:pt-0 md:border-t-0 md:pl-3 md:border-l border-l-[#dee2e6]" data-v-2438688d>`);
        _push(ssrRenderComponent(_component_NuxtLink, {
          to: `/category/${(_e = (_d = unref(latestPosts)[1]) == null ? void 0 : _d.category) == null ? void 0 : _e.cat_slug}/${(_f = unref(latestPosts)[1]) == null ? void 0 : _f.content_id}`,
          class: "categorypost-2 group"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            var _a2, _b2, _c2, _d2, _e2, _f2;
            if (_push2) {
              _push2(`<div class="cat-feature-image overflow-hidden" data-v-2438688d${_scopeId}>`);
              _push2(ssrRenderComponent(_component_nuxt_img, {
                src: `${unref(siteurl).site_url}/media/content/images/${(_a2 = unref(latestPosts)[1]) == null ? void 0 : _a2.img_bg_path}`,
                class: "mx-auto w-full group-hover:scale-110 duration-300 h-full",
                placeholder: unref(img)(`${unref(siteurl).site_url}/logo/placeholder.jpg`)
              }, null, _parent2, _scopeId));
              _push2(`</div><div class="flex flex-col gap-3 mt-2" data-v-2438688d${_scopeId}><h3 class="cat-postheading text-xl group-hover:text-[#ff0000] leading-[24px] text-[#121212]" data-v-2438688d${_scopeId}>${ssrInterpolate((_b2 = unref(latestPosts)[1]) == null ? void 0 : _b2.content_heading)}</h3>`);
              _push2(ssrRenderComponent(_component_ClientOnly, null, {}, _parent2, _scopeId));
              _push2(`<small class="cat-postdate" data-v-2438688d${_scopeId}> \u09AA\u09CD\u09B0\u0995\u09BE\u09B6: ${ssrInterpolate(postCreatedDate((_c2 = unref(latestPosts)[1]) == null ? void 0 : _c2.created_at))}</small></div>`);
            } else {
              return [
                createVNode("div", { class: "cat-feature-image overflow-hidden" }, [
                  createVNode(_component_nuxt_img, {
                    src: `${unref(siteurl).site_url}/media/content/images/${(_d2 = unref(latestPosts)[1]) == null ? void 0 : _d2.img_bg_path}`,
                    class: "mx-auto w-full group-hover:scale-110 duration-300 h-full",
                    placeholder: unref(img)(`${unref(siteurl).site_url}/logo/placeholder.jpg`)
                  }, null, 8, ["src", "placeholder"])
                ]),
                createVNode("div", { class: "flex flex-col gap-3 mt-2" }, [
                  createVNode("h3", { class: "cat-postheading text-xl group-hover:text-[#ff0000] leading-[24px] text-[#121212]" }, toDisplayString((_e2 = unref(latestPosts)[1]) == null ? void 0 : _e2.content_heading), 1),
                  createVNode(_component_ClientOnly, null, {
                    default: withCtx(() => {
                      var _a3;
                      return [
                        createVNode("div", {
                          class: "cat-postdesc text-[15px] font-[300] text-[#555555]",
                          innerHTML: `${(_a3 = unref(latestPosts)[1]) == null ? void 0 : _a3.content_details.substring(0, 155)}...`
                        }, null, 8, ["innerHTML"])
                      ];
                    }),
                    _: 1
                  }),
                  createVNode("small", { class: "cat-postdate" }, " \u09AA\u09CD\u09B0\u0995\u09BE\u09B6: " + toDisplayString(postCreatedDate((_f2 = unref(latestPosts)[1]) == null ? void 0 : _f2.created_at)), 1)
                ])
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div>`);
      if (unref(latestPosts)[2]) {
        _push(`<div class="grid grid-cols-12 gap-4 md:gap-0 py-4 border-b border-b-[#dee2e6]" data-v-2438688d>`);
        _push(ssrRenderComponent(_component_NuxtLink, {
          to: `/category/${(_h = (_g = unref(latestPosts)[2]) == null ? void 0 : _g.category) == null ? void 0 : _h.cat_slug}/${(_i = unref(latestPosts)[2]) == null ? void 0 : _i.content_id}`,
          class: "cat-box group md:pr-3 md:border-r border-r-[#dee2e6] col-span-12 md:col-span-4"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            var _a2, _b2, _c2, _d2, _e2, _f2;
            if (_push2) {
              _push2(`<div class="cat-box-image overflow-hidden" data-v-2438688d${_scopeId}>`);
              _push2(ssrRenderComponent(_component_nuxt_img, {
                src: `${unref(siteurl).site_url}/media/content/images/${(_a2 = unref(latestPosts)[2]) == null ? void 0 : _a2.img_bg_path}`,
                class: "mx-auto w-full group-hover:scale-110 duration-300 h-full",
                placeholder: unref(img)(`${unref(siteurl).site_url}/logo/placeholder.jpg`)
              }, null, _parent2, _scopeId));
              _push2(`</div><div class="flex flex-col gap-3 mt-2" data-v-2438688d${_scopeId}><h3 class="cat-postheading text-xl group-hover:text-[#ff0000] leading-[24px] text-[#121212]" data-v-2438688d${_scopeId}>${ssrInterpolate((_b2 = unref(latestPosts)[2]) == null ? void 0 : _b2.content_heading)}</h3>`);
              _push2(ssrRenderComponent(_component_ClientOnly, null, {}, _parent2, _scopeId));
              _push2(`<small class="cat-postdate" data-v-2438688d${_scopeId}> \u09AA\u09CD\u09B0\u0995\u09BE\u09B6: ${ssrInterpolate(postCreatedDate((_c2 = unref(latestPosts)[2]) == null ? void 0 : _c2.created_at))}</small></div>`);
            } else {
              return [
                createVNode("div", { class: "cat-box-image overflow-hidden" }, [
                  createVNode(_component_nuxt_img, {
                    src: `${unref(siteurl).site_url}/media/content/images/${(_d2 = unref(latestPosts)[2]) == null ? void 0 : _d2.img_bg_path}`,
                    class: "mx-auto w-full group-hover:scale-110 duration-300 h-full",
                    placeholder: unref(img)(`${unref(siteurl).site_url}/logo/placeholder.jpg`)
                  }, null, 8, ["src", "placeholder"])
                ]),
                createVNode("div", { class: "flex flex-col gap-3 mt-2" }, [
                  createVNode("h3", { class: "cat-postheading text-xl group-hover:text-[#ff0000] leading-[24px] text-[#121212]" }, toDisplayString((_e2 = unref(latestPosts)[2]) == null ? void 0 : _e2.content_heading), 1),
                  createVNode(_component_ClientOnly, null, {
                    default: withCtx(() => {
                      var _a3;
                      return [
                        createVNode("div", {
                          class: "cat-postdesc text-[15px] font-[300] text-[#555555]",
                          innerHTML: `${(_a3 = unref(latestPosts)[2]) == null ? void 0 : _a3.content_details.substring(0, 155)}...`
                        }, null, 8, ["innerHTML"])
                      ];
                    }),
                    _: 1
                  }),
                  createVNode("small", { class: "cat-postdate" }, " \u09AA\u09CD\u09B0\u0995\u09BE\u09B6: " + toDisplayString(postCreatedDate((_f2 = unref(latestPosts)[2]) == null ? void 0 : _f2.created_at)), 1)
                ])
              ];
            }
          }),
          _: 1
        }, _parent));
        if (unref(latestPosts)[3]) {
          _push(ssrRenderComponent(_component_NuxtLink, {
            to: `/category/${(_k = (_j = unref(latestPosts)[3]) == null ? void 0 : _j.category) == null ? void 0 : _k.cat_slug}/${(_l = unref(latestPosts)[3]) == null ? void 0 : _l.content_id}`,
            class: "cat-box group md:px-3 md:border-r border-r-[#dee2e6] col-span-12 md:col-span-4"
          }, {
            default: withCtx((_, _push2, _parent2, _scopeId) => {
              var _a2, _b2, _c2, _d2, _e2, _f2;
              if (_push2) {
                _push2(`<div class="cat-box-image overflow-hidden" data-v-2438688d${_scopeId}>`);
                _push2(ssrRenderComponent(_component_nuxt_img, {
                  src: `${unref(siteurl).site_url}/media/content/images/${(_a2 = unref(latestPosts)[3]) == null ? void 0 : _a2.img_bg_path}`,
                  class: "mx-auto w-full group-hover:scale-110 duration-300 h-full",
                  placeholder: unref(img)(`${unref(siteurl).site_url}/logo/placeholder.jpg`)
                }, null, _parent2, _scopeId));
                _push2(`</div><div class="flex flex-col gap-3 mt-2" data-v-2438688d${_scopeId}><h3 class="cat-postheading text-xl group-hover:text-[#ff0000] leading-[24px] text-[#121212]" data-v-2438688d${_scopeId}>${ssrInterpolate((_b2 = unref(latestPosts)[3]) == null ? void 0 : _b2.content_heading)}</h3>`);
                _push2(ssrRenderComponent(_component_ClientOnly, null, {}, _parent2, _scopeId));
                _push2(`<small class="cat-postdate" data-v-2438688d${_scopeId}> \u09AA\u09CD\u09B0\u0995\u09BE\u09B6: ${ssrInterpolate(postCreatedDate((_c2 = unref(latestPosts)[3]) == null ? void 0 : _c2.created_at))}</small></div>`);
              } else {
                return [
                  createVNode("div", { class: "cat-box-image overflow-hidden" }, [
                    createVNode(_component_nuxt_img, {
                      src: `${unref(siteurl).site_url}/media/content/images/${(_d2 = unref(latestPosts)[3]) == null ? void 0 : _d2.img_bg_path}`,
                      class: "mx-auto w-full group-hover:scale-110 duration-300 h-full",
                      placeholder: unref(img)(`${unref(siteurl).site_url}/logo/placeholder.jpg`)
                    }, null, 8, ["src", "placeholder"])
                  ]),
                  createVNode("div", { class: "flex flex-col gap-3 mt-2" }, [
                    createVNode("h3", { class: "cat-postheading text-xl group-hover:text-[#ff0000] leading-[24px] text-[#121212]" }, toDisplayString((_e2 = unref(latestPosts)[3]) == null ? void 0 : _e2.content_heading), 1),
                    createVNode(_component_ClientOnly, null, {
                      default: withCtx(() => {
                        var _a3;
                        return [
                          createVNode("div", {
                            class: "cat-postdesc text-[15px] font-[300] text-[#555555]",
                            innerHTML: `${(_a3 = unref(latestPosts)[3]) == null ? void 0 : _a3.content_details.substring(0, 155)}...`
                          }, null, 8, ["innerHTML"])
                        ];
                      }),
                      _: 1
                    }),
                    createVNode("small", { class: "cat-postdate" }, " \u09AA\u09CD\u09B0\u0995\u09BE\u09B6: " + toDisplayString(postCreatedDate((_f2 = unref(latestPosts)[3]) == null ? void 0 : _f2.created_at)), 1)
                  ])
                ];
              }
            }),
            _: 1
          }, _parent));
        } else {
          _push(`<!---->`);
        }
        if (unref(latestPosts)[4]) {
          _push(ssrRenderComponent(_component_NuxtLink, {
            to: `/category/${(_n = (_m = unref(latestPosts)[4]) == null ? void 0 : _m.category) == null ? void 0 : _n.cat_slug}/${(_o = unref(latestPosts)[4]) == null ? void 0 : _o.content_id}`,
            class: "cat-box group md:pl-3 col-span-12 md:col-span-4"
          }, {
            default: withCtx((_, _push2, _parent2, _scopeId) => {
              var _a2, _b2, _c2, _d2, _e2, _f2;
              if (_push2) {
                _push2(`<div class="cat-box-image overflow-hidden" data-v-2438688d${_scopeId}>`);
                _push2(ssrRenderComponent(_component_nuxt_img, {
                  src: `${unref(siteurl).site_url}/media/content/images/${(_a2 = unref(latestPosts)[4]) == null ? void 0 : _a2.img_bg_path}`,
                  class: "mx-auto w-full group-hover:scale-110 duration-300 h-full",
                  placeholder: unref(img)(`${unref(siteurl).site_url}/logo/placeholder.jpg`)
                }, null, _parent2, _scopeId));
                _push2(`</div><div class="flex flex-col gap-3 mt-2" data-v-2438688d${_scopeId}><h3 class="cat-postheading text-xl group-hover:text-[#ff0000] leading-[24px] text-[#121212]" data-v-2438688d${_scopeId}>${ssrInterpolate((_b2 = unref(latestPosts)[4]) == null ? void 0 : _b2.content_heading)}</h3>`);
                _push2(ssrRenderComponent(_component_ClientOnly, null, {}, _parent2, _scopeId));
                _push2(`<small class="cat-postdate" data-v-2438688d${_scopeId}> \u09AA\u09CD\u09B0\u0995\u09BE\u09B6: ${ssrInterpolate(postCreatedDate((_c2 = unref(latestPosts)[4]) == null ? void 0 : _c2.created_at))}</small></div>`);
              } else {
                return [
                  createVNode("div", { class: "cat-box-image overflow-hidden" }, [
                    createVNode(_component_nuxt_img, {
                      src: `${unref(siteurl).site_url}/media/content/images/${(_d2 = unref(latestPosts)[4]) == null ? void 0 : _d2.img_bg_path}`,
                      class: "mx-auto w-full group-hover:scale-110 duration-300 h-full",
                      placeholder: unref(img)(`${unref(siteurl).site_url}/logo/placeholder.jpg`)
                    }, null, 8, ["src", "placeholder"])
                  ]),
                  createVNode("div", { class: "flex flex-col gap-3 mt-2" }, [
                    createVNode("h3", { class: "cat-postheading text-xl group-hover:text-[#ff0000] leading-[24px] text-[#121212]" }, toDisplayString((_e2 = unref(latestPosts)[4]) == null ? void 0 : _e2.content_heading), 1),
                    createVNode(_component_ClientOnly, null, {
                      default: withCtx(() => {
                        var _a3;
                        return [
                          createVNode("div", {
                            class: "cat-postdesc text-[15px] font-[300] text-[#555555]",
                            innerHTML: `${(_a3 = unref(latestPosts)[4]) == null ? void 0 : _a3.content_details.substring(0, 155)}...`
                          }, null, 8, ["innerHTML"])
                        ];
                      }),
                      _: 1
                    }),
                    createVNode("small", { class: "cat-postdate" }, " \u09AA\u09CD\u09B0\u0995\u09BE\u09B6: " + toDisplayString(postCreatedDate((_f2 = unref(latestPosts)[4]) == null ? void 0 : _f2.created_at)), 1)
                  ])
                ];
              }
            }),
            _: 1
          }, _parent));
        } else {
          _push(`<!---->`);
        }
        _push(`<div class="col-span-12 cat-inside-ads" data-v-2438688d>`);
        _push(ssrRenderComponent(_component_NuxtLink, { to: "/" }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(ssrRenderComponent(_component_nuxt_img, {
                src: `/assets/img/cat-ads.gif`,
                class: "mx-auto w-full group-hover:scale-110 duration-300 px-2 mt-6 mb-2",
                placeholder: unref(img)(`${unref(siteurl).site_url}/logo/placeholder.jpg`)
              }, null, _parent2, _scopeId));
            } else {
              return [
                createVNode(_component_nuxt_img, {
                  src: `/assets/img/cat-ads.gif`,
                  class: "mx-auto w-full group-hover:scale-110 duration-300 px-2 mt-6 mb-2",
                  placeholder: unref(img)(`${unref(siteurl).site_url}/logo/placeholder.jpg`)
                }, null, 8, ["src", "placeholder"])
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(`</div></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<div class="category-post-list grid grid-cols-12 mt-4" data-v-2438688d><div class="col-span-2 hidden md:block" data-v-2438688d></div><div class="col-span-12 md:col-span-8" data-v-2438688d><!--[-->`);
      ssrRenderList(unref(latestPostContentExcept), (latestPost, cpInx) => {
        var _a2;
        _push(`<div class="cat-post-item py-4 border-b" data-v-2438688d>`);
        _push(ssrRenderComponent(_component_NuxtLink, {
          to: `/category/${(_a2 = latestPost == null ? void 0 : latestPost.category) == null ? void 0 : _a2.cat_slug}/${latestPost == null ? void 0 : latestPost.content_id}`,
          class: "grid grid-cols-12 gap-3 group"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<h3 class="cat-title col-span-12 text-[20px] group-hover:text-[#ff0000]" data-v-2438688d${_scopeId}>${ssrInterpolate(latestPost == null ? void 0 : latestPost.content_heading)}</h3><div class="col-span-7 flex flex-col gap-3" data-v-2438688d${_scopeId}>`);
              _push2(ssrRenderComponent(_component_ClientOnly, null, {}, _parent2, _scopeId));
              _push2(`<span class="post-date flex flex-col gap-1" data-v-2438688d${_scopeId}><small class="text-[#555555]" data-v-2438688d${_scopeId}>\u0986\u09AA\u09A1\u09C7\u099F: ${ssrInterpolate(postCreatedDate(latestPost == null ? void 0 : latestPost.updated_at))}</small><small class="text-[#555555]" data-v-2438688d${_scopeId}>\u09AA\u09CD\u09B0\u0995\u09BE\u09B6: ${ssrInterpolate(postCreatedDate(latestPost == null ? void 0 : latestPost.created_at))}</small></span></div><div class="col-span-5 category-post-image overflow-hidden" data-v-2438688d${_scopeId}>`);
              _push2(ssrRenderComponent(_component_nuxt_img, {
                src: `${unref(siteurl).site_url}/media/content/images/${latestPost == null ? void 0 : latestPost.img_bg_path}`,
                class: "mx-auto w-full group-hover:scale-110 duration-300",
                placeholder: unref(img)(`${unref(siteurl).site_url}/logo/placeholder.jpg`)
              }, null, _parent2, _scopeId));
              _push2(`</div>`);
            } else {
              return [
                createVNode("h3", { class: "cat-title col-span-12 text-[20px] group-hover:text-[#ff0000]" }, toDisplayString(latestPost == null ? void 0 : latestPost.content_heading), 1),
                createVNode("div", { class: "col-span-7 flex flex-col gap-3" }, [
                  createVNode(_component_ClientOnly, null, {
                    default: withCtx(() => [
                      createVNode("div", {
                        class: "cat-desc text-[#555555] text-[15px] font-[300]",
                        innerHTML: `${latestPost == null ? void 0 : latestPost.content_details.substring(0, 160)}...`
                      }, null, 8, ["innerHTML"])
                    ]),
                    _: 2
                  }, 1024),
                  createVNode("span", { class: "post-date flex flex-col gap-1" }, [
                    createVNode("small", { class: "text-[#555555]" }, "\u0986\u09AA\u09A1\u09C7\u099F: " + toDisplayString(postCreatedDate(latestPost == null ? void 0 : latestPost.updated_at)), 1),
                    createVNode("small", { class: "text-[#555555]" }, "\u09AA\u09CD\u09B0\u0995\u09BE\u09B6: " + toDisplayString(postCreatedDate(latestPost == null ? void 0 : latestPost.created_at)), 1)
                  ])
                ]),
                createVNode("div", { class: "col-span-5 category-post-image overflow-hidden" }, [
                  createVNode(_component_nuxt_img, {
                    src: `${unref(siteurl).site_url}/media/content/images/${latestPost == null ? void 0 : latestPost.img_bg_path}`,
                    class: "mx-auto w-full group-hover:scale-110 duration-300",
                    placeholder: unref(img)(`${unref(siteurl).site_url}/logo/placeholder.jpg`)
                  }, null, 8, ["src", "placeholder"])
                ])
              ];
            }
          }),
          _: 2
        }, _parent));
        _push(`</div>`);
      });
      _push(`<!--]--></div><div class="col-span-2 hidden md:block" data-v-2438688d></div></div>`);
      if (((_p = unref(latestPosts)) == null ? void 0 : _p.length) > 10) {
        _push(`<div class="flex justify-center items-center" data-v-2438688d><button class="border border-[#dee2e6] text-[#3375af] px-8 py-2 rounded-sm mt-5 hover:border-[#3375af]" data-v-2438688d><b data-v-2438688d>\u0986\u09B0\u0993</b></button></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div><div class="col-span-12 md:col-span-3" data-v-2438688d>`);
      _push(ssrRenderComponent(_component_Tabs, {
        class: `sticky ${unref(stickyScroll) ? " top-44" : "top-16"}`
      }, null, _parent));
      _push(`</div></div></div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/collection/latest.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const latest = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-2438688d"]]);

export { latest as default };
//# sourceMappingURL=latest-fd638f6a.mjs.map
