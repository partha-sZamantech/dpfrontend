const SpecialTopContent_vue_vue_type_style_index_0_scoped_f61f79a4_lang = ".specialMiddleTop[data-v-f61f79a4]:first-child{padding-top:0}";

const National_vue_vue_type_style_index_0_scoped_d4eaa86f_lang = ".h-national-excpt[data-v-d4eaa86f]:first-child{padding-top:0}";

const PostTabs_vue_vue_type_style_index_0_scoped_038bdf36_lang = "[data-v-038bdf36]::-webkit-scrollbar{width:5px}[data-v-038bdf36]::-webkit-scrollbar-track{background:#ddd}[data-v-038bdf36]::-webkit-scrollbar-thumb{background:#3375af;border-radius:5px}[data-v-038bdf36]::-webkit-scrollbar-thumb:hover{background:#bdb8b8}";

const Sports_vue_vue_type_style_index_0_scoped_ed66a8e6_lang = ".h-sports-excpt[data-v-ed66a8e6]:first-child{padding-top:0}";

const Saradesh_vue_vue_type_style_index_0_scoped_1a894a04_lang = ".h-sports-excpt[data-v-1a894a04]:first-child{padding-top:0}";

const Entertainment_vue_vue_type_style_index_0_scoped_b118b580_lang = ".h-sports-excpt[data-v-b118b580]:first-child{padding-top:0}";

const Lifestyle_vue_vue_type_style_index_0_scoped_54d51d37_lang = ".h-sports-excpt[data-v-54d51d37]:first-child{padding-top:0}";

const LawCourt_vue_vue_type_style_index_0_scoped_e5354911_lang = ".h-sports-excpt[data-v-e5354911]:first-child{padding-top:0}";

const Crime_vue_vue_type_style_index_0_scoped_7db8be11_lang = ".h-sports-excpt[data-v-7db8be11]:first-child{padding-top:0}";

const Gallery_vue_vue_type_style_index_0_scoped_0c12ec66_lang = ".overlay[data-v-0c12ec66]{background:linear-gradient(180deg,hsla(0,0%,100%,0) 40%,rgba(0,0,0,.7) 70%,#000);display:block;height:100%;opacity:.9;position:absolute;top:0;width:100%}.img-title[data-v-0c12ec66]{bottom:10px;color:#fff;margin-left:5%;margin-right:5%;position:absolute}.image-box:hover .overlay[data-v-0c12ec66]{background:linear-gradient(180deg,hsla(0,0%,100%,0) 40%,hsla(0,0%,100%,.5) 70%,#fff)}";

const indexStyles_74e64ad9 = [SpecialTopContent_vue_vue_type_style_index_0_scoped_f61f79a4_lang, National_vue_vue_type_style_index_0_scoped_d4eaa86f_lang, PostTabs_vue_vue_type_style_index_0_scoped_038bdf36_lang, Sports_vue_vue_type_style_index_0_scoped_ed66a8e6_lang, Saradesh_vue_vue_type_style_index_0_scoped_1a894a04_lang, Entertainment_vue_vue_type_style_index_0_scoped_b118b580_lang, Lifestyle_vue_vue_type_style_index_0_scoped_54d51d37_lang, LawCourt_vue_vue_type_style_index_0_scoped_e5354911_lang, Crime_vue_vue_type_style_index_0_scoped_7db8be11_lang, Gallery_vue_vue_type_style_index_0_scoped_0c12ec66_lang];

export { indexStyles_74e64ad9 as default };
//# sourceMappingURL=index-styles.74e64ad9.mjs.map
