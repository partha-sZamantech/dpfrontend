import { H as Head, T as Title, M as Meta, L as Link } from './components-5bc40629.mjs';
import { _ as __nuxt_component_0 } from './nuxt-link-c659c711.mjs';
import __nuxt_component_0$1 from './Icon-ec29c746.mjs';
import { s as siteUrlState, w as websiteUrlState, u as useImage, a as singlePageStickyState, b as useFetch, _ as __nuxt_component_1 } from './state-7a7e2860.mjs';
import { computed, withAsyncContext, ref, mergeProps, withCtx, unref, createTextVNode, toDisplayString, createVNode, openBlock, createBlock, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent, ssrInterpolate, ssrRenderAttr, ssrRenderList, ssrRenderClass } from 'vue/server-renderer';
import { _ as __nuxt_component_4 } from './client-only-0841c2aa.mjs';
import { _ as _export_sfc, u as useRoute } from '../server.mjs';
import { u as useState } from './state-b54abad0.mjs';
import './index-6a088328.mjs';
import '@unhead/shared';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'ipx';
import './config-a9056531.mjs';
import '@iconify/vue/dist/offline';
import '@iconify/vue';
import 'unhead';
import 'vue-router';

const _sfc_main$6 = {
  __name: "Top",
  __ssrInlineRender: true,
  props: ["DetailTopAds"],
  setup(__props) {
    const data = __props;
    const siteurl = siteUrlState();
    return (_ctx, _push, _parent, _attrs) => {
      var _a, _b, _c, _d, _e;
      if (((_a = data == null ? void 0 : data.DetailTopAds) == null ? void 0 : _a.status) === 1) {
        _push(`<div${ssrRenderAttrs(mergeProps({ class: "ad-container" }, _attrs))}><div class="ad-section bg-[#f7f7f7]">`);
        if (((_b = data == null ? void 0 : data.DetailTopAds) == null ? void 0 : _b.type) === 3) {
          _push(`<a${ssrRenderAttr("href", (_c = data == null ? void 0 : data.DetailTopAds) == null ? void 0 : _c.external_link)} target="_blank" rel="nofollow"><img class="mx-auto"${ssrRenderAttr("src", `${unref(siteurl).site_url}/media/advertisement/${(_d = data == null ? void 0 : data.DetailTopAds) == null ? void 0 : _d.desktop_image_path}`)} alt="Header Ad"></a>`);
        } else {
          _push(`<div>${(_e = data == null ? void 0 : data.DetailTopAds) == null ? void 0 : _e.code}</div>`);
        }
        _push(`</div></div>`);
      } else {
        _push(`<!---->`);
      }
    };
  }
};
const _sfc_setup$6 = _sfc_main$6.setup;
_sfc_main$6.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Ads/Desktop/Detail/Top.vue");
  return _sfc_setup$6 ? _sfc_setup$6(props, ctx) : void 0;
};
const __nuxt_component_6 = _sfc_main$6;
const _sfc_main$5 = {
  __name: "RightOne",
  __ssrInlineRender: true,
  props: ["DetailRightOneAds"],
  setup(__props) {
    const data = __props;
    const siteurl = siteUrlState();
    return (_ctx, _push, _parent, _attrs) => {
      var _a, _b, _c, _d, _e;
      if (((_a = data == null ? void 0 : data.DetailRightOneAds) == null ? void 0 : _a.status) === 1) {
        _push(`<div${ssrRenderAttrs(mergeProps({ class: "ad-container" }, _attrs))}><div class="ad-section bg-[#f7f7f7]">`);
        if (((_b = data == null ? void 0 : data.DetailRightOneAds) == null ? void 0 : _b.type) === 3) {
          _push(`<a${ssrRenderAttr("href", (_c = data == null ? void 0 : data.DetailRightOneAds) == null ? void 0 : _c.external_link)} target="_blank" rel="nofollow"><img class="mx-auto"${ssrRenderAttr("src", `${unref(siteurl).site_url}/media/advertisement/${(_d = data == null ? void 0 : data.DetailRightOneAds) == null ? void 0 : _d.desktop_image_path}`)} alt="Header Ad"></a>`);
        } else {
          _push(`<div>${(_e = data == null ? void 0 : data.DetailRightOneAds) == null ? void 0 : _e.code}</div>`);
        }
        _push(`</div></div>`);
      } else {
        _push(`<!---->`);
      }
    };
  }
};
const _sfc_setup$5 = _sfc_main$5.setup;
_sfc_main$5.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Ads/Desktop/Detail/RightOne.vue");
  return _sfc_setup$5 ? _sfc_setup$5(props, ctx) : void 0;
};
const __nuxt_component_9 = _sfc_main$5;
const _sfc_main$4 = {
  __name: "RightTwo",
  __ssrInlineRender: true,
  props: ["DetailRightTwoAds"],
  setup(__props) {
    const data = __props;
    const siteurl = siteUrlState();
    return (_ctx, _push, _parent, _attrs) => {
      var _a, _b, _c, _d, _e;
      if (((_a = data == null ? void 0 : data.DetailRightTwoAds) == null ? void 0 : _a.status) === 1) {
        _push(`<div${ssrRenderAttrs(mergeProps({ class: "ad-container" }, _attrs))}><div class="ad-section bg-[#f7f7f7]">`);
        if (((_b = data == null ? void 0 : data.DetailRightTwoAds) == null ? void 0 : _b.type) === 3) {
          _push(`<a${ssrRenderAttr("href", (_c = data == null ? void 0 : data.DetailRightTwoAds) == null ? void 0 : _c.external_link)} target="_blank" rel="nofollow"><img class="mx-auto"${ssrRenderAttr("src", `${unref(siteurl).site_url}/media/advertisement/${(_d = data == null ? void 0 : data.DetailRightTwoAds) == null ? void 0 : _d.desktop_image_path}`)} alt="Header Ad"></a>`);
        } else {
          _push(`<div>${(_e = data == null ? void 0 : data.DetailRightTwoAds) == null ? void 0 : _e.code}</div>`);
        }
        _push(`</div></div>`);
      } else {
        _push(`<!---->`);
      }
    };
  }
};
const _sfc_setup$4 = _sfc_main$4.setup;
_sfc_main$4.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Ads/Desktop/Detail/RightTwo.vue");
  return _sfc_setup$4 ? _sfc_setup$4(props, ctx) : void 0;
};
const __nuxt_component_10 = _sfc_main$4;
const _sfc_main$3 = {
  __name: "RightThree",
  __ssrInlineRender: true,
  props: ["DetailRightThreeAds"],
  setup(__props) {
    const data = __props;
    const siteurl = siteUrlState();
    return (_ctx, _push, _parent, _attrs) => {
      var _a, _b, _c, _d, _e;
      if (((_a = data == null ? void 0 : data.DetailRightThreeAds) == null ? void 0 : _a.status) === 1) {
        _push(`<div${ssrRenderAttrs(mergeProps({ class: "ad-container" }, _attrs))}><div class="ad-section bg-[#f7f7f7]">`);
        if (((_b = data == null ? void 0 : data.DetailRightThreeAds) == null ? void 0 : _b.type) === 3) {
          _push(`<a${ssrRenderAttr("href", (_c = data == null ? void 0 : data.DetailRightThreeAds) == null ? void 0 : _c.external_link)} target="_blank" rel="nofollow"><img class="mx-auto"${ssrRenderAttr("src", `${unref(siteurl).site_url}/media/advertisement/${(_d = data == null ? void 0 : data.DetailRightThreeAds) == null ? void 0 : _d.desktop_image_path}`)} alt="Header Ad"></a>`);
        } else {
          _push(`<div>${(_e = data == null ? void 0 : data.DetailRightThreeAds) == null ? void 0 : _e.code}</div>`);
        }
        _push(`</div></div>`);
      } else {
        _push(`<!---->`);
      }
    };
  }
};
const _sfc_setup$3 = _sfc_main$3.setup;
_sfc_main$3.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Ads/Desktop/Detail/RightThree.vue");
  return _sfc_setup$3 ? _sfc_setup$3(props, ctx) : void 0;
};
const __nuxt_component_11 = _sfc_main$3;
const _sfc_main$2 = {
  __name: "After",
  __ssrInlineRender: true,
  props: ["DetailAfterAds"],
  setup(__props) {
    const data = __props;
    const siteurl = siteUrlState();
    return (_ctx, _push, _parent, _attrs) => {
      var _a, _b, _c, _d, _e;
      if (((_a = data == null ? void 0 : data.DetailAfterAds) == null ? void 0 : _a.status) === 1) {
        _push(`<div${ssrRenderAttrs(mergeProps({ class: "ad-container" }, _attrs))}><div class="ad-section bg-[#f7f7f7]">`);
        if (((_b = data == null ? void 0 : data.DetailAfterAds) == null ? void 0 : _b.type) === 3) {
          _push(`<a${ssrRenderAttr("href", (_c = data == null ? void 0 : data.DetailAfterAds) == null ? void 0 : _c.external_link)} target="_blank" rel="nofollow"><img class="mx-auto"${ssrRenderAttr("src", `${unref(siteurl).site_url}/media/advertisement/${(_d = data == null ? void 0 : data.DetailAfterAds) == null ? void 0 : _d.desktop_image_path}`)} alt="Header Ad"></a>`);
        } else {
          _push(`<div>${(_e = data == null ? void 0 : data.DetailAfterAds) == null ? void 0 : _e.code}</div>`);
        }
        _push(`</div></div>`);
      } else {
        _push(`<!---->`);
      }
    };
  }
};
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Ads/Desktop/Detail/After.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const __nuxt_component_12 = _sfc_main$2;
const _sfc_main$1 = {
  __name: "Bottom",
  __ssrInlineRender: true,
  props: ["DetailBottomAds"],
  setup(__props) {
    const data = __props;
    const siteurl = siteUrlState();
    return (_ctx, _push, _parent, _attrs) => {
      var _a, _b, _c, _d, _e;
      if (((_a = data == null ? void 0 : data.DetailBottomAds) == null ? void 0 : _a.status) === 1) {
        _push(`<div${ssrRenderAttrs(mergeProps({ class: "ad-container" }, _attrs))}><div class="ad-section bg-[#f7f7f7]">`);
        if (((_b = data == null ? void 0 : data.DetailBottomAds) == null ? void 0 : _b.type) === 3) {
          _push(`<a${ssrRenderAttr("href", (_c = data == null ? void 0 : data.DetailBottomAds) == null ? void 0 : _c.external_link)} target="_blank" rel="nofollow"><img class="mx-auto"${ssrRenderAttr("src", `${unref(siteurl).site_url}/media/advertisement/${(_d = data == null ? void 0 : data.DetailBottomAds) == null ? void 0 : _d.desktop_image_path}`)} alt="Header Ad"></a>`);
        } else {
          _push(`<div>${(_e = data == null ? void 0 : data.DetailBottomAds) == null ? void 0 : _e.code}</div>`);
        }
        _push(`</div></div>`);
      } else {
        _push(`<!---->`);
      }
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Ads/Desktop/Detail/Bottom.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_13 = _sfc_main$1;
const _sfc_main = {
  __name: "[content_id]",
  __ssrInlineRender: true,
  async setup(__props) {
    var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j, _k, _l, _m, _n, _o, _p, _q, _r, _s, _t, _u, _v, _w, _x, _y;
    let __temp, __restore;
    const siteurl = siteUrlState();
    const websiteUrl = websiteUrlState();
    const img = useImage();
    const singlePageSticky = singlePageStickyState();
    const stickyScroll = computed(
      () => singlePageSticky.value
    );
    const category_slug = useRoute().params.category_slug;
    const content_id = useRoute().params.content_id;
    const { data: pdailts } = ([__temp, __restore] = withAsyncContext(() => useFetch("/api/detailpage/detail", {
      method: "POST",
      body: {
        category_slug,
        content_id
      }
    }, "$jzLn8HdhZe")), __temp = await __temp, __restore(), __temp);
    const detailsContent = useState(() => [], "$f8KsCHkaqW");
    detailsContent.value = (_a = pdailts == null ? void 0 : pdailts.value) == null ? void 0 : _a.detailsContent;
    const ogUrl = ref(null);
    ogUrl.value = `${(_b = websiteUrl == null ? void 0 : websiteUrl.value) == null ? void 0 : _b.website_url}/category/${(_d = (_c = detailsContent == null ? void 0 : detailsContent.value) == null ? void 0 : _c.category) == null ? void 0 : _d.cat_slug}/${(_e = detailsContent == null ? void 0 : detailsContent.value) == null ? void 0 : _e.content_id}`;
    const ogTitle = ref(null);
    ogTitle.value = (_f = detailsContent == null ? void 0 : detailsContent.value) == null ? void 0 : _f.content_heading;
    const ogDescription = ref(null);
    ogDescription.value = (_g = detailsContent == null ? void 0 : detailsContent.value) == null ? void 0 : _g.content_brief;
    const metaKeywords = ref(null);
    metaKeywords.value = (_h = detailsContent == null ? void 0 : detailsContent.value) == null ? void 0 : _h.meta_keywords;
    ogDescription.value = (_i = detailsContent == null ? void 0 : detailsContent.value) == null ? void 0 : _i.content_brief;
    const ogImage = ref(null);
    ogImage.value = `${(_j = siteurl == null ? void 0 : siteurl.value) == null ? void 0 : _j.site_url}/api/ogimage/get/${(_l = (_k = detailsContent == null ? void 0 : detailsContent.value) == null ? void 0 : _k.category) == null ? void 0 : _l.cat_slug}?imgPath=${(_m = detailsContent == null ? void 0 : detailsContent.value) == null ? void 0 : _m.img_bg_path}`;
    const twitterTitle = ref(null);
    twitterTitle.value = (_n = detailsContent == null ? void 0 : detailsContent.value) == null ? void 0 : _n.content_heading;
    const twitterDescription = ref(null);
    twitterDescription.value = (_o = detailsContent == null ? void 0 : detailsContent.value) == null ? void 0 : _o.content_brief;
    const twitterImage = ref(null);
    twitterImage.value = `${(_p = siteurl == null ? void 0 : siteurl.value) == null ? void 0 : _p.site_url}/api/ogimage/get/${(_r = (_q = detailsContent == null ? void 0 : detailsContent.value) == null ? void 0 : _q.category) == null ? void 0 : _r.cat_slug}?imgPath=${(_s = detailsContent == null ? void 0 : detailsContent.value) == null ? void 0 : _s.img_bg_path}`;
    const latestPostsDpage = useState(() => [], "$jd9rQQaRCP");
    latestPostsDpage.value = (_t = pdailts == null ? void 0 : pdailts.value) == null ? void 0 : _t.allLatestPost;
    const firstMoreContents = useState(() => [], "$sHo2kuaQxN");
    firstMoreContents.value = (_u = pdailts == null ? void 0 : pdailts.value) == null ? void 0 : _u.moreContents;
    const moreDetailsContents = useState(() => [], "$lkRFXDL8rH");
    moreDetailsContents.value = (_v = pdailts == null ? void 0 : pdailts.value) == null ? void 0 : _v.moreDetailContent;
    const firstInsideMoreNews = useState(() => [], "$isgto0EoQ6");
    firstInsideMoreNews.value = (_w = pdailts == null ? void 0 : pdailts.value) == null ? void 0 : _w.insideMoreNews;
    const readPostsState = useState(() => [], "$01yg6Qpfz0");
    const relatedDetailContent = useState(() => [], "$1l0SaGl37L");
    for (let s = 0; s < moreDetailsContents.value.length; s++) {
      readPostsState.value.push(moreDetailsContents.value[s].content_id);
      const { data: rlcd } = ([__temp, __restore] = withAsyncContext(() => {
        var _a2;
        return useFetch("/api/detailpage/relatedcontent", {
          method: "POST",
          body: {
            readedIds: readPostsState.value,
            detailId: (_a2 = detailsContent == null ? void 0 : detailsContent.value) == null ? void 0 : _a2.content_id
          }
        }, "$rSDXGx1wCG");
      }), __temp = await __temp, __restore(), __temp);
      let reldata = rlcd.value.slice(1, 5);
      relatedDetailContent.value.push(reldata);
    }
    const moreDetailCatWisePost = useState(() => [], "$nmAzibax8Y");
    for (let i = 0; i < moreDetailsContents.value.length; i++) {
      const { data: mdcwp } = ([__temp, __restore] = withAsyncContext(() => {
        var _a2, _b2;
        return useFetch("/api/detailpage/catwiseposts", {
          method: "POST",
          body: {
            cat_id: (_a2 = moreDetailsContents == null ? void 0 : moreDetailsContents.value[i]) == null ? void 0 : _a2.cat_id,
            content_id: (_b2 = moreDetailsContents == null ? void 0 : moreDetailsContents.value[i]) == null ? void 0 : _b2.content_id
          }
        }, "$Kf3N4QtKph");
      }), __temp = await __temp, __restore(), __temp);
      let datapush = mdcwp.value;
      moreDetailCatWisePost.value.push(datapush);
    }
    moreDetailCatWisePost.value = [...new Set(moreDetailCatWisePost.value)];
    const firstContentTags = useState(() => [], "$LrdZ2TX2Be");
    const firstsplittag = (_y = (_x = detailsContent == null ? void 0 : detailsContent.value) == null ? void 0 : _x.tags) == null ? void 0 : _y.split(",");
    if (firstsplittag) {
      firstsplittag.forEach((tagval) => {
        firstContentTags.value.push(tagval);
      });
      firstContentTags.value = [...new Map(firstContentTags.value.map((fvl) => [fvl, fvl])).values()];
    }
    const fRelatedContents = useState(() => [], "$FKLjCG9lku");
    const { data: frcontent } = ([__temp, __restore] = withAsyncContext(() => useFetch("/api/detailpage/firstrelatedcontent", {
      method: "POST",
      body: {
        content_id
      }
    }, "$6sONy26oPB")), __temp = await __temp, __restore(), __temp);
    fRelatedContents.value = frcontent;
    const insideMoreExceptPost = useState(() => [], "$vqxVzyX54p");
    for (let m = 0; m < moreDetailsContents.value.length; m++) {
      const { data: insidempect } = ([__temp, __restore] = withAsyncContext(() => {
        var _a2, _b2, _c2;
        return useFetch("/api/detailpage/insidemoredetailexcept", {
          method: "POST",
          body: {
            currentPostDetailId: (_a2 = detailsContent == null ? void 0 : detailsContent.value) == null ? void 0 : _a2.content_id,
            morePostId: (_b2 = moreDetailsContents == null ? void 0 : moreDetailsContents.value[m]) == null ? void 0 : _b2.content_id,
            cat_id: (_c2 = moreDetailsContents == null ? void 0 : moreDetailsContents.value[m]) == null ? void 0 : _c2.cat_id
          }
        }, "$uf9pl2Jaad");
      }), __temp = await __temp, __restore(), __temp);
      let insidePost = insidempect.value;
      insideMoreExceptPost.value.push(insidePost);
    }
    insideMoreExceptPost.value = [...new Set(insideMoreExceptPost.value)];
    ref(0);
    ref(0);
    const balvalue = ref(null);
    const DetailTopAds = useState(() => "", "$nJwF5g8Tbd");
    const { data: detTpAds } = ([__temp, __restore] = withAsyncContext(() => useFetch("/api/adsmanagement/getads", {
      method: "POST",
      body: {
        page: 4,
        position: 1
      }
    }, "$HQNeDFs1mI")), __temp = await __temp, __restore(), __temp);
    DetailTopAds.value = detTpAds.value;
    const DetailAfterAds = useState(() => "", "$BXnU7UQLjM");
    const { data: detaftAds } = ([__temp, __restore] = withAsyncContext(() => useFetch("/api/adsmanagement/getads", {
      method: "POST",
      body: {
        page: 4,
        position: 5
      }
    }, "$3iMxUu4yRY")), __temp = await __temp, __restore(), __temp);
    DetailAfterAds.value = detaftAds.value;
    const DetailBottomAds = useState(() => "", "$CCMoDQUZAG");
    const { data: detbtmAds } = ([__temp, __restore] = withAsyncContext(() => useFetch("/api/adsmanagement/getads", {
      method: "POST",
      body: {
        page: 4,
        position: 6
      }
    }, "$KHIDdpHlJL")), __temp = await __temp, __restore(), __temp);
    DetailBottomAds.value = detbtmAds.value;
    const DetailRightOneAds = useState(() => "", "$WokgC6p4HL");
    const { data: detrtoneAds } = ([__temp, __restore] = withAsyncContext(() => useFetch("/api/adsmanagement/getads", {
      method: "POST",
      body: {
        page: 4,
        position: 7
      }
    }, "$pbp4RZeXw7")), __temp = await __temp, __restore(), __temp);
    DetailRightOneAds.value = detrtoneAds.value;
    const DetailRightTwoAds = useState(() => "", "$4Sxuh6sFPe");
    const { data: detrttwoAds } = ([__temp, __restore] = withAsyncContext(() => useFetch("/api/adsmanagement/getads", {
      method: "POST",
      body: {
        page: 4,
        position: 8
      }
    }, "$97HXGzwRje")), __temp = await __temp, __restore(), __temp);
    DetailRightTwoAds.value = detrttwoAds.value;
    const DetailRightThreeAds = useState(() => "", "$CDP3Ga8Sj2");
    const { data: detrtthreeAds } = ([__temp, __restore] = withAsyncContext(() => useFetch("/api/adsmanagement/getads", {
      method: "POST",
      body: {
        page: 4,
        position: 9
      }
    }, "$JoOVfpnbum")), __temp = await __temp, __restore(), __temp);
    DetailRightThreeAds.value = detrtthreeAds.value;
    return (_ctx, _push, _parent, _attrs) => {
      var _a2, _b2, _c2, _d2, _e2, _f2, _g2, _h2, _i2, _j2, _k2, _l2, _m2, _n2, _o2, _p2, _q2, _r2, _s2, _t2, _u2, _v2, _w2, _x2, _y2, _z, _A, _B, _C, _D, _E, _F, _G;
      const _component_Head = Head;
      const _component_Title = Title;
      const _component_Meta = Meta;
      const _component_Link = Link;
      const _component_NuxtLink = __nuxt_component_0;
      const _component_Icon = __nuxt_component_0$1;
      const _component_AdsDesktopDetailTop = __nuxt_component_6;
      const _component_ClientOnly = __nuxt_component_4;
      const _component_nuxt_img = __nuxt_component_1;
      const _component_AdsDesktopDetailRightOne = __nuxt_component_9;
      const _component_AdsDesktopDetailRightTwo = __nuxt_component_10;
      const _component_AdsDesktopDetailRightThree = __nuxt_component_11;
      const _component_AdsDesktopDetailAfter = __nuxt_component_12;
      const _component_AdsDesktopDetailBottom = __nuxt_component_13;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "max-w-[1280px] mx-auto detail-page px-4 md:px-2 py-4" }, _attrs))} data-v-d0382835>`);
      _push(ssrRenderComponent(_component_Head, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_Title, null, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`${ssrInterpolate(unref(detailsContent).content_heading)}`);
                } else {
                  return [
                    createTextVNode(toDisplayString(unref(detailsContent).content_heading), 1)
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_Meta, {
              content: "500",
              "http-equiv": "refresh"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_Meta, {
              name: "description",
              content: unref(ogDescription)
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_Meta, {
              name: "keywords",
              content: unref(metaKeywords)
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_Meta, {
              property: "og:url",
              content: unref(ogUrl)
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_Meta, {
              property: "og:title",
              content: unref(ogTitle)
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_Meta, {
              property: "og:description",
              content: unref(ogDescription)
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_Meta, {
              property: "og:image",
              content: unref(ogImage)
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_Meta, {
              name: "twitter:title",
              content: unref(ogTitle)
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_Meta, {
              name: "twitter:description",
              content: unref(ogDescription)
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_Meta, {
              name: "twitter:image",
              content: unref(ogImage)
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_Meta, {
              name: "twitter:url",
              content: unref(ogUrl)
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_Link, {
              rel: "canonical",
              href: unref(ogUrl)
            }, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_Title, null, {
                default: withCtx(() => [
                  createTextVNode(toDisplayString(unref(detailsContent).content_heading), 1)
                ]),
                _: 1
              }),
              createVNode(_component_Meta, {
                content: "500",
                "http-equiv": "refresh"
              }),
              createVNode(_component_Meta, {
                name: "description",
                content: unref(ogDescription)
              }, null, 8, ["content"]),
              createVNode(_component_Meta, {
                name: "keywords",
                content: unref(metaKeywords)
              }, null, 8, ["content"]),
              createVNode(_component_Meta, {
                property: "og:url",
                content: unref(ogUrl)
              }, null, 8, ["content"]),
              createVNode(_component_Meta, {
                property: "og:title",
                content: unref(ogTitle)
              }, null, 8, ["content"]),
              createVNode(_component_Meta, {
                property: "og:description",
                content: unref(ogDescription)
              }, null, 8, ["content"]),
              createVNode(_component_Meta, {
                property: "og:image",
                content: unref(ogImage)
              }, null, 8, ["content"]),
              createVNode(_component_Meta, {
                name: "twitter:title",
                content: unref(ogTitle)
              }, null, 8, ["content"]),
              createVNode(_component_Meta, {
                name: "twitter:description",
                content: unref(ogDescription)
              }, null, 8, ["content"]),
              createVNode(_component_Meta, {
                name: "twitter:image",
                content: unref(ogImage)
              }, null, 8, ["content"]),
              createVNode(_component_Meta, {
                name: "twitter:url",
                content: unref(ogUrl)
              }, null, 8, ["content"]),
              createVNode(_component_Link, {
                rel: "canonical",
                href: unref(ogUrl)
              }, null, 8, ["href"])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<div class="breadcrump border-b pb-1 mb-5" data-v-d0382835><div class="flex gap-1 justify-start items-center" data-v-d0382835>`);
      _push(ssrRenderComponent(_component_NuxtLink, { to: "/" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_Icon, {
              class: "text-xl",
              name: "material-symbols:house-rounded"
            }, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_Icon, {
                class: "text-xl",
                name: "material-symbols:house-rounded"
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_Icon, { name: "ic:outline-keyboard-arrow-right" }, null, _parent));
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: `/${(_b2 = (_a2 = unref(detailsContent)) == null ? void 0 : _a2.category) == null ? void 0 : _b2.cat_slug}`
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          var _a3, _b3, _c3, _d3;
          if (_push2) {
            _push2(`${ssrInterpolate((_b3 = (_a3 = unref(detailsContent)) == null ? void 0 : _a3.category) == null ? void 0 : _b3.cat_name_bn)}`);
          } else {
            return [
              createTextVNode(toDisplayString((_d3 = (_c3 = unref(detailsContent)) == null ? void 0 : _c3.category) == null ? void 0 : _d3.cat_name_bn), 1)
            ];
          }
        }),
        _: 1
      }, _parent));
      if ((_c2 = unref(detailsContent)) == null ? void 0 : _c2.subcategory) {
        _push(ssrRenderComponent(_component_Icon, { name: "ic:outline-keyboard-arrow-right" }, null, _parent));
      } else {
        _push(`<!---->`);
      }
      if ((_d2 = unref(detailsContent)) == null ? void 0 : _d2.subcategory) {
        _push(ssrRenderComponent(_component_NuxtLink, { to: `/` }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            var _a3, _b3, _c3, _d3;
            if (_push2) {
              _push2(`${ssrInterpolate((_b3 = (_a3 = unref(detailsContent)) == null ? void 0 : _a3.subcategory) == null ? void 0 : _b3.subcat_name_bn)}`);
            } else {
              return [
                createTextVNode(toDisplayString((_d3 = (_c3 = unref(detailsContent)) == null ? void 0 : _c3.subcategory) == null ? void 0 : _d3.subcat_name_bn), 1)
              ];
            }
          }),
          _: 1
        }, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div>`);
      if (unref(DetailTopAds).status === 1) {
        _push(`<div class="pb-4 mb-4 border-b border-b-[#e2e2e2]" data-v-d0382835>`);
        _push(ssrRenderComponent(_component_AdsDesktopDetailTop, { DetailTopAds: unref(DetailTopAds) }, null, _parent));
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<div class="grid grid-cols-12 gap-5 relative d-print" data-v-d0382835><div class="col-span-12 md:col-span-9" id="singlepost" data-v-d0382835><div class="single-post flex flex-col gap-3"${ssrRenderAttr("data-title", (_e2 = unref(detailsContent)) == null ? void 0 : _e2.content_heading)}${ssrRenderAttr("data-nid", (_f2 = unref(detailsContent)) == null ? void 0 : _f2.content_id)}${ssrRenderAttr("data-description", (_g2 = unref(detailsContent)) == null ? void 0 : _g2.content_brief)}${ssrRenderAttr("data-keywords", (_h2 = unref(detailsContent)) == null ? void 0 : _h2.meta_keywords)}${ssrRenderAttr("data-href", `${(_i2 = unref(websiteUrl)) == null ? void 0 : _i2.website_url}/category/${(_k2 = (_j2 = unref(detailsContent)) == null ? void 0 : _j2.category) == null ? void 0 : _k2.cat_slug}/${(_l2 = unref(detailsContent)) == null ? void 0 : _l2.content_id}`)}${ssrRenderAttr("data-src", `${(_m2 = unref(siteurl)) == null ? void 0 : _m2.site_url}/api/ogimage/get/${(_o2 = (_n2 = unref(detailsContent)) == null ? void 0 : _n2.category) == null ? void 0 : _o2.cat_slug}?imgPath=${(_p2 = unref(detailsContent)) == null ? void 0 : _p2.img_bg_path}`)} data-v-d0382835><div class="singlePost-heading flex flex-col gap-2" data-v-d0382835>`);
      if ((_q2 = unref(detailsContent)) == null ? void 0 : _q2.content_sub_heading) {
        _push(`<h4 class="text-[20px] text-[#ff0000]" data-v-d0382835>${ssrInterpolate((_r2 = unref(detailsContent)) == null ? void 0 : _r2.content_sub_heading)}</h4>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<h2 class="md:text-[32px] md:leading-[50px] print:text-[32px]" data-v-d0382835>${ssrInterpolate(unref(detailsContent).content_heading)} ${ssrInterpolate(unref(balvalue))}</h2><div class="h-2 w-12 rounded-md bg-[#3375af] print:hidden" data-v-d0382835></div></div><div class="flex flex-col gap-2 md:gap-0 md:flex-row justify-between md:items-end border-b pb-3" data-v-d0382835><div class="author-details flex flex-col gap-1" data-v-d0382835>`);
      if ((_s2 = unref(detailsContent)) == null ? void 0 : _s2.author) {
        _push(`<p data-v-d0382835>`);
        _push(ssrRenderComponent(_component_NuxtLink, {
          class: "hover:text-[#3375af] font-[600]",
          to: `/author/${(_u2 = (_t2 = unref(detailsContent)) == null ? void 0 : _t2.author) == null ? void 0 : _u2.author_slug}`
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            var _a3, _b3, _c3, _d3;
            if (_push2) {
              _push2(`${ssrInterpolate((_b3 = (_a3 = unref(detailsContent)) == null ? void 0 : _a3.author) == null ? void 0 : _b3.author_name_bn)}`);
            } else {
              return [
                createTextVNode(toDisplayString((_d3 = (_c3 = unref(detailsContent)) == null ? void 0 : _c3.author) == null ? void 0 : _d3.author_name_bn), 1)
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(`</p>`);
      } else {
        _push(`<p data-v-d0382835>`);
        _push(ssrRenderComponent(_component_NuxtLink, {
          class: "hover:text-[#3375af] font-[600]",
          to: "/author/dhaka-prokash-desk"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`\u09A2\u09BE\u0995\u09BE\u09AA\u09CD\u09B0\u0995\u09BE\u09B6 \u09A1\u09C7\u09B8\u09CD\u0995`);
            } else {
              return [
                createTextVNode("\u09A2\u09BE\u0995\u09BE\u09AA\u09CD\u09B0\u0995\u09BE\u09B6 \u09A1\u09C7\u09B8\u09CD\u0995")
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(`</p>`);
      }
      _push(`<p data-v-d0382835>\u09AA\u09CD\u09B0\u0995\u09BE\u09B6: `);
      _push(ssrRenderComponent(_component_ClientOnly, null, {}, _parent));
      _push(`</p></div><div class="social-item flex gap-2 items-start md:justify-center print:hidden" data-v-d0382835>`);
      _push(ssrRenderComponent(_component_NuxtLink, { to: "/" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<svg class="hover:scale-125 duration-200" xmlns="http://www.w3.org/2000/svg" height="28" width="28" viewBox="0 0 32 32" enable-background="new 0 0 32 32" xml:space="preserve" data-v-d0382835${_scopeId}><path fill="#1877F2" d="M16,0L16,0c8.837,0,16,7.163,16,16l0,0c0,8.837-7.163,16-16,16l0,0C7.163,32,0,24.837,0,16l0,0 C0,7.163,7.163,0,16,0z" data-v-d0382835${_scopeId}></path><path fill="#FFFFFF" d="M18,17.5h2.5l1-4H18v-2c0-1.03,0-2,2-2h1.5V6.14C21.174,6.097,19.943,6,18.643,6C15.928,6,14,7.657,14,10.7 v2.8h-3v4h3V26h4V17.5z" data-v-d0382835${_scopeId}></path></svg>`);
          } else {
            return [
              (openBlock(), createBlock("svg", {
                class: "hover:scale-125 duration-200",
                xmlns: "http://www.w3.org/2000/svg",
                height: "28",
                width: "28",
                viewBox: "0 0 32 32",
                "enable-background": "new 0 0 32 32",
                "xml:space": "preserve"
              }, [
                createVNode("path", {
                  fill: "#1877F2",
                  d: "M16,0L16,0c8.837,0,16,7.163,16,16l0,0c0,8.837-7.163,16-16,16l0,0C7.163,32,0,24.837,0,16l0,0 C0,7.163,7.163,0,16,0z"
                }),
                createVNode("path", {
                  fill: "#FFFFFF",
                  d: "M18,17.5h2.5l1-4H18v-2c0-1.03,0-2,2-2h1.5V6.14C21.174,6.097,19.943,6,18.643,6C15.928,6,14,7.657,14,10.7 v2.8h-3v4h3V26h4V17.5z"
                })
              ]))
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_NuxtLink, { to: "/" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<svg class="hover:scale-125 duration-200" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" enable-background="new 0 0 24 24" xml:space="preserve" height="28" width="28" data-v-d0382835${_scopeId}><circle fill="#0F1419" cx="12" cy="12" r="12" data-v-d0382835${_scopeId}></circle><path fill="#FFFFFF" d="M15.531,7h1.662l-3.63,4.236L17.833,17h-3.343l-2.62-3.495L8.876,17H7.212l3.882-4.531L7,7h3.427
l2.366,3.195L15.531,7z M14.947,15.986h0.92L9.926,7.962H8.937L14.947,15.986z" data-v-d0382835${_scopeId}></path></svg>`);
          } else {
            return [
              (openBlock(), createBlock("svg", {
                class: "hover:scale-125 duration-200",
                xmlns: "http://www.w3.org/2000/svg",
                viewBox: "0 0 24 24",
                "enable-background": "new 0 0 24 24",
                "xml:space": "preserve",
                height: "28",
                width: "28"
              }, [
                createVNode("circle", {
                  fill: "#0F1419",
                  cx: "12",
                  cy: "12",
                  r: "12"
                }),
                createVNode("path", {
                  fill: "#FFFFFF",
                  d: "M15.531,7h1.662l-3.63,4.236L17.833,17h-3.343l-2.62-3.495L8.876,17H7.212l3.882-4.531L7,7h3.427\r\nl2.366,3.195L15.531,7z M14.947,15.986h0.92L9.926,7.962H8.937L14.947,15.986z"
                })
              ]))
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<div class="cursor-pointer" data-v-d0382835><svg class="hover:scale-125 duration-200" height="28" width="28" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32" enable-background="new 0 0 32 32" xml:space="preserve" data-v-d0382835><path fill="#595959" d="M16,0L16,0c8.837,0,16,7.163,16,16l0,0c0,8.837-7.163,16-16,16l0,0C7.163,32,0,24.837,0,16l0,0 C0,7.163,7.163,0,16,0z" data-v-d0382835></path><path fill="#FFFFFF" d="M12,20h8v4h-8V20z M21.6,22.4v-4H10.4v4H8.8c-0.212,0-0.416-0.084-0.566-0.234C8.084,22.016,8,21.812,8,21.6 v-8c0-0.212,0.084-0.416,0.234-0.566C8.384,12.884,8.588,12.8,8.8,12.8h14.4c0.212,0,0.416,0.084,0.566,0.234 C23.916,13.184,24,13.388,24,13.6v8c0,0.212-0.084,0.416-0.234,0.566c-0.15,0.15-0.353,0.234-0.566,0.234H21.6z M10.4,14.4V16h2.4 v-1.6H10.4z M12,8h8c0.212,0,0.416,0.084,0.566,0.234C20.716,8.384,20.8,8.588,20.8,8.8v2.4h-9.6V8.8 c0-0.212,0.084-0.416,0.234-0.566C11.584,8.084,11.788,8,12,8z" data-v-d0382835></path></svg></div><div class="sharethis-inline-share-buttons" data-v-d0382835></div></div></div><div class="feature-image border-b" data-v-d0382835>`);
      _push(ssrRenderComponent(_component_nuxt_img, {
        src: `${unref(siteurl).site_url}/media/content/images/${(_v2 = unref(detailsContent)) == null ? void 0 : _v2.img_bg_path}`,
        class: "mx-auto w-full",
        placeholder: unref(img)(`${unref(siteurl).site_url}/logo/placeholder.jpg`)
      }, null, _parent));
      if ((_w2 = unref(detailsContent)) == null ? void 0 : _w2.img_bg_caption) {
        _push(`<p class="feature-image-capture text-center py-2" data-v-d0382835>${ssrInterpolate((_x2 = unref(detailsContent)) == null ? void 0 : _x2.img_bg_caption)}</p>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div><div class="singlePost-detail grid grid-cols-12" data-v-d0382835><div class="hidden md:block md:col-span-2" data-v-d0382835></div><div class="col-span-12 md:col-span-8" data-v-d0382835><div class="postdetails text-[18px] text-gray-700 pb-4" data-v-d0382835>${(_y2 = unref(detailsContent)) == null ? void 0 : _y2.content_details}</div><div class="category-tags-area flex flex-col gap-4 border-b border-t pb-4 pt-3 print:hidden" data-v-d0382835>`);
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: `/${(_A = (_z = unref(detailsContent)) == null ? void 0 : _z.category) == null ? void 0 : _A.cat_slug}`,
        class: "text-[18px] py-1"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          var _a3, _b3, _c3, _d3;
          if (_push2) {
            _push2(`<span class="py-1 font-semibold border-b-2 border-[#3375af] text-[#3375af]" data-v-d0382835${_scopeId}>${ssrInterpolate((_b3 = (_a3 = unref(detailsContent)) == null ? void 0 : _a3.category) == null ? void 0 : _b3.cat_name_bn)}</span> \u09A5\u09C7\u0995\u09C7 \u0986\u09B0\u0993 \u09AA\u09DC\u09C1\u09A8`);
          } else {
            return [
              createVNode("span", { class: "py-1 font-semibold border-b-2 border-[#3375af] text-[#3375af]" }, toDisplayString((_d3 = (_c3 = unref(detailsContent)) == null ? void 0 : _c3.category) == null ? void 0 : _d3.cat_name_bn), 1),
              createTextVNode(" \u09A5\u09C7\u0995\u09C7 \u0986\u09B0\u0993 \u09AA\u09DC\u09C1\u09A8")
            ];
          }
        }),
        _: 1
      }, _parent));
      if (((_B = unref(firstContentTags)) == null ? void 0 : _B.length) > 0) {
        _push(`<ul class="flex flex-wrap gap-3 items-center" data-v-d0382835><!--[-->`);
        ssrRenderList(unref(firstContentTags), (ftag) => {
          _push(`<li class="text-[#337ab7] bg-[#d9edf7] rounded-sm hover:bg-[#d0e6f1]" data-v-d0382835>`);
          _push(ssrRenderComponent(_component_NuxtLink, {
            class: "px-4 py-2 block",
            to: `/topic/${ftag}`
          }, {
            default: withCtx((_, _push2, _parent2, _scopeId) => {
              if (_push2) {
                _push2(`${ssrInterpolate(ftag)}`);
              } else {
                return [
                  createTextVNode(toDisplayString(ftag), 1)
                ];
              }
            }),
            _: 2
          }, _parent));
          _push(`</li>`);
        });
        _push(`<!--]--></ul>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div><div class="hidden md:block md:col-span-2" data-v-d0382835></div></div></div></div><div class="col-span-12 md:col-span-3" data-v-d0382835>`);
      if (unref(DetailRightOneAds).status === 1) {
        _push(`<div class="pb-4 mb-3 border-b border-b-[#e2e2e2]" data-v-d0382835>`);
        _push(ssrRenderComponent(_component_AdsDesktopDetailRightOne, { DetailRightOneAds: unref(DetailRightOneAds) }, null, _parent));
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<div class="${ssrRenderClass(`sticky ${unref(stickyScroll) ? " top-[164px]" : "top-14"} duration-200`)}" data-v-d0382835>`);
      if (((_C = unref(firstMoreContents)) == null ? void 0 : _C.length) > 0) {
        _push(`<div class="${ssrRenderClass(`flex flex-col gap-2`)}" data-v-d0382835><div class="border-b-[3px] border-[#3375af] pb-1" data-v-d0382835><h3 class="text-[#3375af] text-[18px] font-[600]" data-v-d0382835>${ssrInterpolate((_E = (_D = unref(detailsContent)) == null ? void 0 : _D.category) == null ? void 0 : _E.cat_name_bn)} \u09A8\u09BF\u09DF\u09C7 \u0986\u09B0\u0993 \u09AA\u09DC\u09C1\u09A8</h3></div><div class="detail-page-category-content-exept flex flex-col" data-v-d0382835><!--[-->`);
        ssrRenderList(unref(firstMoreContents), (fmoreContent) => {
          var _a3, _b3;
          _push(`<div class="grid grid-cols-12 gap-4 group h-national-excpt border-b py-4" data-v-d0382835><div class="col-span-5 overflow-hidden" data-v-d0382835>`);
          _push(ssrRenderComponent(_component_NuxtLink, {
            to: `/category/${(_a3 = fmoreContent == null ? void 0 : fmoreContent.category) == null ? void 0 : _a3.cat_slug}/${fmoreContent == null ? void 0 : fmoreContent.content_id}`
          }, {
            default: withCtx((_, _push2, _parent2, _scopeId) => {
              if (_push2) {
                _push2(ssrRenderComponent(_component_nuxt_img, {
                  src: `${unref(siteurl).site_url}/media/content/images/${fmoreContent == null ? void 0 : fmoreContent.img_bg_path}`,
                  class: "mx-auto w-full group-hover:scale-110 duration-300",
                  placeholder: unref(img)(`${unref(siteurl).site_url}/logo/placeholder.jpg`)
                }, null, _parent2, _scopeId));
              } else {
                return [
                  createVNode(_component_nuxt_img, {
                    src: `${unref(siteurl).site_url}/media/content/images/${fmoreContent == null ? void 0 : fmoreContent.img_bg_path}`,
                    class: "mx-auto w-full group-hover:scale-110 duration-300",
                    placeholder: unref(img)(`${unref(siteurl).site_url}/logo/placeholder.jpg`)
                  }, null, 8, ["src", "placeholder"])
                ];
              }
            }),
            _: 2
          }, _parent));
          _push(`</div><div class="col-span-7" data-v-d0382835>`);
          _push(ssrRenderComponent(_component_NuxtLink, {
            to: `/category/${(_b3 = fmoreContent == null ? void 0 : fmoreContent.category) == null ? void 0 : _b3.cat_slug}/${fmoreContent == null ? void 0 : fmoreContent.content_id}`
          }, {
            default: withCtx((_, _push2, _parent2, _scopeId) => {
              if (_push2) {
                _push2(`<h4 class="text-[16px] leading-tight group-hover:text-[#ff0000]" data-v-d0382835${_scopeId}>${ssrInterpolate(fmoreContent.content_heading)}</h4>`);
              } else {
                return [
                  createVNode("h4", { class: "text-[16px] leading-tight group-hover:text-[#ff0000]" }, toDisplayString(fmoreContent.content_heading), 1)
                ];
              }
            }),
            _: 2
          }, _parent));
          _push(`</div></div>`);
        });
        _push(`<!--]--></div></div>`);
      } else {
        _push(`<!---->`);
      }
      if (unref(DetailRightTwoAds).status === 1) {
        _push(`<div class="pb-4 mb-3 border-b border-b-[#e2e2e2]" data-v-d0382835>`);
        _push(ssrRenderComponent(_component_AdsDesktopDetailRightTwo, { DetailRightTwoAds: unref(DetailRightTwoAds) }, null, _parent));
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      if (unref(DetailRightThreeAds).status === 1) {
        _push(`<div class="pb-4 mb-3 border-b border-b-[#e2e2e2]" data-v-d0382835>`);
        _push(ssrRenderComponent(_component_AdsDesktopDetailRightThree, { DetailRightThreeAds: unref(DetailRightThreeAds) }, null, _parent));
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div>`);
      if (unref(DetailAfterAds).status === 1) {
        _push(`<div class="col-span-12 py-4 border-b border-t border-b-[#e2e2e2] border-t-[#e2e2e2]" data-v-d0382835>`);
        _push(ssrRenderComponent(_component_AdsDesktopDetailAfter, { DetailAfterAds: unref(DetailAfterAds) }, null, _parent));
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      if (((_F = unref(fRelatedContents)) == null ? void 0 : _F.length) > 0) {
        _push(`<div class="col-span-12" data-v-d0382835><div class="read-more" data-v-d0382835><div class="category-header border-b-4 border-b-[#3375af] my-3" data-v-d0382835><div class="flex gap-3 items-center" data-v-d0382835><span class="w-3 h-3 bg-[#3375af]" data-v-d0382835></span><h2 class="text-[#3375af] text-[18px] font-semibold" data-v-d0382835>\u0986\u09B0\u0993 \u09AA\u09A1\u09BC\u09C1\u09A8</h2></div></div><div class="grid grid-cols-2 md:grid-cols-4 gap-4" data-v-d0382835><!--[-->`);
        ssrRenderList(unref(fRelatedContents).slice(1, 5), (fRelatedContent) => {
          var _a3;
          _push(ssrRenderComponent(_component_NuxtLink, {
            to: `/category/${(_a3 = fRelatedContent == null ? void 0 : fRelatedContent.category) == null ? void 0 : _a3.cat_slug}/${fRelatedContent == null ? void 0 : fRelatedContent.content_id}`,
            class: "flex flex-col gap-2 group",
            key: fRelatedContent.content_id
          }, {
            default: withCtx((_, _push2, _parent2, _scopeId) => {
              if (_push2) {
                _push2(`<div class="feature_image_readmore overflow-hidden" data-v-d0382835${_scopeId}>`);
                _push2(ssrRenderComponent(_component_nuxt_img, {
                  src: `${unref(siteurl).site_url}/media/content/images/${fRelatedContent == null ? void 0 : fRelatedContent.img_bg_path}`,
                  class: "mx-auto w-full group-hover:scale-110 duration-300",
                  placeholder: unref(img)(`${unref(siteurl).site_url}/logo/placeholder.jpg`)
                }, null, _parent2, _scopeId));
                _push2(`</div><h5 class="text-[18px] group-hover:text-[#ff0000]" data-v-d0382835${_scopeId}>${ssrInterpolate(fRelatedContent == null ? void 0 : fRelatedContent.content_heading)}</h5>`);
              } else {
                return [
                  createVNode("div", { class: "feature_image_readmore overflow-hidden" }, [
                    createVNode(_component_nuxt_img, {
                      src: `${unref(siteurl).site_url}/media/content/images/${fRelatedContent == null ? void 0 : fRelatedContent.img_bg_path}`,
                      class: "mx-auto w-full group-hover:scale-110 duration-300",
                      placeholder: unref(img)(`${unref(siteurl).site_url}/logo/placeholder.jpg`)
                    }, null, 8, ["src", "placeholder"])
                  ]),
                  createVNode("h5", { class: "text-[18px] group-hover:text-[#ff0000]" }, toDisplayString(fRelatedContent == null ? void 0 : fRelatedContent.content_heading), 1)
                ];
              }
            }),
            _: 2
          }, _parent));
        });
        _push(`<!--]--></div></div></div>`);
      } else {
        _push(`<!---->`);
      }
      if (unref(DetailBottomAds).status === 1) {
        _push(`<div class="col-span-12 py-4 border-b border-t border-b-[#e2e2e2] border-t-[#e2e2e2]" data-v-d0382835>`);
        _push(ssrRenderComponent(_component_AdsDesktopDetailBottom, { DetailBottomAds: unref(DetailBottomAds) }, null, _parent));
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div>`);
      if (((_G = unref(moreDetailsContents)) == null ? void 0 : _G.length) > 0) {
        _push(`<!--[-->`);
        ssrRenderList(unref(moreDetailsContents), (moreDetailContent, mcinx) => {
          var _a3, _b3, _c3, _d3, _e3, _f3, _g3, _h3, _i3;
          _push(`<div class="border-t pt-8 mt-10 grid grid-cols-12 gap-5 relative d-print" data-v-d0382835><div class="col-span-12 md:col-span-9"${ssrRenderAttr("id", `singlepost${mcinx}`)} data-v-d0382835><div class="single-post flex flex-col gap-3"${ssrRenderAttr("data-title", moreDetailContent == null ? void 0 : moreDetailContent.content_heading)}${ssrRenderAttr("data-nid", moreDetailContent == null ? void 0 : moreDetailContent.content_id)}${ssrRenderAttr("data-description", moreDetailContent == null ? void 0 : moreDetailContent.content_brief)}${ssrRenderAttr("data-keywords", moreDetailContent == null ? void 0 : moreDetailContent.meta_keywords)}${ssrRenderAttr("data-href", `${(_a3 = unref(websiteUrl)) == null ? void 0 : _a3.website_url}/category/${(_b3 = moreDetailContent == null ? void 0 : moreDetailContent.category) == null ? void 0 : _b3.cat_slug}/${moreDetailContent == null ? void 0 : moreDetailContent.content_id}`)}${ssrRenderAttr("data-src", `${(_c3 = unref(siteurl)) == null ? void 0 : _c3.site_url}/api/ogimage/get/${(_d3 = moreDetailContent == null ? void 0 : moreDetailContent.category) == null ? void 0 : _d3.cat_slug}?imgPath=${moreDetailContent == null ? void 0 : moreDetailContent.img_bg_path}`)} data-v-d0382835><div class="singlePost-heading flex flex-col gap-2" data-v-d0382835>`);
          if (moreDetailContent == null ? void 0 : moreDetailContent.content_sub_heading) {
            _push(`<h4 class="text-[20px] text-[#ff0000]" data-v-d0382835>${ssrInterpolate(moreDetailContent == null ? void 0 : moreDetailContent.content_sub_heading)}</h4>`);
          } else {
            _push(`<!---->`);
          }
          _push(`<h2 class="md:text-[32px] md:leading-[50px] print:text-[32px]" data-v-d0382835>${ssrInterpolate(moreDetailContent.content_heading)} ${ssrInterpolate(unref(balvalue))}</h2><div class="h-2 w-12 rounded-md bg-[#3375af] print:hidden" data-v-d0382835></div></div><div class="flex justify-between items-end border-b pb-3" data-v-d0382835>`);
          if (moreDetailContent == null ? void 0 : moreDetailContent.author) {
            _push(`<div class="author-details flex flex-col gap-1" data-v-d0382835>`);
            if (moreDetailContent == null ? void 0 : moreDetailContent.author) {
              _push(`<p data-v-d0382835>`);
              _push(ssrRenderComponent(_component_NuxtLink, {
                class: "hover:text-[#3375af] font-[600]",
                to: `/author/${(_e3 = moreDetailContent == null ? void 0 : moreDetailContent.author) == null ? void 0 : _e3.author_slug}`
              }, {
                default: withCtx((_, _push2, _parent2, _scopeId) => {
                  var _a4, _b4;
                  if (_push2) {
                    _push2(`${ssrInterpolate((_a4 = moreDetailContent == null ? void 0 : moreDetailContent.author) == null ? void 0 : _a4.author_name_bn)}`);
                  } else {
                    return [
                      createTextVNode(toDisplayString((_b4 = moreDetailContent == null ? void 0 : moreDetailContent.author) == null ? void 0 : _b4.author_name_bn), 1)
                    ];
                  }
                }),
                _: 2
              }, _parent));
              _push(`</p>`);
            } else {
              _push(`<p data-v-d0382835>`);
              _push(ssrRenderComponent(_component_NuxtLink, {
                class: "hover:text-[#3375af] font-[600]",
                to: "/author/dhaka-prokash-desk"
              }, {
                default: withCtx((_, _push2, _parent2, _scopeId) => {
                  if (_push2) {
                    _push2(`\u09A2\u09BE\u0995\u09BE\u09AA\u09CD\u09B0\u0995\u09BE\u09B6 \u09A1\u09C7\u09B8\u09CD\u0995`);
                  } else {
                    return [
                      createTextVNode("\u09A2\u09BE\u0995\u09BE\u09AA\u09CD\u09B0\u0995\u09BE\u09B6 \u09A1\u09C7\u09B8\u09CD\u0995")
                    ];
                  }
                }),
                _: 2
              }, _parent));
              _push(`</p>`);
            }
            _push(`<p data-v-d0382835>\u09AA\u09CD\u09B0\u0995\u09BE\u09B6: `);
            _push(ssrRenderComponent(_component_ClientOnly, null, {}, _parent));
            _push(`</p></div>`);
          } else {
            _push(`<!---->`);
          }
          _push(`<div class="social-item flex gap-2 items-start justify-center print:hidden" data-v-d0382835>`);
          _push(ssrRenderComponent(_component_NuxtLink, { to: "/" }, {
            default: withCtx((_, _push2, _parent2, _scopeId) => {
              if (_push2) {
                _push2(`<svg class="hover:scale-125 duration-200" xmlns="http://www.w3.org/2000/svg" height="28" width="28" viewBox="0 0 32 32" enable-background="new 0 0 32 32" xml:space="preserve" data-v-d0382835${_scopeId}><path fill="#1877F2" d="M16,0L16,0c8.837,0,16,7.163,16,16l0,0c0,8.837-7.163,16-16,16l0,0C7.163,32,0,24.837,0,16l0,0 C0,7.163,7.163,0,16,0z" data-v-d0382835${_scopeId}></path><path fill="#FFFFFF" d="M18,17.5h2.5l1-4H18v-2c0-1.03,0-2,2-2h1.5V6.14C21.174,6.097,19.943,6,18.643,6C15.928,6,14,7.657,14,10.7 v2.8h-3v4h3V26h4V17.5z" data-v-d0382835${_scopeId}></path></svg>`);
              } else {
                return [
                  (openBlock(), createBlock("svg", {
                    class: "hover:scale-125 duration-200",
                    xmlns: "http://www.w3.org/2000/svg",
                    height: "28",
                    width: "28",
                    viewBox: "0 0 32 32",
                    "enable-background": "new 0 0 32 32",
                    "xml:space": "preserve"
                  }, [
                    createVNode("path", {
                      fill: "#1877F2",
                      d: "M16,0L16,0c8.837,0,16,7.163,16,16l0,0c0,8.837-7.163,16-16,16l0,0C7.163,32,0,24.837,0,16l0,0 C0,7.163,7.163,0,16,0z"
                    }),
                    createVNode("path", {
                      fill: "#FFFFFF",
                      d: "M18,17.5h2.5l1-4H18v-2c0-1.03,0-2,2-2h1.5V6.14C21.174,6.097,19.943,6,18.643,6C15.928,6,14,7.657,14,10.7 v2.8h-3v4h3V26h4V17.5z"
                    })
                  ]))
                ];
              }
            }),
            _: 2
          }, _parent));
          _push(ssrRenderComponent(_component_NuxtLink, { to: "/" }, {
            default: withCtx((_, _push2, _parent2, _scopeId) => {
              if (_push2) {
                _push2(`<svg class="hover:scale-125 duration-200" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" enable-background="new 0 0 24 24" xml:space="preserve" height="28" width="28" data-v-d0382835${_scopeId}><circle fill="#0F1419" cx="12" cy="12" r="12" data-v-d0382835${_scopeId}></circle><path fill="#FFFFFF" d="M15.531,7h1.662l-3.63,4.236L17.833,17h-3.343l-2.62-3.495L8.876,17H7.212l3.882-4.531L7,7h3.427
l2.366,3.195L15.531,7z M14.947,15.986h0.92L9.926,7.962H8.937L14.947,15.986z" data-v-d0382835${_scopeId}></path></svg>`);
              } else {
                return [
                  (openBlock(), createBlock("svg", {
                    class: "hover:scale-125 duration-200",
                    xmlns: "http://www.w3.org/2000/svg",
                    viewBox: "0 0 24 24",
                    "enable-background": "new 0 0 24 24",
                    "xml:space": "preserve",
                    height: "28",
                    width: "28"
                  }, [
                    createVNode("circle", {
                      fill: "#0F1419",
                      cx: "12",
                      cy: "12",
                      r: "12"
                    }),
                    createVNode("path", {
                      fill: "#FFFFFF",
                      d: "M15.531,7h1.662l-3.63,4.236L17.833,17h-3.343l-2.62-3.495L8.876,17H7.212l3.882-4.531L7,7h3.427\r\nl2.366,3.195L15.531,7z M14.947,15.986h0.92L9.926,7.962H8.937L14.947,15.986z"
                    })
                  ]))
                ];
              }
            }),
            _: 2
          }, _parent));
          _push(`<div class="cursor-pointer" data-v-d0382835><svg class="hover:scale-125 duration-200" height="28" width="28" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32" enable-background="new 0 0 32 32" xml:space="preserve" data-v-d0382835><path fill="#595959" d="M16,0L16,0c8.837,0,16,7.163,16,16l0,0c0,8.837-7.163,16-16,16l0,0C7.163,32,0,24.837,0,16l0,0 C0,7.163,7.163,0,16,0z" data-v-d0382835></path><path fill="#FFFFFF" d="M12,20h8v4h-8V20z M21.6,22.4v-4H10.4v4H8.8c-0.212,0-0.416-0.084-0.566-0.234C8.084,22.016,8,21.812,8,21.6 v-8c0-0.212,0.084-0.416,0.234-0.566C8.384,12.884,8.588,12.8,8.8,12.8h14.4c0.212,0,0.416,0.084,0.566,0.234 C23.916,13.184,24,13.388,24,13.6v8c0,0.212-0.084,0.416-0.234,0.566c-0.15,0.15-0.353,0.234-0.566,0.234H21.6z M10.4,14.4V16h2.4 v-1.6H10.4z M12,8h8c0.212,0,0.416,0.084,0.566,0.234C20.716,8.384,20.8,8.588,20.8,8.8v2.4h-9.6V8.8 c0-0.212,0.084-0.416,0.234-0.566C11.584,8.084,11.788,8,12,8z" data-v-d0382835></path></svg></div></div></div><div class="feature-image border-b" data-v-d0382835>`);
          _push(ssrRenderComponent(_component_nuxt_img, {
            src: `${unref(siteurl).site_url}/media/content/images/${moreDetailContent == null ? void 0 : moreDetailContent.img_bg_path}`,
            class: "mx-auto w-full",
            placeholder: unref(img)(`${unref(siteurl).site_url}/logo/placeholder.jpg`)
          }, null, _parent));
          if (moreDetailContent == null ? void 0 : moreDetailContent.img_bg_caption) {
            _push(`<p class="feature-image-capture text-center py-2" data-v-d0382835>${ssrInterpolate(moreDetailContent == null ? void 0 : moreDetailContent.img_bg_caption)}</p>`);
          } else {
            _push(`<!---->`);
          }
          _push(`</div><div class="singlePost-detail grid grid-cols-12" data-v-d0382835><div class="hidden md:block md:col-span-2" data-v-d0382835></div><div class="col-span-12 md:col-span-8" data-v-d0382835><div class="${ssrRenderClass(`postdetails postdetailinside${mcinx} text-[18px] text-gray-700 pb-4`)}" data-v-d0382835>${moreDetailContent == null ? void 0 : moreDetailContent.content_details}</div>`);
          if (moreDetailContent == null ? void 0 : moreDetailContent.tags) {
            _push(`<div class="category-tags-area flex flex-col gap-4 border-b border-t pb-4 pt-3 print:hidden" data-v-d0382835>`);
            _push(ssrRenderComponent(_component_NuxtLink, {
              to: `/${(_f3 = moreDetailContent == null ? void 0 : moreDetailContent.category) == null ? void 0 : _f3.cat_slug}`,
              class: "text-[18px] py-1"
            }, {
              default: withCtx((_, _push2, _parent2, _scopeId) => {
                var _a4, _b4;
                if (_push2) {
                  _push2(`<span class="py-1 font-semibold border-b-2 border-[#3375af] text-[#3375af]" data-v-d0382835${_scopeId}>${ssrInterpolate((_a4 = moreDetailContent == null ? void 0 : moreDetailContent.category) == null ? void 0 : _a4.cat_name_bn)}</span> \u09A5\u09C7\u0995\u09C7 \u0986\u09B0\u0993 \u09AA\u09DC\u09C1\u09A8`);
                } else {
                  return [
                    createVNode("span", { class: "py-1 font-semibold border-b-2 border-[#3375af] text-[#3375af]" }, toDisplayString((_b4 = moreDetailContent == null ? void 0 : moreDetailContent.category) == null ? void 0 : _b4.cat_name_bn), 1),
                    createTextVNode(" \u09A5\u09C7\u0995\u09C7 \u0986\u09B0\u0993 \u09AA\u09DC\u09C1\u09A8")
                  ];
                }
              }),
              _: 2
            }, _parent));
            _push(`<ul class="flex flex-wrap gap-3 items-center" data-v-d0382835><!--[-->`);
            ssrRenderList(moreDetailContent == null ? void 0 : moreDetailContent.tags.split(","), (mtag) => {
              _push(`<li class="text-[#337ab7] bg-[#d9edf7] rounded-sm hover:bg-[#d0e6f1]" data-v-d0382835>`);
              _push(ssrRenderComponent(_component_NuxtLink, {
                class: "px-4 py-2 block",
                to: `/topic/${mtag}`
              }, {
                default: withCtx((_, _push2, _parent2, _scopeId) => {
                  if (_push2) {
                    _push2(`${ssrInterpolate(mtag)}`);
                  } else {
                    return [
                      createTextVNode(toDisplayString(mtag), 1)
                    ];
                  }
                }),
                _: 2
              }, _parent));
              _push(`</li>`);
            });
            _push(`<!--]--></ul></div>`);
          } else {
            _push(`<!---->`);
          }
          _push(`</div><div class="hidden md:block md:col-span-2" data-v-d0382835></div></div></div></div><div class="col-span-12 md:col-span-3" data-v-d0382835>`);
          if (unref(DetailRightOneAds).status === 1) {
            _push(`<div class="pb-4 mb-3 border-b border-b-[#e2e2e2]" data-v-d0382835>`);
            _push(ssrRenderComponent(_component_AdsDesktopDetailRightOne, { DetailRightOneAds: unref(DetailRightOneAds) }, null, _parent));
            _push(`</div>`);
          } else {
            _push(`<!---->`);
          }
          _push(`<div class="${ssrRenderClass(`sticky ${unref(stickyScroll) ? " top-[164px]" : "top-14"} duration-200`)}" data-v-d0382835>`);
          if (((_g3 = unref(moreDetailsContents)) == null ? void 0 : _g3.length) > 0) {
            _push(`<div class="${ssrRenderClass(`flex flex-col gap-2`)}" data-v-d0382835><div class="border-b-[3px] border-[#3375af] pb-1" data-v-d0382835><h3 class="text-[#3375af] text-[18px] font-[600]" data-v-d0382835>${ssrInterpolate((_h3 = moreDetailContent == null ? void 0 : moreDetailContent.category) == null ? void 0 : _h3.cat_name_bn)} \u09A8\u09BF\u09DF\u09C7 \u0986\u09B0\u0993 \u09AA\u09DC\u09C1\u09A8</h3></div><div class="detail-page-category-content-exept flex flex-col" data-v-d0382835><!--[-->`);
            ssrRenderList(unref(moreDetailCatWisePost)[mcinx], (moreDetCatCon) => {
              var _a4, _b4;
              _push(`<div class="grid grid-cols-12 gap-4 group h-national-excpt border-b py-4" data-v-d0382835><div class="col-span-5 overflow-hidden" data-v-d0382835>`);
              _push(ssrRenderComponent(_component_NuxtLink, {
                to: `/category/${(_a4 = moreDetCatCon == null ? void 0 : moreDetCatCon.category) == null ? void 0 : _a4.cat_slug}/${moreDetCatCon == null ? void 0 : moreDetCatCon.content_id}`
              }, {
                default: withCtx((_, _push2, _parent2, _scopeId) => {
                  if (_push2) {
                    _push2(ssrRenderComponent(_component_nuxt_img, {
                      src: `${unref(siteurl).site_url}/media/content/images/${moreDetCatCon == null ? void 0 : moreDetCatCon.img_bg_path}`,
                      class: "mx-auto w-full group-hover:scale-110 duration-300",
                      placeholder: unref(img)(`${unref(siteurl).site_url}/logo/placeholder.jpg`)
                    }, null, _parent2, _scopeId));
                  } else {
                    return [
                      createVNode(_component_nuxt_img, {
                        src: `${unref(siteurl).site_url}/media/content/images/${moreDetCatCon == null ? void 0 : moreDetCatCon.img_bg_path}`,
                        class: "mx-auto w-full group-hover:scale-110 duration-300",
                        placeholder: unref(img)(`${unref(siteurl).site_url}/logo/placeholder.jpg`)
                      }, null, 8, ["src", "placeholder"])
                    ];
                  }
                }),
                _: 2
              }, _parent));
              _push(`</div><div class="col-span-7" data-v-d0382835>`);
              _push(ssrRenderComponent(_component_NuxtLink, {
                to: `/category/${(_b4 = moreDetCatCon == null ? void 0 : moreDetCatCon.category) == null ? void 0 : _b4.cat_slug}/${moreDetCatCon == null ? void 0 : moreDetCatCon.content_id}`
              }, {
                default: withCtx((_, _push2, _parent2, _scopeId) => {
                  if (_push2) {
                    _push2(`<h4 class="text-[16px] leading-tight group-hover:text-[#ff0000]" data-v-d0382835${_scopeId}>${ssrInterpolate(moreDetCatCon.content_heading)}</h4>`);
                  } else {
                    return [
                      createVNode("h4", { class: "text-[16px] leading-tight group-hover:text-[#ff0000]" }, toDisplayString(moreDetCatCon.content_heading), 1)
                    ];
                  }
                }),
                _: 2
              }, _parent));
              _push(`</div></div>`);
            });
            _push(`<!--]--></div></div>`);
          } else {
            _push(`<!---->`);
          }
          if (unref(DetailRightTwoAds).status === 1) {
            _push(`<div class="pb-4 mb-3 border-b border-b-[#e2e2e2]" data-v-d0382835>`);
            _push(ssrRenderComponent(_component_AdsDesktopDetailRightTwo, { DetailRightTwoAds: unref(DetailRightTwoAds) }, null, _parent));
            _push(`</div>`);
          } else {
            _push(`<!---->`);
          }
          if (unref(DetailRightThreeAds).status === 1) {
            _push(`<div class="pb-4 mb-3 border-b border-b-[#e2e2e2]" data-v-d0382835>`);
            _push(ssrRenderComponent(_component_AdsDesktopDetailRightThree, { DetailRightThreeAds: unref(DetailRightThreeAds) }, null, _parent));
            _push(`</div>`);
          } else {
            _push(`<!---->`);
          }
          _push(`</div></div>`);
          if (unref(DetailAfterAds).status === 1) {
            _push(`<div class="col-span-12 py-4 border-b border-t border-b-[#e2e2e2] border-t-[#e2e2e2]" data-v-d0382835>`);
            _push(ssrRenderComponent(_component_AdsDesktopDetailAfter, { DetailAfterAds: unref(DetailAfterAds) }, null, _parent));
            _push(`</div>`);
          } else {
            _push(`<!---->`);
          }
          if (((_i3 = unref(relatedDetailContent)) == null ? void 0 : _i3.length) > 0 && mcinx !== 2) {
            _push(`<div class="col-span-12" data-v-d0382835><div class="read-more" data-v-d0382835><div class="category-header border-b-4 border-b-[#3375af] my-3" data-v-d0382835><div class="flex gap-3 items-center" data-v-d0382835><span class="w-3 h-3 bg-[#3375af]" data-v-d0382835></span><h2 class="text-[#3375af] text-[18px] font-semibold" data-v-d0382835>\u0986\u09B0\u0993 \u09AA\u09A1\u09BC\u09C1\u09A8</h2></div></div><div class="grid grid-cols-2 md:grid-cols-4 gap-4" data-v-d0382835><!--[-->`);
            ssrRenderList(unref(relatedDetailContent)[mcinx], (relDetailContent) => {
              var _a4;
              _push(ssrRenderComponent(_component_NuxtLink, {
                to: `/category/${(_a4 = relDetailContent == null ? void 0 : relDetailContent.category) == null ? void 0 : _a4.cat_slug}/${relDetailContent == null ? void 0 : relDetailContent.content_id}`,
                class: "flex flex-col gap-2 group",
                key: relDetailContent.content_id
              }, {
                default: withCtx((_, _push2, _parent2, _scopeId) => {
                  if (_push2) {
                    _push2(`<div class="feature_image_readmore overflow-hidden" data-v-d0382835${_scopeId}>`);
                    _push2(ssrRenderComponent(_component_nuxt_img, {
                      src: `${unref(siteurl).site_url}/media/content/images/${relDetailContent == null ? void 0 : relDetailContent.img_bg_path}`,
                      class: "mx-auto w-full group-hover:scale-110 duration-300",
                      placeholder: unref(img)(`${unref(siteurl).site_url}/logo/placeholder.jpg`)
                    }, null, _parent2, _scopeId));
                    _push2(`</div><h5 class="text-[18px] group-hover:text-[#ff0000]" data-v-d0382835${_scopeId}>${ssrInterpolate(relDetailContent == null ? void 0 : relDetailContent.content_heading)}</h5>`);
                  } else {
                    return [
                      createVNode("div", { class: "feature_image_readmore overflow-hidden" }, [
                        createVNode(_component_nuxt_img, {
                          src: `${unref(siteurl).site_url}/media/content/images/${relDetailContent == null ? void 0 : relDetailContent.img_bg_path}`,
                          class: "mx-auto w-full group-hover:scale-110 duration-300",
                          placeholder: unref(img)(`${unref(siteurl).site_url}/logo/placeholder.jpg`)
                        }, null, 8, ["src", "placeholder"])
                      ]),
                      createVNode("h5", { class: "text-[18px] group-hover:text-[#ff0000]" }, toDisplayString(relDetailContent == null ? void 0 : relDetailContent.content_heading), 1)
                    ];
                  }
                }),
                _: 2
              }, _parent));
            });
            _push(`<!--]--></div></div></div>`);
          } else {
            _push(`<div class="col-span-12" data-v-d0382835><div class="read-more" data-v-d0382835><div class="category-header border-b-4 border-b-[#3375af] my-3" data-v-d0382835><div class="flex gap-3 items-center" data-v-d0382835><span class="w-3 h-3 bg-[#3375af]" data-v-d0382835></span><h2 class="text-[#3375af] text-[18px] font-semibold" data-v-d0382835>\u09B8\u09B0\u09CD\u09AC\u09B6\u09C7\u09B7 \u09B8\u0982\u09AC\u09BE\u09A6</h2></div></div><div class="grid grid-cols-2 md:grid-cols-4 gap-4" data-v-d0382835><!--[-->`);
            ssrRenderList(unref(latestPostsDpage), (latestPostC) => {
              var _a4;
              _push(ssrRenderComponent(_component_NuxtLink, {
                to: `/category/${(_a4 = latestPostC == null ? void 0 : latestPostC.category) == null ? void 0 : _a4.cat_slug}/${latestPostC == null ? void 0 : latestPostC.content_id}`,
                class: "flex flex-col gap-2 group",
                key: latestPostC.content_id
              }, {
                default: withCtx((_, _push2, _parent2, _scopeId) => {
                  if (_push2) {
                    _push2(`<div class="feature_image_readmore overflow-hidden" data-v-d0382835${_scopeId}>`);
                    _push2(ssrRenderComponent(_component_nuxt_img, {
                      src: `${unref(siteurl).site_url}/media/content/images/${latestPostC == null ? void 0 : latestPostC.img_bg_path}`,
                      class: "mx-auto w-full group-hover:scale-110 duration-300",
                      placeholder: unref(img)(`${unref(siteurl).site_url}/logo/placeholder.jpg`)
                    }, null, _parent2, _scopeId));
                    _push2(`</div><h5 class="text-[18px] group-hover:text-[#ff0000]" data-v-d0382835${_scopeId}>${ssrInterpolate(latestPostC == null ? void 0 : latestPostC.content_heading)}</h5>`);
                  } else {
                    return [
                      createVNode("div", { class: "feature_image_readmore overflow-hidden" }, [
                        createVNode(_component_nuxt_img, {
                          src: `${unref(siteurl).site_url}/media/content/images/${latestPostC == null ? void 0 : latestPostC.img_bg_path}`,
                          class: "mx-auto w-full group-hover:scale-110 duration-300",
                          placeholder: unref(img)(`${unref(siteurl).site_url}/logo/placeholder.jpg`)
                        }, null, 8, ["src", "placeholder"])
                      ]),
                      createVNode("h5", { class: "text-[18px] group-hover:text-[#ff0000]" }, toDisplayString(latestPostC == null ? void 0 : latestPostC.content_heading), 1)
                    ];
                  }
                }),
                _: 2
              }, _parent));
            });
            _push(`<!--]--></div></div></div>`);
          }
          if (unref(DetailBottomAds).status === 1) {
            _push(`<div class="col-span-12 py-4 border-b border-t border-b-[#e2e2e2] border-t-[#e2e2e2]" data-v-d0382835>`);
            _push(ssrRenderComponent(_component_AdsDesktopDetailBottom, { DetailBottomAds: unref(DetailBottomAds) }, null, _parent));
            _push(`</div>`);
          } else {
            _push(`<!---->`);
          }
          _push(`</div>`);
        });
        _push(`<!--]-->`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/category/[category_slug]/[content_id].vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const _content_id_ = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-d0382835"]]);

export { _content_id_ as default };
//# sourceMappingURL=_content_id_-542ec72f.mjs.map
