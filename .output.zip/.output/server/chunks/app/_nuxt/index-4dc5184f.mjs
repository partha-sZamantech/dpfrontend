import { H as Head, T as Title } from './components-5bc40629.mjs';
import { _ as __nuxt_component_0 } from './nuxt-link-c659c711.mjs';
import { u as useImage, s as siteUrlState, a as singlePageStickyState, b as useFetch, _ as __nuxt_component_1 } from './state-7a7e2860.mjs';
import { _ as __nuxt_component_4 } from './client-only-0841c2aa.mjs';
import { _ as __nuxt_component_6 } from './Tabs-8fde547c.mjs';
import { computed, ref, withAsyncContext, mergeProps, withCtx, unref, createTextVNode, toDisplayString, createVNode, useSSRContext } from 'vue';
import { _ as _export_sfc, u as useRoute } from '../server.mjs';
import { u as useState } from './state-b54abad0.mjs';
import { ssrRenderAttrs, ssrRenderComponent, ssrInterpolate, ssrRenderAttr, ssrRenderList } from 'vue/server-renderer';
import { _ as _imports_0 } from './bar-ads-359c1719.mjs';
import './index-6a088328.mjs';
import '@unhead/shared';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'ipx';
import 'unhead';
import 'vue-router';
import '../../handlers/renderer.mjs';
import 'vue-bundle-renderer/runtime';
import 'devalue';
import '@unhead/ssr';

const _sfc_main = {
  __name: "index",
  __ssrInlineRender: true,
  async setup(__props) {
    var _a, _b, _c, _d;
    let __temp, __restore;
    const img = useImage();
    const siteurl = siteUrlState();
    const singlePageSticky = singlePageStickyState();
    const stickyScroll = computed(
      () => singlePageSticky.value
    );
    const getDate = new Intl.DateTimeFormat("bn-bd", { year: "numeric", month: "long", day: "numeric", hour: "numeric", minute: "numeric" });
    const postCreatedDate = (date) => {
      if (date) {
        return getDate.format(new Date(date)).replace("\u098F", "|").replace("PM", "\u09AA\u09BF\u098F\u09AE").replace("AM", "\u098F\u098F\u09AE");
      }
    };
    const subcat_slug = useRoute().params.subcategory;
    const cat_slug = useRoute().params.category;
    const subcategoryContents = useState(() => [], "$zQGG5GH4oe");
    const subcategoryContentExcept = useState(() => [], "$L5QBxR0b20");
    const category = ref(null);
    const subcategory = ref(null);
    const take = ref(15);
    const { data: subctcont } = ([__temp, __restore] = withAsyncContext(() => useFetch("/api/subcatcontent/subcatcontent", {
      method: "POST",
      body: {
        cat_slug,
        subcat_slug,
        take: take.value
      }
    }, "$4S2dGFHCcx")), __temp = await __temp, __restore(), __temp);
    category.value = (_a = subctcont == null ? void 0 : subctcont.value) == null ? void 0 : _a.category;
    subcategoryContents.value = (_b = subctcont == null ? void 0 : subctcont.value) == null ? void 0 : _b.contents;
    subcategory.value = (_c = subctcont == null ? void 0 : subctcont.value) == null ? void 0 : _c.subcategory;
    subcategoryContentExcept.value = (_d = subctcont == null ? void 0 : subctcont.value) == null ? void 0 : _d.contents.slice(5, take.value);
    return (_ctx, _push, _parent, _attrs) => {
      var _a2, _b2, _c2, _d2, _e, _f, _g, _h, _i, _j, _k, _l, _m, _n, _o, _p, _q, _r, _s, _t, _u;
      const _component_Head = Head;
      const _component_Title = Title;
      const _component_NuxtLink = __nuxt_component_0;
      const _component_nuxt_img = __nuxt_component_1;
      const _component_ClientOnly = __nuxt_component_4;
      const _component_Tabs = __nuxt_component_6;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "category-page" }, _attrs))} data-v-45f2cca3>`);
      _push(ssrRenderComponent(_component_Head, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_Title, null, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`${ssrInterpolate(unref(subcategory).subcat_name_bn)}`);
                } else {
                  return [
                    createTextVNode(toDisplayString(unref(subcategory).subcat_name_bn), 1)
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_Title, null, {
                default: withCtx(() => [
                  createTextVNode(toDisplayString(unref(subcategory).subcat_name_bn), 1)
                ]),
                _: 1
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<div class="category-ads-section border-b border-b-[#dee2e6] py-4" data-v-45f2cca3><div class="bg-[#f7f7f7]" data-v-45f2cca3><a target="_blank" href="/" data-v-45f2cca3><img class="mx-auto"${ssrRenderAttr("src", _imports_0)} alt="" data-v-45f2cca3></a></div></div><div class="max-w-[1280px] mx-auto category-content px-4 md:px-2 py-4 relative" data-v-45f2cca3><div class="breadcrump border-b border-b-[#dee2e6] pb-2 mb-5 flex flex-col gap-2 md:gap-2" data-v-45f2cca3><div class="flex gap-1 justify-start items-center" data-v-45f2cca3>`);
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: `/${(_a2 = unref(category)) == null ? void 0 : _a2.cat_slug}`,
        class: "font-semibold"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          var _a3, _b3;
          if (_push2) {
            _push2(`<h1 class="text-xl md:text-xl border-b text-[#000000] hover:text-[#3375af] hover:border-b-[#3375af]" data-v-45f2cca3${_scopeId}>${ssrInterpolate((_a3 = unref(category)) == null ? void 0 : _a3.cat_name_bn)}</h1>`);
          } else {
            return [
              createVNode("h1", { class: "text-xl md:text-xl border-b text-[#000000] hover:text-[#3375af] hover:border-b-[#3375af]" }, toDisplayString((_b3 = unref(category)) == null ? void 0 : _b3.cat_name_bn), 1)
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div><div class="flex flex-col gap-4" data-v-45f2cca3>`);
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: `/${(_b2 = unref(category)) == null ? void 0 : _b2.cat_slug}/${unref(subcat_slug)}`,
        class: "text-[#3375af] font-semibold"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<h1 class="text-xl md:text-3xl" data-v-45f2cca3${_scopeId}>${ssrInterpolate(unref(subcategory).subcat_name_bn)}</h1>`);
          } else {
            return [
              createVNode("h1", { class: "text-xl md:text-3xl" }, toDisplayString(unref(subcategory).subcat_name_bn), 1)
            ];
          }
        }),
        _: 1
      }, _parent));
      if (((_d2 = (_c2 = unref(category)) == null ? void 0 : _c2.subcat) == null ? void 0 : _d2.length) > 0) {
        _push(`<div class="subcategory flex flex-wrap gap-3" data-v-45f2cca3><!--[-->`);
        ssrRenderList((_e = unref(category)) == null ? void 0 : _e.subcat, (subcat) => {
          var _a3, _b3;
          _push(`<div class="subcategoryLink" data-v-45f2cca3>`);
          _push(ssrRenderComponent(_component_NuxtLink, {
            to: `/${(_a3 = unref(category)) == null ? void 0 : _a3.cat_slug}/${subcat == null ? void 0 : subcat.subcat_slug}`,
            class: `${((_b3 = unref(subcategory)) == null ? void 0 : _b3.subcat_name_bn) === (subcat == null ? void 0 : subcat.subcat_name_bn) && "text-[#3375af]"} text-[#121212] font-[600] text-sm md:text-[16px] hover:text-[#3375af]`
          }, {
            default: withCtx((_, _push2, _parent2, _scopeId) => {
              if (_push2) {
                _push2(`${ssrInterpolate(subcat == null ? void 0 : subcat.subcat_name_bn)}`);
              } else {
                return [
                  createTextVNode(toDisplayString(subcat == null ? void 0 : subcat.subcat_name_bn), 1)
                ];
              }
            }),
            _: 2
          }, _parent));
          _push(`</div>`);
        });
        _push(`<!--]--></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div><div class="grid grid-cols-12 gap-8 md:gap-3" data-v-45f2cca3>`);
      if (unref(subcategoryContents)[0]) {
        _push(`<div class="col-span-12 md:col-span-9 md:border-r md:pr-3" data-v-45f2cca3><div class="grid grid-cols-12 border-b border-b-[#dee2e6] pb-4" data-v-45f2cca3><div class="col-span-12 md:col-span-8 md:pr-3 mb-1 md:mb-0" data-v-45f2cca3><div class="lead-post md:h-[328px] group overflow-hidden" data-v-45f2cca3>`);
        _push(ssrRenderComponent(_component_NuxtLink, {
          to: `/category/${(_g = (_f = unref(subcategoryContents)[0]) == null ? void 0 : _f.category) == null ? void 0 : _g.cat_slug}/${(_h = unref(subcategoryContents)[0]) == null ? void 0 : _h.content_id}`,
          class: "relative"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            var _a3, _b3, _c3, _d3;
            if (_push2) {
              _push2(ssrRenderComponent(_component_nuxt_img, {
                src: `${unref(siteurl).site_url}/media/content/images/${(_a3 = unref(subcategoryContents)[0]) == null ? void 0 : _a3.img_bg_path}`,
                class: "mx-auto w-full group-hover:scale-110 duration-300 md:h-full",
                placeholder: unref(img)(`${unref(siteurl).site_url}/logo/placeholder.jpg`)
              }, null, _parent2, _scopeId));
              _push2(`<div class="lead-overly absolute h-full w-full block top-0" data-v-45f2cca3${_scopeId}><h5 class="img-title leading-8 text-white group-hover:text-[#ff0000] text-[18px] md:text-[24px] absolute bottom-4 left-6" data-v-45f2cca3${_scopeId}>${ssrInterpolate((_b3 = unref(subcategoryContents)[0]) == null ? void 0 : _b3.content_heading)}</h5></div>`);
            } else {
              return [
                createVNode(_component_nuxt_img, {
                  src: `${unref(siteurl).site_url}/media/content/images/${(_c3 = unref(subcategoryContents)[0]) == null ? void 0 : _c3.img_bg_path}`,
                  class: "mx-auto w-full group-hover:scale-110 duration-300 md:h-full",
                  placeholder: unref(img)(`${unref(siteurl).site_url}/logo/placeholder.jpg`)
                }, null, 8, ["src", "placeholder"]),
                createVNode("div", { class: "lead-overly absolute h-full w-full block top-0" }, [
                  createVNode("h5", { class: "img-title leading-8 text-white group-hover:text-[#ff0000] text-[18px] md:text-[24px] absolute bottom-4 left-6" }, toDisplayString((_d3 = unref(subcategoryContents)[0]) == null ? void 0 : _d3.content_heading), 1)
                ])
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(`</div></div>`);
        if (unref(subcategoryContents)[1]) {
          _push(`<div class="col-span-12 md:col-span-4 border-t mt-2 md:mt-0 pt-3 md:pt-0 md:border-t-0 md:pl-3 md:border-l border-l-[#dee2e6]" data-v-45f2cca3>`);
          _push(ssrRenderComponent(_component_NuxtLink, {
            to: `/category/${(_j = (_i = unref(subcategoryContents)[1]) == null ? void 0 : _i.category) == null ? void 0 : _j.cat_slug}/${(_k = unref(subcategoryContents)[1]) == null ? void 0 : _k.content_id}`,
            class: "categorypost-2 group"
          }, {
            default: withCtx((_, _push2, _parent2, _scopeId) => {
              var _a3, _b3, _c3, _d3, _e2, _f2;
              if (_push2) {
                _push2(`<div class="cat-feature-image overflow-hidden" data-v-45f2cca3${_scopeId}>`);
                _push2(ssrRenderComponent(_component_nuxt_img, {
                  src: `${unref(siteurl).site_url}/media/content/images/${(_a3 = unref(subcategoryContents)[1]) == null ? void 0 : _a3.img_bg_path}`,
                  class: "mx-auto w-full group-hover:scale-110 duration-300 h-full",
                  placeholder: unref(img)(`${unref(siteurl).site_url}/logo/placeholder.jpg`)
                }, null, _parent2, _scopeId));
                _push2(`</div><div class="flex flex-col gap-3 mt-2" data-v-45f2cca3${_scopeId}><h3 class="cat-postheading text-xl group-hover:text-[#ff0000] leading-[24px] text-[#121212]" data-v-45f2cca3${_scopeId}>${ssrInterpolate((_b3 = unref(subcategoryContents)[1]) == null ? void 0 : _b3.content_heading)}</h3>`);
                _push2(ssrRenderComponent(_component_ClientOnly, null, {}, _parent2, _scopeId));
                _push2(`<small class="cat-postdate" data-v-45f2cca3${_scopeId}> \u09AA\u09CD\u09B0\u0995\u09BE\u09B6: ${ssrInterpolate(postCreatedDate((_c3 = unref(subcategoryContents)[1]) == null ? void 0 : _c3.created_at))}</small></div>`);
              } else {
                return [
                  createVNode("div", { class: "cat-feature-image overflow-hidden" }, [
                    createVNode(_component_nuxt_img, {
                      src: `${unref(siteurl).site_url}/media/content/images/${(_d3 = unref(subcategoryContents)[1]) == null ? void 0 : _d3.img_bg_path}`,
                      class: "mx-auto w-full group-hover:scale-110 duration-300 h-full",
                      placeholder: unref(img)(`${unref(siteurl).site_url}/logo/placeholder.jpg`)
                    }, null, 8, ["src", "placeholder"])
                  ]),
                  createVNode("div", { class: "flex flex-col gap-3 mt-2" }, [
                    createVNode("h3", { class: "cat-postheading text-xl group-hover:text-[#ff0000] leading-[24px] text-[#121212]" }, toDisplayString((_e2 = unref(subcategoryContents)[1]) == null ? void 0 : _e2.content_heading), 1),
                    createVNode(_component_ClientOnly, null, {
                      default: withCtx(() => {
                        var _a4;
                        return [
                          createVNode("div", {
                            class: "cat-postdesc text-[15px] font-[300] text-[#555555]",
                            innerHTML: `${(_a4 = unref(subcategoryContents)[1]) == null ? void 0 : _a4.content_details.substring(0, 155)}...`
                          }, null, 8, ["innerHTML"])
                        ];
                      }),
                      _: 1
                    }),
                    createVNode("small", { class: "cat-postdate" }, " \u09AA\u09CD\u09B0\u0995\u09BE\u09B6: " + toDisplayString(postCreatedDate((_f2 = unref(subcategoryContents)[1]) == null ? void 0 : _f2.created_at)), 1)
                  ])
                ];
              }
            }),
            _: 1
          }, _parent));
          _push(`</div>`);
        } else {
          _push(`<!---->`);
        }
        _push(`</div><div class="grid grid-cols-12 gap-4 md:gap-0 py-4 border-b border-b-[#dee2e6]" data-v-45f2cca3>`);
        if (unref(subcategoryContents)[2]) {
          _push(ssrRenderComponent(_component_NuxtLink, {
            to: `/category/${(_m = (_l = unref(subcategoryContents)[2]) == null ? void 0 : _l.category) == null ? void 0 : _m.cat_slug}/${(_n = unref(subcategoryContents)[2]) == null ? void 0 : _n.content_id}`,
            class: "cat-box group md:pr-3 md:border-r border-r-[#dee2e6] col-span-12 md:col-span-4"
          }, {
            default: withCtx((_, _push2, _parent2, _scopeId) => {
              var _a3, _b3, _c3, _d3, _e2, _f2;
              if (_push2) {
                _push2(`<div class="cat-box-image overflow-hidden" data-v-45f2cca3${_scopeId}>`);
                _push2(ssrRenderComponent(_component_nuxt_img, {
                  src: `${unref(siteurl).site_url}/media/content/images/${(_a3 = unref(subcategoryContents)[2]) == null ? void 0 : _a3.img_bg_path}`,
                  class: "mx-auto w-full group-hover:scale-110 duration-300 h-full",
                  placeholder: unref(img)(`${unref(siteurl).site_url}/logo/placeholder.jpg`)
                }, null, _parent2, _scopeId));
                _push2(`</div><div class="flex flex-col gap-3 mt-2" data-v-45f2cca3${_scopeId}><h3 class="cat-postheading text-xl group-hover:text-[#ff0000] leading-[24px] text-[#121212]" data-v-45f2cca3${_scopeId}>${ssrInterpolate((_b3 = unref(subcategoryContents)[2]) == null ? void 0 : _b3.content_heading)}</h3>`);
                _push2(ssrRenderComponent(_component_ClientOnly, null, {}, _parent2, _scopeId));
                _push2(`<small class="cat-postdate" data-v-45f2cca3${_scopeId}> \u09AA\u09CD\u09B0\u0995\u09BE\u09B6: ${ssrInterpolate(postCreatedDate((_c3 = unref(subcategoryContents)[2]) == null ? void 0 : _c3.created_at))}</small></div>`);
              } else {
                return [
                  createVNode("div", { class: "cat-box-image overflow-hidden" }, [
                    createVNode(_component_nuxt_img, {
                      src: `${unref(siteurl).site_url}/media/content/images/${(_d3 = unref(subcategoryContents)[2]) == null ? void 0 : _d3.img_bg_path}`,
                      class: "mx-auto w-full group-hover:scale-110 duration-300 h-full",
                      placeholder: unref(img)(`${unref(siteurl).site_url}/logo/placeholder.jpg`)
                    }, null, 8, ["src", "placeholder"])
                  ]),
                  createVNode("div", { class: "flex flex-col gap-3 mt-2" }, [
                    createVNode("h3", { class: "cat-postheading text-xl group-hover:text-[#ff0000] leading-[24px] text-[#121212]" }, toDisplayString((_e2 = unref(subcategoryContents)[2]) == null ? void 0 : _e2.content_heading), 1),
                    createVNode(_component_ClientOnly, null, {
                      default: withCtx(() => {
                        var _a4;
                        return [
                          createVNode("div", {
                            class: "cat-postdesc text-[15px] font-[300] text-[#555555]",
                            innerHTML: `${(_a4 = unref(subcategoryContents)[2]) == null ? void 0 : _a4.content_details.substring(0, 155)}...`
                          }, null, 8, ["innerHTML"])
                        ];
                      }),
                      _: 1
                    }),
                    createVNode("small", { class: "cat-postdate" }, " \u09AA\u09CD\u09B0\u0995\u09BE\u09B6: " + toDisplayString(postCreatedDate((_f2 = unref(subcategoryContents)[2]) == null ? void 0 : _f2.created_at)), 1)
                  ])
                ];
              }
            }),
            _: 1
          }, _parent));
        } else {
          _push(`<!---->`);
        }
        if (unref(subcategoryContents)[3]) {
          _push(ssrRenderComponent(_component_NuxtLink, {
            to: `/category/${(_p = (_o = unref(subcategoryContents)[3]) == null ? void 0 : _o.category) == null ? void 0 : _p.cat_slug}/${(_q = unref(subcategoryContents)[3]) == null ? void 0 : _q.content_id}`,
            class: "cat-box group md:px-3 md:border-r border-r-[#dee2e6] col-span-12 md:col-span-4"
          }, {
            default: withCtx((_, _push2, _parent2, _scopeId) => {
              var _a3, _b3, _c3, _d3, _e2, _f2;
              if (_push2) {
                _push2(`<div class="cat-box-image overflow-hidden" data-v-45f2cca3${_scopeId}>`);
                _push2(ssrRenderComponent(_component_nuxt_img, {
                  src: `${unref(siteurl).site_url}/media/content/images/${(_a3 = unref(subcategoryContents)[3]) == null ? void 0 : _a3.img_bg_path}`,
                  class: "mx-auto w-full group-hover:scale-110 duration-300 h-full",
                  placeholder: unref(img)(`${unref(siteurl).site_url}/logo/placeholder.jpg`)
                }, null, _parent2, _scopeId));
                _push2(`</div><div class="flex flex-col gap-3 mt-2" data-v-45f2cca3${_scopeId}><h3 class="cat-postheading text-xl group-hover:text-[#ff0000] leading-[24px] text-[#121212]" data-v-45f2cca3${_scopeId}>${ssrInterpolate((_b3 = unref(subcategoryContents)[3]) == null ? void 0 : _b3.content_heading)}</h3>`);
                _push2(ssrRenderComponent(_component_ClientOnly, null, {}, _parent2, _scopeId));
                _push2(`<small class="cat-postdate" data-v-45f2cca3${_scopeId}> \u09AA\u09CD\u09B0\u0995\u09BE\u09B6: ${ssrInterpolate(postCreatedDate((_c3 = unref(subcategoryContents)[3]) == null ? void 0 : _c3.created_at))}</small></div>`);
              } else {
                return [
                  createVNode("div", { class: "cat-box-image overflow-hidden" }, [
                    createVNode(_component_nuxt_img, {
                      src: `${unref(siteurl).site_url}/media/content/images/${(_d3 = unref(subcategoryContents)[3]) == null ? void 0 : _d3.img_bg_path}`,
                      class: "mx-auto w-full group-hover:scale-110 duration-300 h-full",
                      placeholder: unref(img)(`${unref(siteurl).site_url}/logo/placeholder.jpg`)
                    }, null, 8, ["src", "placeholder"])
                  ]),
                  createVNode("div", { class: "flex flex-col gap-3 mt-2" }, [
                    createVNode("h3", { class: "cat-postheading text-xl group-hover:text-[#ff0000] leading-[24px] text-[#121212]" }, toDisplayString((_e2 = unref(subcategoryContents)[3]) == null ? void 0 : _e2.content_heading), 1),
                    createVNode(_component_ClientOnly, null, {
                      default: withCtx(() => {
                        var _a4;
                        return [
                          createVNode("div", {
                            class: "cat-postdesc text-[15px] font-[300] text-[#555555]",
                            innerHTML: `${(_a4 = unref(subcategoryContents)[3]) == null ? void 0 : _a4.content_details.substring(0, 155)}...`
                          }, null, 8, ["innerHTML"])
                        ];
                      }),
                      _: 1
                    }),
                    createVNode("small", { class: "cat-postdate" }, " \u09AA\u09CD\u09B0\u0995\u09BE\u09B6: " + toDisplayString(postCreatedDate((_f2 = unref(subcategoryContents)[3]) == null ? void 0 : _f2.created_at)), 1)
                  ])
                ];
              }
            }),
            _: 1
          }, _parent));
        } else {
          _push(`<!---->`);
        }
        if (unref(subcategoryContents)[4]) {
          _push(ssrRenderComponent(_component_NuxtLink, {
            to: `/category/${(_s = (_r = unref(subcategoryContents)[4]) == null ? void 0 : _r.category) == null ? void 0 : _s.cat_slug}/${(_t = unref(subcategoryContents)[4]) == null ? void 0 : _t.content_id}`,
            class: "cat-box group md:pl-3 col-span-12 md:col-span-4"
          }, {
            default: withCtx((_, _push2, _parent2, _scopeId) => {
              var _a3, _b3, _c3, _d3, _e2, _f2;
              if (_push2) {
                _push2(`<div class="cat-box-image overflow-hidden" data-v-45f2cca3${_scopeId}>`);
                _push2(ssrRenderComponent(_component_nuxt_img, {
                  src: `${unref(siteurl).site_url}/media/content/images/${(_a3 = unref(subcategoryContents)[4]) == null ? void 0 : _a3.img_bg_path}`,
                  class: "mx-auto w-full group-hover:scale-110 duration-300 h-full",
                  placeholder: unref(img)(`${unref(siteurl).site_url}/logo/placeholder.jpg`)
                }, null, _parent2, _scopeId));
                _push2(`</div><div class="flex flex-col gap-3 mt-2" data-v-45f2cca3${_scopeId}><h3 class="cat-postheading text-xl group-hover:text-[#ff0000] leading-[24px] text-[#121212]" data-v-45f2cca3${_scopeId}>${ssrInterpolate((_b3 = unref(subcategoryContents)[4]) == null ? void 0 : _b3.content_heading)}</h3>`);
                _push2(ssrRenderComponent(_component_ClientOnly, null, {}, _parent2, _scopeId));
                _push2(`<small class="cat-postdate" data-v-45f2cca3${_scopeId}> \u09AA\u09CD\u09B0\u0995\u09BE\u09B6: ${ssrInterpolate(postCreatedDate((_c3 = unref(subcategoryContents)[4]) == null ? void 0 : _c3.created_at))}</small></div>`);
              } else {
                return [
                  createVNode("div", { class: "cat-box-image overflow-hidden" }, [
                    createVNode(_component_nuxt_img, {
                      src: `${unref(siteurl).site_url}/media/content/images/${(_d3 = unref(subcategoryContents)[4]) == null ? void 0 : _d3.img_bg_path}`,
                      class: "mx-auto w-full group-hover:scale-110 duration-300 h-full",
                      placeholder: unref(img)(`${unref(siteurl).site_url}/logo/placeholder.jpg`)
                    }, null, 8, ["src", "placeholder"])
                  ]),
                  createVNode("div", { class: "flex flex-col gap-3 mt-2" }, [
                    createVNode("h3", { class: "cat-postheading text-xl group-hover:text-[#ff0000] leading-[24px] text-[#121212]" }, toDisplayString((_e2 = unref(subcategoryContents)[4]) == null ? void 0 : _e2.content_heading), 1),
                    createVNode(_component_ClientOnly, null, {
                      default: withCtx(() => {
                        var _a4;
                        return [
                          createVNode("div", {
                            class: "cat-postdesc text-[15px] font-[300] text-[#555555]",
                            innerHTML: `${(_a4 = unref(subcategoryContents)[4]) == null ? void 0 : _a4.content_details.substring(0, 155)}...`
                          }, null, 8, ["innerHTML"])
                        ];
                      }),
                      _: 1
                    }),
                    createVNode("small", { class: "cat-postdate" }, " \u09AA\u09CD\u09B0\u0995\u09BE\u09B6: " + toDisplayString(postCreatedDate((_f2 = unref(subcategoryContents)[4]) == null ? void 0 : _f2.created_at)), 1)
                  ])
                ];
              }
            }),
            _: 1
          }, _parent));
        } else {
          _push(`<!---->`);
        }
        _push(`<div class="col-span-12 cat-inside-ads" data-v-45f2cca3>`);
        _push(ssrRenderComponent(_component_NuxtLink, { to: "/" }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(ssrRenderComponent(_component_nuxt_img, {
                src: `/assets/img/cat-ads.gif`,
                class: "mx-auto w-full group-hover:scale-110 duration-300 px-2 mt-6 mb-2",
                placeholder: unref(img)(`${unref(siteurl).site_url}/logo/placeholder.jpg`)
              }, null, _parent2, _scopeId));
            } else {
              return [
                createVNode(_component_nuxt_img, {
                  src: `/assets/img/cat-ads.gif`,
                  class: "mx-auto w-full group-hover:scale-110 duration-300 px-2 mt-6 mb-2",
                  placeholder: unref(img)(`${unref(siteurl).site_url}/logo/placeholder.jpg`)
                }, null, 8, ["src", "placeholder"])
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(`</div></div><div class="category-post-list grid grid-cols-12 mt-4" data-v-45f2cca3><div class="col-span-2 hidden md:block" data-v-45f2cca3></div><div class="col-span-12 md:col-span-8" data-v-45f2cca3><!--[-->`);
        ssrRenderList(unref(subcategoryContentExcept), (catPost, cpInx) => {
          var _a3;
          _push(`<div class="cat-post-item py-4 border-b" data-v-45f2cca3>`);
          _push(ssrRenderComponent(_component_NuxtLink, {
            to: `/category/${(_a3 = catPost == null ? void 0 : catPost.category) == null ? void 0 : _a3.cat_slug}/${catPost == null ? void 0 : catPost.content_id}`,
            class: "grid grid-cols-12 gap-3 group"
          }, {
            default: withCtx((_, _push2, _parent2, _scopeId) => {
              if (_push2) {
                _push2(`<h3 class="cat-title col-span-12 text-[20px] group-hover:text-[#ff0000]" data-v-45f2cca3${_scopeId}>${ssrInterpolate(catPost == null ? void 0 : catPost.content_heading)}</h3><div class="col-span-7 flex flex-col gap-3" data-v-45f2cca3${_scopeId}>`);
                _push2(ssrRenderComponent(_component_ClientOnly, null, {}, _parent2, _scopeId));
                _push2(`<span class="post-date flex flex-col gap-1" data-v-45f2cca3${_scopeId}><small class="text-[#555555]" data-v-45f2cca3${_scopeId}>\u0986\u09AA\u09A1\u09C7\u099F: ${ssrInterpolate(postCreatedDate(catPost == null ? void 0 : catPost.updated_at))}</small><small class="text-[#555555]" data-v-45f2cca3${_scopeId}>\u09AA\u09CD\u09B0\u0995\u09BE\u09B6: ${ssrInterpolate(postCreatedDate(catPost == null ? void 0 : catPost.created_at))}</small></span></div><div class="col-span-5 category-post-image overflow-hidden" data-v-45f2cca3${_scopeId}>`);
                _push2(ssrRenderComponent(_component_nuxt_img, {
                  src: `${unref(siteurl).site_url}/media/content/images/${catPost == null ? void 0 : catPost.img_bg_path}`,
                  class: "mx-auto w-full group-hover:scale-110 duration-300",
                  placeholder: unref(img)(`${unref(siteurl).site_url}/logo/placeholder.jpg`)
                }, null, _parent2, _scopeId));
                _push2(`</div>`);
              } else {
                return [
                  createVNode("h3", { class: "cat-title col-span-12 text-[20px] group-hover:text-[#ff0000]" }, toDisplayString(catPost == null ? void 0 : catPost.content_heading), 1),
                  createVNode("div", { class: "col-span-7 flex flex-col gap-3" }, [
                    createVNode(_component_ClientOnly, null, {
                      default: withCtx(() => [
                        createVNode("div", {
                          class: "cat-desc text-[#555555] text-[15px] font-[300]",
                          innerHTML: catPost == null ? void 0 : catPost.content_details.substring(0, 160)
                        }, null, 8, ["innerHTML"])
                      ]),
                      _: 2
                    }, 1024),
                    createVNode("span", { class: "post-date flex flex-col gap-1" }, [
                      createVNode("small", { class: "text-[#555555]" }, "\u0986\u09AA\u09A1\u09C7\u099F: " + toDisplayString(postCreatedDate(catPost == null ? void 0 : catPost.updated_at)), 1),
                      createVNode("small", { class: "text-[#555555]" }, "\u09AA\u09CD\u09B0\u0995\u09BE\u09B6: " + toDisplayString(postCreatedDate(catPost == null ? void 0 : catPost.created_at)), 1)
                    ])
                  ]),
                  createVNode("div", { class: "col-span-5 category-post-image overflow-hidden" }, [
                    createVNode(_component_nuxt_img, {
                      src: `${unref(siteurl).site_url}/media/content/images/${catPost == null ? void 0 : catPost.img_bg_path}`,
                      class: "mx-auto w-full group-hover:scale-110 duration-300",
                      placeholder: unref(img)(`${unref(siteurl).site_url}/logo/placeholder.jpg`)
                    }, null, 8, ["src", "placeholder"])
                  ])
                ];
              }
            }),
            _: 2
          }, _parent));
          _push(`</div>`);
        });
        _push(`<!--]--></div><div class="col-span-2 hidden md:block" data-v-45f2cca3></div></div>`);
        if (((_u = unref(subcategoryContents)) == null ? void 0 : _u.length) > 10) {
          _push(`<div class="flex justify-center items-center" data-v-45f2cca3><button class="border border-[#dee2e6] text-[#3375af] px-8 py-2 rounded-sm mt-5 hover:border-[#3375af]" data-v-45f2cca3><b data-v-45f2cca3>\u0986\u09B0\u0993</b></button></div>`);
        } else {
          _push(`<!---->`);
        }
        _push(`</div>`);
      } else {
        _push(`<div class="col-span-12 md:col-span-9 md:border-r md:pr-3" data-v-45f2cca3><h2 class="text-2xl text-center py-8" data-v-45f2cca3>\u0986\u09AA\u09A8\u09BF \u09AF\u09C7 \u09AC\u09BF\u09B7\u09AF\u09BC\u099F\u09BF \u0985\u09A8\u09C1\u09B8\u09A8\u09CD\u09A7\u09BE\u09A8 \u0995\u09B0\u099B\u09C7\u09A8 \u09A4\u09BE \u0996\u09C1\u099C\u09C7 \u09AA\u09BE\u0993\u09AF\u09BC\u09BE \u09AF\u09BE\u09AF\u09BC\u09A8\u09BF</h2></div>`);
      }
      _push(`<div class="col-span-12 md:col-span-3" data-v-45f2cca3>`);
      _push(ssrRenderComponent(_component_Tabs, {
        class: `sticky ${unref(stickyScroll) ? " top-44" : "top-16"}`
      }, null, _parent));
      _push(`</div></div></div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/[category]/[subcategory]/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const index = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-45f2cca3"]]);

export { index as default };
//# sourceMappingURL=index-4dc5184f.mjs.map
