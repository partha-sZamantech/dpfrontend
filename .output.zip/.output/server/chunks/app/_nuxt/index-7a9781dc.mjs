import { b as useFetch, s as siteUrlState, u as useImage, c as specialTopContentState, N as NationalHomeContentState, _ as __nuxt_component_1$1 } from './state-7a7e2860.mjs';
import { withAsyncContext, mergeProps, unref, useSSRContext, withCtx, createVNode, toDisplayString, ref } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderAttr, ssrInterpolate, ssrRenderList, ssrRenderStyle, ssrRenderClass } from 'vue/server-renderer';
import { _ as __nuxt_component_4$1 } from './client-only-0841c2aa.mjs';
import { j as useRuntimeConfig, _ as _export_sfc } from '../server.mjs';
import { u as useState } from './state-b54abad0.mjs';
import { _ as __nuxt_component_0$1 } from './nuxt-link-c659c711.mjs';
import __nuxt_component_0$2 from './Icon-ec29c746.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'ipx';
import './index-6a088328.mjs';
import '@unhead/shared';
import 'unhead';
import 'vue-router';
import './config-a9056531.mjs';
import '@iconify/vue/dist/offline';
import '@iconify/vue';

const _sfc_main$K = {
  __name: "MiddleTop",
  __ssrInlineRender: true,
  props: ["homeMiddleAds"],
  setup(__props) {
    const data = __props;
    const siteurl = siteUrlState();
    return (_ctx, _push, _parent, _attrs) => {
      var _a, _b, _c, _d, _e;
      if (((_a = data == null ? void 0 : data.homeMiddleAds) == null ? void 0 : _a.status) === 1) {
        _push(`<div${ssrRenderAttrs(mergeProps({ class: "ad-container" }, _attrs))}><div class="ad-section bg-[#f7f7f7]">`);
        if (((_b = data == null ? void 0 : data.homeMiddleAds) == null ? void 0 : _b.type) === 3) {
          _push(`<a${ssrRenderAttr("href", (_c = data == null ? void 0 : data.homeMiddleAds) == null ? void 0 : _c.external_link)} target="_blank" rel="nofollow"><img class="mx-auto"${ssrRenderAttr("src", `${unref(siteurl).site_url}/media/advertisement/${(_d = data == null ? void 0 : data.homeMiddleAds) == null ? void 0 : _d.desktop_image_path}`)} alt="Header Ad"></a>`);
        } else {
          _push(`<div>${(_e = data == null ? void 0 : data.homeMiddleAds) == null ? void 0 : _e.code}</div>`);
        }
        _push(`</div></div>`);
      } else {
        _push(`<!---->`);
      }
    };
  }
};
const _sfc_setup$K = _sfc_main$K.setup;
_sfc_main$K.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Ads/Desktop/Home/MiddleTop.vue");
  return _sfc_setup$K ? _sfc_setup$K(props, ctx) : void 0;
};
const __nuxt_component_0 = _sfc_main$K;
const _sfc_main$J = {
  __name: "Headline",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    const config = /* @__PURE__ */ useRuntimeConfig();
    const breakingNews = useState(() => [], "$q0tIEGWp3j");
    const { data: Headline } = ([__temp, __restore] = withAsyncContext(() => useFetch(`${config.public.apiUrl}/api/breaking-news`, {
      method: "GET"
    }, "$R6xfnkpHNx")), __temp = await __temp, __restore(), __temp);
    breakingNews.value = Headline;
    return (_ctx, _push, _parent, _attrs) => {
      const _component_ClientOnly = __nuxt_component_4$1;
      _push(ssrRenderComponent(_component_ClientOnly, _attrs, {}, _parent));
    };
  }
};
const _sfc_setup$J = _sfc_main$J.setup;
_sfc_main$J.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Headline.vue");
  return _sfc_setup$J ? _sfc_setup$J(props, ctx) : void 0;
};
const __nuxt_component_1 = _sfc_main$J;
const _sfc_main$I = {
  __name: "SpecialTopContent",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    const img = useImage();
    const siteurl = siteUrlState();
    const specialTopContents = specialTopContentState();
    const { data: spTopCon } = ([__temp, __restore] = withAsyncContext(() => useFetch(`/api/home/specialtopcontent`, {
      method: "GET"
    }, "$O6aJ9AS1wD")), __temp = await __temp, __restore(), __temp);
    specialTopContents.value = spTopCon;
    return (_ctx, _push, _parent, _attrs) => {
      var _a, _b, _c, _d;
      const _component_NuxtLink = __nuxt_component_0$1;
      const _component_nuxt_img = __nuxt_component_1$1;
      const _component_ClientOnly = __nuxt_component_4$1;
      const _component_Icon = __nuxt_component_0$2;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "specialContent py-3" }, _attrs))} data-v-f61f79a4><div class="grid grid-cols-12 gap-5" data-v-f61f79a4><div class="col-span-12 md:col-span-7" data-v-f61f79a4><div class="grid grid-cols-12 gap-4" data-v-f61f79a4><div class="col-span-12 md:col-span-7 group" data-v-f61f79a4>`);
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: `/category/${(_b = (_a = unref(specialTopContents)[0]) == null ? void 0 : _a.category) == null ? void 0 : _b.cat_slug}/${(_c = unref(specialTopContents)[0]) == null ? void 0 : _c.content_id}`,
        class: "flex flex-col gap-3"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          var _a2, _b2;
          if (_push2) {
            _push2(`<div class="overflow-hidden" data-v-f61f79a4${_scopeId}>`);
            _push2(ssrRenderComponent(_component_nuxt_img, {
              src: `${unref(siteurl).site_url}/media/content/images/${unref(specialTopContents)[0].img_bg_path}`,
              class: "mx-auto w-full group-hover:scale-110 duration-300",
              placeholder: unref(img)(`${unref(siteurl).site_url}/logo/placeholder.jpg`)
            }, null, _parent2, _scopeId));
            _push2(`</div><h2 class="text-[#ff0000] text-[32px] leading-tight" data-v-f61f79a4${_scopeId}>${ssrInterpolate((_a2 = unref(specialTopContents)[0]) == null ? void 0 : _a2.content_heading)}</h2>`);
            _push2(ssrRenderComponent(_component_ClientOnly, null, {}, _parent2, _scopeId));
          } else {
            return [
              createVNode("div", { class: "overflow-hidden" }, [
                createVNode(_component_nuxt_img, {
                  src: `${unref(siteurl).site_url}/media/content/images/${unref(specialTopContents)[0].img_bg_path}`,
                  class: "mx-auto w-full group-hover:scale-110 duration-300",
                  placeholder: unref(img)(`${unref(siteurl).site_url}/logo/placeholder.jpg`)
                }, null, 8, ["src", "placeholder"])
              ]),
              createVNode("h2", { class: "text-[#ff0000] text-[32px] leading-tight" }, toDisplayString((_b2 = unref(specialTopContents)[0]) == null ? void 0 : _b2.content_heading), 1),
              createVNode(_component_ClientOnly, null, {
                default: withCtx(() => {
                  var _a3, _b3;
                  return [
                    createVNode("div", {
                      class: "font-[300] text-[#555555]",
                      innerHTML: `${(_b3 = (_a3 = unref(specialTopContents)[0]) == null ? void 0 : _a3.content_details) == null ? void 0 : _b3.substring(
                        0,
                        165
                      )} ...`
                    }, null, 8, ["innerHTML"])
                  ];
                }),
                _: 1
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div><div class="col-span-12 md:col-span-5" data-v-f61f79a4><div class="flex flex-col gap-2" data-v-f61f79a4><!--[-->`);
      ssrRenderList((_d = unref(specialTopContents)) == null ? void 0 : _d.slice(1, 5), (topcontent) => {
        var _a2;
        _push(ssrRenderComponent(_component_NuxtLink, {
          to: `/category/${(_a2 = topcontent == null ? void 0 : topcontent.category) == null ? void 0 : _a2.cat_slug}/${topcontent == null ? void 0 : topcontent.content_id}`,
          class: "grid grid-cols-12 gap-4 group py-4 border-b specialMiddleTop",
          key: topcontent == null ? void 0 : topcontent.content_id
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            var _a3, _b2, _c2, _d2;
            if (_push2) {
              _push2(`<div class="col-span-5" data-v-f61f79a4${_scopeId}><div class="overflow-hidden" data-v-f61f79a4${_scopeId}>`);
              _push2(ssrRenderComponent(_component_nuxt_img, {
                alt: topcontent == null ? void 0 : topcontent.content_heading,
                src: `${(_a3 = unref(siteurl)) == null ? void 0 : _a3.site_url}/media/content/images/${topcontent == null ? void 0 : topcontent.img_bg_path}`,
                class: "mx-auto w-full group-hover:scale-110 duration-300",
                placeholder: unref(img)(`${(_b2 = unref(siteurl)) == null ? void 0 : _b2.site_url}/logo/placeholder.jpg`)
              }, null, _parent2, _scopeId));
              _push2(`</div></div><div class="col-span-7" data-v-f61f79a4${_scopeId}><h4 class="text-[20px] leading-tight group-hover:text-[#ff0000]" data-v-f61f79a4${_scopeId}>${ssrInterpolate(topcontent == null ? void 0 : topcontent.content_heading)}</h4></div>`);
            } else {
              return [
                createVNode("div", { class: "col-span-5" }, [
                  createVNode("div", { class: "overflow-hidden" }, [
                    createVNode(_component_nuxt_img, {
                      alt: topcontent == null ? void 0 : topcontent.content_heading,
                      src: `${(_c2 = unref(siteurl)) == null ? void 0 : _c2.site_url}/media/content/images/${topcontent == null ? void 0 : topcontent.img_bg_path}`,
                      class: "mx-auto w-full group-hover:scale-110 duration-300",
                      placeholder: unref(img)(`${(_d2 = unref(siteurl)) == null ? void 0 : _d2.site_url}/logo/placeholder.jpg`)
                    }, null, 8, ["alt", "src", "placeholder"])
                  ])
                ]),
                createVNode("div", { class: "col-span-7" }, [
                  createVNode("h4", { class: "text-[20px] leading-tight group-hover:text-[#ff0000]" }, toDisplayString(topcontent == null ? void 0 : topcontent.content_heading), 1)
                ])
              ];
            }
          }),
          _: 2
        }, _parent));
      });
      _push(`<!--]--></div></div></div></div><div class="col-span-12 md:col-span-5" data-v-f61f79a4><div class="flex flex-col gap-1" data-v-f61f79a4><div data-v-f61f79a4><iframe width="518" height="292" src="https://www.youtube.com/embed/rWdN3xUDdE8?enablejsapi=1&amp;autoplay=1&amp;mute=1&amp;rel=0&amp;showinfo=1&amp;controls=1&amp;loop=1&amp;playlist={{$spTopFirstVideo-&gt;code}}" frameborder="0" allowfullscreen style="${ssrRenderStyle({ "width": "100%!important" })}" data-v-f61f79a4></iframe></div><div class="grid grid-cols-1 md:grid-cols-2 md:place-items-center" data-v-f61f79a4>`);
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: "/",
        class: "grid grid-cols-12 gap-4 items-center group border-b py-4 group"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_Icon, {
              name: "simple-icons:youtubemusic",
              class: "col-span-2 md:col-span-3 text-4xl group-hover:text-[#3375af] text-[#ff0000]"
            }, null, _parent2, _scopeId));
            _push2(`<h4 class="text-[18px] col-span-10 md:col-span-9 group-hover:text-[#3375af]" data-v-f61f79a4${_scopeId}>\u09AE\u09BE \u09A6\u09BF\u09AC\u09B8\u09C7\u09B0 \u09AA\u09C7\u099B\u09A8\u09C7\u09B0 \u0997\u09B2\u09CD\u09AA</h4>`);
          } else {
            return [
              createVNode(_component_Icon, {
                name: "simple-icons:youtubemusic",
                class: "col-span-2 md:col-span-3 text-4xl group-hover:text-[#3375af] text-[#ff0000]"
              }),
              createVNode("h4", { class: "text-[18px] col-span-10 md:col-span-9 group-hover:text-[#3375af]" }, "\u09AE\u09BE \u09A6\u09BF\u09AC\u09B8\u09C7\u09B0 \u09AA\u09C7\u099B\u09A8\u09C7\u09B0 \u0997\u09B2\u09CD\u09AA")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: "/",
        class: "grid grid-cols-12 gap-4 items-center group border-b py-4 group"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_Icon, {
              name: "simple-icons:youtubemusic",
              class: "col-span-2 md:col-span-3 text-4xl group-hover:text-[#3375af] text-[#ff0000]"
            }, null, _parent2, _scopeId));
            _push2(`<h4 class="text-[18px] col-span-10 md:col-span-9 group-hover:text-[#3375af]" data-v-f61f79a4${_scopeId}>\u09AE\u09BE \u09A6\u09BF\u09AC\u09B8\u09C7\u09B0 \u09AA\u09C7\u099B\u09A8\u09C7\u09B0 \u0997\u09B2\u09CD\u09AA</h4>`);
          } else {
            return [
              createVNode(_component_Icon, {
                name: "simple-icons:youtubemusic",
                class: "col-span-2 md:col-span-3 text-4xl group-hover:text-[#3375af] text-[#ff0000]"
              }),
              createVNode("h4", { class: "text-[18px] col-span-10 md:col-span-9 group-hover:text-[#3375af]" }, "\u09AE\u09BE \u09A6\u09BF\u09AC\u09B8\u09C7\u09B0 \u09AA\u09C7\u099B\u09A8\u09C7\u09B0 \u0997\u09B2\u09CD\u09AA")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: "/",
        class: "grid grid-cols-12 gap-4 items-center group border-b py-4 group"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_Icon, {
              name: "simple-icons:youtubemusic",
              class: "col-span-2 md:col-span-3 text-4xl group-hover:text-[#3375af] text-[#ff0000]"
            }, null, _parent2, _scopeId));
            _push2(`<h4 class="text-[18px] col-span-10 md:col-span-9 group-hover:text-[#3375af]" data-v-f61f79a4${_scopeId}>\u09AE\u09BE \u09A6\u09BF\u09AC\u09B8\u09C7\u09B0 \u09AA\u09C7\u099B\u09A8\u09C7\u09B0 \u0997\u09B2\u09CD\u09AA</h4>`);
          } else {
            return [
              createVNode(_component_Icon, {
                name: "simple-icons:youtubemusic",
                class: "col-span-2 md:col-span-3 text-4xl group-hover:text-[#3375af] text-[#ff0000]"
              }),
              createVNode("h4", { class: "text-[18px] col-span-10 md:col-span-9 group-hover:text-[#3375af]" }, "\u09AE\u09BE \u09A6\u09BF\u09AC\u09B8\u09C7\u09B0 \u09AA\u09C7\u099B\u09A8\u09C7\u09B0 \u0997\u09B2\u09CD\u09AA")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: "/",
        class: "grid grid-cols-12 gap-4 items-center group border-b py-4 group"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_Icon, {
              name: "simple-icons:youtubemusic",
              class: "col-span-2 md:col-span-3 text-4xl group-hover:text-[#3375af] text-[#ff0000]"
            }, null, _parent2, _scopeId));
            _push2(`<h4 class="text-[18px] col-span-10 md:col-span-9 group-hover:text-[#3375af]" data-v-f61f79a4${_scopeId}>\u09AE\u09BE \u09A6\u09BF\u09AC\u09B8\u09C7\u09B0 \u09AA\u09C7\u099B\u09A8\u09C7\u09B0 \u0997\u09B2\u09CD\u09AA</h4>`);
          } else {
            return [
              createVNode(_component_Icon, {
                name: "simple-icons:youtubemusic",
                class: "col-span-2 md:col-span-3 text-4xl group-hover:text-[#3375af] text-[#ff0000]"
              }),
              createVNode("h4", { class: "text-[18px] col-span-10 md:col-span-9 group-hover:text-[#3375af]" }, "\u09AE\u09BE \u09A6\u09BF\u09AC\u09B8\u09C7\u09B0 \u09AA\u09C7\u099B\u09A8\u09C7\u09B0 \u0997\u09B2\u09CD\u09AA")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div></div></div></div>`);
    };
  }
};
const _sfc_setup$I = _sfc_main$I.setup;
_sfc_main$I.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Home/SpecialTopContent.vue");
  return _sfc_setup$I ? _sfc_setup$I(props, ctx) : void 0;
};
const __nuxt_component_2 = /* @__PURE__ */ _export_sfc(_sfc_main$I, [["__scopeId", "data-v-f61f79a4"]]);
const _sfc_main$H = {
  __name: "MiddleOne",
  __ssrInlineRender: true,
  props: ["homeMiddleOneAds"],
  setup(__props) {
    const data = __props;
    const siteurl = siteUrlState();
    return (_ctx, _push, _parent, _attrs) => {
      var _a, _b, _c, _d, _e;
      if (((_a = data == null ? void 0 : data.homeMiddleOneAds) == null ? void 0 : _a.status) === 1) {
        _push(`<div${ssrRenderAttrs(mergeProps({ class: "ad-container" }, _attrs))}><div class="ad-section bg-[#f7f7f7]">`);
        if (((_b = data == null ? void 0 : data.homeMiddleOneAds) == null ? void 0 : _b.type) === 3) {
          _push(`<a${ssrRenderAttr("href", (_c = data == null ? void 0 : data.homeMiddleOneAds) == null ? void 0 : _c.external_link)} target="_blank" rel="nofollow"><img class="mx-auto"${ssrRenderAttr("src", `${unref(siteurl).site_url}/media/advertisement/${(_d = data == null ? void 0 : data.homeMiddleOneAds) == null ? void 0 : _d.desktop_image_path}`)} alt="Header Ad"></a>`);
        } else {
          _push(`<div>${(_e = data == null ? void 0 : data.homeMiddleOneAds) == null ? void 0 : _e.code}</div>`);
        }
        _push(`</div></div>`);
      } else {
        _push(`<!---->`);
      }
    };
  }
};
const _sfc_setup$H = _sfc_main$H.setup;
_sfc_main$H.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Ads/Desktop/Home/MiddleOne.vue");
  return _sfc_setup$H ? _sfc_setup$H(props, ctx) : void 0;
};
const __nuxt_component_3 = _sfc_main$H;
const _sfc_main$G = {
  __name: "SpecialBottomContent",
  __ssrInlineRender: true,
  setup(__props) {
    useImage();
    specialTopContentState();
    siteUrlState();
    return (_ctx, _push, _parent, _attrs) => {
      const _component_ClientOnly = __nuxt_component_4$1;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "grid grid-cols-2 md:grid-cols-3 gap-5 py-4" }, _attrs))}>`);
      _push(ssrRenderComponent(_component_ClientOnly, null, {}, _parent));
      _push(`</div>`);
    };
  }
};
const _sfc_setup$G = _sfc_main$G.setup;
_sfc_main$G.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Home/SpecialBottomContent.vue");
  return _sfc_setup$G ? _sfc_setup$G(props, ctx) : void 0;
};
const __nuxt_component_4 = _sfc_main$G;
const _sfc_main$F = {
  __name: "MiddleTwo",
  __ssrInlineRender: true,
  props: ["homeMiddleTwoAds"],
  setup(__props) {
    const data = __props;
    const siteurl = siteUrlState();
    return (_ctx, _push, _parent, _attrs) => {
      var _a, _b, _c, _d, _e;
      if (((_a = data == null ? void 0 : data.homeMiddleTwoAds) == null ? void 0 : _a.status) === 1) {
        _push(`<div${ssrRenderAttrs(mergeProps({ class: "ad-container" }, _attrs))}><div class="ad-section bg-[#f7f7f7]">`);
        if (((_b = data == null ? void 0 : data.homeMiddleTwoAds) == null ? void 0 : _b.type) === 3) {
          _push(`<a${ssrRenderAttr("href", (_c = data == null ? void 0 : data.homeMiddleTwoAds) == null ? void 0 : _c.external_link)} target="_blank" rel="nofollow"><img class="mx-auto"${ssrRenderAttr("src", `${unref(siteurl).site_url}/media/advertisement/${(_d = data == null ? void 0 : data.homeMiddleTwoAds) == null ? void 0 : _d.desktop_image_path}`)} alt="Header Ad"></a>`);
        } else {
          _push(`<div>${(_e = data == null ? void 0 : data.homeMiddleTwoAds) == null ? void 0 : _e.code}</div>`);
        }
        _push(`</div></div>`);
      } else {
        _push(`<!---->`);
      }
    };
  }
};
const _sfc_setup$F = _sfc_main$F.setup;
_sfc_main$F.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Ads/Desktop/Home/MiddleTwo.vue");
  return _sfc_setup$F ? _sfc_setup$F(props, ctx) : void 0;
};
const __nuxt_component_5 = _sfc_main$F;
const _sfc_main$E = {
  __name: "National",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    const siteurl = siteUrlState();
    const img = useImage();
    const nationalHCon = NationalHomeContentState();
    const { data: nationalhc } = ([__temp, __restore] = withAsyncContext(() => useFetch("/api/home/nationalhomecontent", {
      method: "GET"
    }, "$irsP0yNlwo")), __temp = await __temp, __restore(), __temp);
    nationalHCon.value = nationalhc;
    return (_ctx, _push, _parent, _attrs) => {
      var _a, _b, _c, _d, _e;
      const _component_NuxtLink = __nuxt_component_0$1;
      const _component_nuxt_img = __nuxt_component_1$1;
      const _component_ClientOnly = __nuxt_component_4$1;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "home-national-category" }, _attrs))} data-v-d4eaa86f><div class="category-header border-b-4 border-b-[#3375af] my-3" data-v-d4eaa86f>`);
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: `/${(_b = (_a = unref(nationalHCon)[0]) == null ? void 0 : _a.category) == null ? void 0 : _b.cat_slug}`,
        class: "flex gap-3 items-center"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<span class="w-3 h-3 bg-[#3375af]" data-v-d4eaa86f${_scopeId}></span><h2 class="text-[#3375af] text-[18px] font-semibold" data-v-d4eaa86f${_scopeId}>\u099C\u09BE\u09A4\u09C0\u09DF</h2>`);
          } else {
            return [
              createVNode("span", { class: "w-3 h-3 bg-[#3375af]" }),
              createVNode("h2", { class: "text-[#3375af] text-[18px] font-semibold" }, "\u099C\u09BE\u09A4\u09C0\u09DF")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div><div class="grid grid-cols-12 gap-4" data-v-d4eaa86f><div class="col-span-12 md:col-span-7" data-v-d4eaa86f>`);
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: `/category/${(_d = (_c = unref(nationalHCon)[0]) == null ? void 0 : _c.category) == null ? void 0 : _d.cat_slug}/${(_e = unref(nationalHCon)[0]) == null ? void 0 : _e.content_id}`,
        class: "flex flex-col group gap-2"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          var _a2, _b2, _c2, _d2, _e2, _f;
          if (_push2) {
            _push2(`<div class="national-feature-image overflow-hidden" data-v-d4eaa86f${_scopeId}>`);
            _push2(ssrRenderComponent(_component_nuxt_img, {
              src: `${unref(siteurl).site_url}/media/content/images/${(_a2 = unref(nationalHCon)[0]) == null ? void 0 : _a2.img_bg_path}`,
              class: "mx-auto w-full group-hover:scale-110 duration-300",
              placeholder: unref(img)(`${(_b2 = unref(siteurl)) == null ? void 0 : _b2.site_url}/logo/placeholder.jpg`)
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="national-feature-description flex flex-col gap-1" data-v-d4eaa86f${_scopeId}><h3 class="text-[25px] leading-tight group-hover:text-[#ff0000]" data-v-d4eaa86f${_scopeId}>${ssrInterpolate((_c2 = unref(nationalHCon)[0]) == null ? void 0 : _c2.content_heading)}</h3>`);
            _push2(ssrRenderComponent(_component_ClientOnly, null, {}, _parent2, _scopeId));
            _push2(`</div>`);
          } else {
            return [
              createVNode("div", { class: "national-feature-image overflow-hidden" }, [
                createVNode(_component_nuxt_img, {
                  src: `${unref(siteurl).site_url}/media/content/images/${(_d2 = unref(nationalHCon)[0]) == null ? void 0 : _d2.img_bg_path}`,
                  class: "mx-auto w-full group-hover:scale-110 duration-300",
                  placeholder: unref(img)(`${(_e2 = unref(siteurl)) == null ? void 0 : _e2.site_url}/logo/placeholder.jpg`)
                }, null, 8, ["src", "placeholder"])
              ]),
              createVNode("div", { class: "national-feature-description flex flex-col gap-1" }, [
                createVNode("h3", { class: "text-[25px] leading-tight group-hover:text-[#ff0000]" }, toDisplayString((_f = unref(nationalHCon)[0]) == null ? void 0 : _f.content_heading), 1),
                createVNode(_component_ClientOnly, null, {
                  default: withCtx(() => {
                    var _a3, _b3;
                    return [
                      createVNode("div", {
                        class: "text-[16px] font-[300] text-[#555555]",
                        innerHTML: `${(_b3 = (_a3 = unref(nationalHCon)[0]) == null ? void 0 : _a3.content_details) == null ? void 0 : _b3.substring(
                          0,
                          200
                        )} ...`
                      }, null, 8, ["innerHTML"])
                    ];
                  }),
                  _: 1
                })
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div><div class="col-span-12 md:col-span-5" data-v-d4eaa86f><div class="home-national-category-except-post flex flex-col" data-v-d4eaa86f><!--[-->`);
      ssrRenderList(unref(nationalHCon).slice(1, 5), (nationalcntent) => {
        var _a2, _b2;
        _push(`<div class="grid grid-cols-12 gap-4 group h-national-excpt border-b py-4" data-v-d4eaa86f><div class="col-span-5 overflow-hidden" data-v-d4eaa86f>`);
        _push(ssrRenderComponent(_component_NuxtLink, {
          to: `/category/${(_a2 = nationalcntent == null ? void 0 : nationalcntent.category) == null ? void 0 : _a2.cat_slug}/${nationalcntent == null ? void 0 : nationalcntent.content_id}`
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            var _a3, _b3;
            if (_push2) {
              _push2(ssrRenderComponent(_component_nuxt_img, {
                src: `${unref(siteurl).site_url}/media/content/images/${nationalcntent == null ? void 0 : nationalcntent.img_bg_path}`,
                class: "mx-auto w-full group-hover:scale-110 duration-300",
                placeholder: unref(img)(`${(_a3 = unref(siteurl)) == null ? void 0 : _a3.site_url}/logo/placeholder.jpg`)
              }, null, _parent2, _scopeId));
            } else {
              return [
                createVNode(_component_nuxt_img, {
                  src: `${unref(siteurl).site_url}/media/content/images/${nationalcntent == null ? void 0 : nationalcntent.img_bg_path}`,
                  class: "mx-auto w-full group-hover:scale-110 duration-300",
                  placeholder: unref(img)(`${(_b3 = unref(siteurl)) == null ? void 0 : _b3.site_url}/logo/placeholder.jpg`)
                }, null, 8, ["src", "placeholder"])
              ];
            }
          }),
          _: 2
        }, _parent));
        _push(`</div><div class="col-span-7" data-v-d4eaa86f>`);
        _push(ssrRenderComponent(_component_NuxtLink, {
          to: `/category/${(_b2 = nationalcntent == null ? void 0 : nationalcntent.category) == null ? void 0 : _b2.cat_slug}/${nationalcntent == null ? void 0 : nationalcntent.content_id}`
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<h4 class="text-[18px] leading-tight group-hover:text-[#ff0000]" data-v-d4eaa86f${_scopeId}>${ssrInterpolate(nationalcntent == null ? void 0 : nationalcntent.content_heading)}</h4>`);
            } else {
              return [
                createVNode("h4", { class: "text-[18px] leading-tight group-hover:text-[#ff0000]" }, toDisplayString(nationalcntent == null ? void 0 : nationalcntent.content_heading), 1)
              ];
            }
          }),
          _: 2
        }, _parent));
        _push(`</div></div>`);
      });
      _push(`<!--]--></div></div></div></div>`);
    };
  }
};
const _sfc_setup$E = _sfc_main$E.setup;
_sfc_main$E.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Home/Category/National.vue");
  return _sfc_setup$E ? _sfc_setup$E(props, ctx) : void 0;
};
const __nuxt_component_6 = /* @__PURE__ */ _export_sfc(_sfc_main$E, [["__scopeId", "data-v-d4eaa86f"]]);
const _sfc_main$D = {
  __name: "MiddleThree",
  __ssrInlineRender: true,
  props: ["homeMiddleThreeAds"],
  setup(__props) {
    const data = __props;
    const siteurl = siteUrlState();
    return (_ctx, _push, _parent, _attrs) => {
      var _a, _b, _c, _d, _e;
      if (((_a = data == null ? void 0 : data.homeMiddleThreeAds) == null ? void 0 : _a.status) === 1) {
        _push(`<div${ssrRenderAttrs(mergeProps({ class: "ad-container" }, _attrs))}><div class="ad-section bg-[#f7f7f7]">`);
        if (((_b = data == null ? void 0 : data.homeMiddleThreeAds) == null ? void 0 : _b.type) === 3) {
          _push(`<a${ssrRenderAttr("href", (_c = data == null ? void 0 : data.homeMiddleThreeAds) == null ? void 0 : _c.external_link)} target="_blank" rel="nofollow"><img class="mx-auto"${ssrRenderAttr("src", `${unref(siteurl).site_url}/media/advertisement/${(_d = data == null ? void 0 : data.homeMiddleThreeAds) == null ? void 0 : _d.desktop_image_path}`)} alt="Header Ad"></a>`);
        } else {
          _push(`<div>${(_e = data == null ? void 0 : data.homeMiddleThreeAds) == null ? void 0 : _e.code}</div>`);
        }
        _push(`</div></div>`);
      } else {
        _push(`<!---->`);
      }
    };
  }
};
const _sfc_setup$D = _sfc_main$D.setup;
_sfc_main$D.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Ads/Desktop/Home/MiddleThree.vue");
  return _sfc_setup$D ? _sfc_setup$D(props, ctx) : void 0;
};
const __nuxt_component_7 = _sfc_main$D;
const _sfc_main$C = {
  __name: "PoliticsEconomyInternational",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    const img = useImage();
    const siteurl = siteUrlState();
    const politics = useState(() => [], "$st39zL9vPr");
    const { data: pltic } = ([__temp, __restore] = withAsyncContext(() => useFetch("/api/home/politicscontent", {
      method: "GET"
    }, "$SntLfs75IZ")), __temp = await __temp, __restore(), __temp);
    politics.value = pltic;
    const economycontent = useState(() => [], "$SxCaF0fAJB");
    const { data: econ } = ([__temp, __restore] = withAsyncContext(() => useFetch("/api/home/economycontent", {
      method: "GET"
    }, "$LZC5acJ0r5")), __temp = await __temp, __restore(), __temp);
    economycontent.value = econ;
    const internationalcontent = useState(() => [], "$eTsEzN3BwH");
    const { data: intntnal } = ([__temp, __restore] = withAsyncContext(() => useFetch("/api/home/internationalcontent", {
      method: "GET"
    }, "$LpApBbxfC1")), __temp = await __temp, __restore(), __temp);
    internationalcontent.value = intntnal;
    return (_ctx, _push, _parent, _attrs) => {
      var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j, _k, _l, _m, _n, _o;
      const _component_NuxtLink = __nuxt_component_0$1;
      const _component_nuxt_img = __nuxt_component_1$1;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "grid grid-cols-12 gap-4 py-4" }, _attrs))}><div class="col-span-12 md:col-span-4"><div class="home-politic-category"><div class="category-header border-b-4 border-b-[#3375af] my-3">`);
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: `/${(_b = (_a = unref(politics)[0]) == null ? void 0 : _a.category) == null ? void 0 : _b.cat_slug}`,
        class: "flex gap-3 items-center"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<span class="w-3 h-3 bg-[#3375af]"${_scopeId}></span><h2 class="text-[#3375af] text-[18px] font-semibold"${_scopeId}>\u09B0\u09BE\u099C\u09A8\u09C0\u09A4\u09BF</h2>`);
          } else {
            return [
              createVNode("span", { class: "w-3 h-3 bg-[#3375af]" }),
              createVNode("h2", { class: "text-[#3375af] text-[18px] font-semibold" }, "\u09B0\u09BE\u099C\u09A8\u09C0\u09A4\u09BF")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div><div class="home-p-c-ontent flex flex-col gap-3">`);
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: `/category/${(_d = (_c = unref(politics)[0]) == null ? void 0 : _c.category) == null ? void 0 : _d.cat_slug}/${(_e = unref(politics)[0]) == null ? void 0 : _e.content_id}`,
        class: "flex flex-col gap-2 group"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          var _a2, _b2, _c2, _d2, _e2, _f2;
          if (_push2) {
            _push2(`<div class="overflow-hidden"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_nuxt_img, {
              src: `${unref(siteurl).site_url}/media/content/images/${(_a2 = unref(politics)[0]) == null ? void 0 : _a2.img_bg_path}`,
              class: "mx-auto w-full group-hover:scale-110 duration-300",
              placeholder: unref(img)(`${(_b2 = unref(siteurl)) == null ? void 0 : _b2.site_url}/logo/placeholder.jpg`)
            }, null, _parent2, _scopeId));
            _push2(`</div><h3 class="text-[19px] leading-tight group-hover:text-[#ff0000]"${_scopeId}>${ssrInterpolate((_c2 = unref(politics)[0]) == null ? void 0 : _c2.content_heading)}</h3>`);
          } else {
            return [
              createVNode("div", { class: "overflow-hidden" }, [
                createVNode(_component_nuxt_img, {
                  src: `${unref(siteurl).site_url}/media/content/images/${(_d2 = unref(politics)[0]) == null ? void 0 : _d2.img_bg_path}`,
                  class: "mx-auto w-full group-hover:scale-110 duration-300",
                  placeholder: unref(img)(`${(_e2 = unref(siteurl)) == null ? void 0 : _e2.site_url}/logo/placeholder.jpg`)
                }, null, 8, ["src", "placeholder"])
              ]),
              createVNode("h3", { class: "text-[19px] leading-tight group-hover:text-[#ff0000]" }, toDisplayString((_f2 = unref(politics)[0]) == null ? void 0 : _f2.content_heading), 1)
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<div class="h-p-c-excpt flex flex-col"><!--[-->`);
      ssrRenderList(unref(politics).slice(1, 6), (hpolitic) => {
        var _a2;
        _push(ssrRenderComponent(_component_NuxtLink, {
          to: `/category/${(_a2 = hpolitic == null ? void 0 : hpolitic.category) == null ? void 0 : _a2.cat_slug}/${hpolitic == null ? void 0 : hpolitic.content_id}`,
          class: "border-b py-3",
          key: hpolitic.content_id
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<h4 class="text-[17px] hover:text-[#ff0000] leading-tight"${_scopeId}>${ssrInterpolate(hpolitic.content_heading)}</h4>`);
            } else {
              return [
                createVNode("h4", { class: "text-[17px] hover:text-[#ff0000] leading-tight" }, toDisplayString(hpolitic.content_heading), 1)
              ];
            }
          }),
          _: 2
        }, _parent));
      });
      _push(`<!--]--></div></div></div></div><div class="col-span-12 md:col-span-4"><div class="home-economy-category"><div class="category-header border-b-4 border-b-[#3375af] my-3">`);
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: `/${(_g = (_f = unref(economycontent)[0]) == null ? void 0 : _f.category) == null ? void 0 : _g.cat_slug}`,
        class: "flex gap-3 items-center"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<span class="w-3 h-3 bg-[#3375af]"${_scopeId}></span><h2 class="text-[#3375af] text-[18px] font-semibold"${_scopeId}>\u0985\u09B0\u09CD\u09A5\u09A8\u09C0\u09A4\u09BF</h2>`);
          } else {
            return [
              createVNode("span", { class: "w-3 h-3 bg-[#3375af]" }),
              createVNode("h2", { class: "text-[#3375af] text-[18px] font-semibold" }, "\u0985\u09B0\u09CD\u09A5\u09A8\u09C0\u09A4\u09BF")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div><div class="home-econ-c-ontent flex flex-col gap-3">`);
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: `/category/${(_i = (_h = unref(economycontent)[0]) == null ? void 0 : _h.category) == null ? void 0 : _i.cat_slug}/${(_j = unref(economycontent)[0]) == null ? void 0 : _j.content_id}`,
        class: "flex flex-col gap-2 group"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          var _a2, _b2, _c2, _d2, _e2, _f2;
          if (_push2) {
            _push2(`<div class="overflow-hidden"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_nuxt_img, {
              src: `${unref(siteurl).site_url}/media/content/images/${(_a2 = unref(economycontent)[0]) == null ? void 0 : _a2.img_bg_path}`,
              class: "mx-auto w-full group-hover:scale-110 duration-300",
              placeholder: unref(img)(`${(_b2 = unref(siteurl)) == null ? void 0 : _b2.site_url}/logo/placeholder.jpg`)
            }, null, _parent2, _scopeId));
            _push2(`</div><h3 class="text-[19px] leading-tight group-hover:text-[#ff0000]"${_scopeId}>${ssrInterpolate((_c2 = unref(economycontent)[0]) == null ? void 0 : _c2.content_heading)}</h3>`);
          } else {
            return [
              createVNode("div", { class: "overflow-hidden" }, [
                createVNode(_component_nuxt_img, {
                  src: `${unref(siteurl).site_url}/media/content/images/${(_d2 = unref(economycontent)[0]) == null ? void 0 : _d2.img_bg_path}`,
                  class: "mx-auto w-full group-hover:scale-110 duration-300",
                  placeholder: unref(img)(`${(_e2 = unref(siteurl)) == null ? void 0 : _e2.site_url}/logo/placeholder.jpg`)
                }, null, 8, ["src", "placeholder"])
              ]),
              createVNode("h3", { class: "text-[19px] leading-tight group-hover:text-[#ff0000]" }, toDisplayString((_f2 = unref(economycontent)[0]) == null ? void 0 : _f2.content_heading), 1)
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<div class="h-p-c-excpt flex flex-col"><!--[-->`);
      ssrRenderList(unref(economycontent).slice(1, 6), (heconmy) => {
        var _a2;
        _push(ssrRenderComponent(_component_NuxtLink, {
          to: `/category/${(_a2 = heconmy == null ? void 0 : heconmy.category) == null ? void 0 : _a2.cat_slug}/${heconmy == null ? void 0 : heconmy.content_id}`,
          class: "border-b py-3",
          key: heconmy.content_id
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<h4 class="text-[17px] hover:text-[#ff0000] leading-tight"${_scopeId}>${ssrInterpolate(heconmy.content_heading)}</h4>`);
            } else {
              return [
                createVNode("h4", { class: "text-[17px] hover:text-[#ff0000] leading-tight" }, toDisplayString(heconmy.content_heading), 1)
              ];
            }
          }),
          _: 2
        }, _parent));
      });
      _push(`<!--]--></div></div></div></div><div class="col-span-12 md:col-span-4"><div class="home-international-category"><div class="category-header border-b-4 border-b-[#3375af] my-3">`);
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: `/${(_l = (_k = unref(internationalcontent)[0]) == null ? void 0 : _k.category) == null ? void 0 : _l.cat_slug}`,
        class: "flex gap-3 items-center"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<span class="w-3 h-3 bg-[#3375af]"${_scopeId}></span><h2 class="text-[#3375af] text-[18px] font-semibold"${_scopeId}>\u09B8\u09BE\u09B0\u09BE\u09AC\u09BF\u09B6\u09CD\u09AC</h2>`);
          } else {
            return [
              createVNode("span", { class: "w-3 h-3 bg-[#3375af]" }),
              createVNode("h2", { class: "text-[#3375af] text-[18px] font-semibold" }, "\u09B8\u09BE\u09B0\u09BE\u09AC\u09BF\u09B6\u09CD\u09AC")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div><div class="home-int-c-content flex flex-col gap-3">`);
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: `/category/${(_n = (_m = unref(internationalcontent)[0]) == null ? void 0 : _m.category) == null ? void 0 : _n.cat_slug}/${(_o = unref(internationalcontent)[0]) == null ? void 0 : _o.content_id}`,
        class: "flex flex-col gap-2 group"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          var _a2, _b2, _c2, _d2, _e2, _f2;
          if (_push2) {
            _push2(`<div class="overflow-hidden"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_nuxt_img, {
              src: `${unref(siteurl).site_url}/media/content/images/${(_a2 = unref(internationalcontent)[0]) == null ? void 0 : _a2.img_bg_path}`,
              class: "mx-auto w-full group-hover:scale-110 duration-300",
              placeholder: unref(img)(`${(_b2 = unref(siteurl)) == null ? void 0 : _b2.site_url}/logo/placeholder.jpg`)
            }, null, _parent2, _scopeId));
            _push2(`</div><h3 class="text-[19px] leading-tight group-hover:text-[#ff0000]"${_scopeId}>${ssrInterpolate((_c2 = unref(internationalcontent)[0]) == null ? void 0 : _c2.content_heading)}</h3>`);
          } else {
            return [
              createVNode("div", { class: "overflow-hidden" }, [
                createVNode(_component_nuxt_img, {
                  src: `${unref(siteurl).site_url}/media/content/images/${(_d2 = unref(internationalcontent)[0]) == null ? void 0 : _d2.img_bg_path}`,
                  class: "mx-auto w-full group-hover:scale-110 duration-300",
                  placeholder: unref(img)(`${(_e2 = unref(siteurl)) == null ? void 0 : _e2.site_url}/logo/placeholder.jpg`)
                }, null, 8, ["src", "placeholder"])
              ]),
              createVNode("h3", { class: "text-[19px] leading-tight group-hover:text-[#ff0000]" }, toDisplayString((_f2 = unref(internationalcontent)[0]) == null ? void 0 : _f2.content_heading), 1)
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<div class="h-p-c-excpt flex flex-col"><!--[-->`);
      ssrRenderList(unref(internationalcontent).slice(1, 6), (hinternatcon) => {
        var _a2;
        _push(ssrRenderComponent(_component_NuxtLink, {
          to: `/category/${(_a2 = hinternatcon == null ? void 0 : hinternatcon.category) == null ? void 0 : _a2.cat_slug}/${hinternatcon == null ? void 0 : hinternatcon.content_id}`,
          class: "border-b py-3",
          key: hinternatcon.content_id
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<h4 class="text-[17px] hover:text-[#ff0000] leading-tight"${_scopeId}>${ssrInterpolate(hinternatcon.content_heading)}</h4>`);
            } else {
              return [
                createVNode("h4", { class: "text-[17px] hover:text-[#ff0000] leading-tight" }, toDisplayString(hinternatcon.content_heading), 1)
              ];
            }
          }),
          _: 2
        }, _parent));
      });
      _push(`<!--]--></div></div></div></div></div>`);
    };
  }
};
const _sfc_setup$C = _sfc_main$C.setup;
_sfc_main$C.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Home/Category/PoliticsEconomyInternational.vue");
  return _sfc_setup$C ? _sfc_setup$C(props, ctx) : void 0;
};
const __nuxt_component_8 = _sfc_main$C;
const _sfc_main$B = {
  __name: "MiddleFour",
  __ssrInlineRender: true,
  props: ["homeMiddleFourAds"],
  setup(__props) {
    const data = __props;
    const siteurl = siteUrlState();
    return (_ctx, _push, _parent, _attrs) => {
      var _a, _b, _c, _d, _e;
      if (((_a = data == null ? void 0 : data.homeMiddleFourAds) == null ? void 0 : _a.status) === 1) {
        _push(`<div${ssrRenderAttrs(mergeProps({ class: "ad-container" }, _attrs))}><div class="ad-section bg-[#f7f7f7]">`);
        if (((_b = data == null ? void 0 : data.homeMiddleFourAds) == null ? void 0 : _b.type) === 3) {
          _push(`<a${ssrRenderAttr("href", (_c = data == null ? void 0 : data.homeMiddleFourAds) == null ? void 0 : _c.external_link)} target="_blank" rel="nofollow"><img class="mx-auto"${ssrRenderAttr("src", `${unref(siteurl).site_url}/media/advertisement/${(_d = data == null ? void 0 : data.homeMiddleFourAds) == null ? void 0 : _d.desktop_image_path}`)} alt="Header Ad"></a>`);
        } else {
          _push(`<div>${(_e = data == null ? void 0 : data.homeMiddleFourAds) == null ? void 0 : _e.code}</div>`);
        }
        _push(`</div></div>`);
      } else {
        _push(`<!---->`);
      }
    };
  }
};
const _sfc_setup$B = _sfc_main$B.setup;
_sfc_main$B.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Ads/Desktop/Home/MiddleFour.vue");
  return _sfc_setup$B ? _sfc_setup$B(props, ctx) : void 0;
};
const __nuxt_component_9 = _sfc_main$B;
const _sfc_main$A = {
  __name: "RightOne",
  __ssrInlineRender: true,
  props: ["homeRightOneAds"],
  setup(__props) {
    const data = __props;
    const siteurl = siteUrlState();
    return (_ctx, _push, _parent, _attrs) => {
      var _a, _b, _c, _d, _e;
      if (((_a = data == null ? void 0 : data.homeRightOneAds) == null ? void 0 : _a.status) === 1) {
        _push(`<div${ssrRenderAttrs(mergeProps({ class: "ad-container" }, _attrs))}><div class="ad-section bg-[#f7f7f7]">`);
        if (((_b = data == null ? void 0 : data.homeRightOneAds) == null ? void 0 : _b.type) === 3) {
          _push(`<a${ssrRenderAttr("href", (_c = data == null ? void 0 : data.homeRightOneAds) == null ? void 0 : _c.external_link)} target="_blank" rel="nofollow"><img class="mx-auto"${ssrRenderAttr("src", `${unref(siteurl).site_url}/media/advertisement/${(_d = data == null ? void 0 : data.homeRightOneAds) == null ? void 0 : _d.desktop_image_path}`)} alt="Header Ad"></a>`);
        } else {
          _push(`<div>${(_e = data == null ? void 0 : data.homeRightOneAds) == null ? void 0 : _e.code}</div>`);
        }
        _push(`</div></div>`);
      } else {
        _push(`<!---->`);
      }
    };
  }
};
const _sfc_setup$A = _sfc_main$A.setup;
_sfc_main$A.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Ads/Desktop/Home/RightOne.vue");
  return _sfc_setup$A ? _sfc_setup$A(props, ctx) : void 0;
};
const __nuxt_component_10 = _sfc_main$A;
const _sfc_main$z = {
  __name: "RightTwo",
  __ssrInlineRender: true,
  props: ["homeRightTwoAds"],
  setup(__props) {
    const data = __props;
    const siteurl = siteUrlState();
    return (_ctx, _push, _parent, _attrs) => {
      var _a, _b, _c, _d, _e;
      if (((_a = data == null ? void 0 : data.homeRightTwoAds) == null ? void 0 : _a.status) === 1) {
        _push(`<div${ssrRenderAttrs(mergeProps({ class: "ad-container" }, _attrs))}><div class="ad-section bg-[#f7f7f7]">`);
        if (((_b = data == null ? void 0 : data.homeRightTwoAds) == null ? void 0 : _b.type) === 3) {
          _push(`<a${ssrRenderAttr("href", (_c = data == null ? void 0 : data.homeRightTwoAds) == null ? void 0 : _c.external_link)} target="_blank" rel="nofollow"><img class="mx-auto"${ssrRenderAttr("src", `${unref(siteurl).site_url}/media/advertisement/${(_d = data == null ? void 0 : data.homeRightTwoAds) == null ? void 0 : _d.desktop_image_path}`)} alt="Header Ad"></a>`);
        } else {
          _push(`<div>${(_e = data == null ? void 0 : data.homeRightTwoAds) == null ? void 0 : _e.code}</div>`);
        }
        _push(`</div></div>`);
      } else {
        _push(`<!---->`);
      }
    };
  }
};
const _sfc_setup$z = _sfc_main$z.setup;
_sfc_main$z.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Ads/Desktop/Home/RightTwo.vue");
  return _sfc_setup$z ? _sfc_setup$z(props, ctx) : void 0;
};
const __nuxt_component_11 = _sfc_main$z;
const _sfc_main$y = {
  __name: "PostTabs",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    const img = useImage();
    const isActiveStatus = ref(false);
    const siteurl = siteUrlState();
    const latestposts = useState(() => [], "$gN9MS8eIzK");
    const { data: latpost } = ([__temp, __restore] = withAsyncContext(() => useFetch(`/api/home/latestposts`, {
      method: "GET"
    }, "$IXJFgVdv5V")), __temp = await __temp, __restore(), __temp);
    latestposts.value = latpost;
    const popularposts = useState(() => [], "$SRofXRrD32");
    const { data: hplpost } = ([__temp, __restore] = withAsyncContext(() => useFetch(`/api/home/popularposts`, {
      method: "GET"
    }, "$UEhABlwjrz")), __temp = await __temp, __restore(), __temp);
    popularposts.value = hplpost;
    return (_ctx, _push, _parent, _attrs) => {
      const _component_NuxtLink = __nuxt_component_0$1;
      const _component_nuxt_img = __nuxt_component_1$1;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "home-post-tabs border border-t-2 border-t-[#124d80] my-4" }, _attrs))} data-v-038bdf36><div class="grid grid-cols-2 text-[17px] text-center" data-v-038bdf36>`);
      if (unref(isActiveStatus) === false) {
        _push(`<div class="${ssrRenderClass(`bg-[#3375af] text-white py-1`)}" data-v-038bdf36>\u09B8\u09B0\u09CD\u09AC\u09B6\u09C7\u09B7</div>`);
      } else {
        _push(`<div class="${ssrRenderClass(`hover:bg-[#3375af] hover:text-white cursor-pointer py-1`)}" data-v-038bdf36>\u09B8\u09B0\u09CD\u09AC\u09B6\u09C7\u09B7 </div>`);
      }
      if (unref(isActiveStatus) === true) {
        _push(`<div class="${ssrRenderClass(`bg-[#3375af] text-white py-1`)}" data-v-038bdf36> \u09B8\u09B0\u09CD\u09AC\u09BE\u09A7\u09BF\u0995 \u09AA\u09A0\u09BF\u09A4 </div>`);
      } else {
        _push(`<div class="${ssrRenderClass(`hover:bg-[#3375af] hover:text-white cursor-pointer py-1`)}" data-v-038bdf36> \u09B8\u09B0\u09CD\u09AC\u09BE\u09A7\u09BF\u0995 \u09AA\u09A0\u09BF\u09A4 </div>`);
      }
      _push(`</div>`);
      if (unref(isActiveStatus) === false) {
        _push(`<div class="latest-post px-3 h-[430px] overflow-y-auto" data-v-038bdf36><!--[-->`);
        ssrRenderList(unref(latestposts), (latstpost) => {
          var _a;
          _push(ssrRenderComponent(_component_NuxtLink, {
            to: `/category/${(_a = latstpost == null ? void 0 : latstpost.category) == null ? void 0 : _a.cat_slug}/${latstpost == null ? void 0 : latstpost.content_id}`,
            class: "grid grid-cols-12 gap-3 group border-b py-3 latest-post-loop",
            key: latstpost == null ? void 0 : latstpost.content_id
          }, {
            default: withCtx((_, _push2, _parent2, _scopeId) => {
              var _a2, _b;
              if (_push2) {
                _push2(`<div class="latest-post-tab-image col-span-4 overflow-hidden" data-v-038bdf36${_scopeId}>`);
                _push2(ssrRenderComponent(_component_nuxt_img, {
                  src: `${unref(siteurl).site_url}/media/content/images/${latstpost == null ? void 0 : latstpost.img_bg_path}`,
                  class: "mx-auto w-full group-hover:scale-110 duration-300",
                  placeholder: unref(img)(`${(_a2 = unref(siteurl)) == null ? void 0 : _a2.site_url}/logo/placeholder.jpg`)
                }, null, _parent2, _scopeId));
                _push2(`</div><div class="tab-latast-post-title col-span-8" data-v-038bdf36${_scopeId}><h4 class="text-[17px] group-hover:text-[#ff0000]" data-v-038bdf36${_scopeId}>${ssrInterpolate(latstpost == null ? void 0 : latstpost.content_heading)}</h4></div>`);
              } else {
                return [
                  createVNode("div", { class: "latest-post-tab-image col-span-4 overflow-hidden" }, [
                    createVNode(_component_nuxt_img, {
                      src: `${unref(siteurl).site_url}/media/content/images/${latstpost == null ? void 0 : latstpost.img_bg_path}`,
                      class: "mx-auto w-full group-hover:scale-110 duration-300",
                      placeholder: unref(img)(`${(_b = unref(siteurl)) == null ? void 0 : _b.site_url}/logo/placeholder.jpg`)
                    }, null, 8, ["src", "placeholder"])
                  ]),
                  createVNode("div", { class: "tab-latast-post-title col-span-8" }, [
                    createVNode("h4", { class: "text-[17px] group-hover:text-[#ff0000]" }, toDisplayString(latstpost == null ? void 0 : latstpost.content_heading), 1)
                  ])
                ];
              }
            }),
            _: 2
          }, _parent));
        });
        _push(`<!--]--></div>`);
      } else {
        _push(`<div class="latest-post px-3 h-[430px] overflow-y-auto" data-v-038bdf36><!--[-->`);
        ssrRenderList(unref(popularposts), (poplarpost) => {
          var _a;
          _push(ssrRenderComponent(_component_NuxtLink, {
            to: `/category/${(_a = poplarpost == null ? void 0 : poplarpost.category) == null ? void 0 : _a.cat_slug}/${poplarpost == null ? void 0 : poplarpost.content_id}`,
            class: "grid grid-cols-12 gap-3 group border-b py-3 latest-post-loop",
            key: poplarpost == null ? void 0 : poplarpost.content_id
          }, {
            default: withCtx((_, _push2, _parent2, _scopeId) => {
              var _a2, _b;
              if (_push2) {
                _push2(`<div class="latest-post-tab-image col-span-4 overflow-hidden" data-v-038bdf36${_scopeId}>`);
                _push2(ssrRenderComponent(_component_nuxt_img, {
                  src: `${unref(siteurl).site_url}/media/content/images/${poplarpost == null ? void 0 : poplarpost.img_bg_path}`,
                  class: "mx-auto w-full group-hover:scale-110 duration-300",
                  placeholder: unref(img)(`${(_a2 = unref(siteurl)) == null ? void 0 : _a2.site_url}/logo/placeholder.jpg`)
                }, null, _parent2, _scopeId));
                _push2(`</div><div class="tab-latast-post-title col-span-8" data-v-038bdf36${_scopeId}><h4 class="text-[17px] group-hover:text-[#ff0000]" data-v-038bdf36${_scopeId}>${ssrInterpolate(poplarpost == null ? void 0 : poplarpost.content_heading)}</h4></div>`);
              } else {
                return [
                  createVNode("div", { class: "latest-post-tab-image col-span-4 overflow-hidden" }, [
                    createVNode(_component_nuxt_img, {
                      src: `${unref(siteurl).site_url}/media/content/images/${poplarpost == null ? void 0 : poplarpost.img_bg_path}`,
                      class: "mx-auto w-full group-hover:scale-110 duration-300",
                      placeholder: unref(img)(`${(_b = unref(siteurl)) == null ? void 0 : _b.site_url}/logo/placeholder.jpg`)
                    }, null, 8, ["src", "placeholder"])
                  ]),
                  createVNode("div", { class: "tab-latast-post-title col-span-8" }, [
                    createVNode("h4", { class: "text-[17px] group-hover:text-[#ff0000]" }, toDisplayString(poplarpost == null ? void 0 : poplarpost.content_heading), 1)
                  ])
                ];
              }
            }),
            _: 2
          }, _parent));
        });
        _push(`<!--]--></div>`);
      }
      _push(`</div>`);
    };
  }
};
const _sfc_setup$y = _sfc_main$y.setup;
_sfc_main$y.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Home/PostTabs.vue");
  return _sfc_setup$y ? _sfc_setup$y(props, ctx) : void 0;
};
const __nuxt_component_12 = /* @__PURE__ */ _export_sfc(_sfc_main$y, [["__scopeId", "data-v-038bdf36"]]);
const _sfc_main$x = {
  __name: "RightThree",
  __ssrInlineRender: true,
  props: ["homeRightThreeAds"],
  setup(__props) {
    const data = __props;
    const siteurl = siteUrlState();
    return (_ctx, _push, _parent, _attrs) => {
      var _a, _b, _c, _d, _e;
      if (((_a = data == null ? void 0 : data.homeRightThreeAds) == null ? void 0 : _a.status) === 1) {
        _push(`<div${ssrRenderAttrs(mergeProps({ class: "ad-container" }, _attrs))}><div class="ad-section bg-[#f7f7f7]">`);
        if (((_b = data == null ? void 0 : data.homeRightThreeAds) == null ? void 0 : _b.type) === 3) {
          _push(`<a${ssrRenderAttr("href", (_c = data == null ? void 0 : data.homeRightThreeAds) == null ? void 0 : _c.external_link)} target="_blank" rel="nofollow"><img class="mx-auto"${ssrRenderAttr("src", `${unref(siteurl).site_url}/media/advertisement/${(_d = data == null ? void 0 : data.homeRightThreeAds) == null ? void 0 : _d.desktop_image_path}`)} alt="Header Ad"></a>`);
        } else {
          _push(`<div>${(_e = data == null ? void 0 : data.homeRightThreeAds) == null ? void 0 : _e.code}</div>`);
        }
        _push(`</div></div>`);
      } else {
        _push(`<!---->`);
      }
    };
  }
};
const _sfc_setup$x = _sfc_main$x.setup;
_sfc_main$x.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Ads/Desktop/Home/RightThree.vue");
  return _sfc_setup$x ? _sfc_setup$x(props, ctx) : void 0;
};
const __nuxt_component_13 = _sfc_main$x;
const _sfc_main$w = {
  __name: "RightFour",
  __ssrInlineRender: true,
  props: ["homeRightFourAds"],
  setup(__props) {
    const data = __props;
    const siteurl = siteUrlState();
    return (_ctx, _push, _parent, _attrs) => {
      var _a, _b, _c, _d, _e;
      if (((_a = data == null ? void 0 : data.homeRightFourAds) == null ? void 0 : _a.status) === 1) {
        _push(`<div${ssrRenderAttrs(mergeProps({ class: "ad-container" }, _attrs))}><div class="ad-section bg-[#f7f7f7]">`);
        if (((_b = data == null ? void 0 : data.homeRightFourAds) == null ? void 0 : _b.type) === 3) {
          _push(`<a${ssrRenderAttr("href", (_c = data == null ? void 0 : data.homeRightFourAds) == null ? void 0 : _c.external_link)} target="_blank" rel="nofollow"><img class="mx-auto"${ssrRenderAttr("src", `${unref(siteurl).site_url}/media/advertisement/${(_d = data == null ? void 0 : data.homeRightFourAds) == null ? void 0 : _d.desktop_image_path}`)} alt="Header Ad"></a>`);
        } else {
          _push(`<div>${(_e = data == null ? void 0 : data.homeRightFourAds) == null ? void 0 : _e.code}</div>`);
        }
        _push(`</div></div>`);
      } else {
        _push(`<!---->`);
      }
    };
  }
};
const _sfc_setup$w = _sfc_main$w.setup;
_sfc_main$w.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Ads/Desktop/Home/RightFour.vue");
  return _sfc_setup$w ? _sfc_setup$w(props, ctx) : void 0;
};
const __nuxt_component_14 = _sfc_main$w;
const _sfc_main$v = {
  __name: "RightFive",
  __ssrInlineRender: true,
  props: ["homeRightFiveAds"],
  setup(__props) {
    const data = __props;
    const siteurl = siteUrlState();
    return (_ctx, _push, _parent, _attrs) => {
      var _a, _b, _c, _d, _e;
      if (((_a = data == null ? void 0 : data.homeRightFiveAds) == null ? void 0 : _a.status) === 1) {
        _push(`<div${ssrRenderAttrs(mergeProps({ class: "ad-container" }, _attrs))}><div class="ad-section bg-[#f7f7f7]">`);
        if (((_b = data == null ? void 0 : data.homeRightFiveAds) == null ? void 0 : _b.type) === 3) {
          _push(`<a${ssrRenderAttr("href", (_c = data == null ? void 0 : data.homeRightFiveAds) == null ? void 0 : _c.external_link)} target="_blank" rel="nofollow"><img class="mx-auto"${ssrRenderAttr("src", `${unref(siteurl).site_url}/media/advertisement/${(_d = data == null ? void 0 : data.homeRightFiveAds) == null ? void 0 : _d.desktop_image_path}`)} alt="Header Ad"></a>`);
        } else {
          _push(`<div>${(_e = data == null ? void 0 : data.homeRightFiveAds) == null ? void 0 : _e.code}</div>`);
        }
        _push(`</div></div>`);
      } else {
        _push(`<!---->`);
      }
    };
  }
};
const _sfc_setup$v = _sfc_main$v.setup;
_sfc_main$v.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Ads/Desktop/Home/RightFive.vue");
  return _sfc_setup$v ? _sfc_setup$v(props, ctx) : void 0;
};
const __nuxt_component_15 = _sfc_main$v;
const _sfc_main$u = {
  __name: "RIghtSix",
  __ssrInlineRender: true,
  props: ["homeRightSixAds"],
  setup(__props) {
    const data = __props;
    const siteurl = siteUrlState();
    return (_ctx, _push, _parent, _attrs) => {
      var _a, _b, _c, _d, _e;
      if (((_a = data == null ? void 0 : data.homeRightSixAds) == null ? void 0 : _a.status) === 1) {
        _push(`<div${ssrRenderAttrs(mergeProps({ class: "ad-container" }, _attrs))}><div class="ad-section bg-[#f7f7f7]">`);
        if (((_b = data == null ? void 0 : data.homeRightSixAds) == null ? void 0 : _b.type) === 3) {
          _push(`<a${ssrRenderAttr("href", (_c = data == null ? void 0 : data.homeRightSixAds) == null ? void 0 : _c.external_link)} target="_blank" rel="nofollow"><img class="mx-auto"${ssrRenderAttr("src", `${unref(siteurl).site_url}/media/advertisement/${(_d = data == null ? void 0 : data.homeRightSixAds) == null ? void 0 : _d.desktop_image_path}`)} alt="Header Ad"></a>`);
        } else {
          _push(`<div>${(_e = data == null ? void 0 : data.homeRightSixAds) == null ? void 0 : _e.code}</div>`);
        }
        _push(`</div></div>`);
      } else {
        _push(`<!---->`);
      }
    };
  }
};
const _sfc_setup$u = _sfc_main$u.setup;
_sfc_main$u.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Ads/Desktop/Home/RIghtSix.vue");
  return _sfc_setup$u ? _sfc_setup$u(props, ctx) : void 0;
};
const __nuxt_component_16 = _sfc_main$u;
const _sfc_main$t = {
  __name: "RightSeven",
  __ssrInlineRender: true,
  props: ["homeRightSevenAds"],
  setup(__props) {
    const data = __props;
    const siteurl = siteUrlState();
    return (_ctx, _push, _parent, _attrs) => {
      var _a, _b, _c, _d, _e;
      if (((_a = data == null ? void 0 : data.homeRightSevenAds) == null ? void 0 : _a.status) === 1) {
        _push(`<div${ssrRenderAttrs(mergeProps({ class: "ad-container" }, _attrs))}><div class="ad-section bg-[#f7f7f7]">`);
        if (((_b = data == null ? void 0 : data.homeRightSevenAds) == null ? void 0 : _b.type) === 3) {
          _push(`<a${ssrRenderAttr("href", (_c = data == null ? void 0 : data.homeRightSevenAds) == null ? void 0 : _c.external_link)} target="_blank" rel="nofollow"><img class="mx-auto"${ssrRenderAttr("src", `${unref(siteurl).site_url}/media/advertisement/${(_d = data == null ? void 0 : data.homeRightSevenAds) == null ? void 0 : _d.desktop_image_path}`)} alt="Header Ad"></a>`);
        } else {
          _push(`<div>${(_e = data == null ? void 0 : data.homeRightSevenAds) == null ? void 0 : _e.code}</div>`);
        }
        _push(`</div></div>`);
      } else {
        _push(`<!---->`);
      }
    };
  }
};
const _sfc_setup$t = _sfc_main$t.setup;
_sfc_main$t.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Ads/Desktop/Home/RightSeven.vue");
  return _sfc_setup$t ? _sfc_setup$t(props, ctx) : void 0;
};
const __nuxt_component_17 = _sfc_main$t;
const _sfc_main$s = {
  __name: "SpecialReport",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    const img = useImage();
    const siteUrl = siteUrlState();
    const specialreports = useState(() => [], "$b8BO193X0X");
    const { data: hsreport } = ([__temp, __restore] = withAsyncContext(() => useFetch("/api/home/specialreports", {
      method: "GET"
    }, "$zi06LhBJmZ")), __temp = await __temp, __restore(), __temp);
    specialreports.value = hsreport;
    return (_ctx, _push, _parent, _attrs) => {
      var _a, _b;
      const _component_NuxtLink = __nuxt_component_0$1;
      const _component_nuxt_img = __nuxt_component_1$1;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "home-special-report-category mb-6" }, _attrs))}><div class="category-header border-b-4 border-b-[#3375af] my-3">`);
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: `/${(_b = (_a = unref(specialreports)[0]) == null ? void 0 : _a.category) == null ? void 0 : _b.cat_slug}`,
        class: "flex gap-3 items-center"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<span class="w-3 h-3 bg-[#3375af]"${_scopeId}></span><h2 class="text-[#3375af] text-[18px] font-semibold"${_scopeId}>\u09AC\u09BF\u09B6\u09C7\u09B7 \u09AA\u09CD\u09B0\u09A4\u09BF\u09AC\u09C7\u09A6\u09A8</h2>`);
          } else {
            return [
              createVNode("span", { class: "w-3 h-3 bg-[#3375af]" }),
              createVNode("h2", { class: "text-[#3375af] text-[18px] font-semibold" }, "\u09AC\u09BF\u09B6\u09C7\u09B7 \u09AA\u09CD\u09B0\u09A4\u09BF\u09AC\u09C7\u09A6\u09A8")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div><div class="grid grid-cols-12 gap-4"><!--[-->`);
      ssrRenderList(unref(specialreports), (hspecialreport) => {
        var _a2;
        _push(`<div class="col-span-12 md:col-span-3">`);
        _push(ssrRenderComponent(_component_NuxtLink, {
          to: `/category/${(_a2 = hspecialreport == null ? void 0 : hspecialreport.category) == null ? void 0 : _a2.cat_slug}/${hspecialreport == null ? void 0 : hspecialreport.content_id}`,
          class: "flex flex-col gap-2 group"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            var _a3, _b2;
            if (_push2) {
              _push2(`<div class="overflow-hidden"${_scopeId}>`);
              _push2(ssrRenderComponent(_component_nuxt_img, {
                src: `${unref(siteUrl).site_url}/media/content/images/${hspecialreport == null ? void 0 : hspecialreport.img_bg_path}`,
                class: "mx-auto w-full group-hover:scale-110 duration-300",
                placeholder: unref(img)(`${(_a3 = unref(siteUrl)) == null ? void 0 : _a3.site_url}/logo/placeholder.jpg`)
              }, null, _parent2, _scopeId));
              _push2(`</div><h3 class="text-[19px] leading-tight group-hover:text-[#ff0000]"${_scopeId}>${ssrInterpolate(hspecialreport == null ? void 0 : hspecialreport.content_heading)}</h3>`);
            } else {
              return [
                createVNode("div", { class: "overflow-hidden" }, [
                  createVNode(_component_nuxt_img, {
                    src: `${unref(siteUrl).site_url}/media/content/images/${hspecialreport == null ? void 0 : hspecialreport.img_bg_path}`,
                    class: "mx-auto w-full group-hover:scale-110 duration-300",
                    placeholder: unref(img)(`${(_b2 = unref(siteUrl)) == null ? void 0 : _b2.site_url}/logo/placeholder.jpg`)
                  }, null, 8, ["src", "placeholder"])
                ]),
                createVNode("h3", { class: "text-[19px] leading-tight group-hover:text-[#ff0000]" }, toDisplayString(hspecialreport == null ? void 0 : hspecialreport.content_heading), 1)
              ];
            }
          }),
          _: 2
        }, _parent));
        _push(`</div>`);
      });
      _push(`<!--]--></div></div>`);
    };
  }
};
const _sfc_setup$s = _sfc_main$s.setup;
_sfc_main$s.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Home/Category/SpecialReport.vue");
  return _sfc_setup$s ? _sfc_setup$s(props, ctx) : void 0;
};
const __nuxt_component_18 = _sfc_main$s;
const _sfc_main$r = {
  __name: "Sports",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    const img = useImage();
    const siteUrl = siteUrlState();
    const sportscontent = useState(() => [], "$R8EFbgK5a7");
    const { data: hsport } = ([__temp, __restore] = withAsyncContext(() => useFetch("/api/home/sportscontent", {
      method: "GET"
    }, "$2GWCAhupIL")), __temp = await __temp, __restore(), __temp);
    sportscontent.value = hsport;
    return (_ctx, _push, _parent, _attrs) => {
      var _a, _b, _c, _d, _e;
      const _component_NuxtLink = __nuxt_component_0$1;
      const _component_nuxt_img = __nuxt_component_1$1;
      const _component_ClientOnly = __nuxt_component_4$1;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "home-sports-category" }, _attrs))} data-v-ed66a8e6><div class="category-header border-b-4 border-b-[#3375af] my-3" data-v-ed66a8e6>`);
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: `/${(_b = (_a = unref(sportscontent)[0]) == null ? void 0 : _a.category) == null ? void 0 : _b.cat_slug}`,
        class: "flex gap-3 items-center"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<span class="w-3 h-3 bg-[#3375af]" data-v-ed66a8e6${_scopeId}></span><h2 class="text-[#3375af] text-[18px] font-semibold" data-v-ed66a8e6${_scopeId}>\u0996\u09C7\u09B2\u09BE</h2>`);
          } else {
            return [
              createVNode("span", { class: "w-3 h-3 bg-[#3375af]" }),
              createVNode("h2", { class: "text-[#3375af] text-[18px] font-semibold" }, "\u0996\u09C7\u09B2\u09BE")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div><div class="grid grid-cols-12 gap-4" data-v-ed66a8e6><div class="col-span-12 md:col-span-7" data-v-ed66a8e6>`);
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: `/category/${(_d = (_c = unref(sportscontent)[0]) == null ? void 0 : _c.category) == null ? void 0 : _d.cat_slug}/${(_e = unref(sportscontent)[0]) == null ? void 0 : _e.content_id}`,
        class: "flex flex-col group gap-2"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          var _a2, _b2, _c2, _d2;
          if (_push2) {
            _push2(`<div class="national-feature-image overflow-hidden" data-v-ed66a8e6${_scopeId}>`);
            _push2(ssrRenderComponent(_component_nuxt_img, {
              src: `${unref(siteUrl).site_url}/media/content/images/${(_a2 = unref(sportscontent)[0]) == null ? void 0 : _a2.img_bg_path}`,
              class: "mx-auto w-full group-hover:scale-110 duration-300",
              placeholder: unref(img)(`${unref(siteUrl).site_url}/media/common/logo1672518180.png`, { height: 300 })
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="national-feature-description flex flex-col gap-1" data-v-ed66a8e6${_scopeId}><h3 class="text-[25px] leading-tight group-hover:text-[#ff0000]" data-v-ed66a8e6${_scopeId}>${ssrInterpolate((_b2 = unref(sportscontent)[0]) == null ? void 0 : _b2.content_heading)}</h3>`);
            _push2(ssrRenderComponent(_component_ClientOnly, null, {}, _parent2, _scopeId));
            _push2(`</div>`);
          } else {
            return [
              createVNode("div", { class: "national-feature-image overflow-hidden" }, [
                createVNode(_component_nuxt_img, {
                  src: `${unref(siteUrl).site_url}/media/content/images/${(_c2 = unref(sportscontent)[0]) == null ? void 0 : _c2.img_bg_path}`,
                  class: "mx-auto w-full group-hover:scale-110 duration-300",
                  placeholder: unref(img)(`${unref(siteUrl).site_url}/media/common/logo1672518180.png`, { height: 300 })
                }, null, 8, ["src", "placeholder"])
              ]),
              createVNode("div", { class: "national-feature-description flex flex-col gap-1" }, [
                createVNode("h3", { class: "text-[25px] leading-tight group-hover:text-[#ff0000]" }, toDisplayString((_d2 = unref(sportscontent)[0]) == null ? void 0 : _d2.content_heading), 1),
                createVNode(_component_ClientOnly, null, {
                  default: withCtx(() => {
                    var _a3, _b3;
                    return [
                      createVNode("div", {
                        class: "text-[16px] font-[400]",
                        innerHTML: `${(_b3 = (_a3 = unref(sportscontent)[0]) == null ? void 0 : _a3.content_details) == null ? void 0 : _b3.substring(
                          0,
                          165
                        )} ...`
                      }, null, 8, ["innerHTML"])
                    ];
                  }),
                  _: 1
                })
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div><div class="col-span-12 md:col-span-5" data-v-ed66a8e6><div class="home-national-category-except-post flex flex-col" data-v-ed66a8e6><!--[-->`);
      ssrRenderList(unref(sportscontent).slice(1, 5), (hmsport) => {
        var _a2, _b2;
        _push(`<div class="grid grid-cols-12 gap-4 group h-sports-excpt border-b py-4" data-v-ed66a8e6><div class="col-span-5 overflow-hidden" data-v-ed66a8e6>`);
        _push(ssrRenderComponent(_component_NuxtLink, {
          to: `/category/${(_a2 = hmsport == null ? void 0 : hmsport.category) == null ? void 0 : _a2.cat_slug}/${hmsport == null ? void 0 : hmsport.content_id}`
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            var _a3, _b3;
            if (_push2) {
              _push2(ssrRenderComponent(_component_nuxt_img, {
                src: `${unref(siteUrl).site_url}/media/content/images/${hmsport == null ? void 0 : hmsport.img_bg_path}`,
                class: "mx-auto w-full group-hover:scale-110 duration-300",
                placeholder: unref(img)(`${(_a3 = unref(siteUrl)) == null ? void 0 : _a3.site_url}/logo/placeholder.jpg`)
              }, null, _parent2, _scopeId));
            } else {
              return [
                createVNode(_component_nuxt_img, {
                  src: `${unref(siteUrl).site_url}/media/content/images/${hmsport == null ? void 0 : hmsport.img_bg_path}`,
                  class: "mx-auto w-full group-hover:scale-110 duration-300",
                  placeholder: unref(img)(`${(_b3 = unref(siteUrl)) == null ? void 0 : _b3.site_url}/logo/placeholder.jpg`)
                }, null, 8, ["src", "placeholder"])
              ];
            }
          }),
          _: 2
        }, _parent));
        _push(`</div><div class="col-span-7" data-v-ed66a8e6>`);
        _push(ssrRenderComponent(_component_NuxtLink, {
          to: `/category/${(_b2 = hmsport == null ? void 0 : hmsport.category) == null ? void 0 : _b2.cat_slug}/${hmsport == null ? void 0 : hmsport.content_id}`
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<h4 class="text-[18px] leading-tight group-hover:text-[#ff0000]" data-v-ed66a8e6${_scopeId}>${ssrInterpolate(hmsport == null ? void 0 : hmsport.content_heading)}</h4>`);
            } else {
              return [
                createVNode("h4", { class: "text-[18px] leading-tight group-hover:text-[#ff0000]" }, toDisplayString(hmsport == null ? void 0 : hmsport.content_heading), 1)
              ];
            }
          }),
          _: 2
        }, _parent));
        _push(`</div></div>`);
      });
      _push(`<!--]--></div></div></div></div>`);
    };
  }
};
const _sfc_setup$r = _sfc_main$r.setup;
_sfc_main$r.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Home/Category/Sports.vue");
  return _sfc_setup$r ? _sfc_setup$r(props, ctx) : void 0;
};
const __nuxt_component_19 = /* @__PURE__ */ _export_sfc(_sfc_main$r, [["__scopeId", "data-v-ed66a8e6"]]);
const _sfc_main$q = {
  __name: "Saradesh",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    const img = useImage();
    const siteUrl = siteUrlState();
    const saradeshcontents = useState(() => [], "$SYQwHJpeIw");
    const { data: hsradesh } = ([__temp, __restore] = withAsyncContext(() => useFetch("/api/home/saradeshcontent", {
      method: "GET"
    }, "$MJUsmayPdM")), __temp = await __temp, __restore(), __temp);
    saradeshcontents.value = hsradesh;
    return (_ctx, _push, _parent, _attrs) => {
      var _a, _b;
      const _component_NuxtLink = __nuxt_component_0$1;
      const _component_nuxt_img = __nuxt_component_1$1;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "home-saradesh-category" }, _attrs))} data-v-1a894a04><div class="category-header border-b-4 border-b-[#3375af] my-3" data-v-1a894a04>`);
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: `/${(_b = (_a = unref(saradeshcontents)[0]) == null ? void 0 : _a.category) == null ? void 0 : _b.cat_slug}`,
        class: "flex gap-3 items-center"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<span class="w-3 h-3 bg-[#3375af]" data-v-1a894a04${_scopeId}></span><h2 class="text-[#3375af] text-[18px] font-semibold" data-v-1a894a04${_scopeId}>\u09B8\u09BE\u09B0\u09BE\u09A6\u09C7\u09B6</h2>`);
          } else {
            return [
              createVNode("span", { class: "w-3 h-3 bg-[#3375af]" }),
              createVNode("h2", { class: "text-[#3375af] text-[18px] font-semibold" }, "\u09B8\u09BE\u09B0\u09BE\u09A6\u09C7\u09B6")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div><div class="home-saradesh-category-except-post flex flex-col" data-v-1a894a04><!--[-->`);
      ssrRenderList(unref(saradeshcontents), (saradeshcon) => {
        var _a2, _b2;
        _push(`<div class="grid grid-cols-12 gap-4 group h-sports-excpt border-b py-4" data-v-1a894a04><div class="col-span-5 overflow-hidden" data-v-1a894a04>`);
        _push(ssrRenderComponent(_component_NuxtLink, {
          to: `/category/${(_a2 = saradeshcon == null ? void 0 : saradeshcon.category) == null ? void 0 : _a2.cat_slug}/${saradeshcon == null ? void 0 : saradeshcon.content_id}`
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            var _a3, _b3;
            if (_push2) {
              _push2(ssrRenderComponent(_component_nuxt_img, {
                src: `${unref(siteUrl).site_url}/media/content/images/${saradeshcon == null ? void 0 : saradeshcon.img_bg_path}`,
                class: "mx-auto w-full group-hover:scale-110 duration-300",
                placeholder: unref(img)(`${(_a3 = unref(siteUrl)) == null ? void 0 : _a3.site_url}/logo/placeholder.jpg`)
              }, null, _parent2, _scopeId));
            } else {
              return [
                createVNode(_component_nuxt_img, {
                  src: `${unref(siteUrl).site_url}/media/content/images/${saradeshcon == null ? void 0 : saradeshcon.img_bg_path}`,
                  class: "mx-auto w-full group-hover:scale-110 duration-300",
                  placeholder: unref(img)(`${(_b3 = unref(siteUrl)) == null ? void 0 : _b3.site_url}/logo/placeholder.jpg`)
                }, null, 8, ["src", "placeholder"])
              ];
            }
          }),
          _: 2
        }, _parent));
        _push(`</div><div class="col-span-7" data-v-1a894a04>`);
        _push(ssrRenderComponent(_component_NuxtLink, {
          to: `/category/${(_b2 = saradeshcon == null ? void 0 : saradeshcon.category) == null ? void 0 : _b2.cat_slug}/${saradeshcon == null ? void 0 : saradeshcon.content_id}`
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<h4 class="text-[18px] leading-tight group-hover:text-[#ff0000]" data-v-1a894a04${_scopeId}>${ssrInterpolate(saradeshcon == null ? void 0 : saradeshcon.content_heading)}</h4>`);
            } else {
              return [
                createVNode("h4", { class: "text-[18px] leading-tight group-hover:text-[#ff0000]" }, toDisplayString(saradeshcon == null ? void 0 : saradeshcon.content_heading), 1)
              ];
            }
          }),
          _: 2
        }, _parent));
        _push(`</div></div>`);
      });
      _push(`<!--]--></div></div>`);
    };
  }
};
const _sfc_setup$q = _sfc_main$q.setup;
_sfc_main$q.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Home/Category/Saradesh.vue");
  return _sfc_setup$q ? _sfc_setup$q(props, ctx) : void 0;
};
const __nuxt_component_20 = /* @__PURE__ */ _export_sfc(_sfc_main$q, [["__scopeId", "data-v-1a894a04"]]);
const _sfc_main$p = {
  __name: "MiddleFive",
  __ssrInlineRender: true,
  props: ["homeMiddleFiveAds"],
  setup(__props) {
    const data = __props;
    const siteurl = siteUrlState();
    return (_ctx, _push, _parent, _attrs) => {
      var _a, _b, _c, _d, _e;
      if (((_a = data == null ? void 0 : data.homeMiddleFiveAds) == null ? void 0 : _a.status) === 1) {
        _push(`<div${ssrRenderAttrs(mergeProps({ class: "ad-container" }, _attrs))}><div class="ad-section bg-[#f7f7f7]">`);
        if (((_b = data == null ? void 0 : data.homeMiddleFiveAds) == null ? void 0 : _b.type) === 3) {
          _push(`<a${ssrRenderAttr("href", (_c = data == null ? void 0 : data.homeMiddleFiveAds) == null ? void 0 : _c.external_link)} target="_blank" rel="nofollow"><img class="mx-auto"${ssrRenderAttr("src", `${unref(siteurl).site_url}/media/advertisement/${(_d = data == null ? void 0 : data.homeMiddleFiveAds) == null ? void 0 : _d.desktop_image_path}`)} alt="Header Ad"></a>`);
        } else {
          _push(`<div>${(_e = data == null ? void 0 : data.homeMiddleFiveAds) == null ? void 0 : _e.code}</div>`);
        }
        _push(`</div></div>`);
      } else {
        _push(`<!---->`);
      }
    };
  }
};
const _sfc_setup$p = _sfc_main$p.setup;
_sfc_main$p.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Ads/Desktop/Home/MiddleFive.vue");
  return _sfc_setup$p ? _sfc_setup$p(props, ctx) : void 0;
};
const __nuxt_component_21 = _sfc_main$p;
const _sfc_main$o = {
  __name: "Entertainment",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    const img = useImage();
    const siteurl = siteUrlState();
    const entertainments = useState(() => [], "$U7TIb2Z76L");
    const { data: entertainc } = ([__temp, __restore] = withAsyncContext(() => useFetch("/api/home/entertainmentcontent", {
      method: "GET"
    }, "$PnBFPNc8eD")), __temp = await __temp, __restore(), __temp);
    entertainments.value = entertainc;
    return (_ctx, _push, _parent, _attrs) => {
      var _a, _b, _c, _d, _e;
      const _component_NuxtLink = __nuxt_component_0$1;
      const _component_nuxt_img = __nuxt_component_1$1;
      const _component_ClientOnly = __nuxt_component_4$1;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "home-intertainment-category" }, _attrs))} data-v-b118b580><div class="category-header border-b-4 border-b-[#3375af] my-3" data-v-b118b580>`);
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: `/${(_b = (_a = unref(entertainments)[0]) == null ? void 0 : _a.category) == null ? void 0 : _b.cat_slug}`,
        class: "flex gap-3 items-center"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<span class="w-3 h-3 bg-[#3375af]" data-v-b118b580${_scopeId}></span><h2 class="text-[#3375af] text-[18px] font-semibold" data-v-b118b580${_scopeId}>\u09AC\u09BF\u09A8\u09CB\u09A6\u09A8</h2>`);
          } else {
            return [
              createVNode("span", { class: "w-3 h-3 bg-[#3375af]" }),
              createVNode("h2", { class: "text-[#3375af] text-[18px] font-semibold" }, "\u09AC\u09BF\u09A8\u09CB\u09A6\u09A8")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div><div class="grid grid-cols-12 gap-4" data-v-b118b580><div class="col-span-12 md:col-span-6" data-v-b118b580>`);
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: `/category/${(_d = (_c = unref(entertainments)[0]) == null ? void 0 : _c.category) == null ? void 0 : _d.cat_slug}/${(_e = unref(entertainments)[0]) == null ? void 0 : _e.content_id}`,
        class: "flex flex-col group gap-2"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          var _a2, _b2, _c2, _d2;
          if (_push2) {
            _push2(`<div class="intertainment-feature-image overflow-hidden" data-v-b118b580${_scopeId}>`);
            _push2(ssrRenderComponent(_component_nuxt_img, {
              src: `${unref(siteurl).site_url}/media/content/images/${(_a2 = unref(entertainments)[0]) == null ? void 0 : _a2.img_bg_path}`,
              class: "mx-auto w-full group-hover:scale-110 duration-300",
              placeholder: unref(img)(`${unref(siteurl).site_url}/media/common/logo1672518180.png`, { height: 300 })
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="intertainment-feature-description flex flex-col gap-1" data-v-b118b580${_scopeId}><h3 class="text-[25px] leading-tight group-hover:text-[#ff0000]" data-v-b118b580${_scopeId}>${ssrInterpolate((_b2 = unref(entertainments)[0]) == null ? void 0 : _b2.content_heading)}</h3>`);
            _push2(ssrRenderComponent(_component_ClientOnly, null, {}, _parent2, _scopeId));
            _push2(`</div>`);
          } else {
            return [
              createVNode("div", { class: "intertainment-feature-image overflow-hidden" }, [
                createVNode(_component_nuxt_img, {
                  src: `${unref(siteurl).site_url}/media/content/images/${(_c2 = unref(entertainments)[0]) == null ? void 0 : _c2.img_bg_path}`,
                  class: "mx-auto w-full group-hover:scale-110 duration-300",
                  placeholder: unref(img)(`${unref(siteurl).site_url}/media/common/logo1672518180.png`, { height: 300 })
                }, null, 8, ["src", "placeholder"])
              ]),
              createVNode("div", { class: "intertainment-feature-description flex flex-col gap-1" }, [
                createVNode("h3", { class: "text-[25px] leading-tight group-hover:text-[#ff0000]" }, toDisplayString((_d2 = unref(entertainments)[0]) == null ? void 0 : _d2.content_heading), 1),
                createVNode(_component_ClientOnly, null, {
                  default: withCtx(() => {
                    var _a3, _b3;
                    return [
                      createVNode("div", {
                        class: "text-md",
                        innerHTML: `${(_b3 = (_a3 = unref(entertainments)[0]) == null ? void 0 : _a3.content_details) == null ? void 0 : _b3.substring(
                          0,
                          270
                        )} ...`
                      }, null, 8, ["innerHTML"])
                    ];
                  }),
                  _: 1
                })
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div><div class="col-span-12 md:col-span-6" data-v-b118b580><div class="home-intertainment-category-except-post grid grid-cols-2 gap-4" data-v-b118b580><!--[-->`);
      ssrRenderList(unref(entertainments).slice(1, 5), (entertainment) => {
        var _a2, _b2;
        _push(`<div class="flex flex-col gap-4 group h-sports-excpt" data-v-b118b580><div class="col-span-5 overflow-hidden" data-v-b118b580>`);
        _push(ssrRenderComponent(_component_NuxtLink, {
          to: `/category/${(_a2 = entertainment == null ? void 0 : entertainment.category) == null ? void 0 : _a2.cat_slug}/${entertainment == null ? void 0 : entertainment.content_id}`
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            var _a3, _b3;
            if (_push2) {
              _push2(ssrRenderComponent(_component_nuxt_img, {
                src: `${unref(siteurl).site_url}/media/content/images/${entertainment == null ? void 0 : entertainment.img_bg_path}`,
                class: "mx-auto w-full group-hover:scale-110 duration-300",
                placeholder: unref(img)(`${(_a3 = unref(siteurl)) == null ? void 0 : _a3.site_url}/logo/placeholder.jpg`)
              }, null, _parent2, _scopeId));
            } else {
              return [
                createVNode(_component_nuxt_img, {
                  src: `${unref(siteurl).site_url}/media/content/images/${entertainment == null ? void 0 : entertainment.img_bg_path}`,
                  class: "mx-auto w-full group-hover:scale-110 duration-300",
                  placeholder: unref(img)(`${(_b3 = unref(siteurl)) == null ? void 0 : _b3.site_url}/logo/placeholder.jpg`)
                }, null, 8, ["src", "placeholder"])
              ];
            }
          }),
          _: 2
        }, _parent));
        _push(`</div><div class="col-span-7" data-v-b118b580>`);
        _push(ssrRenderComponent(_component_NuxtLink, {
          to: `/category/${(_b2 = entertainment == null ? void 0 : entertainment.category) == null ? void 0 : _b2.cat_slug}/${entertainment == null ? void 0 : entertainment.content_id}`
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<h4 class="text-[18px] leading-tight group-hover:text-[#ff0000]" data-v-b118b580${_scopeId}>${ssrInterpolate(entertainment == null ? void 0 : entertainment.content_heading)}</h4>`);
            } else {
              return [
                createVNode("h4", { class: "text-[18px] leading-tight group-hover:text-[#ff0000]" }, toDisplayString(entertainment == null ? void 0 : entertainment.content_heading), 1)
              ];
            }
          }),
          _: 2
        }, _parent));
        _push(`</div></div>`);
      });
      _push(`<!--]--></div></div></div></div>`);
    };
  }
};
const _sfc_setup$o = _sfc_main$o.setup;
_sfc_main$o.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Home/Category/Entertainment.vue");
  return _sfc_setup$o ? _sfc_setup$o(props, ctx) : void 0;
};
const __nuxt_component_22 = /* @__PURE__ */ _export_sfc(_sfc_main$o, [["__scopeId", "data-v-b118b580"]]);
const _sfc_main$n = {
  __name: "Lifestyle",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    const img = useImage();
    const siteurl = siteUrlState();
    const lifestyles = useState(() => [], "$WGz53CY87q");
    const { data: lifesc } = ([__temp, __restore] = withAsyncContext(() => useFetch("/api/home/lifestylecontent", {
      method: "GET"
    }, "$Y2DKSoLacn")), __temp = await __temp, __restore(), __temp);
    lifestyles.value = lifesc;
    return (_ctx, _push, _parent, _attrs) => {
      var _a, _b, _c;
      const _component_NuxtLink = __nuxt_component_0$1;
      const _component_nuxt_img = __nuxt_component_1$1;
      if (((_a = unref(lifestyles)) == null ? void 0 : _a.length) > 0) {
        _push(`<div${ssrRenderAttrs(mergeProps({ class: "home-entertainment-category" }, _attrs))} data-v-54d51d37><div class="category-header border-b-4 border-b-[#3375af] my-3" data-v-54d51d37>`);
        _push(ssrRenderComponent(_component_NuxtLink, {
          to: `/${(_c = (_b = unref(lifestyles)[0]) == null ? void 0 : _b.category) == null ? void 0 : _c.cat_slug}`,
          class: "flex gap-3 items-center"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<span class="w-3 h-3 bg-[#3375af]" data-v-54d51d37${_scopeId}></span><h2 class="text-[#3375af] text-[18px] font-semibold" data-v-54d51d37${_scopeId}>\u09B2\u09BE\u0987\u09AB\u09B8\u09CD\u099F\u09BE\u0987\u09B2</h2>`);
            } else {
              return [
                createVNode("span", { class: "w-3 h-3 bg-[#3375af]" }),
                createVNode("h2", { class: "text-[#3375af] text-[18px] font-semibold" }, "\u09B2\u09BE\u0987\u09AB\u09B8\u09CD\u099F\u09BE\u0987\u09B2")
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(`</div><div class="home-crime-category-except-post flex flex-col" data-v-54d51d37><!--[-->`);
        ssrRenderList(unref(lifestyles), (lifestyle) => {
          var _a2, _b2;
          _push(`<div class="grid grid-cols-12 gap-4 group h-sports-excpt border-b py-4" data-v-54d51d37><div class="col-span-5 overflow-hidden" data-v-54d51d37>`);
          _push(ssrRenderComponent(_component_NuxtLink, {
            to: `/category/${(_a2 = lifestyle == null ? void 0 : lifestyle.category) == null ? void 0 : _a2.cat_slug}/${lifestyle == null ? void 0 : lifestyle.content_id}`
          }, {
            default: withCtx((_, _push2, _parent2, _scopeId) => {
              var _a3, _b3;
              if (_push2) {
                _push2(ssrRenderComponent(_component_nuxt_img, {
                  src: `${unref(siteurl).site_url}/media/content/images/${lifestyle == null ? void 0 : lifestyle.img_bg_path}`,
                  class: "mx-auto w-full group-hover:scale-110 duration-300",
                  placeholder: unref(img)(`${(_a3 = unref(siteurl)) == null ? void 0 : _a3.site_url}/logo/placeholder.jpg`)
                }, null, _parent2, _scopeId));
              } else {
                return [
                  createVNode(_component_nuxt_img, {
                    src: `${unref(siteurl).site_url}/media/content/images/${lifestyle == null ? void 0 : lifestyle.img_bg_path}`,
                    class: "mx-auto w-full group-hover:scale-110 duration-300",
                    placeholder: unref(img)(`${(_b3 = unref(siteurl)) == null ? void 0 : _b3.site_url}/logo/placeholder.jpg`)
                  }, null, 8, ["src", "placeholder"])
                ];
              }
            }),
            _: 2
          }, _parent));
          _push(`</div><div class="col-span-7" data-v-54d51d37>`);
          _push(ssrRenderComponent(_component_NuxtLink, {
            to: `/category/${(_b2 = lifestyle == null ? void 0 : lifestyle.category) == null ? void 0 : _b2.cat_slug}/${lifestyle == null ? void 0 : lifestyle.content_id}`
          }, {
            default: withCtx((_, _push2, _parent2, _scopeId) => {
              if (_push2) {
                _push2(`<h4 class="text-[18px] leading-tight group-hover:text-[#ff0000]" data-v-54d51d37${_scopeId}>${ssrInterpolate(lifestyle == null ? void 0 : lifestyle.content_heading)}</h4>`);
              } else {
                return [
                  createVNode("h4", { class: "text-[18px] leading-tight group-hover:text-[#ff0000]" }, toDisplayString(lifestyle == null ? void 0 : lifestyle.content_heading), 1)
                ];
              }
            }),
            _: 2
          }, _parent));
          _push(`</div></div>`);
        });
        _push(`<!--]--></div></div>`);
      } else {
        _push(`<!---->`);
      }
    };
  }
};
const _sfc_setup$n = _sfc_main$n.setup;
_sfc_main$n.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Home/Category/Lifestyle.vue");
  return _sfc_setup$n ? _sfc_setup$n(props, ctx) : void 0;
};
const __nuxt_component_23 = /* @__PURE__ */ _export_sfc(_sfc_main$n, [["__scopeId", "data-v-54d51d37"]]);
const _sfc_main$m = {
  __name: "MiddleSix",
  __ssrInlineRender: true,
  props: ["homeMiddleSixAds"],
  setup(__props) {
    const data = __props;
    const siteurl = siteUrlState();
    return (_ctx, _push, _parent, _attrs) => {
      var _a, _b, _c, _d, _e;
      if (((_a = data == null ? void 0 : data.homeMiddleSixAds) == null ? void 0 : _a.status) === 1) {
        _push(`<div${ssrRenderAttrs(mergeProps({ class: "ad-container" }, _attrs))}><div class="ad-section bg-[#f7f7f7]">`);
        if (((_b = data == null ? void 0 : data.homeMiddleSixAds) == null ? void 0 : _b.type) === 3) {
          _push(`<a${ssrRenderAttr("href", (_c = data == null ? void 0 : data.homeMiddleSixAds) == null ? void 0 : _c.external_link)} target="_blank" rel="nofollow"><img class="mx-auto"${ssrRenderAttr("src", `${unref(siteurl).site_url}/media/advertisement/${(_d = data == null ? void 0 : data.homeMiddleSixAds) == null ? void 0 : _d.desktop_image_path}`)} alt="Header Ad"></a>`);
        } else {
          _push(`<div>${(_e = data == null ? void 0 : data.homeMiddleSixAds) == null ? void 0 : _e.code}</div>`);
        }
        _push(`</div></div>`);
      } else {
        _push(`<!---->`);
      }
    };
  }
};
const _sfc_setup$m = _sfc_main$m.setup;
_sfc_main$m.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Ads/Desktop/Home/MiddleSix.vue");
  return _sfc_setup$m ? _sfc_setup$m(props, ctx) : void 0;
};
const __nuxt_component_24 = _sfc_main$m;
const _sfc_main$l = {
  __name: "EnglishContent",
  __ssrInlineRender: true,
  setup(__props) {
    const img = useImage();
    const siteUrl = siteUrlState();
    return (_ctx, _push, _parent, _attrs) => {
      const _component_NuxtLink = __nuxt_component_0$1;
      const _component_nuxt_img = __nuxt_component_1$1;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "max-w-[1280px] mx-auto px-4 md:px-2 py-6 md:py-10" }, _attrs))}><div class="category-header border-b-4 border-b-[#3375af]">`);
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: "/",
        class: "flex gap-3 items-center"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<span class="w-3 h-3 bg-[#3375af]"${_scopeId}></span><h2 class="text-[#3375af] text-[18px] font-semibold"${_scopeId}>ENGLISH</h2>`);
          } else {
            return [
              createVNode("span", { class: "w-3 h-3 bg-[#3375af]" }),
              createVNode("h2", { class: "text-[#3375af] text-[18px] font-semibold" }, "ENGLISH")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div><div class="grid grid-cols-12 gap-6 mt-4"><div class="col-span-12 md:col-span-3"><div class="flex flex-col gap-3">`);
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: "/",
        class: "flex flex-col gap-2 group"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          var _a, _b;
          if (_push2) {
            _push2(`<div class="overflow-hidden"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_nuxt_img, {
              src: "https://www.dhakaprokash24.com/media/content/images/2023October/SM/gaja-2-20231008122635.jpg",
              class: "mx-auto w-full group-hover:scale-110 duration-300",
              placeholder: unref(img)(`${(_a = unref(siteUrl)) == null ? void 0 : _a.site_url}/logo/placeholder.jpg`)
            }, null, _parent2, _scopeId));
            _push2(`</div><p class="text-[20px] group-hover:text-[#ff0000] font-semibold"${_scopeId}>Level playing field will ensure in KCC polls: CEC</p>`);
          } else {
            return [
              createVNode("div", { class: "overflow-hidden" }, [
                createVNode(_component_nuxt_img, {
                  src: "https://www.dhakaprokash24.com/media/content/images/2023October/SM/gaja-2-20231008122635.jpg",
                  class: "mx-auto w-full group-hover:scale-110 duration-300",
                  placeholder: unref(img)(`${(_b = unref(siteUrl)) == null ? void 0 : _b.site_url}/logo/placeholder.jpg`)
                }, null, 8, ["placeholder"])
              ]),
              createVNode("p", { class: "text-[20px] group-hover:text-[#ff0000] font-semibold" }, "Level playing field will ensure in KCC polls: CEC")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: "/",
        class: "flex flex-col gap-2 group"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          var _a, _b;
          if (_push2) {
            _push2(`<div class="overflow-hidden"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_nuxt_img, {
              src: "https://www.dhakaprokash24.com/media/content/images/2023October/SM/gaja-2-20231008122635.jpg",
              class: "mx-auto w-full group-hover:scale-110 duration-300",
              placeholder: unref(img)(`${(_a = unref(siteUrl)) == null ? void 0 : _a.site_url}/logo/placeholder.jpg`)
            }, null, _parent2, _scopeId));
            _push2(`</div><p class="text-[20px] group-hover:text-[#ff0000] font-semibold"${_scopeId}>Level playing field will ensure in KCC polls: CEC</p>`);
          } else {
            return [
              createVNode("div", { class: "overflow-hidden" }, [
                createVNode(_component_nuxt_img, {
                  src: "https://www.dhakaprokash24.com/media/content/images/2023October/SM/gaja-2-20231008122635.jpg",
                  class: "mx-auto w-full group-hover:scale-110 duration-300",
                  placeholder: unref(img)(`${(_b = unref(siteUrl)) == null ? void 0 : _b.site_url}/logo/placeholder.jpg`)
                }, null, 8, ["placeholder"])
              ]),
              createVNode("p", { class: "text-[20px] group-hover:text-[#ff0000] font-semibold" }, "Level playing field will ensure in KCC polls: CEC")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div><div class="col-span-12 md:col-span-6">`);
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: "/",
        class: "flex flex-col gap-5 group"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          var _a, _b;
          if (_push2) {
            _push2(`<div class="overflow-hidden"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_nuxt_img, {
              src: "https://www.dhakaprokash24.com/media/content/images/2023October/SM/gaja-2-20231008122635.jpg",
              class: "mx-auto w-full group-hover:scale-110 duration-300",
              placeholder: unref(img)(`${(_a = unref(siteUrl)) == null ? void 0 : _a.site_url}/logo/placeholder.jpg`)
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="flex flex-col gap-2"${_scopeId}><h3 class="text-[20px] group-hover:text-[#ff0000] font-semibold leading-tight"${_scopeId}>Level playing field will ensure in KCC polls: CEC</h3><p class="leading-tight text-[14px]"${_scopeId}>Power supply situation is again getting worse with the decrease in generation and rising mercury level in hot summer. According to official sources at state-owned Bangladesh Power Development Board (BPDB), the country experienced 1,451MW of load shedding at 12 noon on..</p></div>`);
          } else {
            return [
              createVNode("div", { class: "overflow-hidden" }, [
                createVNode(_component_nuxt_img, {
                  src: "https://www.dhakaprokash24.com/media/content/images/2023October/SM/gaja-2-20231008122635.jpg",
                  class: "mx-auto w-full group-hover:scale-110 duration-300",
                  placeholder: unref(img)(`${(_b = unref(siteUrl)) == null ? void 0 : _b.site_url}/logo/placeholder.jpg`)
                }, null, 8, ["placeholder"])
              ]),
              createVNode("div", { class: "flex flex-col gap-2" }, [
                createVNode("h3", { class: "text-[20px] group-hover:text-[#ff0000] font-semibold leading-tight" }, "Level playing field will ensure in KCC polls: CEC"),
                createVNode("p", { class: "leading-tight text-[14px]" }, "Power supply situation is again getting worse with the decrease in generation and rising mercury level in hot summer. According to official sources at state-owned Bangladesh Power Development Board (BPDB), the country experienced 1,451MW of load shedding at 12 noon on..")
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div><div class="col-span-12 md:col-span-3"><div class="flex flex-col gap-3">`);
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: "/",
        class: "flex flex-col gap-2 group"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          var _a, _b;
          if (_push2) {
            _push2(`<div class="overflow-hidden"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_nuxt_img, {
              src: "https://www.dhakaprokash24.com/media/content/images/2023October/SM/gaja-2-20231008122635.jpg",
              class: "mx-auto w-full group-hover:scale-110 duration-300",
              placeholder: unref(img)(`${(_a = unref(siteUrl)) == null ? void 0 : _a.site_url}/logo/placeholder.jpg`)
            }, null, _parent2, _scopeId));
            _push2(`</div><p class="text-[20px] group-hover:text-[#ff0000] font-semibold"${_scopeId}>Level playing field will ensure in KCC polls: CEC</p>`);
          } else {
            return [
              createVNode("div", { class: "overflow-hidden" }, [
                createVNode(_component_nuxt_img, {
                  src: "https://www.dhakaprokash24.com/media/content/images/2023October/SM/gaja-2-20231008122635.jpg",
                  class: "mx-auto w-full group-hover:scale-110 duration-300",
                  placeholder: unref(img)(`${(_b = unref(siteUrl)) == null ? void 0 : _b.site_url}/logo/placeholder.jpg`)
                }, null, 8, ["placeholder"])
              ]),
              createVNode("p", { class: "text-[20px] group-hover:text-[#ff0000] font-semibold" }, "Level playing field will ensure in KCC polls: CEC")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: "/",
        class: "flex flex-col gap-2 group"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          var _a, _b;
          if (_push2) {
            _push2(`<div class="overflow-hidden"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_nuxt_img, {
              src: "https://www.dhakaprokash24.com/media/content/images/2023October/SM/gaja-2-20231008122635.jpg",
              class: "mx-auto w-full group-hover:scale-110 duration-300",
              placeholder: unref(img)(`${(_a = unref(siteUrl)) == null ? void 0 : _a.site_url}/logo/placeholder.jpg`)
            }, null, _parent2, _scopeId));
            _push2(`</div><p class="text-[20px] group-hover:text-[#ff0000] font-semibold"${_scopeId}>Level playing field will ensure in KCC polls: CEC</p>`);
          } else {
            return [
              createVNode("div", { class: "overflow-hidden" }, [
                createVNode(_component_nuxt_img, {
                  src: "https://www.dhakaprokash24.com/media/content/images/2023October/SM/gaja-2-20231008122635.jpg",
                  class: "mx-auto w-full group-hover:scale-110 duration-300",
                  placeholder: unref(img)(`${(_b = unref(siteUrl)) == null ? void 0 : _b.site_url}/logo/placeholder.jpg`)
                }, null, 8, ["placeholder"])
              ]),
              createVNode("p", { class: "text-[20px] group-hover:text-[#ff0000] font-semibold" }, "Level playing field will ensure in KCC polls: CEC")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div></div></div>`);
    };
  }
};
const _sfc_setup$l = _sfc_main$l.setup;
_sfc_main$l.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Home/EnglishContent.vue");
  return _sfc_setup$l ? _sfc_setup$l(props, ctx) : void 0;
};
const __nuxt_component_25 = _sfc_main$l;
const _sfc_main$k = {
  __name: "MiddleSeven",
  __ssrInlineRender: true,
  props: ["homeMiddleSevenAds"],
  setup(__props) {
    const data = __props;
    const siteurl = siteUrlState();
    return (_ctx, _push, _parent, _attrs) => {
      var _a, _b, _c, _d, _e;
      if (((_a = data == null ? void 0 : data.homeMiddleSevenAds) == null ? void 0 : _a.status) === 1) {
        _push(`<div${ssrRenderAttrs(mergeProps({ class: "ad-container" }, _attrs))}><div class="ad-section bg-[#f7f7f7]">`);
        if (((_b = data == null ? void 0 : data.homeMiddleSevenAds) == null ? void 0 : _b.type) === 3) {
          _push(`<a${ssrRenderAttr("href", (_c = data == null ? void 0 : data.homeMiddleSevenAds) == null ? void 0 : _c.external_link)} target="_blank" rel="nofollow"><img class="mx-auto"${ssrRenderAttr("src", `${unref(siteurl).site_url}/media/advertisement/${(_d = data == null ? void 0 : data.homeMiddleSevenAds) == null ? void 0 : _d.desktop_image_path}`)} alt="Header Ad"></a>`);
        } else {
          _push(`<div>${(_e = data == null ? void 0 : data.homeMiddleSevenAds) == null ? void 0 : _e.code}</div>`);
        }
        _push(`</div></div>`);
      } else {
        _push(`<!---->`);
      }
    };
  }
};
const _sfc_setup$k = _sfc_main$k.setup;
_sfc_main$k.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Ads/Desktop/Home/MiddleSeven.vue");
  return _sfc_setup$k ? _sfc_setup$k(props, ctx) : void 0;
};
const __nuxt_component_26 = _sfc_main$k;
const _sfc_main$j = {
  __name: "LawCourt",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    const img = useImage();
    const siteurl = siteUrlState();
    const lawcourtContents = useState(() => [], "$lV6Y8aJpPY");
    const { data: lwcourt } = ([__temp, __restore] = withAsyncContext(() => useFetch("/api/home/lawcourtcontent", {
      method: "GET"
    }, "$P2QvlUiVGg")), __temp = await __temp, __restore(), __temp);
    lawcourtContents.value = lwcourt;
    return (_ctx, _push, _parent, _attrs) => {
      var _a, _b, _c, _d, _e;
      const _component_NuxtLink = __nuxt_component_0$1;
      const _component_nuxt_img = __nuxt_component_1$1;
      const _component_ClientOnly = __nuxt_component_4$1;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "home-law-court-category" }, _attrs))} data-v-e5354911><div class="category-header border-b-4 border-b-[#3375af] my-3" data-v-e5354911>`);
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: `/${(_b = (_a = unref(lawcourtContents)[0]) == null ? void 0 : _a.category) == null ? void 0 : _b.cat_slug}`,
        class: "flex gap-3 items-center"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<span class="w-3 h-3 bg-[#3375af]" data-v-e5354911${_scopeId}></span><h2 class="text-[#3375af] text-[18px] font-semibold" data-v-e5354911${_scopeId}>\u0986\u0987\u09A8 \u0986\u09A6\u09BE\u09B2\u09A4</h2>`);
          } else {
            return [
              createVNode("span", { class: "w-3 h-3 bg-[#3375af]" }),
              createVNode("h2", { class: "text-[#3375af] text-[18px] font-semibold" }, "\u0986\u0987\u09A8 \u0986\u09A6\u09BE\u09B2\u09A4")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div><div class="grid grid-cols-12 gap-4" data-v-e5354911><div class="col-span-12 md:col-span-6" data-v-e5354911>`);
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: `/category/${(_d = (_c = unref(lawcourtContents)[0]) == null ? void 0 : _c.category) == null ? void 0 : _d.cat_slug}/${(_e = unref(lawcourtContents)[0]) == null ? void 0 : _e.content_id}`,
        class: "flex flex-col group gap-2"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          var _a2, _b2, _c2, _d2, _e2, _f;
          if (_push2) {
            _push2(`<div class="intertainment-feature-image overflow-hidden" data-v-e5354911${_scopeId}>`);
            _push2(ssrRenderComponent(_component_nuxt_img, {
              src: `${unref(siteurl).site_url}/media/content/images/${(_a2 = unref(lawcourtContents)[0]) == null ? void 0 : _a2.img_bg_path}`,
              class: "mx-auto w-full group-hover:scale-110 duration-300",
              placeholder: unref(img)(`${(_b2 = unref(siteurl)) == null ? void 0 : _b2.site_url}/logo/placeholder.jpg`)
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="intertainment-feature-description flex flex-col gap-1" data-v-e5354911${_scopeId}><h3 class="text-[25px] leading-tight group-hover:text-[#ff0000]" data-v-e5354911${_scopeId}>${ssrInterpolate((_c2 = unref(lawcourtContents)[0]) == null ? void 0 : _c2.content_heading)}</h3>`);
            _push2(ssrRenderComponent(_component_ClientOnly, null, {}, _parent2, _scopeId));
            _push2(`</div>`);
          } else {
            return [
              createVNode("div", { class: "intertainment-feature-image overflow-hidden" }, [
                createVNode(_component_nuxt_img, {
                  src: `${unref(siteurl).site_url}/media/content/images/${(_d2 = unref(lawcourtContents)[0]) == null ? void 0 : _d2.img_bg_path}`,
                  class: "mx-auto w-full group-hover:scale-110 duration-300",
                  placeholder: unref(img)(`${(_e2 = unref(siteurl)) == null ? void 0 : _e2.site_url}/logo/placeholder.jpg`)
                }, null, 8, ["src", "placeholder"])
              ]),
              createVNode("div", { class: "intertainment-feature-description flex flex-col gap-1" }, [
                createVNode("h3", { class: "text-[25px] leading-tight group-hover:text-[#ff0000]" }, toDisplayString((_f = unref(lawcourtContents)[0]) == null ? void 0 : _f.content_heading), 1),
                createVNode(_component_ClientOnly, null, {
                  default: withCtx(() => {
                    var _a3, _b3;
                    return [
                      createVNode("div", {
                        class: "text-md",
                        innerHTML: `${(_b3 = (_a3 = unref(lawcourtContents)[0]) == null ? void 0 : _a3.content_details) == null ? void 0 : _b3.substring(
                          0,
                          270
                        )} ...`
                      }, null, 8, ["innerHTML"])
                    ];
                  }),
                  _: 1
                })
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div><div class="col-span-12 md:col-span-6" data-v-e5354911><div class="home-intertainment-category-except-post grid grid-cols-2 gap-4" data-v-e5354911><!--[-->`);
      ssrRenderList(unref(lawcourtContents).slice(1, 5), (lawcourtContent) => {
        var _a2, _b2;
        _push(`<div class="flex flex-col gap-4 group h-sports-excpt" data-v-e5354911><div class="col-span-5 overflow-hidden" data-v-e5354911>`);
        _push(ssrRenderComponent(_component_NuxtLink, {
          to: `/category/${(_a2 = lawcourtContent == null ? void 0 : lawcourtContent.category) == null ? void 0 : _a2.cat_slug}/${lawcourtContent == null ? void 0 : lawcourtContent.content_id}`
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(ssrRenderComponent(_component_nuxt_img, {
                src: `${unref(siteurl).site_url}/media/content/images/${lawcourtContent == null ? void 0 : lawcourtContent.img_bg_path}`,
                class: "mx-auto w-full group-hover:scale-110 duration-300",
                placeholder: unref(img)(`${unref(siteurl).site_url}/media/common/logo1672518180.png`, { height: 300 })
              }, null, _parent2, _scopeId));
            } else {
              return [
                createVNode(_component_nuxt_img, {
                  src: `${unref(siteurl).site_url}/media/content/images/${lawcourtContent == null ? void 0 : lawcourtContent.img_bg_path}`,
                  class: "mx-auto w-full group-hover:scale-110 duration-300",
                  placeholder: unref(img)(`${unref(siteurl).site_url}/media/common/logo1672518180.png`, { height: 300 })
                }, null, 8, ["src", "placeholder"])
              ];
            }
          }),
          _: 2
        }, _parent));
        _push(`</div><div class="col-span-7" data-v-e5354911>`);
        _push(ssrRenderComponent(_component_NuxtLink, {
          to: `/category/${(_b2 = lawcourtContent == null ? void 0 : lawcourtContent.category) == null ? void 0 : _b2.cat_slug}/${lawcourtContent == null ? void 0 : lawcourtContent.content_id}`
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<h4 class="text-[18px] leading-tight group-hover:text-[#ff0000]" data-v-e5354911${_scopeId}>${ssrInterpolate(lawcourtContent == null ? void 0 : lawcourtContent.content_heading)}</h4>`);
            } else {
              return [
                createVNode("h4", { class: "text-[18px] leading-tight group-hover:text-[#ff0000]" }, toDisplayString(lawcourtContent == null ? void 0 : lawcourtContent.content_heading), 1)
              ];
            }
          }),
          _: 2
        }, _parent));
        _push(`</div></div>`);
      });
      _push(`<!--]--></div></div></div></div>`);
    };
  }
};
const _sfc_setup$j = _sfc_main$j.setup;
_sfc_main$j.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Home/Category/LawCourt.vue");
  return _sfc_setup$j ? _sfc_setup$j(props, ctx) : void 0;
};
const __nuxt_component_27 = /* @__PURE__ */ _export_sfc(_sfc_main$j, [["__scopeId", "data-v-e5354911"]]);
const _sfc_main$i = {
  __name: "Crime",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    const img = useImage();
    const siteurl = siteUrlState();
    const crimecontents = useState(() => [], "$sdR5g9mTVX");
    const { data: crmct } = ([__temp, __restore] = withAsyncContext(() => useFetch("/api/home/crimecontent", {
      method: "GET"
    }, "$7ITcpljnzJ")), __temp = await __temp, __restore(), __temp);
    crimecontents.value = crmct;
    return (_ctx, _push, _parent, _attrs) => {
      var _a, _b;
      const _component_NuxtLink = __nuxt_component_0$1;
      const _component_nuxt_img = __nuxt_component_1$1;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "home-crime-category" }, _attrs))} data-v-7db8be11><div class="category-header border-b-4 border-b-[#3375af] my-3" data-v-7db8be11>`);
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: `/${(_b = (_a = unref(crimecontents)[0]) == null ? void 0 : _a.category) == null ? void 0 : _b.cat_slug}`,
        class: "flex gap-3 items-center"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<span class="w-3 h-3 bg-[#3375af]" data-v-7db8be11${_scopeId}></span><h2 class="text-[#3375af] text-[18px] font-semibold" data-v-7db8be11${_scopeId}>\u0985\u09AA\u09B0\u09BE\u09A7</h2>`);
          } else {
            return [
              createVNode("span", { class: "w-3 h-3 bg-[#3375af]" }),
              createVNode("h2", { class: "text-[#3375af] text-[18px] font-semibold" }, "\u0985\u09AA\u09B0\u09BE\u09A7")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div><div class="home-crime-category-except-post flex flex-col" data-v-7db8be11><!--[-->`);
      ssrRenderList(unref(crimecontents), (crimecontent) => {
        var _a2, _b2;
        _push(`<div class="grid grid-cols-12 gap-4 group h-sports-excpt border-b py-4" data-v-7db8be11><div class="col-span-5 overflow-hidden" data-v-7db8be11>`);
        _push(ssrRenderComponent(_component_NuxtLink, {
          to: `/category/${(_a2 = crimecontent == null ? void 0 : crimecontent.category) == null ? void 0 : _a2.cat_slug}/${crimecontent == null ? void 0 : crimecontent.content_id}`
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            var _a3, _b3;
            if (_push2) {
              _push2(ssrRenderComponent(_component_nuxt_img, {
                src: `${unref(siteurl).site_url}/media/content/images/${crimecontent == null ? void 0 : crimecontent.img_bg_path}`,
                class: "mx-auto w-full group-hover:scale-110 duration-300",
                placeholder: unref(img)(`${(_a3 = unref(siteurl)) == null ? void 0 : _a3.site_url}/logo/placeholder.jpg`)
              }, null, _parent2, _scopeId));
            } else {
              return [
                createVNode(_component_nuxt_img, {
                  src: `${unref(siteurl).site_url}/media/content/images/${crimecontent == null ? void 0 : crimecontent.img_bg_path}`,
                  class: "mx-auto w-full group-hover:scale-110 duration-300",
                  placeholder: unref(img)(`${(_b3 = unref(siteurl)) == null ? void 0 : _b3.site_url}/logo/placeholder.jpg`)
                }, null, 8, ["src", "placeholder"])
              ];
            }
          }),
          _: 2
        }, _parent));
        _push(`</div><div class="col-span-7" data-v-7db8be11>`);
        _push(ssrRenderComponent(_component_NuxtLink, {
          to: `/category/${(_b2 = crimecontent == null ? void 0 : crimecontent.category) == null ? void 0 : _b2.cat_slug}/${crimecontent == null ? void 0 : crimecontent.content_id}`
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<h4 class="text-[18px] leading-tight group-hover:text-[#ff0000]" data-v-7db8be11${_scopeId}>${ssrInterpolate(crimecontent == null ? void 0 : crimecontent.content_heading)}</h4>`);
            } else {
              return [
                createVNode("h4", { class: "text-[18px] leading-tight group-hover:text-[#ff0000]" }, toDisplayString(crimecontent == null ? void 0 : crimecontent.content_heading), 1)
              ];
            }
          }),
          _: 2
        }, _parent));
        _push(`</div></div>`);
      });
      _push(`<!--]--></div></div>`);
    };
  }
};
const _sfc_setup$i = _sfc_main$i.setup;
_sfc_main$i.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Home/Category/Crime.vue");
  return _sfc_setup$i ? _sfc_setup$i(props, ctx) : void 0;
};
const __nuxt_component_28 = /* @__PURE__ */ _export_sfc(_sfc_main$i, [["__scopeId", "data-v-7db8be11"]]);
const _sfc_main$h = {
  __name: "Technology",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    const img = useImage();
    const siteurl = siteUrlState();
    const technologycontents = useState(() => [], "$AYYXbjJeIW");
    const { data: technologyc } = ([__temp, __restore] = withAsyncContext(() => useFetch("/api/home/technologycontent", {
      method: "GET"
    }, "$prFCGVJlmW")), __temp = await __temp, __restore(), __temp);
    technologycontents.value = technologyc;
    return (_ctx, _push, _parent, _attrs) => {
      var _a, _b, _c, _d, _e, _f;
      const _component_NuxtLink = __nuxt_component_0$1;
      const _component_nuxt_img = __nuxt_component_1$1;
      const _component_ClientOnly = __nuxt_component_4$1;
      if (((_a = unref(technologycontents)) == null ? void 0 : _a.length) > 0) {
        _push(`<div${ssrRenderAttrs(mergeProps({ class: "home-technology-category" }, _attrs))}><div class="category-header border-b-4 border-b-[#3375af] my-3">`);
        _push(ssrRenderComponent(_component_NuxtLink, {
          to: `/${(_c = (_b = unref(technologycontents)[0]) == null ? void 0 : _b.category) == null ? void 0 : _c.cat_slug}`,
          class: "flex gap-3 items-center"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<span class="w-3 h-3 bg-[#3375af]"${_scopeId}></span><h2 class="text-[#3375af] text-[18px] font-semibold"${_scopeId}>\u09AC\u09BF\u099C\u09CD\u099E\u09BE\u09A8-\u09A4\u09A5\u09CD\u09AF\u09AA\u09CD\u09B0\u09AF\u09C1\u0995\u09CD\u09A4\u09BF</h2>`);
            } else {
              return [
                createVNode("span", { class: "w-3 h-3 bg-[#3375af]" }),
                createVNode("h2", { class: "text-[#3375af] text-[18px] font-semibold" }, "\u09AC\u09BF\u099C\u09CD\u099E\u09BE\u09A8-\u09A4\u09A5\u09CD\u09AF\u09AA\u09CD\u09B0\u09AF\u09C1\u0995\u09CD\u09A4\u09BF")
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(`</div><div class="flex flex-col gap-4"><div class="">`);
        _push(ssrRenderComponent(_component_NuxtLink, {
          to: `/category/${(_e = (_d = unref(technologycontents)[0]) == null ? void 0 : _d.category) == null ? void 0 : _e.cat_slug}/${(_f = unref(technologycontents)[0]) == null ? void 0 : _f.content_id}`,
          class: "grid grid-cols-1 md:grid-cols-2 group gap-2"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            var _a2, _b2, _c2, _d2;
            if (_push2) {
              _push2(`<div class="intertainment-feature-image overflow-hidden"${_scopeId}>`);
              _push2(ssrRenderComponent(_component_nuxt_img, {
                src: `${unref(siteurl).site_url}/media/content/images/${(_a2 = unref(technologycontents)[0]) == null ? void 0 : _a2.img_bg_path}`,
                class: "mx-auto w-full group-hover:scale-110 duration-300",
                placeholder: unref(img)(`${unref(siteurl).site_url}/media/common/logo1672518180.png`, { height: 300 })
              }, null, _parent2, _scopeId));
              _push2(`</div><div class="intertainment-feature-description flex flex-col gap-1"${_scopeId}><h3 class="text-[25px] leading-tight group-hover:text-[#ff0000]"${_scopeId}>${ssrInterpolate((_b2 = unref(technologycontents)[0]) == null ? void 0 : _b2.content_heading)}</h3>`);
              _push2(ssrRenderComponent(_component_ClientOnly, null, {}, _parent2, _scopeId));
              _push2(`</div>`);
            } else {
              return [
                createVNode("div", { class: "intertainment-feature-image overflow-hidden" }, [
                  createVNode(_component_nuxt_img, {
                    src: `${unref(siteurl).site_url}/media/content/images/${(_c2 = unref(technologycontents)[0]) == null ? void 0 : _c2.img_bg_path}`,
                    class: "mx-auto w-full group-hover:scale-110 duration-300",
                    placeholder: unref(img)(`${unref(siteurl).site_url}/media/common/logo1672518180.png`, { height: 300 })
                  }, null, 8, ["src", "placeholder"])
                ]),
                createVNode("div", { class: "intertainment-feature-description flex flex-col gap-1" }, [
                  createVNode("h3", { class: "text-[25px] leading-tight group-hover:text-[#ff0000]" }, toDisplayString((_d2 = unref(technologycontents)[0]) == null ? void 0 : _d2.content_heading), 1),
                  createVNode(_component_ClientOnly, null, {
                    default: withCtx(() => {
                      var _a3, _b3;
                      return [
                        createVNode("div", {
                          class: "text-md",
                          innerHTML: `${(_b3 = (_a3 = unref(technologycontents)[0]) == null ? void 0 : _a3.content_details) == null ? void 0 : _b3.substring(
                            0,
                            165
                          )} ...`
                        }, null, 8, ["innerHTML"])
                      ];
                    }),
                    _: 1
                  })
                ])
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(`</div><div class="col-span-12 md:col-span-6"><div class="home-intertainment-category-except-post grid grid-cols-2 gap-4"><!--[-->`);
        ssrRenderList(unref(technologycontents).slice(1, 5), (technologycontent) => {
          var _a2, _b2;
          _push(`<div class="flex flex-col gap-4 group h-sports-excpt"><div class="col-span-5 overflow-hidden">`);
          _push(ssrRenderComponent(_component_NuxtLink, {
            to: `/category/${(_a2 = technologycontent == null ? void 0 : technologycontent.category) == null ? void 0 : _a2.cat_slug}/${technologycontent == null ? void 0 : technologycontent.content_id}`
          }, {
            default: withCtx((_, _push2, _parent2, _scopeId) => {
              var _a3, _b3;
              if (_push2) {
                _push2(ssrRenderComponent(_component_nuxt_img, {
                  src: `${unref(siteurl).site_url}/media/content/images/${technologycontent == null ? void 0 : technologycontent.img_bg_path}`,
                  class: "mx-auto w-full group-hover:scale-110 duration-300",
                  placeholder: unref(img)(`${(_a3 = unref(siteurl)) == null ? void 0 : _a3.site_url}/logo/placeholder.jpg`)
                }, null, _parent2, _scopeId));
              } else {
                return [
                  createVNode(_component_nuxt_img, {
                    src: `${unref(siteurl).site_url}/media/content/images/${technologycontent == null ? void 0 : technologycontent.img_bg_path}`,
                    class: "mx-auto w-full group-hover:scale-110 duration-300",
                    placeholder: unref(img)(`${(_b3 = unref(siteurl)) == null ? void 0 : _b3.site_url}/logo/placeholder.jpg`)
                  }, null, 8, ["src", "placeholder"])
                ];
              }
            }),
            _: 2
          }, _parent));
          _push(`</div><div class="col-span-7">`);
          _push(ssrRenderComponent(_component_NuxtLink, {
            to: `/category/${(_b2 = technologycontent == null ? void 0 : technologycontent.category) == null ? void 0 : _b2.cat_slug}/${technologycontent == null ? void 0 : technologycontent.content_id}`
          }, {
            default: withCtx((_, _push2, _parent2, _scopeId) => {
              if (_push2) {
                _push2(`<h4 class="text-[18px] leading-tight group-hover:text-[#ff0000]"${_scopeId}>${ssrInterpolate(technologycontent == null ? void 0 : technologycontent.content_heading)}</h4>`);
              } else {
                return [
                  createVNode("h4", { class: "text-[18px] leading-tight group-hover:text-[#ff0000]" }, toDisplayString(technologycontent == null ? void 0 : technologycontent.content_heading), 1)
                ];
              }
            }),
            _: 2
          }, _parent));
          _push(`</div></div>`);
        });
        _push(`<!--]--></div></div></div></div>`);
      } else {
        _push(`<!---->`);
      }
    };
  }
};
const _sfc_setup$h = _sfc_main$h.setup;
_sfc_main$h.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Home/Category/Technology.vue");
  return _sfc_setup$h ? _sfc_setup$h(props, ctx) : void 0;
};
const __nuxt_component_29 = _sfc_main$h;
const _sfc_main$g = {
  __name: "Career",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    const img = useImage();
    const siteurl = siteUrlState();
    const careers = useState(() => [], "$AIFE9o2ERb");
    const { data: dcareer } = ([__temp, __restore] = withAsyncContext(() => useFetch("/api/home/careercontent", {
      method: "GET"
    }, "$tUBKVPG5PA")), __temp = await __temp, __restore(), __temp);
    careers.value = dcareer;
    return (_ctx, _push, _parent, _attrs) => {
      var _a, _b, _c, _d, _e, _f;
      const _component_NuxtLink = __nuxt_component_0$1;
      const _component_nuxt_img = __nuxt_component_1$1;
      if (((_a = unref(careers)) == null ? void 0 : _a.length) > 0) {
        _push(`<div${ssrRenderAttrs(mergeProps({ class: "home-career-category" }, _attrs))}><div class="category-header border-b-4 border-b-[#3375af] my-3">`);
        _push(ssrRenderComponent(_component_NuxtLink, {
          to: `/${(_c = (_b = unref(careers)[0]) == null ? void 0 : _b.category) == null ? void 0 : _c.cat_slug}`,
          class: "flex gap-3 items-center"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<span class="w-3 h-3 bg-[#3375af]"${_scopeId}></span><h2 class="text-[#3375af] text-[18px] font-semibold"${_scopeId}>\u0995\u09CD\u09AF\u09BE\u09B0\u09BF\u09DF\u09BE\u09B0</h2>`);
            } else {
              return [
                createVNode("span", { class: "w-3 h-3 bg-[#3375af]" }),
                createVNode("h2", { class: "text-[#3375af] text-[18px] font-semibold" }, "\u0995\u09CD\u09AF\u09BE\u09B0\u09BF\u09DF\u09BE\u09B0")
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(`</div><div class="home-career-c-content flex flex-col gap-3">`);
        _push(ssrRenderComponent(_component_NuxtLink, {
          to: `/category/${(_e = (_d = unref(careers)[0]) == null ? void 0 : _d.category) == null ? void 0 : _e.cat_slug}/${(_f = unref(careers)[0]) == null ? void 0 : _f.content_id}`,
          class: "flex flex-col gap-2 group"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            var _a2, _b2, _c2, _d2, _e2, _f2;
            if (_push2) {
              _push2(`<div class="overflow-hidden"${_scopeId}>`);
              _push2(ssrRenderComponent(_component_nuxt_img, {
                src: `${unref(siteurl).site_url}/media/content/images/${(_a2 = unref(careers)[0]) == null ? void 0 : _a2.img_bg_path}`,
                class: "mx-auto w-full group-hover:scale-110 duration-300",
                placeholder: unref(img)(`${(_b2 = unref(siteurl)) == null ? void 0 : _b2.site_url}/logo/placeholder.jpg`)
              }, null, _parent2, _scopeId));
              _push2(`</div><h3 class="text-[19px] leading-tight group-hover:text-[#ff0000]"${_scopeId}>${ssrInterpolate((_c2 = unref(careers)[0]) == null ? void 0 : _c2.content_heading)}</h3>`);
            } else {
              return [
                createVNode("div", { class: "overflow-hidden" }, [
                  createVNode(_component_nuxt_img, {
                    src: `${unref(siteurl).site_url}/media/content/images/${(_d2 = unref(careers)[0]) == null ? void 0 : _d2.img_bg_path}`,
                    class: "mx-auto w-full group-hover:scale-110 duration-300",
                    placeholder: unref(img)(`${(_e2 = unref(siteurl)) == null ? void 0 : _e2.site_url}/logo/placeholder.jpg`)
                  }, null, 8, ["src", "placeholder"])
                ]),
                createVNode("h3", { class: "text-[19px] leading-tight group-hover:text-[#ff0000]" }, toDisplayString((_f2 = unref(careers)[0]) == null ? void 0 : _f2.content_heading), 1)
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(`<div class="h-p-c-excpt flex flex-col"><!--[-->`);
        ssrRenderList(unref(careers).slice(1, 8), (career) => {
          var _a2;
          _push(ssrRenderComponent(_component_NuxtLink, {
            to: `/category/${(_a2 = career == null ? void 0 : career.category) == null ? void 0 : _a2.cat_slug}/${career == null ? void 0 : career.content_id}`,
            class: "border-b py-3",
            key: career.content_id
          }, {
            default: withCtx((_, _push2, _parent2, _scopeId) => {
              if (_push2) {
                _push2(`<h4 class="text-[17px] hover:text-[#ff0000] leading-tight"${_scopeId}>${ssrInterpolate(career == null ? void 0 : career.content_heading)}</h4>`);
              } else {
                return [
                  createVNode("h4", { class: "text-[17px] hover:text-[#ff0000] leading-tight" }, toDisplayString(career == null ? void 0 : career.content_heading), 1)
                ];
              }
            }),
            _: 2
          }, _parent));
        });
        _push(`<!--]--></div></div></div>`);
      } else {
        _push(`<!---->`);
      }
    };
  }
};
const _sfc_setup$g = _sfc_main$g.setup;
_sfc_main$g.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Home/Category/Career.vue");
  return _sfc_setup$g ? _sfc_setup$g(props, ctx) : void 0;
};
const __nuxt_component_30 = _sfc_main$g;
const _sfc_main$f = {
  __name: "Campus",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    const img = useImage();
    const siteurl = siteUrlState();
    const campuses = useState(() => [], "$fsRPCZvHmV");
    const { data: dcampus } = ([__temp, __restore] = withAsyncContext(() => useFetch("/api/home/campuscontent", {
      method: "GET"
    }, "$TaRv9vB6rD")), __temp = await __temp, __restore(), __temp);
    campuses.value = dcampus;
    return (_ctx, _push, _parent, _attrs) => {
      var _a, _b, _c, _d, _e, _f;
      const _component_NuxtLink = __nuxt_component_0$1;
      const _component_nuxt_img = __nuxt_component_1$1;
      if (((_a = unref(campuses)) == null ? void 0 : _a.length) > 0) {
        _push(`<div${ssrRenderAttrs(mergeProps({ class: "home-campus-category" }, _attrs))}><div class="category-header border-b-4 border-b-[#3375af] my-3">`);
        _push(ssrRenderComponent(_component_NuxtLink, {
          to: `/${(_c = (_b = unref(campuses)[0]) == null ? void 0 : _b.category) == null ? void 0 : _c.cat_slug}`,
          class: "flex gap-3 items-center"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<span class="w-3 h-3 bg-[#3375af]"${_scopeId}></span><h2 class="text-[#3375af] text-[18px] font-semibold"${_scopeId}>\u0995\u09CD\u09AF\u09BE\u09AE\u09CD\u09AA\u09BE\u09B8</h2>`);
            } else {
              return [
                createVNode("span", { class: "w-3 h-3 bg-[#3375af]" }),
                createVNode("h2", { class: "text-[#3375af] text-[18px] font-semibold" }, "\u0995\u09CD\u09AF\u09BE\u09AE\u09CD\u09AA\u09BE\u09B8")
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(`</div><div class="home-campus-c-content flex flex-col gap-3">`);
        _push(ssrRenderComponent(_component_NuxtLink, {
          to: `/category/${(_e = (_d = unref(campuses)[0]) == null ? void 0 : _d.category) == null ? void 0 : _e.cat_slug}/${(_f = unref(campuses)[0]) == null ? void 0 : _f.content_id}`,
          class: "flex flex-col gap-2 group"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            var _a2, _b2, _c2, _d2, _e2, _f2;
            if (_push2) {
              _push2(`<div class="overflow-hidden"${_scopeId}>`);
              _push2(ssrRenderComponent(_component_nuxt_img, {
                src: `${unref(siteurl).site_url}/media/content/images/${(_a2 = unref(campuses)[0]) == null ? void 0 : _a2.img_bg_path}`,
                class: "mx-auto w-full group-hover:scale-110 duration-300",
                placeholder: unref(img)(`${(_b2 = unref(siteurl)) == null ? void 0 : _b2.site_url}/logo/placeholder.jpg`)
              }, null, _parent2, _scopeId));
              _push2(`</div><h3 class="text-[19px] leading-tight group-hover:text-[#ff0000]"${_scopeId}>${ssrInterpolate((_c2 = unref(campuses)[0]) == null ? void 0 : _c2.content_heading)}</h3>`);
            } else {
              return [
                createVNode("div", { class: "overflow-hidden" }, [
                  createVNode(_component_nuxt_img, {
                    src: `${unref(siteurl).site_url}/media/content/images/${(_d2 = unref(campuses)[0]) == null ? void 0 : _d2.img_bg_path}`,
                    class: "mx-auto w-full group-hover:scale-110 duration-300",
                    placeholder: unref(img)(`${(_e2 = unref(siteurl)) == null ? void 0 : _e2.site_url}/logo/placeholder.jpg`)
                  }, null, 8, ["src", "placeholder"])
                ]),
                createVNode("h3", { class: "text-[19px] leading-tight group-hover:text-[#ff0000]" }, toDisplayString((_f2 = unref(campuses)[0]) == null ? void 0 : _f2.content_heading), 1)
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(`<div class="h-p-c-excpt flex flex-col"><!--[-->`);
        ssrRenderList(unref(campuses).slice(1, 8), (campus) => {
          var _a2;
          _push(ssrRenderComponent(_component_NuxtLink, {
            to: `/category/${(_a2 = campus == null ? void 0 : campus.category) == null ? void 0 : _a2.cat_slug}/${campus == null ? void 0 : campus.content_id}`,
            class: "border-b py-3",
            key: campus.content_id
          }, {
            default: withCtx((_, _push2, _parent2, _scopeId) => {
              if (_push2) {
                _push2(`<h4 class="text-[17px] hover:text-[#ff0000] leading-tight"${_scopeId}>${ssrInterpolate(campus == null ? void 0 : campus.content_heading)}</h4>`);
              } else {
                return [
                  createVNode("h4", { class: "text-[17px] hover:text-[#ff0000] leading-tight" }, toDisplayString(campus == null ? void 0 : campus.content_heading), 1)
                ];
              }
            }),
            _: 2
          }, _parent));
        });
        _push(`<!--]--></div></div></div>`);
      } else {
        _push(`<!---->`);
      }
    };
  }
};
const _sfc_setup$f = _sfc_main$f.setup;
_sfc_main$f.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Home/Category/Campus.vue");
  return _sfc_setup$f ? _sfc_setup$f(props, ctx) : void 0;
};
const __nuxt_component_31 = _sfc_main$f;
const _sfc_main$e = {
  __name: "MiddleEight",
  __ssrInlineRender: true,
  props: ["homeMiddleEightAds"],
  setup(__props) {
    const data = __props;
    const siteurl = siteUrlState();
    return (_ctx, _push, _parent, _attrs) => {
      var _a, _b, _c, _d, _e;
      if (((_a = data == null ? void 0 : data.homeMiddleEightAds) == null ? void 0 : _a.status) === 1) {
        _push(`<div${ssrRenderAttrs(mergeProps({ class: "ad-container" }, _attrs))}><div class="ad-section bg-[#f7f7f7]">`);
        if (((_b = data == null ? void 0 : data.homeMiddleEightAds) == null ? void 0 : _b.type) === 3) {
          _push(`<a${ssrRenderAttr("href", (_c = data == null ? void 0 : data.homeMiddleEightAds) == null ? void 0 : _c.external_link)} target="_blank" rel="nofollow"><img class="mx-auto"${ssrRenderAttr("src", `${unref(siteurl).site_url}/media/advertisement/${(_d = data == null ? void 0 : data.homeMiddleEightAds) == null ? void 0 : _d.desktop_image_path}`)} alt="Header Ad"></a>`);
        } else {
          _push(`<div>${(_e = data == null ? void 0 : data.homeMiddleEightAds) == null ? void 0 : _e.code}</div>`);
        }
        _push(`</div></div>`);
      } else {
        _push(`<!---->`);
      }
    };
  }
};
const _sfc_setup$e = _sfc_main$e.setup;
_sfc_main$e.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Ads/Desktop/Home/MiddleEight.vue");
  return _sfc_setup$e ? _sfc_setup$e(props, ctx) : void 0;
};
const __nuxt_component_32 = _sfc_main$e;
const _sfc_main$d = {
  __name: "ArtCulture",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    const img = useImage();
    const siteurl = siteUrlState();
    const artscontents = useState(() => [], "$f1fhpGLOme");
    const { data: harts } = ([__temp, __restore] = withAsyncContext(() => useFetch("/api/home/artscontent", {
      method: "GET"
    }, "$0XQcpxXN8Y")), __temp = await __temp, __restore(), __temp);
    artscontents.value = harts;
    return (_ctx, _push, _parent, _attrs) => {
      var _a, _b, _c, _d, _e, _f;
      const _component_NuxtLink = __nuxt_component_0$1;
      const _component_nuxt_img = __nuxt_component_1$1;
      if (((_a = unref(artscontents)) == null ? void 0 : _a.length) > 0) {
        _push(`<div${ssrRenderAttrs(mergeProps({ class: "home-art-culture-category" }, _attrs))}><div class="category-header border-b-4 border-b-[#3375af] my-3">`);
        _push(ssrRenderComponent(_component_NuxtLink, {
          to: `/${(_c = (_b = unref(artscontents)[0]) == null ? void 0 : _b.category) == null ? void 0 : _c.cat_slug}`,
          class: "flex gap-3 items-center"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<span class="w-3 h-3 bg-[#3375af]"${_scopeId}></span><h2 class="text-[#3375af] text-[18px] font-semibold"${_scopeId}>\u09B6\u09BF\u09B2\u09CD\u09AA-\u09B8\u0982\u09B8\u09CD\u0995\u09C3\u09A4\u09BF</h2>`);
            } else {
              return [
                createVNode("span", { class: "w-3 h-3 bg-[#3375af]" }),
                createVNode("h2", { class: "text-[#3375af] text-[18px] font-semibold" }, "\u09B6\u09BF\u09B2\u09CD\u09AA-\u09B8\u0982\u09B8\u09CD\u0995\u09C3\u09A4\u09BF")
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(`</div><div class="home-int-c-content flex flex-col gap-3">`);
        _push(ssrRenderComponent(_component_NuxtLink, {
          to: `/category/${(_e = (_d = unref(artscontents)[0]) == null ? void 0 : _d.category) == null ? void 0 : _e.cat_slug}/${(_f = unref(artscontents)[0]) == null ? void 0 : _f.content_id}`,
          class: "flex flex-col gap-2 group"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            var _a2, _b2, _c2, _d2, _e2, _f2;
            if (_push2) {
              _push2(`<div class="overflow-hidden"${_scopeId}>`);
              _push2(ssrRenderComponent(_component_nuxt_img, {
                src: `${unref(siteurl).site_url}/media/content/images/${(_a2 = unref(artscontents)[0]) == null ? void 0 : _a2.img_bg_path}`,
                class: "mx-auto w-full group-hover:scale-110 duration-300",
                placeholder: unref(img)(`${(_b2 = unref(siteurl)) == null ? void 0 : _b2.site_url}/logo/placeholder.jpg`)
              }, null, _parent2, _scopeId));
              _push2(`</div><h3 class="text-[19px] leading-tight group-hover:text-[#ff0000]"${_scopeId}>${ssrInterpolate((_c2 = unref(artscontents)[0]) == null ? void 0 : _c2.content_heading)}</h3>`);
            } else {
              return [
                createVNode("div", { class: "overflow-hidden" }, [
                  createVNode(_component_nuxt_img, {
                    src: `${unref(siteurl).site_url}/media/content/images/${(_d2 = unref(artscontents)[0]) == null ? void 0 : _d2.img_bg_path}`,
                    class: "mx-auto w-full group-hover:scale-110 duration-300",
                    placeholder: unref(img)(`${(_e2 = unref(siteurl)) == null ? void 0 : _e2.site_url}/logo/placeholder.jpg`)
                  }, null, 8, ["src", "placeholder"])
                ]),
                createVNode("h3", { class: "text-[19px] leading-tight group-hover:text-[#ff0000]" }, toDisplayString((_f2 = unref(artscontents)[0]) == null ? void 0 : _f2.content_heading), 1)
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(`<div class="h-p-c-excpt flex flex-col"><!--[-->`);
        ssrRenderList(unref(artscontents).slice(1, 5), (artscontent) => {
          var _a2;
          _push(ssrRenderComponent(_component_NuxtLink, {
            to: `/category/${(_a2 = artscontent == null ? void 0 : artscontent.category) == null ? void 0 : _a2.cat_slug}/${artscontent == null ? void 0 : artscontent.content_id}`,
            class: "border-b py-3",
            key: artscontent.content_id
          }, {
            default: withCtx((_, _push2, _parent2, _scopeId) => {
              if (_push2) {
                _push2(`<h4 class="text-[17px] hover:text-[#ff0000] leading-tight"${_scopeId}>${ssrInterpolate(artscontent == null ? void 0 : artscontent.content_heading)}</h4>`);
              } else {
                return [
                  createVNode("h4", { class: "text-[17px] hover:text-[#ff0000] leading-tight" }, toDisplayString(artscontent == null ? void 0 : artscontent.content_heading), 1)
                ];
              }
            }),
            _: 2
          }, _parent));
        });
        _push(`<!--]--></div></div></div>`);
      } else {
        _push(`<!---->`);
      }
    };
  }
};
const _sfc_setup$d = _sfc_main$d.setup;
_sfc_main$d.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Home/Category/ArtCulture.vue");
  return _sfc_setup$d ? _sfc_setup$d(props, ctx) : void 0;
};
const __nuxt_component_33 = _sfc_main$d;
const _sfc_main$c = {
  __name: "Health",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    const img = useImage();
    const siteurl = siteUrlState();
    const healthcontents = useState(() => [], "$UdN1sWUt4y");
    const { data: chealth } = ([__temp, __restore] = withAsyncContext(() => useFetch("/api/home/healthcontent", {
      method: "GET"
    }, "$9D7SaiPbCf")), __temp = await __temp, __restore(), __temp);
    healthcontents.value = chealth;
    return (_ctx, _push, _parent, _attrs) => {
      var _a, _b, _c, _d, _e, _f;
      const _component_NuxtLink = __nuxt_component_0$1;
      const _component_nuxt_img = __nuxt_component_1$1;
      if (((_a = unref(healthcontents)) == null ? void 0 : _a.length) > 0) {
        _push(`<div${ssrRenderAttrs(mergeProps({ class: "home-health-category" }, _attrs))}><div class="category-header border-b-4 border-b-[#3375af] my-3">`);
        _push(ssrRenderComponent(_component_NuxtLink, {
          to: `/${(_c = (_b = unref(healthcontents)[0]) == null ? void 0 : _b.category) == null ? void 0 : _c.cat_slug}`,
          class: "flex gap-3 items-center"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<span class="w-3 h-3 bg-[#3375af]"${_scopeId}></span><h2 class="text-[#3375af] text-[18px] font-semibold"${_scopeId}>\u09B8\u09CD\u09AC\u09BE\u09B8\u09CD\u09A5\u09CD\u09AF</h2>`);
            } else {
              return [
                createVNode("span", { class: "w-3 h-3 bg-[#3375af]" }),
                createVNode("h2", { class: "text-[#3375af] text-[18px] font-semibold" }, "\u09B8\u09CD\u09AC\u09BE\u09B8\u09CD\u09A5\u09CD\u09AF")
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(`</div><div class="home-int-c-content flex flex-col gap-3">`);
        _push(ssrRenderComponent(_component_NuxtLink, {
          to: `/category/${(_e = (_d = unref(healthcontents)[0]) == null ? void 0 : _d.category) == null ? void 0 : _e.cat_slug}/${(_f = unref(healthcontents)[0]) == null ? void 0 : _f.content_id}`,
          class: "flex flex-col gap-2 group"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            var _a2, _b2, _c2, _d2, _e2, _f2;
            if (_push2) {
              _push2(`<div class="overflow-hidden"${_scopeId}>`);
              _push2(ssrRenderComponent(_component_nuxt_img, {
                src: `${unref(siteurl).site_url}/media/content/images/${(_a2 = unref(healthcontents)[0]) == null ? void 0 : _a2.img_bg_path}`,
                class: "mx-auto w-full group-hover:scale-110 duration-300",
                placeholder: unref(img)(`${(_b2 = unref(siteurl)) == null ? void 0 : _b2.site_url}/logo/placeholder.jpg`)
              }, null, _parent2, _scopeId));
              _push2(`</div><h3 class="text-[19px] leading-tight group-hover:text-[#ff0000]"${_scopeId}>${ssrInterpolate((_c2 = unref(healthcontents)[0]) == null ? void 0 : _c2.content_heading)}</h3>`);
            } else {
              return [
                createVNode("div", { class: "overflow-hidden" }, [
                  createVNode(_component_nuxt_img, {
                    src: `${unref(siteurl).site_url}/media/content/images/${(_d2 = unref(healthcontents)[0]) == null ? void 0 : _d2.img_bg_path}`,
                    class: "mx-auto w-full group-hover:scale-110 duration-300",
                    placeholder: unref(img)(`${(_e2 = unref(siteurl)) == null ? void 0 : _e2.site_url}/logo/placeholder.jpg`)
                  }, null, 8, ["src", "placeholder"])
                ]),
                createVNode("h3", { class: "text-[19px] leading-tight group-hover:text-[#ff0000]" }, toDisplayString((_f2 = unref(healthcontents)[0]) == null ? void 0 : _f2.content_heading), 1)
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(`<div class="h-p-c-excpt flex flex-col"><!--[-->`);
        ssrRenderList(unref(healthcontents).slice(1, 5), (healthcontent) => {
          var _a2;
          _push(ssrRenderComponent(_component_NuxtLink, {
            to: `/category/${(_a2 = healthcontent == null ? void 0 : healthcontent.category) == null ? void 0 : _a2.cat_slug}/${healthcontent == null ? void 0 : healthcontent.content_id}`,
            class: "border-b py-3",
            key: healthcontent.content_id
          }, {
            default: withCtx((_, _push2, _parent2, _scopeId) => {
              if (_push2) {
                _push2(`<h4 class="text-[17px] hover:text-[#ff0000] leading-tight"${_scopeId}>${ssrInterpolate(healthcontent == null ? void 0 : healthcontent.content_heading)}</h4>`);
              } else {
                return [
                  createVNode("h4", { class: "text-[17px] hover:text-[#ff0000] leading-tight" }, toDisplayString(healthcontent == null ? void 0 : healthcontent.content_heading), 1)
                ];
              }
            }),
            _: 2
          }, _parent));
        });
        _push(`<!--]--></div></div></div>`);
      } else {
        _push(`<!---->`);
      }
    };
  }
};
const _sfc_setup$c = _sfc_main$c.setup;
_sfc_main$c.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Home/Category/Health.vue");
  return _sfc_setup$c ? _sfc_setup$c(props, ctx) : void 0;
};
const __nuxt_component_34 = _sfc_main$c;
const _sfc_main$b = {
  __name: "Education",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    const img = useImage();
    const siteurl = siteUrlState();
    const educationcontents = useState(() => [], "$upb1ldlQoj");
    const { data: heducation } = ([__temp, __restore] = withAsyncContext(() => useFetch("/api/home/educationcontent", {
      method: "GET"
    }, "$7HG88cVY85")), __temp = await __temp, __restore(), __temp);
    educationcontents.value = heducation;
    return (_ctx, _push, _parent, _attrs) => {
      var _a, _b, _c, _d, _e, _f;
      const _component_NuxtLink = __nuxt_component_0$1;
      const _component_nuxt_img = __nuxt_component_1$1;
      if (((_a = unref(educationcontents)) == null ? void 0 : _a.length) > 0) {
        _push(`<div${ssrRenderAttrs(mergeProps({ class: "home-education-category" }, _attrs))}><div class="category-header border-b-4 border-b-[#3375af] my-3">`);
        _push(ssrRenderComponent(_component_NuxtLink, {
          to: `/${(_c = (_b = unref(educationcontents)[0]) == null ? void 0 : _b.category) == null ? void 0 : _c.cat_slug}`,
          class: "flex gap-3 items-center"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<span class="w-3 h-3 bg-[#3375af]"${_scopeId}></span><h2 class="text-[#3375af] text-[18px] font-semibold"${_scopeId}>\u09B6\u09BF\u0995\u09CD\u09B7\u09BE</h2>`);
            } else {
              return [
                createVNode("span", { class: "w-3 h-3 bg-[#3375af]" }),
                createVNode("h2", { class: "text-[#3375af] text-[18px] font-semibold" }, "\u09B6\u09BF\u0995\u09CD\u09B7\u09BE")
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(`</div><div class="home-int-c-content flex flex-col gap-3">`);
        _push(ssrRenderComponent(_component_NuxtLink, {
          to: `/category/${(_e = (_d = unref(educationcontents)[0]) == null ? void 0 : _d.category) == null ? void 0 : _e.cat_slug}/${(_f = unref(educationcontents)[0]) == null ? void 0 : _f.content_id}`,
          class: "flex flex-col gap-2 group"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            var _a2, _b2, _c2, _d2, _e2, _f2;
            if (_push2) {
              _push2(`<div class="overflow-hidden"${_scopeId}>`);
              _push2(ssrRenderComponent(_component_nuxt_img, {
                src: `${unref(siteurl).site_url}/media/content/images/${(_a2 = unref(educationcontents)[0]) == null ? void 0 : _a2.img_bg_path}`,
                class: "mx-auto w-full group-hover:scale-110 duration-300",
                placeholder: unref(img)(`${(_b2 = unref(siteurl)) == null ? void 0 : _b2.site_url}/logo/placeholder.jpg`)
              }, null, _parent2, _scopeId));
              _push2(`</div><h3 class="text-[19px] leading-tight group-hover:text-[#ff0000]"${_scopeId}>${ssrInterpolate((_c2 = unref(educationcontents)[0]) == null ? void 0 : _c2.content_heading)}</h3>`);
            } else {
              return [
                createVNode("div", { class: "overflow-hidden" }, [
                  createVNode(_component_nuxt_img, {
                    src: `${unref(siteurl).site_url}/media/content/images/${(_d2 = unref(educationcontents)[0]) == null ? void 0 : _d2.img_bg_path}`,
                    class: "mx-auto w-full group-hover:scale-110 duration-300",
                    placeholder: unref(img)(`${(_e2 = unref(siteurl)) == null ? void 0 : _e2.site_url}/logo/placeholder.jpg`)
                  }, null, 8, ["src", "placeholder"])
                ]),
                createVNode("h3", { class: "text-[19px] leading-tight group-hover:text-[#ff0000]" }, toDisplayString((_f2 = unref(educationcontents)[0]) == null ? void 0 : _f2.content_heading), 1)
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(`<div class="h-p-c-excpt flex flex-col"><!--[-->`);
        ssrRenderList(unref(educationcontents).slice(1, 5), (educationcontent) => {
          var _a2;
          _push(ssrRenderComponent(_component_NuxtLink, {
            to: `/category/${(_a2 = educationcontent == null ? void 0 : educationcontent.category) == null ? void 0 : _a2.cat_slug}/${educationcontent == null ? void 0 : educationcontent.content_id}`,
            class: "border-b py-3",
            key: educationcontent.content_id
          }, {
            default: withCtx((_, _push2, _parent2, _scopeId) => {
              if (_push2) {
                _push2(`<h4 class="text-[17px] hover:text-[#ff0000] leading-tight"${_scopeId}>${ssrInterpolate(educationcontent == null ? void 0 : educationcontent.content_heading)}</h4>`);
              } else {
                return [
                  createVNode("h4", { class: "text-[17px] hover:text-[#ff0000] leading-tight" }, toDisplayString(educationcontent == null ? void 0 : educationcontent.content_heading), 1)
                ];
              }
            }),
            _: 2
          }, _parent));
        });
        _push(`<!--]--></div></div></div>`);
      } else {
        _push(`<!---->`);
      }
    };
  }
};
const _sfc_setup$b = _sfc_main$b.setup;
_sfc_main$b.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Home/Category/Education.vue");
  return _sfc_setup$b ? _sfc_setup$b(props, ctx) : void 0;
};
const __nuxt_component_35 = _sfc_main$b;
const _sfc_main$a = {
  __name: "Religion",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    const img = useImage();
    const siteurl = siteUrlState();
    const religioncontents = useState(() => [], "$0zcV0AzNxJ");
    const { data: hreligion } = ([__temp, __restore] = withAsyncContext(() => useFetch("/api/home/religion", {
      method: "GET"
    }, "$TawKCdS9sG")), __temp = await __temp, __restore(), __temp);
    religioncontents.value = hreligion;
    return (_ctx, _push, _parent, _attrs) => {
      var _a, _b, _c, _d, _e, _f;
      const _component_NuxtLink = __nuxt_component_0$1;
      const _component_nuxt_img = __nuxt_component_1$1;
      if (((_a = unref(religioncontents)) == null ? void 0 : _a.length) > 0) {
        _push(`<div${ssrRenderAttrs(mergeProps({ class: "home-religion-category" }, _attrs))}><div class="category-header border-b-4 border-b-[#3375af] my-3">`);
        _push(ssrRenderComponent(_component_NuxtLink, {
          to: `/${(_c = (_b = unref(religioncontents)[0]) == null ? void 0 : _b.category) == null ? void 0 : _c.cat_slug}`,
          class: "flex gap-3 items-center"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<span class="w-3 h-3 bg-[#3375af]"${_scopeId}></span><h2 class="text-[#3375af] text-[18px] font-semibold"${_scopeId}>\u09A7\u09B0\u09CD\u09AE</h2>`);
            } else {
              return [
                createVNode("span", { class: "w-3 h-3 bg-[#3375af]" }),
                createVNode("h2", { class: "text-[#3375af] text-[18px] font-semibold" }, "\u09A7\u09B0\u09CD\u09AE")
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(`</div><div class="home-int-c-content flex flex-col gap-3">`);
        _push(ssrRenderComponent(_component_NuxtLink, {
          to: `/category/${(_e = (_d = unref(religioncontents)[0]) == null ? void 0 : _d.category) == null ? void 0 : _e.cat_slug}/${(_f = unref(religioncontents)[0]) == null ? void 0 : _f.content_id}`,
          class: "flex flex-col gap-2 group"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            var _a2, _b2, _c2, _d2, _e2, _f2;
            if (_push2) {
              _push2(`<div class="overflow-hidden"${_scopeId}>`);
              _push2(ssrRenderComponent(_component_nuxt_img, {
                src: `${unref(siteurl).site_url}/media/content/images/${(_a2 = unref(religioncontents)[0]) == null ? void 0 : _a2.img_bg_path}`,
                class: "mx-auto w-full group-hover:scale-110 duration-300",
                placeholder: unref(img)(`${(_b2 = unref(siteurl)) == null ? void 0 : _b2.site_url}/logo/placeholder.jpg`)
              }, null, _parent2, _scopeId));
              _push2(`</div><h3 class="text-[19px] leading-tight group-hover:text-[#ff0000]"${_scopeId}>${ssrInterpolate((_c2 = unref(religioncontents)[0]) == null ? void 0 : _c2.content_heading)}</h3>`);
            } else {
              return [
                createVNode("div", { class: "overflow-hidden" }, [
                  createVNode(_component_nuxt_img, {
                    src: `${unref(siteurl).site_url}/media/content/images/${(_d2 = unref(religioncontents)[0]) == null ? void 0 : _d2.img_bg_path}`,
                    class: "mx-auto w-full group-hover:scale-110 duration-300",
                    placeholder: unref(img)(`${(_e2 = unref(siteurl)) == null ? void 0 : _e2.site_url}/logo/placeholder.jpg`)
                  }, null, 8, ["src", "placeholder"])
                ]),
                createVNode("h3", { class: "text-[19px] leading-tight group-hover:text-[#ff0000]" }, toDisplayString((_f2 = unref(religioncontents)[0]) == null ? void 0 : _f2.content_heading), 1)
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(`<div class="h-p-c-excpt flex flex-col"><!--[-->`);
        ssrRenderList(unref(religioncontents).slice(1, 5), (religioncontent) => {
          var _a2;
          _push(ssrRenderComponent(_component_NuxtLink, {
            to: `/category/${(_a2 = religioncontent == null ? void 0 : religioncontent.category) == null ? void 0 : _a2.cat_slug}/${religioncontent == null ? void 0 : religioncontent.content_id}`,
            class: "border-b py-3",
            key: religioncontent.content_id
          }, {
            default: withCtx((_, _push2, _parent2, _scopeId) => {
              if (_push2) {
                _push2(`<h4 class="text-[17px] hover:text-[#ff0000] leading-tight"${_scopeId}>${ssrInterpolate(religioncontent == null ? void 0 : religioncontent.content_heading)}</h4>`);
              } else {
                return [
                  createVNode("h4", { class: "text-[17px] hover:text-[#ff0000] leading-tight" }, toDisplayString(religioncontent == null ? void 0 : religioncontent.content_heading), 1)
                ];
              }
            }),
            _: 2
          }, _parent));
        });
        _push(`<!--]--></div></div></div>`);
      } else {
        _push(`<!---->`);
      }
    };
  }
};
const _sfc_setup$a = _sfc_main$a.setup;
_sfc_main$a.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Home/Category/Religion.vue");
  return _sfc_setup$a ? _sfc_setup$a(props, ctx) : void 0;
};
const __nuxt_component_36 = _sfc_main$a;
const _sfc_main$9 = {
  __name: "ChildAdolescent",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    const img = useImage();
    const siteurl = siteUrlState();
    const childrenContents = useState(() => [], "$R62wexN9lj");
    const { data: hchildren } = ([__temp, __restore] = withAsyncContext(() => useFetch("/api/home/childrencontent", {
      method: "GET"
    }, "$k88VVOH86h")), __temp = await __temp, __restore(), __temp);
    childrenContents.value = hchildren;
    return (_ctx, _push, _parent, _attrs) => {
      var _a, _b, _c, _d, _e, _f;
      const _component_NuxtLink = __nuxt_component_0$1;
      const _component_nuxt_img = __nuxt_component_1$1;
      if (((_a = unref(childrenContents)) == null ? void 0 : _a.length) > 0) {
        _push(`<div${ssrRenderAttrs(mergeProps({ class: "home-childadolescent-category" }, _attrs))}><div class="category-header border-b-4 border-b-[#3375af] my-3">`);
        _push(ssrRenderComponent(_component_NuxtLink, {
          to: `/${(_c = (_b = unref(childrenContents)[0]) == null ? void 0 : _b.category) == null ? void 0 : _c.cat_slug}`,
          class: "flex gap-3 items-center"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<span class="w-3 h-3 bg-[#3375af]"${_scopeId}></span><h2 class="text-[#3375af] text-[18px] font-semibold"${_scopeId}>\u09B6\u09BF\u09B6\u09C1-\u0995\u09BF\u09B6\u09CB\u09B0</h2>`);
            } else {
              return [
                createVNode("span", { class: "w-3 h-3 bg-[#3375af]" }),
                createVNode("h2", { class: "text-[#3375af] text-[18px] font-semibold" }, "\u09B6\u09BF\u09B6\u09C1-\u0995\u09BF\u09B6\u09CB\u09B0")
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(`</div><div class="home-int-c-content flex flex-col gap-3">`);
        _push(ssrRenderComponent(_component_NuxtLink, {
          to: `/category/${(_e = (_d = unref(childrenContents)[0]) == null ? void 0 : _d.category) == null ? void 0 : _e.cat_slug}/${(_f = unref(childrenContents)[0]) == null ? void 0 : _f.content_id}`,
          class: "flex flex-col gap-2 group"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            var _a2, _b2, _c2, _d2, _e2, _f2;
            if (_push2) {
              _push2(`<div class="overflow-hidden"${_scopeId}>`);
              _push2(ssrRenderComponent(_component_nuxt_img, {
                src: `${unref(siteurl).site_url}/media/content/images/${(_a2 = unref(childrenContents)[0]) == null ? void 0 : _a2.img_bg_path}`,
                class: "mx-auto w-full group-hover:scale-110 duration-300",
                placeholder: unref(img)(`${(_b2 = unref(siteurl)) == null ? void 0 : _b2.site_url}/logo/placeholder.jpg`)
              }, null, _parent2, _scopeId));
              _push2(`</div><h3 class="text-[19px] leading-tight group-hover:text-[#ff0000]"${_scopeId}>${ssrInterpolate((_c2 = unref(childrenContents)[0]) == null ? void 0 : _c2.content_heading)}</h3>`);
            } else {
              return [
                createVNode("div", { class: "overflow-hidden" }, [
                  createVNode(_component_nuxt_img, {
                    src: `${unref(siteurl).site_url}/media/content/images/${(_d2 = unref(childrenContents)[0]) == null ? void 0 : _d2.img_bg_path}`,
                    class: "mx-auto w-full group-hover:scale-110 duration-300",
                    placeholder: unref(img)(`${(_e2 = unref(siteurl)) == null ? void 0 : _e2.site_url}/logo/placeholder.jpg`)
                  }, null, 8, ["src", "placeholder"])
                ]),
                createVNode("h3", { class: "text-[19px] leading-tight group-hover:text-[#ff0000]" }, toDisplayString((_f2 = unref(childrenContents)[0]) == null ? void 0 : _f2.content_heading), 1)
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(`<div class="h-p-c-excpt flex flex-col"><!--[-->`);
        ssrRenderList(unref(childrenContents).slice(1, 5), (childrenContent) => {
          var _a2;
          _push(ssrRenderComponent(_component_NuxtLink, {
            to: `/category/${(_a2 = childrenContent == null ? void 0 : childrenContent.category) == null ? void 0 : _a2.cat_slug}/${childrenContent == null ? void 0 : childrenContent.content_id}`,
            class: "border-b py-3",
            key: childrenContent.content_id
          }, {
            default: withCtx((_, _push2, _parent2, _scopeId) => {
              if (_push2) {
                _push2(`<h4 class="text-[17px] hover:text-[#ff0000] leading-tight"${_scopeId}>${ssrInterpolate(childrenContent == null ? void 0 : childrenContent.content_heading)}</h4>`);
              } else {
                return [
                  createVNode("h4", { class: "text-[17px] hover:text-[#ff0000] leading-tight" }, toDisplayString(childrenContent == null ? void 0 : childrenContent.content_heading), 1)
                ];
              }
            }),
            _: 2
          }, _parent));
        });
        _push(`<!--]--></div></div></div>`);
      } else {
        _push(`<!---->`);
      }
    };
  }
};
const _sfc_setup$9 = _sfc_main$9.setup;
_sfc_main$9.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Home/Category/ChildAdolescent.vue");
  return _sfc_setup$9 ? _sfc_setup$9(props, ctx) : void 0;
};
const __nuxt_component_37 = _sfc_main$9;
const _sfc_main$8 = {
  __name: "Motivation",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    const img = useImage();
    const siteurl = siteUrlState();
    const motivationContents = useState(() => [], "$my7VVJckeb");
    const { data: hmotivation } = ([__temp, __restore] = withAsyncContext(() => useFetch("/api/home/motivationcontent", {
      method: "GET"
    }, "$gL8hv1U4T2")), __temp = await __temp, __restore(), __temp);
    motivationContents.value = hmotivation;
    return (_ctx, _push, _parent, _attrs) => {
      var _a, _b, _c, _d, _e, _f;
      const _component_NuxtLink = __nuxt_component_0$1;
      const _component_nuxt_img = __nuxt_component_1$1;
      if (((_a = unref(motivationContents)) == null ? void 0 : _a.length) > 0) {
        _push(`<div${ssrRenderAttrs(mergeProps({ class: "home-motivation-category" }, _attrs))}><div class="category-header border-b-4 border-b-[#3375af] my-3">`);
        _push(ssrRenderComponent(_component_NuxtLink, {
          to: `/${(_c = (_b = unref(motivationContents)[0]) == null ? void 0 : _b.category) == null ? void 0 : _c.cat_slug}`,
          class: "flex gap-3 items-center"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<span class="w-3 h-3 bg-[#3375af]"${_scopeId}></span><h2 class="text-[#3375af] text-[18px] font-semibold"${_scopeId}>\u09AE\u09CB\u099F\u09BF\u09AD\u09C7\u09B6\u09A8</h2>`);
            } else {
              return [
                createVNode("span", { class: "w-3 h-3 bg-[#3375af]" }),
                createVNode("h2", { class: "text-[#3375af] text-[18px] font-semibold" }, "\u09AE\u09CB\u099F\u09BF\u09AD\u09C7\u09B6\u09A8")
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(`</div><div class="home-int-c-content flex flex-col gap-3">`);
        _push(ssrRenderComponent(_component_NuxtLink, {
          to: `/category/${(_e = (_d = unref(motivationContents)[0]) == null ? void 0 : _d.category) == null ? void 0 : _e.cat_slug}/${(_f = unref(motivationContents)[0]) == null ? void 0 : _f.content_id}`,
          class: "flex flex-col gap-2 group"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            var _a2, _b2, _c2, _d2, _e2, _f2;
            if (_push2) {
              _push2(`<div class="overflow-hidden"${_scopeId}>`);
              _push2(ssrRenderComponent(_component_nuxt_img, {
                src: `${unref(siteurl).site_url}/media/content/images/${(_a2 = unref(motivationContents)[0]) == null ? void 0 : _a2.img_bg_path}`,
                class: "mx-auto w-full group-hover:scale-110 duration-300",
                placeholder: unref(img)(`${(_b2 = unref(siteurl)) == null ? void 0 : _b2.site_url}/logo/placeholder.jpg`)
              }, null, _parent2, _scopeId));
              _push2(`</div><h3 class="text-[19px] leading-tight group-hover:text-[#ff0000]"${_scopeId}>${ssrInterpolate((_c2 = unref(motivationContents)[0]) == null ? void 0 : _c2.content_heading)}</h3>`);
            } else {
              return [
                createVNode("div", { class: "overflow-hidden" }, [
                  createVNode(_component_nuxt_img, {
                    src: `${unref(siteurl).site_url}/media/content/images/${(_d2 = unref(motivationContents)[0]) == null ? void 0 : _d2.img_bg_path}`,
                    class: "mx-auto w-full group-hover:scale-110 duration-300",
                    placeholder: unref(img)(`${(_e2 = unref(siteurl)) == null ? void 0 : _e2.site_url}/logo/placeholder.jpg`)
                  }, null, 8, ["src", "placeholder"])
                ]),
                createVNode("h3", { class: "text-[19px] leading-tight group-hover:text-[#ff0000]" }, toDisplayString((_f2 = unref(motivationContents)[0]) == null ? void 0 : _f2.content_heading), 1)
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(`<div class="h-p-c-excpt flex flex-col"><!--[-->`);
        ssrRenderList(unref(motivationContents).slice(1, 5), (motivationContent) => {
          var _a2;
          _push(ssrRenderComponent(_component_NuxtLink, {
            to: `/category/${(_a2 = motivationContent == null ? void 0 : motivationContent.category) == null ? void 0 : _a2.cat_slug}/${motivationContent == null ? void 0 : motivationContent.content_id}`,
            class: "border-b py-3",
            key: motivationContent.content_id
          }, {
            default: withCtx((_, _push2, _parent2, _scopeId) => {
              if (_push2) {
                _push2(`<h4 class="text-[17px] hover:text-[#ff0000] leading-tight"${_scopeId}>${ssrInterpolate(motivationContent == null ? void 0 : motivationContent.content_heading)}</h4>`);
              } else {
                return [
                  createVNode("h4", { class: "text-[17px] hover:text-[#ff0000] leading-tight" }, toDisplayString(motivationContent == null ? void 0 : motivationContent.content_heading), 1)
                ];
              }
            }),
            _: 2
          }, _parent));
        });
        _push(`<!--]--></div></div></div>`);
      } else {
        _push(`<!---->`);
      }
    };
  }
};
const _sfc_setup$8 = _sfc_main$8.setup;
_sfc_main$8.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Home/Category/Motivation.vue");
  return _sfc_setup$8 ? _sfc_setup$8(props, ctx) : void 0;
};
const __nuxt_component_38 = _sfc_main$8;
const _sfc_main$7 = {
  __name: "Probash",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    const img = useImage();
    const siteurl = siteUrlState();
    const probashContents = useState(() => [], "$8AQi4LM0Wu");
    const { data: hprobash } = ([__temp, __restore] = withAsyncContext(() => useFetch("/api/home/probash", {
      method: "GET"
    }, "$GfFk83cUns")), __temp = await __temp, __restore(), __temp);
    probashContents.value = hprobash;
    return (_ctx, _push, _parent, _attrs) => {
      var _a, _b, _c, _d, _e;
      const _component_NuxtLink = __nuxt_component_0$1;
      const _component_nuxt_img = __nuxt_component_1$1;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "home-probash-category" }, _attrs))}><div class="category-header border-b-4 border-b-[#3375af] my-3">`);
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: `/${(_b = (_a = unref(probashContents)[0]) == null ? void 0 : _a.category) == null ? void 0 : _b.cat_slug}`,
        class: "flex gap-3 items-center"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<span class="w-3 h-3 bg-[#3375af]"${_scopeId}></span><h2 class="text-[#3375af] text-[18px] font-semibold"${_scopeId}>\u09AA\u09CD\u09B0\u09AC\u09BE\u09B8</h2>`);
          } else {
            return [
              createVNode("span", { class: "w-3 h-3 bg-[#3375af]" }),
              createVNode("h2", { class: "text-[#3375af] text-[18px] font-semibold" }, "\u09AA\u09CD\u09B0\u09AC\u09BE\u09B8")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div><div class="home-int-c-content flex flex-col gap-3">`);
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: `/category/${(_d = (_c = unref(probashContents)[0]) == null ? void 0 : _c.category) == null ? void 0 : _d.cat_slug}/${(_e = unref(probashContents)[0]) == null ? void 0 : _e.content_id}`,
        class: "flex flex-col gap-2 group"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          var _a2, _b2, _c2, _d2, _e2, _f;
          if (_push2) {
            _push2(`<div class="overflow-hidden"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_nuxt_img, {
              src: `${unref(siteurl).site_url}/media/content/images/${(_a2 = unref(probashContents)[0]) == null ? void 0 : _a2.img_bg_path}`,
              class: "mx-auto w-full group-hover:scale-110 duration-300",
              placeholder: unref(img)(`${(_b2 = unref(siteurl)) == null ? void 0 : _b2.site_url}/logo/placeholder.jpg`)
            }, null, _parent2, _scopeId));
            _push2(`</div><h3 class="text-[19px] leading-tight group-hover:text-[#ff0000]"${_scopeId}>${ssrInterpolate((_c2 = unref(probashContents)[0]) == null ? void 0 : _c2.content_heading)}</h3>`);
          } else {
            return [
              createVNode("div", { class: "overflow-hidden" }, [
                createVNode(_component_nuxt_img, {
                  src: `${unref(siteurl).site_url}/media/content/images/${(_d2 = unref(probashContents)[0]) == null ? void 0 : _d2.img_bg_path}`,
                  class: "mx-auto w-full group-hover:scale-110 duration-300",
                  placeholder: unref(img)(`${(_e2 = unref(siteurl)) == null ? void 0 : _e2.site_url}/logo/placeholder.jpg`)
                }, null, 8, ["src", "placeholder"])
              ]),
              createVNode("h3", { class: "text-[19px] leading-tight group-hover:text-[#ff0000]" }, toDisplayString((_f = unref(probashContents)[0]) == null ? void 0 : _f.content_heading), 1)
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<div class="h-p-c-excpt flex flex-col"><!--[-->`);
      ssrRenderList(unref(probashContents).slice(1, 5), (probashContent) => {
        var _a2;
        _push(ssrRenderComponent(_component_NuxtLink, {
          to: `/category/${(_a2 = probashContent == null ? void 0 : probashContent.category) == null ? void 0 : _a2.cat_slug}/${probashContent == null ? void 0 : probashContent.content_id}`,
          class: "border-b py-3",
          key: probashContent.content_id
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<h4 class="text-[17px] hover:text-[#ff0000] leading-tight"${_scopeId}>${ssrInterpolate(probashContent == null ? void 0 : probashContent.content_heading)}</h4>`);
            } else {
              return [
                createVNode("h4", { class: "text-[17px] hover:text-[#ff0000] leading-tight" }, toDisplayString(probashContent == null ? void 0 : probashContent.content_heading), 1)
              ];
            }
          }),
          _: 2
        }, _parent));
      });
      _push(`<!--]--></div></div></div>`);
    };
  }
};
const _sfc_setup$7 = _sfc_main$7.setup;
_sfc_main$7.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Home/Category/Probash.vue");
  return _sfc_setup$7 ? _sfc_setup$7(props, ctx) : void 0;
};
const __nuxt_component_39 = _sfc_main$7;
const _sfc_main$6 = {
  __name: "Corporate",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    const img = useImage();
    const siteurl = siteUrlState();
    const corporateContents = useState(() => [], "$Y6g1YQZafl");
    const { data: hcorporate } = ([__temp, __restore] = withAsyncContext(() => useFetch("/api/home/corporatecontent", {
      method: "GET"
    }, "$kNtfgaBywp")), __temp = await __temp, __restore(), __temp);
    corporateContents.value = hcorporate;
    return (_ctx, _push, _parent, _attrs) => {
      var _a, _b, _c, _d, _e;
      const _component_NuxtLink = __nuxt_component_0$1;
      const _component_nuxt_img = __nuxt_component_1$1;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "home-corporate-category" }, _attrs))}><div class="category-header border-b-4 border-b-[#3375af] my-3">`);
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: `/${(_b = (_a = unref(corporateContents)[0]) == null ? void 0 : _a.category) == null ? void 0 : _b.cat_slug}`,
        class: "flex gap-3 items-center"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<span class="w-3 h-3 bg-[#3375af]"${_scopeId}></span><h2 class="text-[#3375af] text-[18px] font-semibold"${_scopeId}>\u0995\u09B0\u09AA\u09CB\u09B0\u09C7\u099F \u0995\u09B0\u09CD\u09A8\u09BE\u09B0</h2>`);
          } else {
            return [
              createVNode("span", { class: "w-3 h-3 bg-[#3375af]" }),
              createVNode("h2", { class: "text-[#3375af] text-[18px] font-semibold" }, "\u0995\u09B0\u09AA\u09CB\u09B0\u09C7\u099F \u0995\u09B0\u09CD\u09A8\u09BE\u09B0")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div><div class="home-int-c-content flex flex-col gap-3">`);
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: `/category/${(_d = (_c = unref(corporateContents)[0]) == null ? void 0 : _c.category) == null ? void 0 : _d.cat_slug}/${(_e = unref(corporateContents)[0]) == null ? void 0 : _e.content_id}`,
        class: "flex flex-col gap-2 group"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          var _a2, _b2, _c2, _d2, _e2, _f;
          if (_push2) {
            _push2(`<div class="overflow-hidden"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_nuxt_img, {
              src: `${unref(siteurl).site_url}/media/content/images/${(_a2 = unref(corporateContents)[0]) == null ? void 0 : _a2.img_bg_path}`,
              class: "mx-auto w-full group-hover:scale-110 duration-300",
              placeholder: unref(img)(`${(_b2 = unref(siteurl)) == null ? void 0 : _b2.site_url}/logo/placeholder.jpg`)
            }, null, _parent2, _scopeId));
            _push2(`</div><h3 class="text-[19px] leading-tight group-hover:text-[#ff0000]"${_scopeId}>${ssrInterpolate((_c2 = unref(corporateContents)[0]) == null ? void 0 : _c2.content_heading)}</h3>`);
          } else {
            return [
              createVNode("div", { class: "overflow-hidden" }, [
                createVNode(_component_nuxt_img, {
                  src: `${unref(siteurl).site_url}/media/content/images/${(_d2 = unref(corporateContents)[0]) == null ? void 0 : _d2.img_bg_path}`,
                  class: "mx-auto w-full group-hover:scale-110 duration-300",
                  placeholder: unref(img)(`${(_e2 = unref(siteurl)) == null ? void 0 : _e2.site_url}/logo/placeholder.jpg`)
                }, null, 8, ["src", "placeholder"])
              ]),
              createVNode("h3", { class: "text-[19px] leading-tight group-hover:text-[#ff0000]" }, toDisplayString((_f = unref(corporateContents)[0]) == null ? void 0 : _f.content_heading), 1)
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<div class="h-p-c-excpt flex flex-col"><!--[-->`);
      ssrRenderList(unref(corporateContents).slice(1, 5), (corporateContent) => {
        var _a2;
        _push(ssrRenderComponent(_component_NuxtLink, {
          to: `/category/${(_a2 = corporateContent == null ? void 0 : corporateContent.category) == null ? void 0 : _a2.cat_slug}/${corporateContent == null ? void 0 : corporateContent.content_id}`,
          class: "border-b py-3",
          key: corporateContent.content_id
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<h4 class="text-[17px] hover:text-[#ff0000] leading-tight"${_scopeId}>${ssrInterpolate(corporateContent == null ? void 0 : corporateContent.content_heading)}</h4>`);
            } else {
              return [
                createVNode("h4", { class: "text-[17px] hover:text-[#ff0000] leading-tight" }, toDisplayString(corporateContent == null ? void 0 : corporateContent.content_heading), 1)
              ];
            }
          }),
          _: 2
        }, _parent));
      });
      _push(`<!--]--></div></div></div>`);
    };
  }
};
const _sfc_setup$6 = _sfc_main$6.setup;
_sfc_main$6.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Home/Category/Corporate.vue");
  return _sfc_setup$6 ? _sfc_setup$6(props, ctx) : void 0;
};
const __nuxt_component_40 = _sfc_main$6;
const _sfc_main$5 = {
  __name: "Literature",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    const img = useImage();
    const siteurl = siteUrlState();
    const literatureContents = useState(() => [], "$9SpNuP59ZQ");
    const { data: hmliterature } = ([__temp, __restore] = withAsyncContext(() => useFetch("/api/home/literaturecontent", {
      method: "GET"
    }, "$KloTJthI8P")), __temp = await __temp, __restore(), __temp);
    literatureContents.value = hmliterature;
    return (_ctx, _push, _parent, _attrs) => {
      var _a, _b, _c, _d, _e;
      const _component_NuxtLink = __nuxt_component_0$1;
      const _component_nuxt_img = __nuxt_component_1$1;
      const _component_ClientOnly = __nuxt_component_4$1;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "home-literature-category" }, _attrs))}><div class="category-header border-b-4 border-b-[#3375af] my-3">`);
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: `/${(_b = (_a = unref(literatureContents)[0]) == null ? void 0 : _a.category) == null ? void 0 : _b.cat_slug}`,
        class: "flex gap-3 items-center"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<span class="w-3 h-3 bg-[#3375af]"${_scopeId}></span><h2 class="text-[#3375af] text-[18px] font-semibold"${_scopeId}>\u09B8\u09BE\u09B9\u09BF\u09A4\u09CD\u09AF</h2>`);
          } else {
            return [
              createVNode("span", { class: "w-3 h-3 bg-[#3375af]" }),
              createVNode("h2", { class: "text-[#3375af] text-[18px] font-semibold" }, "\u09B8\u09BE\u09B9\u09BF\u09A4\u09CD\u09AF")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div><div class="flex flex-col gap-4"><div class="">`);
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: `/category/${(_d = (_c = unref(literatureContents)[0]) == null ? void 0 : _c.category) == null ? void 0 : _d.cat_slug}/${(_e = unref(literatureContents)[0]) == null ? void 0 : _e.content_id}`,
        class: "grid grid-cols-1 md:grid-cols-2 group gap-2"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          var _a2, _b2, _c2, _d2, _e2, _f;
          if (_push2) {
            _push2(`<div class="intertainment-feature-image overflow-hidden"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_nuxt_img, {
              src: `${unref(siteurl).site_url}/media/content/images/${(_a2 = unref(literatureContents)[0]) == null ? void 0 : _a2.img_bg_path}`,
              class: "mx-auto w-full group-hover:scale-110 duration-300",
              placeholder: unref(img)(`${(_b2 = unref(siteurl)) == null ? void 0 : _b2.site_url}/logo/placeholder.jpg`)
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="intertainment-feature-description flex flex-col gap-1"${_scopeId}><h3 class="text-[25px] leading-tight group-hover:text-[#ff0000]"${_scopeId}>${ssrInterpolate((_c2 = unref(literatureContents)[0]) == null ? void 0 : _c2.content_heading)}</h3>`);
            _push2(ssrRenderComponent(_component_ClientOnly, null, {}, _parent2, _scopeId));
            _push2(`</div>`);
          } else {
            return [
              createVNode("div", { class: "intertainment-feature-image overflow-hidden" }, [
                createVNode(_component_nuxt_img, {
                  src: `${unref(siteurl).site_url}/media/content/images/${(_d2 = unref(literatureContents)[0]) == null ? void 0 : _d2.img_bg_path}`,
                  class: "mx-auto w-full group-hover:scale-110 duration-300",
                  placeholder: unref(img)(`${(_e2 = unref(siteurl)) == null ? void 0 : _e2.site_url}/logo/placeholder.jpg`)
                }, null, 8, ["src", "placeholder"])
              ]),
              createVNode("div", { class: "intertainment-feature-description flex flex-col gap-1" }, [
                createVNode("h3", { class: "text-[25px] leading-tight group-hover:text-[#ff0000]" }, toDisplayString((_f = unref(literatureContents)[0]) == null ? void 0 : _f.content_heading), 1),
                createVNode(_component_ClientOnly, null, {
                  default: withCtx(() => {
                    var _a3, _b3;
                    return [
                      createVNode("div", {
                        class: "text-md",
                        innerHTML: `${(_b3 = (_a3 = unref(literatureContents)[0]) == null ? void 0 : _a3.content_details) == null ? void 0 : _b3.substring(
                          0,
                          240
                        )} ...`
                      }, null, 8, ["innerHTML"])
                    ];
                  }),
                  _: 1
                })
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div><div class="col-span-12 md:col-span-6"><div class="home-intertainment-category-except-post grid grid-cols-2 gap-4"><!--[-->`);
      ssrRenderList(unref(literatureContents).slice(1, 5), (literatureContent) => {
        var _a2, _b2;
        _push(`<div class="flex flex-col gap-4 group h-sports-excpt"><div class="col-span-5 overflow-hidden">`);
        _push(ssrRenderComponent(_component_NuxtLink, {
          to: `/category/${(_a2 = literatureContent == null ? void 0 : literatureContent.category) == null ? void 0 : _a2.cat_slug}/${literatureContent == null ? void 0 : literatureContent.content_id}`
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            var _a3, _b3;
            if (_push2) {
              _push2(ssrRenderComponent(_component_nuxt_img, {
                src: `${unref(siteurl).site_url}/media/content/images/${literatureContent == null ? void 0 : literatureContent.img_bg_path}`,
                class: "mx-auto w-full group-hover:scale-110 duration-300",
                placeholder: unref(img)(`${(_a3 = unref(siteurl)) == null ? void 0 : _a3.site_url}/logo/placeholder.jpg`)
              }, null, _parent2, _scopeId));
            } else {
              return [
                createVNode(_component_nuxt_img, {
                  src: `${unref(siteurl).site_url}/media/content/images/${literatureContent == null ? void 0 : literatureContent.img_bg_path}`,
                  class: "mx-auto w-full group-hover:scale-110 duration-300",
                  placeholder: unref(img)(`${(_b3 = unref(siteurl)) == null ? void 0 : _b3.site_url}/logo/placeholder.jpg`)
                }, null, 8, ["src", "placeholder"])
              ];
            }
          }),
          _: 2
        }, _parent));
        _push(`</div><div class="col-span-7">`);
        _push(ssrRenderComponent(_component_NuxtLink, {
          to: `/category/${(_b2 = literatureContent == null ? void 0 : literatureContent.category) == null ? void 0 : _b2.cat_slug}/${literatureContent == null ? void 0 : literatureContent.content_id}`
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<h4 class="text-[18px] leading-tight group-hover:text-[#ff0000]"${_scopeId}>${ssrInterpolate(literatureContent == null ? void 0 : literatureContent.content_heading)}</h4>`);
            } else {
              return [
                createVNode("h4", { class: "text-[18px] leading-tight group-hover:text-[#ff0000]" }, toDisplayString(literatureContent == null ? void 0 : literatureContent.content_heading), 1)
              ];
            }
          }),
          _: 2
        }, _parent));
        _push(`</div></div>`);
      });
      _push(`<!--]--></div></div></div></div>`);
    };
  }
};
const _sfc_setup$5 = _sfc_main$5.setup;
_sfc_main$5.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Home/Category/Literature.vue");
  return _sfc_setup$5 ? _sfc_setup$5(props, ctx) : void 0;
};
const __nuxt_component_41 = _sfc_main$5;
const _sfc_main$4 = {
  __name: "Opinion",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    const img = useImage();
    const siteurl = siteUrlState();
    const opinionContents = useState(() => [], "$PnT0hSWz2y");
    const { data: hmOpinion } = ([__temp, __restore] = withAsyncContext(() => useFetch("/api/home/opinioncontent", {
      method: "GET"
    }, "$g0Ny8tzbQx")), __temp = await __temp, __restore(), __temp);
    opinionContents.value = hmOpinion;
    return (_ctx, _push, _parent, _attrs) => {
      var _a, _b, _c, _d, _e;
      const _component_NuxtLink = __nuxt_component_0$1;
      const _component_nuxt_img = __nuxt_component_1$1;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "home-opinion-category" }, _attrs))}><div class="category-header border-b-4 border-b-[#3375af] my-3">`);
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: `/${(_b = (_a = unref(opinionContents)[0]) == null ? void 0 : _a.category) == null ? void 0 : _b.cat_slug}`,
        class: "flex gap-3 items-center"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<span class="w-3 h-3 bg-[#3375af]"${_scopeId}></span><h2 class="text-[#3375af] text-[18px] font-semibold"${_scopeId}>\u09AE\u09A4\u09BE\u09AE\u09A4</h2>`);
          } else {
            return [
              createVNode("span", { class: "w-3 h-3 bg-[#3375af]" }),
              createVNode("h2", { class: "text-[#3375af] text-[18px] font-semibold" }, "\u09AE\u09A4\u09BE\u09AE\u09A4")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div><div class="home-int-c-content flex flex-col gap-3">`);
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: `/category/${(_d = (_c = unref(opinionContents)[0]) == null ? void 0 : _c.category) == null ? void 0 : _d.cat_slug}/${(_e = unref(opinionContents)[0]) == null ? void 0 : _e.content_id}`,
        class: "flex flex-col gap-2 group"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          var _a2, _b2, _c2, _d2, _e2, _f;
          if (_push2) {
            _push2(`<div class="overflow-hidden"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_nuxt_img, {
              src: `${unref(siteurl).site_url}/media/content/images/${(_a2 = unref(opinionContents)[0]) == null ? void 0 : _a2.img_bg_path}`,
              class: "mx-auto w-full group-hover:scale-110 duration-300",
              placeholder: unref(img)(`${(_b2 = unref(siteurl)) == null ? void 0 : _b2.site_url}/logo/placeholder.jpg`)
            }, null, _parent2, _scopeId));
            _push2(`</div><h3 class="text-[19px] leading-tight group-hover:text-[#ff0000]"${_scopeId}>${ssrInterpolate((_c2 = unref(opinionContents)[0]) == null ? void 0 : _c2.content_heading)}</h3>`);
          } else {
            return [
              createVNode("div", { class: "overflow-hidden" }, [
                createVNode(_component_nuxt_img, {
                  src: `${unref(siteurl).site_url}/media/content/images/${(_d2 = unref(opinionContents)[0]) == null ? void 0 : _d2.img_bg_path}`,
                  class: "mx-auto w-full group-hover:scale-110 duration-300",
                  placeholder: unref(img)(`${(_e2 = unref(siteurl)) == null ? void 0 : _e2.site_url}/logo/placeholder.jpg`)
                }, null, 8, ["src", "placeholder"])
              ]),
              createVNode("h3", { class: "text-[19px] leading-tight group-hover:text-[#ff0000]" }, toDisplayString((_f = unref(opinionContents)[0]) == null ? void 0 : _f.content_heading), 1)
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<div class="h-p-c-excpt flex flex-col"><!--[-->`);
      ssrRenderList(unref(opinionContents).slice(1, 7), (opinionContent) => {
        var _a2;
        _push(ssrRenderComponent(_component_NuxtLink, {
          to: `/category/${(_a2 = opinionContent == null ? void 0 : opinionContent.category) == null ? void 0 : _a2.cat_slug}/${opinionContent == null ? void 0 : opinionContent.content_id}`,
          class: "border-b py-3",
          key: opinionContent.content_id
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<h4 class="text-[17px] hover:text-[#ff0000] leading-tight"${_scopeId}>${ssrInterpolate(opinionContent == null ? void 0 : opinionContent.content_heading)}</h4>`);
            } else {
              return [
                createVNode("h4", { class: "text-[17px] hover:text-[#ff0000] leading-tight" }, toDisplayString(opinionContent == null ? void 0 : opinionContent.content_heading), 1)
              ];
            }
          }),
          _: 2
        }, _parent));
      });
      _push(`<!--]--></div></div></div>`);
    };
  }
};
const _sfc_setup$4 = _sfc_main$4.setup;
_sfc_main$4.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Home/Category/Opinion.vue");
  return _sfc_setup$4 ? _sfc_setup$4(props, ctx) : void 0;
};
const __nuxt_component_42 = _sfc_main$4;
const _sfc_main$3 = {
  __name: "SpecialArticle",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    const img = useImage();
    const siteurl = siteUrlState();
    const specialArticleContents = useState(() => [], "$TbYNChFT2b");
    const { data: hmspecialrticle } = ([__temp, __restore] = withAsyncContext(() => useFetch("/api/home/specialarticle", {
      method: "GET"
    }, "$I5d6CNC20U")), __temp = await __temp, __restore(), __temp);
    specialArticleContents.value = hmspecialrticle;
    return (_ctx, _push, _parent, _attrs) => {
      var _a, _b, _c, _d, _e;
      const _component_NuxtLink = __nuxt_component_0$1;
      const _component_nuxt_img = __nuxt_component_1$1;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "home-special-article-category" }, _attrs))}><div class="category-header border-b-4 border-b-[#3375af] my-3">`);
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: `/${(_b = (_a = unref(specialArticleContents)[0]) == null ? void 0 : _a.category) == null ? void 0 : _b.cat_slug}`,
        class: "flex gap-3 items-center"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<span class="w-3 h-3 bg-[#3375af]"${_scopeId}></span><h2 class="text-[#3375af] text-[18px] font-semibold"${_scopeId}>\u09AC\u09BF\u09B6\u09C7\u09B7 \u09A8\u09BF\u09AC\u09A8\u09CD\u09A7</h2>`);
          } else {
            return [
              createVNode("span", { class: "w-3 h-3 bg-[#3375af]" }),
              createVNode("h2", { class: "text-[#3375af] text-[18px] font-semibold" }, "\u09AC\u09BF\u09B6\u09C7\u09B7 \u09A8\u09BF\u09AC\u09A8\u09CD\u09A7")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div><div class="home-int-c-content flex flex-col gap-3">`);
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: `/category/${(_d = (_c = unref(specialArticleContents)[0]) == null ? void 0 : _c.category) == null ? void 0 : _d.cat_slug}/${(_e = unref(specialArticleContents)[0]) == null ? void 0 : _e.content_id}`,
        class: "flex flex-col gap-2 group"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          var _a2, _b2, _c2, _d2, _e2, _f;
          if (_push2) {
            _push2(`<div class="overflow-hidden"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_nuxt_img, {
              src: `${unref(siteurl).site_url}/media/content/images/${(_a2 = unref(specialArticleContents)[0]) == null ? void 0 : _a2.img_bg_path}`,
              class: "mx-auto w-full group-hover:scale-110 duration-300",
              placeholder: unref(img)(`${(_b2 = unref(siteurl)) == null ? void 0 : _b2.site_url}/logo/placeholder.jpg`)
            }, null, _parent2, _scopeId));
            _push2(`</div><h3 class="text-[19px] leading-tight group-hover:text-[#ff0000]"${_scopeId}>${ssrInterpolate((_c2 = unref(specialArticleContents)[0]) == null ? void 0 : _c2.content_heading)}</h3>`);
          } else {
            return [
              createVNode("div", { class: "overflow-hidden" }, [
                createVNode(_component_nuxt_img, {
                  src: `${unref(siteurl).site_url}/media/content/images/${(_d2 = unref(specialArticleContents)[0]) == null ? void 0 : _d2.img_bg_path}`,
                  class: "mx-auto w-full group-hover:scale-110 duration-300",
                  placeholder: unref(img)(`${(_e2 = unref(siteurl)) == null ? void 0 : _e2.site_url}/logo/placeholder.jpg`)
                }, null, 8, ["src", "placeholder"])
              ]),
              createVNode("h3", { class: "text-[19px] leading-tight group-hover:text-[#ff0000]" }, toDisplayString((_f = unref(specialArticleContents)[0]) == null ? void 0 : _f.content_heading), 1)
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<div class="h-p-c-excpt flex flex-col"><!--[-->`);
      ssrRenderList(unref(specialArticleContents).slice(1, 7), (specialArticleContent) => {
        var _a2;
        _push(ssrRenderComponent(_component_NuxtLink, {
          to: `/category/${(_a2 = specialArticleContent == null ? void 0 : specialArticleContent.category) == null ? void 0 : _a2.cat_slug}/${specialArticleContent == null ? void 0 : specialArticleContent.content_id}`,
          class: "border-b py-3",
          key: specialArticleContent.content_id
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<h4 class="text-[17px] hover:text-[#ff0000] leading-tight"${_scopeId}>${ssrInterpolate(specialArticleContent == null ? void 0 : specialArticleContent.content_heading)}</h4>`);
            } else {
              return [
                createVNode("h4", { class: "text-[17px] hover:text-[#ff0000] leading-tight" }, toDisplayString(specialArticleContent == null ? void 0 : specialArticleContent.content_heading), 1)
              ];
            }
          }),
          _: 2
        }, _parent));
      });
      _push(`<!--]--></div></div></div>`);
    };
  }
};
const _sfc_setup$3 = _sfc_main$3.setup;
_sfc_main$3.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Home/Category/SpecialArticle.vue");
  return _sfc_setup$3 ? _sfc_setup$3(props, ctx) : void 0;
};
const __nuxt_component_43 = _sfc_main$3;
const _sfc_main$2 = {
  __name: "MiddleNine",
  __ssrInlineRender: true,
  props: ["homeMiddleNineAds"],
  setup(__props) {
    const data = __props;
    const siteurl = siteUrlState();
    return (_ctx, _push, _parent, _attrs) => {
      var _a, _b, _c, _d, _e;
      if (((_a = data == null ? void 0 : data.homeMiddleNineAds) == null ? void 0 : _a.status) === 1) {
        _push(`<div${ssrRenderAttrs(mergeProps({ class: "ad-container" }, _attrs))}><div class="ad-section bg-[#f7f7f7]">`);
        if (((_b = data == null ? void 0 : data.homeMiddleNineAds) == null ? void 0 : _b.type) === 3) {
          _push(`<a${ssrRenderAttr("href", (_c = data == null ? void 0 : data.homeMiddleNineAds) == null ? void 0 : _c.external_link)} target="_blank" rel="nofollow"><img class="mx-auto"${ssrRenderAttr("src", `${unref(siteurl).site_url}/media/advertisement/${(_d = data == null ? void 0 : data.homeMiddleNineAds) == null ? void 0 : _d.desktop_image_path}`)} alt="Header Ad"></a>`);
        } else {
          _push(`<div>${(_e = data == null ? void 0 : data.homeMiddleNineAds) == null ? void 0 : _e.code}</div>`);
        }
        _push(`</div></div>`);
      } else {
        _push(`<!---->`);
      }
    };
  }
};
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Ads/Desktop/Home/MiddleNine.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const __nuxt_component_44 = _sfc_main$2;
const _sfc_main$1 = {
  __name: "Gallery",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    const img = useImage();
    const siteurl = siteUrlState();
    const gallerContents = useState(() => [], "$v89lWC5yTo");
    const { data: hmgallery } = ([__temp, __restore] = withAsyncContext(() => useFetch("/api/home/homegallery", {
      method: "GET"
    }, "$u7Vdaq2FLa")), __temp = await __temp, __restore(), __temp);
    gallerContents.value = hmgallery;
    return (_ctx, _push, _parent, _attrs) => {
      const _component_NuxtLink = __nuxt_component_0$1;
      const _component_nuxt_img = __nuxt_component_1$1;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "max-w-[1280px] mx-auto py-4 px-4 md:px-2" }, _attrs))} data-v-0c12ec66><div class="home-photo-gallery mb-4" data-v-0c12ec66><div class="category-header border-b-4 border-b-white" data-v-0c12ec66>`);
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: "/photo",
        class: "flex gap-3 items-center"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<span class="w-4 h-4 bg-white" data-v-0c12ec66${_scopeId}></span><h2 class="text-white text-[26px] font-semibold" data-v-0c12ec66${_scopeId}>\u09AB\u099F\u09CB \u0997\u09CD\u09AF\u09BE\u09B2\u09BE\u09B0\u09BF</h2>`);
          } else {
            return [
              createVNode("span", { class: "w-4 h-4 bg-white" }),
              createVNode("h2", { class: "text-white text-[26px] font-semibold" }, "\u09AB\u099F\u09CB \u0997\u09CD\u09AF\u09BE\u09B2\u09BE\u09B0\u09BF")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div><div class="grid grid-cols-12 md:grid-rows-2 gap-4 md:gap-2 mb-6" data-v-0c12ec66><div class="col-span-12 md:row-span-2 md:col-span-6 group image-box" data-v-0c12ec66><div class="overflow-hidden" data-v-0c12ec66>`);
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: `/photo/${unref(gallerContents)[0].category.cat_slug}/${unref(gallerContents)[0].album_id}`,
        class: "relative"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          var _a, _b;
          if (_push2) {
            _push2(ssrRenderComponent(_component_nuxt_img, {
              src: `${unref(siteurl).site_url}/media/photoAlbum/${unref(gallerContents)[0].album_details[0].img}`,
              class: "mx-auto w-full group-hover:scale-110 duration-300",
              placeholder: unref(img)(`${(_a = unref(siteurl)) == null ? void 0 : _a.site_url}/logo/placeholder.jpg`)
            }, null, _parent2, _scopeId));
            _push2(`<div class="overlay" data-v-0c12ec66${_scopeId}><b data-v-0c12ec66${_scopeId}><p class="img-title text-white group-hover:text-[#ff0000] text-[30px]" data-v-0c12ec66${_scopeId}>${ssrInterpolate(unref(gallerContents)[0].album_name)}</p></b></div>`);
          } else {
            return [
              createVNode(_component_nuxt_img, {
                src: `${unref(siteurl).site_url}/media/photoAlbum/${unref(gallerContents)[0].album_details[0].img}`,
                class: "mx-auto w-full group-hover:scale-110 duration-300",
                placeholder: unref(img)(`${(_b = unref(siteurl)) == null ? void 0 : _b.site_url}/logo/placeholder.jpg`)
              }, null, 8, ["src", "placeholder"]),
              createVNode("div", { class: "overlay" }, [
                createVNode("b", null, [
                  createVNode("p", { class: "img-title text-white group-hover:text-[#ff0000] text-[30px]" }, toDisplayString(unref(gallerContents)[0].album_name), 1)
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div><!--[-->`);
      ssrRenderList(unref(gallerContents).slice(1, 9), (gallerContent, aidx) => {
        _push(`<div class="col-span-12 md:col-span-3 group image-box" data-v-0c12ec66><div class="overflow-hidden" data-v-0c12ec66>`);
        _push(ssrRenderComponent(_component_NuxtLink, {
          to: `/photo/${gallerContent.category.cat_slug}/${gallerContent.album_id}`,
          class: "relative"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            var _a, _b;
            if (_push2) {
              _push2(ssrRenderComponent(_component_nuxt_img, {
                src: `${unref(siteurl).site_url}/media/photoAlbum/${gallerContent.album_details[0].img}`,
                class: "mx-auto w-full group-hover:scale-110 duration-300",
                placeholder: unref(img)(`${(_a = unref(siteurl)) == null ? void 0 : _a.site_url}/logo/placeholder.jpg`)
              }, null, _parent2, _scopeId));
              _push2(`<div class="overlay" data-v-0c12ec66${_scopeId}><b data-v-0c12ec66${_scopeId}><p class="img-title text-white group-hover:text-[#ff0000] text-[19px]" data-v-0c12ec66${_scopeId}>${ssrInterpolate(gallerContent.album_name)}</p></b></div>`);
            } else {
              return [
                createVNode(_component_nuxt_img, {
                  src: `${unref(siteurl).site_url}/media/photoAlbum/${gallerContent.album_details[0].img}`,
                  class: "mx-auto w-full group-hover:scale-110 duration-300",
                  placeholder: unref(img)(`${(_b = unref(siteurl)) == null ? void 0 : _b.site_url}/logo/placeholder.jpg`)
                }, null, 8, ["src", "placeholder"]),
                createVNode("div", { class: "overlay" }, [
                  createVNode("b", null, [
                    createVNode("p", { class: "img-title text-white group-hover:text-[#ff0000] text-[19px]" }, toDisplayString(gallerContent.album_name), 1)
                  ])
                ])
              ];
            }
          }),
          _: 2
        }, _parent));
        _push(`</div></div>`);
      });
      _push(`<!--]--></div></div>`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Home/Gallery.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_45 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["__scopeId", "data-v-0c12ec66"]]);
const _sfc_main = {
  __name: "index",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    const config = /* @__PURE__ */ useRuntimeConfig();
    const allHeadline = useState(() => [], "$PslAyef5YX");
    const { data: allhead } = ([__temp, __restore] = withAsyncContext(() => useFetch(`${config.public.apiUrl}/api/breaking-news`, {
      method: "GET"
    }, "$6PO73qLRkI")), __temp = await __temp, __restore(), __temp);
    allHeadline.value = allhead;
    const homeMiddleAds = useState(() => "", "$nn2AXZkwPl");
    const { data: hmads } = ([__temp, __restore] = withAsyncContext(() => useFetch("/api/adsmanagement/getads", {
      method: "POST",
      body: {
        page: 2,
        position: 1
      }
    }, "$tWBWWSl2bW")), __temp = await __temp, __restore(), __temp);
    homeMiddleAds.value = hmads.value;
    const homeMiddleOneAds = useState(() => "", "$iS068E0JXZ");
    const { data: hmoneads } = ([__temp, __restore] = withAsyncContext(() => useFetch("/api/adsmanagement/getads", {
      method: "POST",
      body: {
        page: 2,
        position: 2
      }
    }, "$yWMagzMCkb")), __temp = await __temp, __restore(), __temp);
    homeMiddleOneAds.value = hmoneads.value;
    const homeMiddleTwoAds = useState(() => "", "$rfMOiMAoiM");
    const { data: hmtwoads } = ([__temp, __restore] = withAsyncContext(() => useFetch("/api/adsmanagement/getads", {
      method: "POST",
      body: {
        page: 2,
        position: 3
      }
    }, "$aFxinvg6WL")), __temp = await __temp, __restore(), __temp);
    homeMiddleTwoAds.value = hmtwoads.value;
    const homeMiddleThreeAds = useState(() => "", "$CmcCqk4k3o");
    const { data: hmthreeads } = ([__temp, __restore] = withAsyncContext(() => useFetch("/api/adsmanagement/getads", {
      method: "POST",
      body: {
        page: 2,
        position: 4
      }
    }, "$mTJki1KJsF")), __temp = await __temp, __restore(), __temp);
    homeMiddleThreeAds.value = hmthreeads.value;
    const homeMiddleFourAds = useState(() => "", "$94lH0aU7Gd");
    const { data: hmfourads } = ([__temp, __restore] = withAsyncContext(() => useFetch("/api/adsmanagement/getads", {
      method: "POST",
      body: {
        page: 2,
        position: 5
      }
    }, "$S41HKvXzho")), __temp = await __temp, __restore(), __temp);
    homeMiddleFourAds.value = hmfourads.value;
    const homeMiddleFiveAds = useState(() => "", "$Mh1tYANjDB");
    const { data: hmfiveads } = ([__temp, __restore] = withAsyncContext(() => useFetch("/api/adsmanagement/getads", {
      method: "POST",
      body: {
        page: 2,
        position: 6
      }
    }, "$jzo8UN0zSU")), __temp = await __temp, __restore(), __temp);
    homeMiddleFiveAds.value = hmfiveads.value;
    const homeMiddleSixAds = useState(() => "", "$gwYCgwx8nT");
    const { data: hmsixads } = ([__temp, __restore] = withAsyncContext(() => useFetch("/api/adsmanagement/getads", {
      method: "POST",
      body: {
        page: 2,
        position: 7
      }
    }, "$TfcCD0Caz7")), __temp = await __temp, __restore(), __temp);
    homeMiddleSixAds.value = hmsixads.value;
    const homeMiddleSevenAds = useState(() => "", "$nO3Mpd75JT");
    const { data: hmsevenads } = ([__temp, __restore] = withAsyncContext(() => useFetch("/api/adsmanagement/getads", {
      method: "POST",
      body: {
        page: 2,
        position: 8
      }
    }, "$63oZeFndhT")), __temp = await __temp, __restore(), __temp);
    homeMiddleSevenAds.value = hmsevenads.value;
    const homeMiddleEightAds = useState(() => "", "$LglIrGh1k2");
    const { data: hmeightads } = ([__temp, __restore] = withAsyncContext(() => useFetch("/api/adsmanagement/getads", {
      method: "POST",
      body: {
        page: 2,
        position: 9
      }
    }, "$g5oxxRQjTP")), __temp = await __temp, __restore(), __temp);
    homeMiddleEightAds.value = hmeightads.value;
    const homeMiddleNineAds = useState(() => "", "$F7guDTzxjS");
    const { data: hmninetads } = ([__temp, __restore] = withAsyncContext(() => useFetch("/api/adsmanagement/getads", {
      method: "POST",
      body: {
        page: 2,
        position: 10
      }
    }, "$GRwAjkt482")), __temp = await __temp, __restore(), __temp);
    homeMiddleNineAds.value = hmninetads.value;
    const homeRightOneAds = useState(() => "", "$dU9P23OpKt");
    const { data: hmnroneads } = ([__temp, __restore] = withAsyncContext(() => useFetch("/api/adsmanagement/getads", {
      method: "POST",
      body: {
        page: 2,
        position: 11
      }
    }, "$4LZmNj5UNA")), __temp = await __temp, __restore(), __temp);
    homeRightOneAds.value = hmnroneads.value;
    const homeRightTwoAds = useState(() => "", "$RaGhREWKYx");
    const { data: hmnrtwoads } = ([__temp, __restore] = withAsyncContext(() => useFetch("/api/adsmanagement/getads", {
      method: "POST",
      body: {
        page: 2,
        position: 12
      }
    }, "$oNnf5W1W96")), __temp = await __temp, __restore(), __temp);
    homeRightTwoAds.value = hmnrtwoads.value;
    const homeRightThreeAds = useState(() => "", "$anTbkS9qt5");
    const { data: hmnrthreeads } = ([__temp, __restore] = withAsyncContext(() => useFetch("/api/adsmanagement/getads", {
      method: "POST",
      body: {
        page: 2,
        position: 13
      }
    }, "$La09c6pndZ")), __temp = await __temp, __restore(), __temp);
    homeRightThreeAds.value = hmnrthreeads.value;
    const homeRightFourAds = useState(() => "", "$GXnO4BuUqt");
    const { data: hmnrfourads } = ([__temp, __restore] = withAsyncContext(() => useFetch("/api/adsmanagement/getads", {
      method: "POST",
      body: {
        page: 2,
        position: 14
      }
    }, "$JByJVFxXk0")), __temp = await __temp, __restore(), __temp);
    homeRightFourAds.value = hmnrfourads.value;
    const homeRightFiveAds = useState(() => "", "$Fsnsu5mbKX");
    const { data: hmnrfiveads } = ([__temp, __restore] = withAsyncContext(() => useFetch("/api/adsmanagement/getads", {
      method: "POST",
      body: {
        page: 2,
        position: 15
      }
    }, "$DOFAXk2gLC")), __temp = await __temp, __restore(), __temp);
    homeRightFiveAds.value = hmnrfiveads.value;
    const homeRightSixAds = useState(() => "", "$tjlvnpqXUP");
    const { data: hmnrsixads } = ([__temp, __restore] = withAsyncContext(() => useFetch("/api/adsmanagement/getads", {
      method: "POST",
      body: {
        page: 2,
        position: 16
      }
    }, "$rUuBxhMfwM")), __temp = await __temp, __restore(), __temp);
    homeRightSixAds.value = hmnrsixads.value;
    const homeRightSevenAds = useState(() => "", "$zFpJXIBRLM");
    const { data: hmnrsevenads } = ([__temp, __restore] = withAsyncContext(() => useFetch("/api/adsmanagement/getads", {
      method: "POST",
      body: {
        page: 2,
        position: 17
      }
    }, "$svesDPDsWl")), __temp = await __temp, __restore(), __temp);
    homeRightSevenAds.value = hmnrsevenads.value;
    return (_ctx, _push, _parent, _attrs) => {
      var _a;
      const _component_AdsDesktopHomeMiddleTop = __nuxt_component_0;
      const _component_Headline = __nuxt_component_1;
      const _component_HomeSpecialTopContent = __nuxt_component_2;
      const _component_AdsDesktopHomeMiddleOne = __nuxt_component_3;
      const _component_HomeSpecialBottomContent = __nuxt_component_4;
      const _component_AdsDesktopHomeMiddleTwo = __nuxt_component_5;
      const _component_HomeCategoryNational = __nuxt_component_6;
      const _component_AdsDesktopHomeMiddleThree = __nuxt_component_7;
      const _component_HomeCategoryPoliticsEconomyInternational = __nuxt_component_8;
      const _component_AdsDesktopHomeMiddleFour = __nuxt_component_9;
      const _component_AdsDesktopHomeRightOne = __nuxt_component_10;
      const _component_AdsDesktopHomeRightTwo = __nuxt_component_11;
      const _component_HomePostTabs = __nuxt_component_12;
      const _component_AdsDesktopHomeRightThree = __nuxt_component_13;
      const _component_AdsDesktopHomeRightFour = __nuxt_component_14;
      const _component_AdsDesktopHomeRightFive = __nuxt_component_15;
      const _component_AdsDesktopHomeRIghtSix = __nuxt_component_16;
      const _component_AdsDesktopHomeRightSeven = __nuxt_component_17;
      const _component_HomeCategorySpecialReport = __nuxt_component_18;
      const _component_HomeCategorySports = __nuxt_component_19;
      const _component_HomeCategorySaradesh = __nuxt_component_20;
      const _component_AdsDesktopHomeMiddleFive = __nuxt_component_21;
      const _component_HomeCategoryEntertainment = __nuxt_component_22;
      const _component_HomeCategoryLifestyle = __nuxt_component_23;
      const _component_AdsDesktopHomeMiddleSix = __nuxt_component_24;
      const _component_HomeEnglishContent = __nuxt_component_25;
      const _component_AdsDesktopHomeMiddleSeven = __nuxt_component_26;
      const _component_HomeCategoryLawCourt = __nuxt_component_27;
      const _component_HomeCategoryCrime = __nuxt_component_28;
      const _component_HomeCategoryTechnology = __nuxt_component_29;
      const _component_HomeCategoryCareer = __nuxt_component_30;
      const _component_HomeCategoryCampus = __nuxt_component_31;
      const _component_AdsDesktopHomeMiddleEight = __nuxt_component_32;
      const _component_HomeCategoryArtCulture = __nuxt_component_33;
      const _component_HomeCategoryHealth = __nuxt_component_34;
      const _component_HomeCategoryEducation = __nuxt_component_35;
      const _component_HomeCategoryReligion = __nuxt_component_36;
      const _component_HomeCategoryChildAdolescent = __nuxt_component_37;
      const _component_HomeCategoryMotivation = __nuxt_component_38;
      const _component_HomeCategoryProbash = __nuxt_component_39;
      const _component_HomeCategoryCorporate = __nuxt_component_40;
      const _component_HomeCategoryLiterature = __nuxt_component_41;
      const _component_HomeCategoryOpinion = __nuxt_component_42;
      const _component_HomeCategorySpecialArticle = __nuxt_component_43;
      const _component_AdsDesktopHomeMiddleNine = __nuxt_component_44;
      const _component_HomeGallery = __nuxt_component_45;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "home-page" }, _attrs))}>`);
      if (unref(homeMiddleAds).status === 1) {
        _push(`<div class="py-4 border-b border-b-[#e2e2e2] mt-6 md:mt-0">`);
        _push(ssrRenderComponent(_component_AdsDesktopHomeMiddleTop, { homeMiddleAds: unref(homeMiddleAds) }, null, _parent));
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<div class="py-2 md:px-2 max-w-[1280px] mx-auto px-4">`);
      if (((_a = unref(allHeadline)) == null ? void 0 : _a.length) > 0) {
        _push(ssrRenderComponent(_component_Headline, null, null, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(ssrRenderComponent(_component_HomeSpecialTopContent, null, null, _parent));
      _push(`<div class="grid grid-cols-12 gap-4"><div class="col-span-12 md:col-span-9">`);
      if (unref(homeMiddleOneAds).status === 1) {
        _push(`<div class="py-4 border-b border-t border-b-[#e2e2e2] border-t-[#e2e2e2]">`);
        _push(ssrRenderComponent(_component_AdsDesktopHomeMiddleOne, { homeMiddleOneAds: unref(homeMiddleOneAds) }, null, _parent));
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(ssrRenderComponent(_component_HomeSpecialBottomContent, null, null, _parent));
      if (unref(homeMiddleTwoAds).status === 1) {
        _push(`<div class="py-4 border-b border-t border-b-[#e2e2e2] border-t-[#e2e2e2]">`);
        _push(ssrRenderComponent(_component_AdsDesktopHomeMiddleTwo, { homeMiddleTwoAds: unref(homeMiddleTwoAds) }, null, _parent));
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(ssrRenderComponent(_component_HomeCategoryNational, null, null, _parent));
      if (unref(homeMiddleThreeAds).status === 1) {
        _push(`<div class="py-4 border-b border-t border-b-[#e2e2e2] border-t-[#e2e2e2]">`);
        _push(ssrRenderComponent(_component_AdsDesktopHomeMiddleThree, { homeMiddleThreeAds: unref(homeMiddleThreeAds) }, null, _parent));
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(ssrRenderComponent(_component_HomeCategoryPoliticsEconomyInternational, null, null, _parent));
      if (unref(homeMiddleFourAds).status === 1) {
        _push(`<div class="py-4 border-b border-t border-b-[#e2e2e2] border-t-[#e2e2e2]">`);
        _push(ssrRenderComponent(_component_AdsDesktopHomeMiddleFour, { homeMiddleFourAds: unref(homeMiddleFourAds) }, null, _parent));
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div><div class="col-span-12 md:col-span-3">`);
      if (unref(homeRightOneAds).status === 1) {
        _push(`<div class="py-4 border-b border-t border-b-[#e2e2e2] border-t-[#e2e2e2]">`);
        _push(ssrRenderComponent(_component_AdsDesktopHomeRightOne, { homeRightOneAds: unref(homeRightOneAds) }, null, _parent));
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      if (unref(homeRightTwoAds).status === 1) {
        _push(`<div class="py-4 border-b border-t border-b-[#e2e2e2] border-t-[#e2e2e2]">`);
        _push(ssrRenderComponent(_component_AdsDesktopHomeRightTwo, { homeRightTwoAds: unref(homeRightTwoAds) }, null, _parent));
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(ssrRenderComponent(_component_HomePostTabs, null, null, _parent));
      if (unref(homeRightThreeAds).status === 1) {
        _push(`<div class="py-4 border-b border-t border-b-[#e2e2e2] border-t-[#e2e2e2]">`);
        _push(ssrRenderComponent(_component_AdsDesktopHomeRightThree, { homeRightThreeAds: unref(homeRightThreeAds) }, null, _parent));
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      if (unref(homeRightFourAds).status === 1) {
        _push(`<div class="py-4 border-b border-t border-b-[#e2e2e2] border-t-[#e2e2e2]">`);
        _push(ssrRenderComponent(_component_AdsDesktopHomeRightFour, { homeRightFourAds: unref(homeRightFourAds) }, null, _parent));
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      if (unref(homeRightFiveAds).status === 1) {
        _push(`<div class="py-4 border-b border-t border-b-[#e2e2e2] border-t-[#e2e2e2]">`);
        _push(ssrRenderComponent(_component_AdsDesktopHomeRightFive, { homeRightFiveAds: unref(homeRightFiveAds) }, null, _parent));
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      if (unref(homeRightSixAds).status === 1) {
        _push(`<div class="py-4 border-b border-t border-b-[#e2e2e2] border-t-[#e2e2e2]">`);
        _push(ssrRenderComponent(_component_AdsDesktopHomeRIghtSix, { homeRightSixAds: unref(homeRightSixAds) }, null, _parent));
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      if (unref(homeRightSevenAds).status === 1) {
        _push(`<div class="py-4 border-b border-t border-b-[#e2e2e2] border-t-[#e2e2e2]">`);
        _push(ssrRenderComponent(_component_AdsDesktopHomeRightSeven, { homeRightSevenAds: unref(homeRightSevenAds) }, null, _parent));
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div>`);
      _push(ssrRenderComponent(_component_HomeCategorySpecialReport, null, null, _parent));
      _push(`<div class="grid grid-cols-12 gap-4 mb-6"><div class="col-span-12 md:col-span-9">`);
      _push(ssrRenderComponent(_component_HomeCategorySports, null, null, _parent));
      _push(`</div><div class="col-span-12 md:col-span-3">`);
      _push(ssrRenderComponent(_component_HomeCategorySaradesh, null, null, _parent));
      _push(`</div></div>`);
      if (unref(homeMiddleFiveAds).status === 1) {
        _push(`<div class="py-4 border-b border-t border-b-[#e2e2e2] border-t-[#e2e2e2]">`);
        _push(ssrRenderComponent(_component_AdsDesktopHomeMiddleFive, { homeMiddleFiveAds: unref(homeMiddleFiveAds) }, null, _parent));
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<div class="grid grid-cols-12 gap-4"><div class="col-span-12 md:col-span-9">`);
      _push(ssrRenderComponent(_component_HomeCategoryEntertainment, null, null, _parent));
      _push(`</div><div class="col-span-12 md:col-span-3">`);
      _push(ssrRenderComponent(_component_HomeCategoryLifestyle, null, null, _parent));
      _push(`</div></div></div>`);
      if (unref(homeMiddleSixAds).status === 1) {
        _push(`<div class="py-4 border-b border-t border-b-[#e2e2e2] border-t-[#e2e2e2]">`);
        _push(ssrRenderComponent(_component_AdsDesktopHomeMiddleSix, { homeMiddleSixAds: unref(homeMiddleSixAds) }, null, _parent));
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<div class="english-content-except bg-[#fff4e6] my-6">`);
      _push(ssrRenderComponent(_component_HomeEnglishContent, null, null, _parent));
      _push(`</div>`);
      if (unref(homeMiddleSevenAds).status === 1) {
        _push(`<div class="py-4 border-b border-t border-b-[#e2e2e2] border-t-[#e2e2e2]">`);
        _push(ssrRenderComponent(_component_AdsDesktopHomeMiddleSeven, { homeMiddleSevenAds: unref(homeMiddleSevenAds) }, null, _parent));
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<div class="py-2 md:px-2 max-w-[1280px] mx-auto px-4"><div class="grid grid-cols-12 gap-6"><div class="col-span-12 md:col-span-9">`);
      _push(ssrRenderComponent(_component_HomeCategoryLawCourt, null, null, _parent));
      _push(`</div><div class="col-span-12 md:col-span-3">`);
      _push(ssrRenderComponent(_component_HomeCategoryCrime, null, null, _parent));
      _push(`</div></div><div class="grid grid-cols-12 gap-6 py-4"><div class="col-span-12 md:col-span-6">`);
      _push(ssrRenderComponent(_component_HomeCategoryTechnology, null, null, _parent));
      _push(`</div><div class="col-span-12 md:col-span-3">`);
      _push(ssrRenderComponent(_component_HomeCategoryCareer, null, null, _parent));
      _push(`</div><div class="col-span-12 md:col-span-3">`);
      _push(ssrRenderComponent(_component_HomeCategoryCampus, null, null, _parent));
      _push(`</div></div>`);
      if (unref(homeMiddleEightAds).status === 1) {
        _push(`<div class="py-4 border-b border-t border-b-[#e2e2e2] border-t-[#e2e2e2]">`);
        _push(ssrRenderComponent(_component_AdsDesktopHomeMiddleEight, { homeMiddleEightAds: unref(homeMiddleEightAds) }, null, _parent));
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<div class="grid grid-cols-12 gap-6 py-4"><div class="col-span-12 md:col-span-3">`);
      _push(ssrRenderComponent(_component_HomeCategoryArtCulture, null, null, _parent));
      _push(`</div><div class="col-span-12 md:col-span-3">`);
      _push(ssrRenderComponent(_component_HomeCategoryHealth, null, null, _parent));
      _push(`</div><div class="col-span-12 md:col-span-3">`);
      _push(ssrRenderComponent(_component_HomeCategoryEducation, null, null, _parent));
      _push(`</div><div class="col-span-12 md:col-span-3">`);
      _push(ssrRenderComponent(_component_HomeCategoryReligion, null, null, _parent));
      _push(`</div></div><div class="grid grid-cols-12 gap-6 py-4"><div class="col-span-12 md:col-span-3">`);
      _push(ssrRenderComponent(_component_HomeCategoryChildAdolescent, null, null, _parent));
      _push(`</div><div class="col-span-12 md:col-span-3">`);
      _push(ssrRenderComponent(_component_HomeCategoryMotivation, null, null, _parent));
      _push(`</div><div class="col-span-12 md:col-span-3">`);
      _push(ssrRenderComponent(_component_HomeCategoryProbash, null, null, _parent));
      _push(`</div><div class="col-span-12 md:col-span-3">`);
      _push(ssrRenderComponent(_component_HomeCategoryCorporate, null, null, _parent));
      _push(`</div></div><div class="grid grid-cols-12 gap-6 py-4"><div class="col-span-12 md:col-span-6">`);
      _push(ssrRenderComponent(_component_HomeCategoryLiterature, null, null, _parent));
      _push(`</div><div class="col-span-12 md:col-span-3">`);
      _push(ssrRenderComponent(_component_HomeCategoryOpinion, null, null, _parent));
      _push(`</div><div class="col-span-12 md:col-span-3">`);
      _push(ssrRenderComponent(_component_HomeCategorySpecialArticle, null, null, _parent));
      _push(`</div></div></div>`);
      if (unref(homeMiddleNineAds).status === 1) {
        _push(`<div class="py-4 border-b border-t border-b-[#e2e2e2] border-t-[#e2e2e2]">`);
        _push(ssrRenderComponent(_component_AdsDesktopHomeMiddleNine, { homeMiddleNineAds: unref(homeMiddleNineAds) }, null, _parent));
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<div class="english-content-except bg-[#00427A] my-6 text-white">`);
      _push(ssrRenderComponent(_component_HomeGallery, null, null, _parent));
      _push(`</div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=index-7a9781dc.mjs.map
