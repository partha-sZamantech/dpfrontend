import { H as Head, T as Title, M as Meta } from './components-5bc40629.mjs';
import { b as useFetch, a as singlePageStickyState, d as allCategoryState, s as siteUrlState, e as desktopMenuState, u as useImage, g as globalPopupState, _ as __nuxt_component_1$1 } from './state-7a7e2860.mjs';
import { withAsyncContext, ref, withCtx, unref, createTextVNode, toDisplayString, createVNode, useSSRContext, mergeProps, openBlock, createBlock } from 'vue';
import { ssrRenderComponent, ssrInterpolate, ssrRenderClass, ssrRenderSlot, ssrRenderAttrs, ssrRenderAttr, ssrRenderList, ssrRenderStyle } from 'vue/server-renderer';
import __nuxt_component_0$2 from './Icon-ec29c746.mjs';
import { _ as __nuxt_component_0$1 } from './nuxt-link-c659c711.mjs';
import { e as useNuxtApp, j as useRuntimeConfig, _ as _export_sfc } from '../server.mjs';
import { u as useState } from './state-b54abad0.mjs';
import { u as useHead } from './index-6a088328.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'ipx';
import './config-a9056531.mjs';
import '@iconify/vue/dist/offline';
import '@iconify/vue';
import 'unhead';
import '@unhead/shared';
import 'vue-router';

const _sfc_main$c = {
  __name: "HeaderBannerTop",
  __ssrInlineRender: true,
  props: ["topBannerAd"],
  setup(__props) {
    const data = __props;
    const siteurl = siteUrlState();
    return (_ctx, _push, _parent, _attrs) => {
      var _a, _b, _c, _d, _e;
      if (((_a = data == null ? void 0 : data.topBannerAd) == null ? void 0 : _a.status) === 1) {
        _push(`<div${ssrRenderAttrs(mergeProps({ class: "ad-container py-2 border-b" }, _attrs))}><div class="ad-section bg-[#f7f7f7]">`);
        if (((_b = data == null ? void 0 : data.topBannerAd) == null ? void 0 : _b.type) === 3) {
          _push(`<a${ssrRenderAttr("href", (_c = data == null ? void 0 : data.topBannerAd) == null ? void 0 : _c.external_link)} target="_blank" rel="nofollow"><img class="mx-auto"${ssrRenderAttr("src", `${unref(siteurl).site_url}/media/advertisement/${(_d = data == null ? void 0 : data.topBannerAd) == null ? void 0 : _d.desktop_image_path}`)} alt="Header Ad"></a>`);
        } else {
          _push(`<div>${(_e = data == null ? void 0 : data.topBannerAd) == null ? void 0 : _e.code}</div>`);
        }
        _push(`</div></div>`);
      } else {
        _push(`<!---->`);
      }
    };
  }
};
const _sfc_setup$c = _sfc_main$c.setup;
_sfc_main$c.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Ads/Desktop/Common/HeaderBannerTop.vue");
  return _sfc_setup$c ? _sfc_setup$c(props, ctx) : void 0;
};
const __nuxt_component_3$2 = _sfc_main$c;
const _sfc_main$b = {
  __name: "DesktopSideMenu",
  __ssrInlineRender: true,
  setup(__props) {
    const desktopMenuStatus = desktopMenuState();
    const allCategory = allCategoryState();
    const desktopMenuCloseHandler = () => {
      desktopMenuStatus.value = false;
    };
    return (_ctx, _push, _parent, _attrs) => {
      const _component_NuxtLink = __nuxt_component_0$1;
      const _component_nuxt_img = __nuxt_component_1$1;
      const _component_Icon = __nuxt_component_0$2;
      _push(`<div${ssrRenderAttrs(mergeProps({
        id: "desktopSidebar",
        class: `${unref(desktopMenuStatus) ? "-left-0" : "-left-72"} fixed inset-0 w-64 shadow-[#ddd_4px_3px_4px_2px] flex flex-col gap-2 duration-500 bg-white h-screen z-10`
      }, _attrs))} data-v-9480f5c6><div class="desktopLogo px-5 py-5 flex justify-between items-center" data-v-9480f5c6>`);
      _push(ssrRenderComponent(_component_NuxtLink, { to: "/" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_nuxt_img, {
              src: "https://www.dhakaprokash24.com/media/common/logo1672518180.png",
              class: "w-40"
            }, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_nuxt_img, {
                src: "https://www.dhakaprokash24.com/media/common/logo1672518180.png",
                class: "w-40"
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_Icon, {
        name: "material-symbols:close",
        onClick: desktopMenuCloseHandler,
        class: "text-3xl cursor-pointer hover:bg-[#f7f7f7]"
      }, null, _parent));
      _push(`</div><div class="overflow-y-auto pb-16" data-v-9480f5c6><div class="desktopSideMenus flex flex-col px-7 py-5 text-[1rem]" data-v-9480f5c6><!--[-->`);
      ssrRenderList(unref(allCategory), (cat, cindex) => {
        _push(ssrRenderComponent(_component_NuxtLink, {
          key: cindex,
          to: `/${cat == null ? void 0 : cat.cat_slug}`,
          class: "py-2 border-b"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`${ssrInterpolate(cat == null ? void 0 : cat.cat_name_bn)}`);
            } else {
              return [
                createTextVNode(toDisplayString(cat == null ? void 0 : cat.cat_name_bn), 1)
              ];
            }
          }),
          _: 2
        }, _parent));
      });
      _push(`<!--]-->`);
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: "/",
        class: "py-2 border-b"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`\u0987\u09AA\u09C7\u09AA\u09BE\u09B0`);
          } else {
            return [
              createTextVNode("\u0987\u09AA\u09C7\u09AA\u09BE\u09B0")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div><div class="social_media flex flex-col gap-2 px-7" data-v-9480f5c6><p class="text-sm" data-v-9480f5c6>\u0985\u09A8\u09C1\u09B8\u09B0\u09A3 \u0995\u09B0\u09C1\u09A8</p><div class="flex gap-6" data-v-9480f5c6>`);
      _push(ssrRenderComponent(_component_NuxtLink, {
        target: "_blank",
        to: "https://www.facebook.com/dhakaprokash24"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<svg xmlns="http://www.w3.org/2000/svg" height="28" width="28" viewBox="0 0 32 32" enable-background="new 0 0 32 32" xml:space="preserve" data-v-9480f5c6${_scopeId}><path fill="#1877F2" d="M16,0L16,0c8.837,0,16,7.163,16,16l0,0c0,8.837-7.163,16-16,16l0,0C7.163,32,0,24.837,0,16l0,0 C0,7.163,7.163,0,16,0z" data-v-9480f5c6${_scopeId}></path><path fill="#FFFFFF" d="M18,17.5h2.5l1-4H18v-2c0-1.03,0-2,2-2h1.5V6.14C21.174,6.097,19.943,6,18.643,6C15.928,6,14,7.657,14,10.7 v2.8h-3v4h3V26h4V17.5z" data-v-9480f5c6${_scopeId}></path></svg>`);
          } else {
            return [
              (openBlock(), createBlock("svg", {
                xmlns: "http://www.w3.org/2000/svg",
                height: "28",
                width: "28",
                viewBox: "0 0 32 32",
                "enable-background": "new 0 0 32 32",
                "xml:space": "preserve"
              }, [
                createVNode("path", {
                  fill: "#1877F2",
                  d: "M16,0L16,0c8.837,0,16,7.163,16,16l0,0c0,8.837-7.163,16-16,16l0,0C7.163,32,0,24.837,0,16l0,0 C0,7.163,7.163,0,16,0z"
                }),
                createVNode("path", {
                  fill: "#FFFFFF",
                  d: "M18,17.5h2.5l1-4H18v-2c0-1.03,0-2,2-2h1.5V6.14C21.174,6.097,19.943,6,18.643,6C15.928,6,14,7.657,14,10.7 v2.8h-3v4h3V26h4V17.5z"
                })
              ]))
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_NuxtLink, {
        target: "_blank",
        to: "https://twitter.com/dhakaprokash24"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<svg xmlns="http://www.w3.org/2000/svg" height="28" width="28" viewBox="0 0 32 32" enable-background="new 0 0 32 32" xml:space="preserve" data-v-9480f5c6${_scopeId}><path fill="#1DA1F2" d="M16,0L16,0c8.837,0,16,7.163,16,16l0,0c0,8.837-7.163,16-16,16l0,0C7.163,32,0,24.837,0,16l0,0 C0,7.163,7.163,0,16,0z" data-v-9480f5c6${_scopeId}></path><path fill="#FFFFFF" d="M26.162,9.656c-0.764,0.338-1.573,0.56-2.402,0.658C24.634,9.791,25.288,8.969,25.6,8 c-0.82,0.488-1.719,0.83-2.656,1.015c-0.629-0.673-1.464-1.12-2.373-1.27c-0.909-0.15-1.843,0.004-2.656,0.439 c-0.813,0.435-1.459,1.126-1.838,1.966c-0.379,0.84-0.47,1.782-0.259,2.679c-1.663-0.083-3.29-0.516-4.775-1.268 c-1.485-0.753-2.795-1.81-3.845-3.102c-0.372,0.638-0.567,1.364-0.566,2.103c0,1.45,0.738,2.731,1.86,3.481 c-0.664-0.021-1.313-0.2-1.894-0.523v0.052c0,0.966,0.334,1.902,0.946,2.649c0.611,0.747,1.463,1.26,2.409,1.452 c-0.616,0.167-1.263,0.192-1.89,0.072c0.267,0.831,0.787,1.558,1.488,2.079c0.701,0.521,1.547,0.81,2.419,0.826 c-0.868,0.681-1.861,1.185-2.923,1.482c-1.062,0.297-2.173,0.382-3.268,0.25c1.912,1.229,4.137,1.882,6.41,1.88 c7.693,0,11.9-6.373,11.9-11.9c0-0.18-0.005-0.362-0.013-0.54c0.819-0.592,1.526-1.325,2.087-2.165L26.162,9.656z" data-v-9480f5c6${_scopeId}></path></svg>`);
          } else {
            return [
              (openBlock(), createBlock("svg", {
                xmlns: "http://www.w3.org/2000/svg",
                height: "28",
                width: "28",
                viewBox: "0 0 32 32",
                "enable-background": "new 0 0 32 32",
                "xml:space": "preserve"
              }, [
                createVNode("path", {
                  fill: "#1DA1F2",
                  d: "M16,0L16,0c8.837,0,16,7.163,16,16l0,0c0,8.837-7.163,16-16,16l0,0C7.163,32,0,24.837,0,16l0,0 C0,7.163,7.163,0,16,0z"
                }),
                createVNode("path", {
                  fill: "#FFFFFF",
                  d: "M26.162,9.656c-0.764,0.338-1.573,0.56-2.402,0.658C24.634,9.791,25.288,8.969,25.6,8 c-0.82,0.488-1.719,0.83-2.656,1.015c-0.629-0.673-1.464-1.12-2.373-1.27c-0.909-0.15-1.843,0.004-2.656,0.439 c-0.813,0.435-1.459,1.126-1.838,1.966c-0.379,0.84-0.47,1.782-0.259,2.679c-1.663-0.083-3.29-0.516-4.775-1.268 c-1.485-0.753-2.795-1.81-3.845-3.102c-0.372,0.638-0.567,1.364-0.566,2.103c0,1.45,0.738,2.731,1.86,3.481 c-0.664-0.021-1.313-0.2-1.894-0.523v0.052c0,0.966,0.334,1.902,0.946,2.649c0.611,0.747,1.463,1.26,2.409,1.452 c-0.616,0.167-1.263,0.192-1.89,0.072c0.267,0.831,0.787,1.558,1.488,2.079c0.701,0.521,1.547,0.81,2.419,0.826 c-0.868,0.681-1.861,1.185-2.923,1.482c-1.062,0.297-2.173,0.382-3.268,0.25c1.912,1.229,4.137,1.882,6.41,1.88 c7.693,0,11.9-6.373,11.9-11.9c0-0.18-0.005-0.362-0.013-0.54c0.819-0.592,1.526-1.325,2.087-2.165L26.162,9.656z"
                })
              ]))
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_NuxtLink, {
        target: "_blank",
        to: "https://www.instagram.com/dhakaprokash24/"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<svg height="28" width="28" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32" enable-background="new 0 0 32 32" xml:space="preserve" data-v-9480f5c6${_scopeId}><radialGradient id="SVGID_1_" cx="-246.536" cy="264.8975" r="1" gradientTransform="matrix(1.941947e-15 -31.7144 -29.4969 -1.806164e-15 7822.1538 -7784.2769)" gradientUnits="userSpaceOnUse" data-v-9480f5c6${_scopeId}><stop offset="0" style="${ssrRenderStyle({ "stop-color": "rgb(255, 221, 85)" })}" data-v-9480f5c6${_scopeId}></stop><stop offset="0.1" style="${ssrRenderStyle({ "stop-color": "rgb(255, 221, 85)" })}" data-v-9480f5c6${_scopeId}></stop><stop offset="0.5" style="${ssrRenderStyle({ "stop-color": "rgb(255, 84, 62)" })}" data-v-9480f5c6${_scopeId}></stop><stop offset="1" style="${ssrRenderStyle({ "stop-color": "rgb(200, 55, 171)" })}" data-v-9480f5c6${_scopeId}></stop></radialGradient><circle fill="url(#SVGID_1_)" cx="16" cy="16" r="16" data-v-9480f5c6${_scopeId}></circle><radialGradient id="SVGID_2_" cx="-219.16" cy="276.2076" r="1" gradientTransform="matrix(2.7825 13.9007 57.2992 -11.4697 -15222.0215 6216.8076)" gradientUnits="userSpaceOnUse" data-v-9480f5c6${_scopeId}><stop offset="0" style="${ssrRenderStyle({ "stop-color": "rgb(55, 113, 200)" })}" data-v-9480f5c6${_scopeId}></stop><stop offset="0.128" style="${ssrRenderStyle({ "stop-color": "rgb(55, 113, 200)" })}" data-v-9480f5c6${_scopeId}></stop><stop offset="1" style="${ssrRenderStyle({ "stop-color": "rgb(102, 0, 255)", "stop-opacity": "0" })}" data-v-9480f5c6${_scopeId}></stop></radialGradient><circle fill="url(#SVGID_2_)" cx="16" cy="16" r="16" data-v-9480f5c6${_scopeId}></circle><path fill="#FFFFFF" d="M16.001,6c-2.716,0-3.057,0.012-4.123,0.06c-1.065,0.049-1.791,0.217-2.427,0.465 C8.793,6.78,8.235,7.122,7.679,7.678C7.123,8.234,6.781,8.792,6.525,9.449c-0.248,0.636-0.417,1.363-0.465,2.427 C6.012,12.943,6,13.284,6,16s0.012,3.056,0.06,4.122c0.049,1.065,0.217,1.791,0.465,2.427c0.256,0.658,0.597,1.216,1.153,1.771 c0.556,0.556,1.114,0.899,1.771,1.154c0.636,0.247,1.363,0.416,2.428,0.465C12.943,25.988,13.284,26,16,26 c2.716,0,3.056-0.012,4.123-0.06c1.065-0.049,1.792-0.217,2.428-0.465c0.657-0.255,1.215-0.598,1.77-1.154 c0.556-0.556,0.898-1.114,1.154-1.771c0.246-0.636,0.415-1.363,0.465-2.427C25.987,19.056,26,18.716,26,16s-0.012-3.057-0.06-4.123 c-0.05-1.065-0.219-1.791-0.465-2.427c-0.256-0.658-0.598-1.216-1.154-1.771c-0.556-0.556-1.113-0.898-1.771-1.153 c-0.638-0.247-1.365-0.416-2.429-0.465C19.054,6.012,18.714,6,15.998,6H16.001z M15.104,7.802c0.266,0,0.563,0,0.897,0 c2.67,0,2.987,0.01,4.041,0.057c0.975,0.045,1.504,0.207,1.857,0.344c0.467,0.181,0.799,0.398,1.149,0.748 c0.35,0.35,0.567,0.683,0.748,1.15c0.137,0.352,0.3,0.881,0.344,1.856c0.048,1.054,0.058,1.371,0.058,4.04 c0,2.669-0.01,2.985-0.058,4.04c-0.045,0.975-0.208,1.504-0.344,1.856c-0.181,0.467-0.398,0.799-0.748,1.149 c-0.35,0.35-0.682,0.567-1.149,0.748c-0.352,0.138-0.882,0.3-1.857,0.345c-1.054,0.048-1.371,0.058-4.041,0.058 c-2.67,0-2.987-0.01-4.041-0.058c-0.975-0.045-1.504-0.208-1.857-0.345c-0.467-0.181-0.8-0.398-1.15-0.748 c-0.35-0.35-0.567-0.683-0.748-1.149c-0.137-0.352-0.3-0.881-0.344-1.856c-0.048-1.054-0.058-1.371-0.058-4.041 s0.01-2.985,0.058-4.04c0.045-0.975,0.207-1.504,0.344-1.857c0.181-0.467,0.398-0.8,0.748-1.15c0.35-0.35,0.683-0.567,1.15-0.748 c0.352-0.137,0.882-0.3,1.857-0.345c0.922-0.042,1.28-0.054,3.144-0.056V7.802z M21.339,9.462c-0.662,0-1.2,0.537-1.2,1.2 c0,0.663,0.538,1.2,1.2,1.2c0.663,0,1.2-0.537,1.2-1.2C22.539,10,22.001,9.462,21.339,9.462L21.339,9.462z M16.001,10.865 c-2.836,0-5.135,2.299-5.135,5.135s2.299,5.134,5.135,5.134c2.836,0,5.135-2.298,5.135-5.134S18.837,10.865,16.001,10.865 L16.001,10.865z M16.001,12.667c1.841,0,3.333,1.492,3.333,3.333c0,1.841-1.493,3.333-3.333,3.333c-1.841,0-3.333-1.493-3.333-3.333 C12.667,14.159,14.16,12.667,16.001,12.667L16.001,12.667z" data-v-9480f5c6${_scopeId}></path></svg>`);
          } else {
            return [
              (openBlock(), createBlock("svg", {
                height: "28",
                width: "28",
                xmlns: "http://www.w3.org/2000/svg",
                viewBox: "0 0 32 32",
                "enable-background": "new 0 0 32 32",
                "xml:space": "preserve"
              }, [
                createVNode("radialGradient", {
                  id: "SVGID_1_",
                  cx: "-246.536",
                  cy: "264.8975",
                  r: "1",
                  gradientTransform: "matrix(1.941947e-15 -31.7144 -29.4969 -1.806164e-15 7822.1538 -7784.2769)",
                  gradientUnits: "userSpaceOnUse"
                }, [
                  createVNode("stop", {
                    offset: "0",
                    style: { "stop-color": "rgb(255, 221, 85)" }
                  }),
                  createVNode("stop", {
                    offset: "0.1",
                    style: { "stop-color": "rgb(255, 221, 85)" }
                  }),
                  createVNode("stop", {
                    offset: "0.5",
                    style: { "stop-color": "rgb(255, 84, 62)" }
                  }),
                  createVNode("stop", {
                    offset: "1",
                    style: { "stop-color": "rgb(200, 55, 171)" }
                  })
                ]),
                createVNode("circle", {
                  fill: "url(#SVGID_1_)",
                  cx: "16",
                  cy: "16",
                  r: "16"
                }),
                createVNode("radialGradient", {
                  id: "SVGID_2_",
                  cx: "-219.16",
                  cy: "276.2076",
                  r: "1",
                  gradientTransform: "matrix(2.7825 13.9007 57.2992 -11.4697 -15222.0215 6216.8076)",
                  gradientUnits: "userSpaceOnUse"
                }, [
                  createVNode("stop", {
                    offset: "0",
                    style: { "stop-color": "rgb(55, 113, 200)" }
                  }),
                  createVNode("stop", {
                    offset: "0.128",
                    style: { "stop-color": "rgb(55, 113, 200)" }
                  }),
                  createVNode("stop", {
                    offset: "1",
                    style: { "stop-color": "rgb(102, 0, 255)", "stop-opacity": "0" }
                  })
                ]),
                createVNode("circle", {
                  fill: "url(#SVGID_2_)",
                  cx: "16",
                  cy: "16",
                  r: "16"
                }),
                createVNode("path", {
                  fill: "#FFFFFF",
                  d: "M16.001,6c-2.716,0-3.057,0.012-4.123,0.06c-1.065,0.049-1.791,0.217-2.427,0.465 C8.793,6.78,8.235,7.122,7.679,7.678C7.123,8.234,6.781,8.792,6.525,9.449c-0.248,0.636-0.417,1.363-0.465,2.427 C6.012,12.943,6,13.284,6,16s0.012,3.056,0.06,4.122c0.049,1.065,0.217,1.791,0.465,2.427c0.256,0.658,0.597,1.216,1.153,1.771 c0.556,0.556,1.114,0.899,1.771,1.154c0.636,0.247,1.363,0.416,2.428,0.465C12.943,25.988,13.284,26,16,26 c2.716,0,3.056-0.012,4.123-0.06c1.065-0.049,1.792-0.217,2.428-0.465c0.657-0.255,1.215-0.598,1.77-1.154 c0.556-0.556,0.898-1.114,1.154-1.771c0.246-0.636,0.415-1.363,0.465-2.427C25.987,19.056,26,18.716,26,16s-0.012-3.057-0.06-4.123 c-0.05-1.065-0.219-1.791-0.465-2.427c-0.256-0.658-0.598-1.216-1.154-1.771c-0.556-0.556-1.113-0.898-1.771-1.153 c-0.638-0.247-1.365-0.416-2.429-0.465C19.054,6.012,18.714,6,15.998,6H16.001z M15.104,7.802c0.266,0,0.563,0,0.897,0 c2.67,0,2.987,0.01,4.041,0.057c0.975,0.045,1.504,0.207,1.857,0.344c0.467,0.181,0.799,0.398,1.149,0.748 c0.35,0.35,0.567,0.683,0.748,1.15c0.137,0.352,0.3,0.881,0.344,1.856c0.048,1.054,0.058,1.371,0.058,4.04 c0,2.669-0.01,2.985-0.058,4.04c-0.045,0.975-0.208,1.504-0.344,1.856c-0.181,0.467-0.398,0.799-0.748,1.149 c-0.35,0.35-0.682,0.567-1.149,0.748c-0.352,0.138-0.882,0.3-1.857,0.345c-1.054,0.048-1.371,0.058-4.041,0.058 c-2.67,0-2.987-0.01-4.041-0.058c-0.975-0.045-1.504-0.208-1.857-0.345c-0.467-0.181-0.8-0.398-1.15-0.748 c-0.35-0.35-0.567-0.683-0.748-1.149c-0.137-0.352-0.3-0.881-0.344-1.856c-0.048-1.054-0.058-1.371-0.058-4.041 s0.01-2.985,0.058-4.04c0.045-0.975,0.207-1.504,0.344-1.857c0.181-0.467,0.398-0.8,0.748-1.15c0.35-0.35,0.683-0.567,1.15-0.748 c0.352-0.137,0.882-0.3,1.857-0.345c0.922-0.042,1.28-0.054,3.144-0.056V7.802z M21.339,9.462c-0.662,0-1.2,0.537-1.2,1.2 c0,0.663,0.538,1.2,1.2,1.2c0.663,0,1.2-0.537,1.2-1.2C22.539,10,22.001,9.462,21.339,9.462L21.339,9.462z M16.001,10.865 c-2.836,0-5.135,2.299-5.135,5.135s2.299,5.134,5.135,5.134c2.836,0,5.135-2.298,5.135-5.134S18.837,10.865,16.001,10.865 L16.001,10.865z M16.001,12.667c1.841,0,3.333,1.492,3.333,3.333c0,1.841-1.493,3.333-3.333,3.333c-1.841,0-3.333-1.493-3.333-3.333 C12.667,14.159,14.16,12.667,16.001,12.667L16.001,12.667z"
                })
              ]))
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_NuxtLink, {
        target: "_blank",
        to: "https://www.youtube.com/DhakaProkash"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<svg xmlns="http://www.w3.org/2000/svg" height="28" width="28" viewBox="0 0 32 32" enable-background="new 0 0 32 32" xml:space="preserve" data-v-9480f5c6${_scopeId}><path fill="#FF0000" d="M16,0L16,0c8.837,0,16,7.163,16,16l0,0c0,8.837-7.163,16-16,16l0,0C7.163,32,0,24.837,0,16l0,0 C0,7.163,7.163,0,16,0z" data-v-9480f5c6${_scopeId}></path><path fill="#FFFFFF" d="M25.543,10.498C26,12.28,26,16,26,16s0,3.72-0.457,5.502c-0.254,0.985-0.997,1.76-1.938,2.022 C21.896,24,16,24,16,24s-5.893,0-7.605-0.476c-0.945-0.266-1.687-1.04-1.938-2.022C6,19.72,6,16,6,16s0-3.72,0.457-5.502 c0.254-0.985,0.997-1.76,1.938-2.022C10.107,8,16,8,16,8s5.896,0,7.605,0.476C24.55,8.742,25.292,9.516,25.543,10.498L25.543,10.498 z M14,19.5l6-3.5l-6-3.5V19.5z" data-v-9480f5c6${_scopeId}></path></svg>`);
          } else {
            return [
              (openBlock(), createBlock("svg", {
                xmlns: "http://www.w3.org/2000/svg",
                height: "28",
                width: "28",
                viewBox: "0 0 32 32",
                "enable-background": "new 0 0 32 32",
                "xml:space": "preserve"
              }, [
                createVNode("path", {
                  fill: "#FF0000",
                  d: "M16,0L16,0c8.837,0,16,7.163,16,16l0,0c0,8.837-7.163,16-16,16l0,0C7.163,32,0,24.837,0,16l0,0 C0,7.163,7.163,0,16,0z"
                }),
                createVNode("path", {
                  fill: "#FFFFFF",
                  d: "M25.543,10.498C26,12.28,26,16,26,16s0,3.72-0.457,5.502c-0.254,0.985-0.997,1.76-1.938,2.022 C21.896,24,16,24,16,24s-5.893,0-7.605-0.476c-0.945-0.266-1.687-1.04-1.938-2.022C6,19.72,6,16,6,16s0-3.72,0.457-5.502 c0.254-0.985,0.997-1.76,1.938-2.022C10.107,8,16,8,16,8s5.896,0,7.605,0.476C24.55,8.742,25.292,9.516,25.543,10.498L25.543,10.498 z M14,19.5l6-3.5l-6-3.5V19.5z"
                })
              ]))
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div></div></div>`);
    };
  }
};
const _sfc_setup$b = _sfc_main$b.setup;
_sfc_main$b.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Header/DesktopSideMenu.vue");
  return _sfc_setup$b ? _sfc_setup$b(props, ctx) : void 0;
};
const __nuxt_component_3$1 = /* @__PURE__ */ _export_sfc(_sfc_main$b, [["__scopeId", "data-v-9480f5c6"]]);
const _sfc_main$a = {
  __name: "HeaderTop",
  __ssrInlineRender: true,
  props: ["scrollDown", "LogoHeaderScollUp"],
  async setup(__props) {
    let __temp, __restore;
    const getDate = new Intl.DateTimeFormat("bn-bd", { weekday: "long", year: "numeric", month: "long", day: "numeric" });
    const todayDate = getDate.format(/* @__PURE__ */ new Date());
    useImage();
    const desktopMenuStatus = desktopMenuState();
    const desktopMenuOpenHandler = () => {
      desktopMenuStatus.value = true;
    };
    const searchStatus = ref(false);
    const searchBoxHandler = () => {
      if (searchStatus.value === true) {
        searchStatus.value = false;
      } else {
        searchStatus.value = true;
      }
    };
    const siteurl = siteUrlState();
    const siteSetting = useState(() => [], "$v0T8YxbKNy");
    const { data: siteSet } = ([__temp, __restore] = withAsyncContext(() => useFetch(`/api/sitesetting`, {
      method: "GET"
    }, "$HmDfIa2iGt")), __temp = await __temp, __restore(), __temp);
    siteSetting.value = siteSet;
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Icon = __nuxt_component_0$2;
      const _component_NuxtLink = __nuxt_component_0$1;
      const _component_nuxt_img = __nuxt_component_1$1;
      const _component_HeaderDesktopSideMenu = __nuxt_component_3$1;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "bg-white py-4" }, _attrs))}><div class="max-w-[1280px] mx-auto bg-white"><div class="${ssrRenderClass(` hidden md:grid grid-cols-3  bg-white px-2 justify-between items-center `)}"><div class="flex gap-3 flex-col"><div class="flex gap-3 items-center h-8"><div>`);
      _push(ssrRenderComponent(_component_Icon, {
        onClick: desktopMenuOpenHandler,
        class: "text-3xl cursor-pointer hover:bg-[#f7f7f7]",
        name: "ic:outline-menu"
      }, null, _parent));
      _push(`</div>`);
      if (!unref(searchStatus)) {
        _push(`<div>`);
        _push(ssrRenderComponent(_component_Icon, {
          onClick: searchBoxHandler,
          class: "text-2xl cursor-pointer",
          name: "tabler:search"
        }, null, _parent));
        _push(`</div>`);
      } else {
        _push(`<div class="${ssrRenderClass(` flex items-center duration-500`)}"><input type="text" placeholder="\u09AF\u09BE \u0996\u09C1\u0981\u099C\u09A4\u09C7 \u099A\u09BE\u09A8 \u09A4\u09BE \u09B2\u09BF\u0996\u09C1\u09A8" class="focus:outline-none border px-2 py-2"><div class="bg-gray-200 px-2 py-2 cursor-pointer">`);
        _push(ssrRenderComponent(_component_Icon, {
          class: "text-2xl",
          name: "tabler:search"
        }, null, _parent));
        _push(`</div><div class="bg-gray-200 px-2 py-2 border-l border-l-gray-400 cursor-pointer">`);
        _push(ssrRenderComponent(_component_Icon, {
          name: "material-symbols:close",
          class: "text-2xl"
        }, null, _parent));
        _push(`</div></div>`);
      }
      _push(`</div><div class="today_date text-sm">${ssrInterpolate(unref(todayDate))}</div></div><div class="header_logo">`);
      _push(ssrRenderComponent(_component_NuxtLink, { to: "/" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          var _a, _b;
          if (_push2) {
            _push2(ssrRenderComponent(_component_nuxt_img, {
              class: "mx-auto",
              src: `${unref(siteurl).site_url}/media/common/${(_a = unref(siteSetting)) == null ? void 0 : _a.logo}`,
              width: "300",
              alt: "Dhaka Prokash"
            }, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_nuxt_img, {
                class: "mx-auto",
                src: `${unref(siteurl).site_url}/media/common/${(_b = unref(siteSetting)) == null ? void 0 : _b.logo}`,
                width: "300",
                alt: "Dhaka Prokash"
              }, null, 8, ["src"])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div><div class="flex gap-4 flex-col"><div class="flex gap-4 items-center place-self-end">`);
      _push(ssrRenderComponent(_component_NuxtLink, {
        target: "_blank",
        to: "https://www.facebook.com/dhakaprokash24"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<svg xmlns="http://www.w3.org/2000/svg" height="28" width="28" viewBox="0 0 32 32" enable-background="new 0 0 32 32" xml:space="preserve"${_scopeId}><path fill="#1877F2" d="M16,0L16,0c8.837,0,16,7.163,16,16l0,0c0,8.837-7.163,16-16,16l0,0C7.163,32,0,24.837,0,16l0,0 C0,7.163,7.163,0,16,0z"${_scopeId}></path><path fill="#FFFFFF" d="M18,17.5h2.5l1-4H18v-2c0-1.03,0-2,2-2h1.5V6.14C21.174,6.097,19.943,6,18.643,6C15.928,6,14,7.657,14,10.7 v2.8h-3v4h3V26h4V17.5z"${_scopeId}></path></svg>`);
          } else {
            return [
              (openBlock(), createBlock("svg", {
                xmlns: "http://www.w3.org/2000/svg",
                height: "28",
                width: "28",
                viewBox: "0 0 32 32",
                "enable-background": "new 0 0 32 32",
                "xml:space": "preserve"
              }, [
                createVNode("path", {
                  fill: "#1877F2",
                  d: "M16,0L16,0c8.837,0,16,7.163,16,16l0,0c0,8.837-7.163,16-16,16l0,0C7.163,32,0,24.837,0,16l0,0 C0,7.163,7.163,0,16,0z"
                }),
                createVNode("path", {
                  fill: "#FFFFFF",
                  d: "M18,17.5h2.5l1-4H18v-2c0-1.03,0-2,2-2h1.5V6.14C21.174,6.097,19.943,6,18.643,6C15.928,6,14,7.657,14,10.7 v2.8h-3v4h3V26h4V17.5z"
                })
              ]))
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_NuxtLink, {
        target: "_blank",
        to: "https://twitter.com/dhakaprokash24"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<svg xmlns="http://www.w3.org/2000/svg" height="28" width="28" viewBox="0 0 32 32" enable-background="new 0 0 32 32" xml:space="preserve"${_scopeId}><path fill="#1DA1F2" d="M16,0L16,0c8.837,0,16,7.163,16,16l0,0c0,8.837-7.163,16-16,16l0,0C7.163,32,0,24.837,0,16l0,0 C0,7.163,7.163,0,16,0z"${_scopeId}></path><path fill="#FFFFFF" d="M26.162,9.656c-0.764,0.338-1.573,0.56-2.402,0.658C24.634,9.791,25.288,8.969,25.6,8 c-0.82,0.488-1.719,0.83-2.656,1.015c-0.629-0.673-1.464-1.12-2.373-1.27c-0.909-0.15-1.843,0.004-2.656,0.439 c-0.813,0.435-1.459,1.126-1.838,1.966c-0.379,0.84-0.47,1.782-0.259,2.679c-1.663-0.083-3.29-0.516-4.775-1.268 c-1.485-0.753-2.795-1.81-3.845-3.102c-0.372,0.638-0.567,1.364-0.566,2.103c0,1.45,0.738,2.731,1.86,3.481 c-0.664-0.021-1.313-0.2-1.894-0.523v0.052c0,0.966,0.334,1.902,0.946,2.649c0.611,0.747,1.463,1.26,2.409,1.452 c-0.616,0.167-1.263,0.192-1.89,0.072c0.267,0.831,0.787,1.558,1.488,2.079c0.701,0.521,1.547,0.81,2.419,0.826 c-0.868,0.681-1.861,1.185-2.923,1.482c-1.062,0.297-2.173,0.382-3.268,0.25c1.912,1.229,4.137,1.882,6.41,1.88 c7.693,0,11.9-6.373,11.9-11.9c0-0.18-0.005-0.362-0.013-0.54c0.819-0.592,1.526-1.325,2.087-2.165L26.162,9.656z"${_scopeId}></path></svg>`);
          } else {
            return [
              (openBlock(), createBlock("svg", {
                xmlns: "http://www.w3.org/2000/svg",
                height: "28",
                width: "28",
                viewBox: "0 0 32 32",
                "enable-background": "new 0 0 32 32",
                "xml:space": "preserve"
              }, [
                createVNode("path", {
                  fill: "#1DA1F2",
                  d: "M16,0L16,0c8.837,0,16,7.163,16,16l0,0c0,8.837-7.163,16-16,16l0,0C7.163,32,0,24.837,0,16l0,0 C0,7.163,7.163,0,16,0z"
                }),
                createVNode("path", {
                  fill: "#FFFFFF",
                  d: "M26.162,9.656c-0.764,0.338-1.573,0.56-2.402,0.658C24.634,9.791,25.288,8.969,25.6,8 c-0.82,0.488-1.719,0.83-2.656,1.015c-0.629-0.673-1.464-1.12-2.373-1.27c-0.909-0.15-1.843,0.004-2.656,0.439 c-0.813,0.435-1.459,1.126-1.838,1.966c-0.379,0.84-0.47,1.782-0.259,2.679c-1.663-0.083-3.29-0.516-4.775-1.268 c-1.485-0.753-2.795-1.81-3.845-3.102c-0.372,0.638-0.567,1.364-0.566,2.103c0,1.45,0.738,2.731,1.86,3.481 c-0.664-0.021-1.313-0.2-1.894-0.523v0.052c0,0.966,0.334,1.902,0.946,2.649c0.611,0.747,1.463,1.26,2.409,1.452 c-0.616,0.167-1.263,0.192-1.89,0.072c0.267,0.831,0.787,1.558,1.488,2.079c0.701,0.521,1.547,0.81,2.419,0.826 c-0.868,0.681-1.861,1.185-2.923,1.482c-1.062,0.297-2.173,0.382-3.268,0.25c1.912,1.229,4.137,1.882,6.41,1.88 c7.693,0,11.9-6.373,11.9-11.9c0-0.18-0.005-0.362-0.013-0.54c0.819-0.592,1.526-1.325,2.087-2.165L26.162,9.656z"
                })
              ]))
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_NuxtLink, {
        target: "_blank",
        to: "https://www.instagram.com/dhakaprokash24/"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<svg height="28" width="28" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32" enable-background="new 0 0 32 32" xml:space="preserve"${_scopeId}><radialGradient id="SVGID_1_" cx="-246.536" cy="264.8975" r="1" gradientTransform="matrix(1.941947e-15 -31.7144 -29.4969 -1.806164e-15 7822.1538 -7784.2769)" gradientUnits="userSpaceOnUse"${_scopeId}><stop offset="0" style="${ssrRenderStyle({ "stop-color": "rgb(255, 221, 85)" })}"${_scopeId}></stop><stop offset="0.1" style="${ssrRenderStyle({ "stop-color": "rgb(255, 221, 85)" })}"${_scopeId}></stop><stop offset="0.5" style="${ssrRenderStyle({ "stop-color": "rgb(255, 84, 62)" })}"${_scopeId}></stop><stop offset="1" style="${ssrRenderStyle({ "stop-color": "rgb(200, 55, 171)" })}"${_scopeId}></stop></radialGradient><circle fill="url(#SVGID_1_)" cx="16" cy="16" r="16"${_scopeId}></circle><radialGradient id="SVGID_2_" cx="-219.16" cy="276.2076" r="1" gradientTransform="matrix(2.7825 13.9007 57.2992 -11.4697 -15222.0215 6216.8076)" gradientUnits="userSpaceOnUse"${_scopeId}><stop offset="0" style="${ssrRenderStyle({ "stop-color": "rgb(55, 113, 200)" })}"${_scopeId}></stop><stop offset="0.128" style="${ssrRenderStyle({ "stop-color": "rgb(55, 113, 200)" })}"${_scopeId}></stop><stop offset="1" style="${ssrRenderStyle({ "stop-color": "rgb(102, 0, 255)", "stop-opacity": "0" })}"${_scopeId}></stop></radialGradient><circle fill="url(#SVGID_2_)" cx="16" cy="16" r="16"${_scopeId}></circle><path fill="#FFFFFF" d="M16.001,6c-2.716,0-3.057,0.012-4.123,0.06c-1.065,0.049-1.791,0.217-2.427,0.465 C8.793,6.78,8.235,7.122,7.679,7.678C7.123,8.234,6.781,8.792,6.525,9.449c-0.248,0.636-0.417,1.363-0.465,2.427 C6.012,12.943,6,13.284,6,16s0.012,3.056,0.06,4.122c0.049,1.065,0.217,1.791,0.465,2.427c0.256,0.658,0.597,1.216,1.153,1.771 c0.556,0.556,1.114,0.899,1.771,1.154c0.636,0.247,1.363,0.416,2.428,0.465C12.943,25.988,13.284,26,16,26 c2.716,0,3.056-0.012,4.123-0.06c1.065-0.049,1.792-0.217,2.428-0.465c0.657-0.255,1.215-0.598,1.77-1.154 c0.556-0.556,0.898-1.114,1.154-1.771c0.246-0.636,0.415-1.363,0.465-2.427C25.987,19.056,26,18.716,26,16s-0.012-3.057-0.06-4.123 c-0.05-1.065-0.219-1.791-0.465-2.427c-0.256-0.658-0.598-1.216-1.154-1.771c-0.556-0.556-1.113-0.898-1.771-1.153 c-0.638-0.247-1.365-0.416-2.429-0.465C19.054,6.012,18.714,6,15.998,6H16.001z M15.104,7.802c0.266,0,0.563,0,0.897,0 c2.67,0,2.987,0.01,4.041,0.057c0.975,0.045,1.504,0.207,1.857,0.344c0.467,0.181,0.799,0.398,1.149,0.748 c0.35,0.35,0.567,0.683,0.748,1.15c0.137,0.352,0.3,0.881,0.344,1.856c0.048,1.054,0.058,1.371,0.058,4.04 c0,2.669-0.01,2.985-0.058,4.04c-0.045,0.975-0.208,1.504-0.344,1.856c-0.181,0.467-0.398,0.799-0.748,1.149 c-0.35,0.35-0.682,0.567-1.149,0.748c-0.352,0.138-0.882,0.3-1.857,0.345c-1.054,0.048-1.371,0.058-4.041,0.058 c-2.67,0-2.987-0.01-4.041-0.058c-0.975-0.045-1.504-0.208-1.857-0.345c-0.467-0.181-0.8-0.398-1.15-0.748 c-0.35-0.35-0.567-0.683-0.748-1.149c-0.137-0.352-0.3-0.881-0.344-1.856c-0.048-1.054-0.058-1.371-0.058-4.041 s0.01-2.985,0.058-4.04c0.045-0.975,0.207-1.504,0.344-1.857c0.181-0.467,0.398-0.8,0.748-1.15c0.35-0.35,0.683-0.567,1.15-0.748 c0.352-0.137,0.882-0.3,1.857-0.345c0.922-0.042,1.28-0.054,3.144-0.056V7.802z M21.339,9.462c-0.662,0-1.2,0.537-1.2,1.2 c0,0.663,0.538,1.2,1.2,1.2c0.663,0,1.2-0.537,1.2-1.2C22.539,10,22.001,9.462,21.339,9.462L21.339,9.462z M16.001,10.865 c-2.836,0-5.135,2.299-5.135,5.135s2.299,5.134,5.135,5.134c2.836,0,5.135-2.298,5.135-5.134S18.837,10.865,16.001,10.865 L16.001,10.865z M16.001,12.667c1.841,0,3.333,1.492,3.333,3.333c0,1.841-1.493,3.333-3.333,3.333c-1.841,0-3.333-1.493-3.333-3.333 C12.667,14.159,14.16,12.667,16.001,12.667L16.001,12.667z"${_scopeId}></path></svg>`);
          } else {
            return [
              (openBlock(), createBlock("svg", {
                height: "28",
                width: "28",
                xmlns: "http://www.w3.org/2000/svg",
                viewBox: "0 0 32 32",
                "enable-background": "new 0 0 32 32",
                "xml:space": "preserve"
              }, [
                createVNode("radialGradient", {
                  id: "SVGID_1_",
                  cx: "-246.536",
                  cy: "264.8975",
                  r: "1",
                  gradientTransform: "matrix(1.941947e-15 -31.7144 -29.4969 -1.806164e-15 7822.1538 -7784.2769)",
                  gradientUnits: "userSpaceOnUse"
                }, [
                  createVNode("stop", {
                    offset: "0",
                    style: { "stop-color": "rgb(255, 221, 85)" }
                  }),
                  createVNode("stop", {
                    offset: "0.1",
                    style: { "stop-color": "rgb(255, 221, 85)" }
                  }),
                  createVNode("stop", {
                    offset: "0.5",
                    style: { "stop-color": "rgb(255, 84, 62)" }
                  }),
                  createVNode("stop", {
                    offset: "1",
                    style: { "stop-color": "rgb(200, 55, 171)" }
                  })
                ]),
                createVNode("circle", {
                  fill: "url(#SVGID_1_)",
                  cx: "16",
                  cy: "16",
                  r: "16"
                }),
                createVNode("radialGradient", {
                  id: "SVGID_2_",
                  cx: "-219.16",
                  cy: "276.2076",
                  r: "1",
                  gradientTransform: "matrix(2.7825 13.9007 57.2992 -11.4697 -15222.0215 6216.8076)",
                  gradientUnits: "userSpaceOnUse"
                }, [
                  createVNode("stop", {
                    offset: "0",
                    style: { "stop-color": "rgb(55, 113, 200)" }
                  }),
                  createVNode("stop", {
                    offset: "0.128",
                    style: { "stop-color": "rgb(55, 113, 200)" }
                  }),
                  createVNode("stop", {
                    offset: "1",
                    style: { "stop-color": "rgb(102, 0, 255)", "stop-opacity": "0" }
                  })
                ]),
                createVNode("circle", {
                  fill: "url(#SVGID_2_)",
                  cx: "16",
                  cy: "16",
                  r: "16"
                }),
                createVNode("path", {
                  fill: "#FFFFFF",
                  d: "M16.001,6c-2.716,0-3.057,0.012-4.123,0.06c-1.065,0.049-1.791,0.217-2.427,0.465 C8.793,6.78,8.235,7.122,7.679,7.678C7.123,8.234,6.781,8.792,6.525,9.449c-0.248,0.636-0.417,1.363-0.465,2.427 C6.012,12.943,6,13.284,6,16s0.012,3.056,0.06,4.122c0.049,1.065,0.217,1.791,0.465,2.427c0.256,0.658,0.597,1.216,1.153,1.771 c0.556,0.556,1.114,0.899,1.771,1.154c0.636,0.247,1.363,0.416,2.428,0.465C12.943,25.988,13.284,26,16,26 c2.716,0,3.056-0.012,4.123-0.06c1.065-0.049,1.792-0.217,2.428-0.465c0.657-0.255,1.215-0.598,1.77-1.154 c0.556-0.556,0.898-1.114,1.154-1.771c0.246-0.636,0.415-1.363,0.465-2.427C25.987,19.056,26,18.716,26,16s-0.012-3.057-0.06-4.123 c-0.05-1.065-0.219-1.791-0.465-2.427c-0.256-0.658-0.598-1.216-1.154-1.771c-0.556-0.556-1.113-0.898-1.771-1.153 c-0.638-0.247-1.365-0.416-2.429-0.465C19.054,6.012,18.714,6,15.998,6H16.001z M15.104,7.802c0.266,0,0.563,0,0.897,0 c2.67,0,2.987,0.01,4.041,0.057c0.975,0.045,1.504,0.207,1.857,0.344c0.467,0.181,0.799,0.398,1.149,0.748 c0.35,0.35,0.567,0.683,0.748,1.15c0.137,0.352,0.3,0.881,0.344,1.856c0.048,1.054,0.058,1.371,0.058,4.04 c0,2.669-0.01,2.985-0.058,4.04c-0.045,0.975-0.208,1.504-0.344,1.856c-0.181,0.467-0.398,0.799-0.748,1.149 c-0.35,0.35-0.682,0.567-1.149,0.748c-0.352,0.138-0.882,0.3-1.857,0.345c-1.054,0.048-1.371,0.058-4.041,0.058 c-2.67,0-2.987-0.01-4.041-0.058c-0.975-0.045-1.504-0.208-1.857-0.345c-0.467-0.181-0.8-0.398-1.15-0.748 c-0.35-0.35-0.567-0.683-0.748-1.149c-0.137-0.352-0.3-0.881-0.344-1.856c-0.048-1.054-0.058-1.371-0.058-4.041 s0.01-2.985,0.058-4.04c0.045-0.975,0.207-1.504,0.344-1.857c0.181-0.467,0.398-0.8,0.748-1.15c0.35-0.35,0.683-0.567,1.15-0.748 c0.352-0.137,0.882-0.3,1.857-0.345c0.922-0.042,1.28-0.054,3.144-0.056V7.802z M21.339,9.462c-0.662,0-1.2,0.537-1.2,1.2 c0,0.663,0.538,1.2,1.2,1.2c0.663,0,1.2-0.537,1.2-1.2C22.539,10,22.001,9.462,21.339,9.462L21.339,9.462z M16.001,10.865 c-2.836,0-5.135,2.299-5.135,5.135s2.299,5.134,5.135,5.134c2.836,0,5.135-2.298,5.135-5.134S18.837,10.865,16.001,10.865 L16.001,10.865z M16.001,12.667c1.841,0,3.333,1.492,3.333,3.333c0,1.841-1.493,3.333-3.333,3.333c-1.841,0-3.333-1.493-3.333-3.333 C12.667,14.159,14.16,12.667,16.001,12.667L16.001,12.667z"
                })
              ]))
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_NuxtLink, {
        target: "_blank",
        to: "https://www.youtube.com/DhakaProkash"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<svg xmlns="http://www.w3.org/2000/svg" height="28" width="28" viewBox="0 0 32 32" enable-background="new 0 0 32 32" xml:space="preserve"${_scopeId}><path fill="#FF0000" d="M16,0L16,0c8.837,0,16,7.163,16,16l0,0c0,8.837-7.163,16-16,16l0,0C7.163,32,0,24.837,0,16l0,0 C0,7.163,7.163,0,16,0z"${_scopeId}></path><path fill="#FFFFFF" d="M25.543,10.498C26,12.28,26,16,26,16s0,3.72-0.457,5.502c-0.254,0.985-0.997,1.76-1.938,2.022 C21.896,24,16,24,16,24s-5.893,0-7.605-0.476c-0.945-0.266-1.687-1.04-1.938-2.022C6,19.72,6,16,6,16s0-3.72,0.457-5.502 c0.254-0.985,0.997-1.76,1.938-2.022C10.107,8,16,8,16,8s5.896,0,7.605,0.476C24.55,8.742,25.292,9.516,25.543,10.498L25.543,10.498 z M14,19.5l6-3.5l-6-3.5V19.5z"${_scopeId}></path></svg>`);
          } else {
            return [
              (openBlock(), createBlock("svg", {
                xmlns: "http://www.w3.org/2000/svg",
                height: "28",
                width: "28",
                viewBox: "0 0 32 32",
                "enable-background": "new 0 0 32 32",
                "xml:space": "preserve"
              }, [
                createVNode("path", {
                  fill: "#FF0000",
                  d: "M16,0L16,0c8.837,0,16,7.163,16,16l0,0c0,8.837-7.163,16-16,16l0,0C7.163,32,0,24.837,0,16l0,0 C0,7.163,7.163,0,16,0z"
                }),
                createVNode("path", {
                  fill: "#FFFFFF",
                  d: "M25.543,10.498C26,12.28,26,16,26,16s0,3.72-0.457,5.502c-0.254,0.985-0.997,1.76-1.938,2.022 C21.896,24,16,24,16,24s-5.893,0-7.605-0.476c-0.945-0.266-1.687-1.04-1.938-2.022C6,19.72,6,16,6,16s0-3.72,0.457-5.502 c0.254-0.985,0.997-1.76,1.938-2.022C10.107,8,16,8,16,8s5.896,0,7.605,0.476C24.55,8.742,25.292,9.516,25.543,10.498L25.543,10.498 z M14,19.5l6-3.5l-6-3.5V19.5z"
                })
              ]))
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div><div class="today_date place-self-end flex gap-2"><div class="px-3 py-1 border cursor-pointer">\u0987\u09AA\u09C7\u09AA\u09BE\u09B0</div><div class="px-3 py-1 border cursor-pointer">English</div></div></div>`);
      _push(ssrRenderComponent(_component_HeaderDesktopSideMenu, { desktopMenuStatus: unref(desktopMenuStatus) }, null, _parent));
      _push(`</div></div></div>`);
    };
  }
};
const _sfc_setup$a = _sfc_main$a.setup;
_sfc_main$a.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Header/HeaderTop.vue");
  return _sfc_setup$a ? _sfc_setup$a(props, ctx) : void 0;
};
const __nuxt_component_4 = _sfc_main$a;
const _sfc_main$9 = {
  __name: "HeaderTopMenu",
  __ssrInlineRender: true,
  props: ["scrollDown"],
  async setup(__props) {
    let __temp, __restore;
    const headCatconfig = /* @__PURE__ */ useRuntimeConfig();
    const headCategory = useState(() => [], "$w3l9th4f4e");
    const { data: headCat } = ([__temp, __restore] = withAsyncContext(() => useFetch(`${headCatconfig.public.apiUrl}/api/headercat`, {
      method: "GET"
    }, "$hHs80Y1JCk")), __temp = await __temp, __restore(), __temp);
    headCategory.value = headCat;
    return (_ctx, _push, _parent, _attrs) => {
      const _component_NuxtLink = __nuxt_component_0$1;
      const _component_Icon = __nuxt_component_0$2;
      _push(`<div${ssrRenderAttrs(mergeProps({
        class: `${__props.scrollDown ? "fixed top-0 right-0 left-0 shadow-lg" : ""} hidden md:block shadow-lg shadow-gray-300 duration-300 bg-[#3375af]`
      }, _attrs))} data-v-4d516d5c><ul class="flex gap-0 justify-center text-[18px] text-white" data-v-4d516d5c><li data-v-4d516d5c>`);
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: "/",
        class: "py-2 px-3 block hover:bg-[#284f81] hover:border-b-2 hover:border-b-white border-b-2 border-b-transparent duration-500"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_Icon, {
              name: "material-symbols:house-rounded",
              class: "text-xl"
            }, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_Icon, {
                name: "material-symbols:house-rounded",
                class: "text-xl"
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</li><li data-v-4d516d5c>`);
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: `/collection/latest`,
        class: "py-2 px-3 block hover:bg-[#284f81] hover:border-b-2 hover:border-b-white border-b-2 border-b-transparent duration-500"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(` \u09B8\u09B0\u09CD\u09AC\u09B6\u09C7\u09B7`);
          } else {
            return [
              createTextVNode(" \u09B8\u09B0\u09CD\u09AC\u09B6\u09C7\u09B7")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</li><!--[-->`);
      ssrRenderList(unref(headCategory), (category) => {
        _push(`<li data-v-4d516d5c>`);
        _push(ssrRenderComponent(_component_NuxtLink, {
          to: `/${category.cat_slug}`,
          class: "py-2 px-3 block hover:bg-[#284f81] hover:border-b-2 hover:border-b-white border-b-2 border-b-transparent duration-500"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`${ssrInterpolate(category.cat_name_bn)}`);
            } else {
              return [
                createTextVNode(toDisplayString(category.cat_name_bn), 1)
              ];
            }
          }),
          _: 2
        }, _parent));
        _push(`</li>`);
      });
      _push(`<!--]--></ul></div>`);
    };
  }
};
const _sfc_setup$9 = _sfc_main$9.setup;
_sfc_main$9.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Header/HeaderTopMenu.vue");
  return _sfc_setup$9 ? _sfc_setup$9(props, ctx) : void 0;
};
const __nuxt_component_5 = /* @__PURE__ */ _export_sfc(_sfc_main$9, [["__scopeId", "data-v-4d516d5c"]]);
const _sfc_main$8 = {
  __name: "Dropdown",
  __ssrInlineRender: true,
  props: ["mobileMenuStatus"],
  setup(__props) {
    const getDate = new Intl.DateTimeFormat("bn-bd", { weekday: "long", year: "numeric", month: "long", day: "numeric" });
    const todayDate = getDate.format(/* @__PURE__ */ new Date());
    const allCats = allCategoryState();
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Icon = __nuxt_component_0$2;
      const _component_NuxtLink = __nuxt_component_0$1;
      _push(`<div${ssrRenderAttrs(mergeProps({
        class: `${__props.mobileMenuStatus ? "left-0 fixed" : "fixed -left-[815px]"} duration-200 bg-white max-w-full md:hidden right-0 top-12 z-[99999]`
      }, _attrs))}><div class="px-8 py-8 flex flex-col gap-4 overflow-y-scroll h-screen"><div class="todayDate text-sm">${ssrInterpolate(unref(todayDate))}</div><div class="flex items-center"><input type="text" placeholder="\u09AF\u09BE \u0996\u09C1\u0981\u099C\u09A4\u09C7 \u099A\u09BE\u09A8 \u09A4\u09BE \u09B2\u09BF\u0996\u09C1\u09A8" class="focus:outline-none border px-2 py-2 w-full"><div class="bg-gray-200 px-2 py-2 cursor-pointer">`);
      _push(ssrRenderComponent(_component_Icon, {
        class: "text-2xl",
        name: "tabler:search"
      }, null, _parent));
      _push(`</div></div><div class=""><div class="grid grid-cols-2 gap-2 font-[400]"><!--[-->`);
      ssrRenderList(unref(allCats), (cat, cindex) => {
        _push(ssrRenderComponent(_component_NuxtLink, {
          key: cindex,
          to: `/${cat == null ? void 0 : cat.cat_slug}`,
          class: "py-2 border-b"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`${ssrInterpolate(cat == null ? void 0 : cat.cat_name_bn)}`);
            } else {
              return [
                createTextVNode(toDisplayString(cat == null ? void 0 : cat.cat_name_bn), 1)
              ];
            }
          }),
          _: 2
        }, _parent));
      });
      _push(`<!--]-->`);
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: "/",
        class: "py-2 border-b"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`\u0987\u09AA\u09C7\u09AA\u09BE\u09B0`);
          } else {
            return [
              createTextVNode("\u0987\u09AA\u09C7\u09AA\u09BE\u09B0")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div><div class="social_media flex flex-col gap-2 mt-3 pb-12 px-8"><p class="text-xl text-center">\u0985\u09A8\u09C1\u09B8\u09B0\u09A3 \u0995\u09B0\u09C1\u09A8</p><div class="flex gap-6 justify-between items-center">`);
      _push(ssrRenderComponent(_component_NuxtLink, {
        target: "_blank",
        to: "https://www.facebook.com/dhakaprokash24"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<svg xmlns="http://www.w3.org/2000/svg" height="28" width="28" viewBox="0 0 32 32" enable-background="new 0 0 32 32" xml:space="preserve"${_scopeId}><path fill="#1877F2" d="M16,0L16,0c8.837,0,16,7.163,16,16l0,0c0,8.837-7.163,16-16,16l0,0C7.163,32,0,24.837,0,16l0,0 C0,7.163,7.163,0,16,0z"${_scopeId}></path><path fill="#FFFFFF" d="M18,17.5h2.5l1-4H18v-2c0-1.03,0-2,2-2h1.5V6.14C21.174,6.097,19.943,6,18.643,6C15.928,6,14,7.657,14,10.7 v2.8h-3v4h3V26h4V17.5z"${_scopeId}></path></svg>`);
          } else {
            return [
              (openBlock(), createBlock("svg", {
                xmlns: "http://www.w3.org/2000/svg",
                height: "28",
                width: "28",
                viewBox: "0 0 32 32",
                "enable-background": "new 0 0 32 32",
                "xml:space": "preserve"
              }, [
                createVNode("path", {
                  fill: "#1877F2",
                  d: "M16,0L16,0c8.837,0,16,7.163,16,16l0,0c0,8.837-7.163,16-16,16l0,0C7.163,32,0,24.837,0,16l0,0 C0,7.163,7.163,0,16,0z"
                }),
                createVNode("path", {
                  fill: "#FFFFFF",
                  d: "M18,17.5h2.5l1-4H18v-2c0-1.03,0-2,2-2h1.5V6.14C21.174,6.097,19.943,6,18.643,6C15.928,6,14,7.657,14,10.7 v2.8h-3v4h3V26h4V17.5z"
                })
              ]))
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_NuxtLink, {
        target: "_blank",
        to: "https://twitter.com/dhakaprokash24"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<svg xmlns="http://www.w3.org/2000/svg" height="28" width="28" viewBox="0 0 32 32" enable-background="new 0 0 32 32" xml:space="preserve"${_scopeId}><path fill="#1DA1F2" d="M16,0L16,0c8.837,0,16,7.163,16,16l0,0c0,8.837-7.163,16-16,16l0,0C7.163,32,0,24.837,0,16l0,0 C0,7.163,7.163,0,16,0z"${_scopeId}></path><path fill="#FFFFFF" d="M26.162,9.656c-0.764,0.338-1.573,0.56-2.402,0.658C24.634,9.791,25.288,8.969,25.6,8 c-0.82,0.488-1.719,0.83-2.656,1.015c-0.629-0.673-1.464-1.12-2.373-1.27c-0.909-0.15-1.843,0.004-2.656,0.439 c-0.813,0.435-1.459,1.126-1.838,1.966c-0.379,0.84-0.47,1.782-0.259,2.679c-1.663-0.083-3.29-0.516-4.775-1.268 c-1.485-0.753-2.795-1.81-3.845-3.102c-0.372,0.638-0.567,1.364-0.566,2.103c0,1.45,0.738,2.731,1.86,3.481 c-0.664-0.021-1.313-0.2-1.894-0.523v0.052c0,0.966,0.334,1.902,0.946,2.649c0.611,0.747,1.463,1.26,2.409,1.452 c-0.616,0.167-1.263,0.192-1.89,0.072c0.267,0.831,0.787,1.558,1.488,2.079c0.701,0.521,1.547,0.81,2.419,0.826 c-0.868,0.681-1.861,1.185-2.923,1.482c-1.062,0.297-2.173,0.382-3.268,0.25c1.912,1.229,4.137,1.882,6.41,1.88 c7.693,0,11.9-6.373,11.9-11.9c0-0.18-0.005-0.362-0.013-0.54c0.819-0.592,1.526-1.325,2.087-2.165L26.162,9.656z"${_scopeId}></path></svg>`);
          } else {
            return [
              (openBlock(), createBlock("svg", {
                xmlns: "http://www.w3.org/2000/svg",
                height: "28",
                width: "28",
                viewBox: "0 0 32 32",
                "enable-background": "new 0 0 32 32",
                "xml:space": "preserve"
              }, [
                createVNode("path", {
                  fill: "#1DA1F2",
                  d: "M16,0L16,0c8.837,0,16,7.163,16,16l0,0c0,8.837-7.163,16-16,16l0,0C7.163,32,0,24.837,0,16l0,0 C0,7.163,7.163,0,16,0z"
                }),
                createVNode("path", {
                  fill: "#FFFFFF",
                  d: "M26.162,9.656c-0.764,0.338-1.573,0.56-2.402,0.658C24.634,9.791,25.288,8.969,25.6,8 c-0.82,0.488-1.719,0.83-2.656,1.015c-0.629-0.673-1.464-1.12-2.373-1.27c-0.909-0.15-1.843,0.004-2.656,0.439 c-0.813,0.435-1.459,1.126-1.838,1.966c-0.379,0.84-0.47,1.782-0.259,2.679c-1.663-0.083-3.29-0.516-4.775-1.268 c-1.485-0.753-2.795-1.81-3.845-3.102c-0.372,0.638-0.567,1.364-0.566,2.103c0,1.45,0.738,2.731,1.86,3.481 c-0.664-0.021-1.313-0.2-1.894-0.523v0.052c0,0.966,0.334,1.902,0.946,2.649c0.611,0.747,1.463,1.26,2.409,1.452 c-0.616,0.167-1.263,0.192-1.89,0.072c0.267,0.831,0.787,1.558,1.488,2.079c0.701,0.521,1.547,0.81,2.419,0.826 c-0.868,0.681-1.861,1.185-2.923,1.482c-1.062,0.297-2.173,0.382-3.268,0.25c1.912,1.229,4.137,1.882,6.41,1.88 c7.693,0,11.9-6.373,11.9-11.9c0-0.18-0.005-0.362-0.013-0.54c0.819-0.592,1.526-1.325,2.087-2.165L26.162,9.656z"
                })
              ]))
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_NuxtLink, {
        target: "_blank",
        to: "https://www.instagram.com/dhakaprokash24/"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<svg height="28" width="28" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32" enable-background="new 0 0 32 32" xml:space="preserve"${_scopeId}><radialGradient id="SVGID_1_" cx="-246.536" cy="264.8975" r="1" gradientTransform="matrix(1.941947e-15 -31.7144 -29.4969 -1.806164e-15 7822.1538 -7784.2769)" gradientUnits="userSpaceOnUse"${_scopeId}><stop offset="0" style="${ssrRenderStyle({ "stop-color": "rgb(255, 221, 85)" })}"${_scopeId}></stop><stop offset="0.1" style="${ssrRenderStyle({ "stop-color": "rgb(255, 221, 85)" })}"${_scopeId}></stop><stop offset="0.5" style="${ssrRenderStyle({ "stop-color": "rgb(255, 84, 62)" })}"${_scopeId}></stop><stop offset="1" style="${ssrRenderStyle({ "stop-color": "rgb(200, 55, 171)" })}"${_scopeId}></stop></radialGradient><circle fill="url(#SVGID_1_)" cx="16" cy="16" r="16"${_scopeId}></circle><radialGradient id="SVGID_2_" cx="-219.16" cy="276.2076" r="1" gradientTransform="matrix(2.7825 13.9007 57.2992 -11.4697 -15222.0215 6216.8076)" gradientUnits="userSpaceOnUse"${_scopeId}><stop offset="0" style="${ssrRenderStyle({ "stop-color": "rgb(55, 113, 200)" })}"${_scopeId}></stop><stop offset="0.128" style="${ssrRenderStyle({ "stop-color": "rgb(55, 113, 200)" })}"${_scopeId}></stop><stop offset="1" style="${ssrRenderStyle({ "stop-color": "rgb(102, 0, 255)", "stop-opacity": "0" })}"${_scopeId}></stop></radialGradient><circle fill="url(#SVGID_2_)" cx="16" cy="16" r="16"${_scopeId}></circle><path fill="#FFFFFF" d="M16.001,6c-2.716,0-3.057,0.012-4.123,0.06c-1.065,0.049-1.791,0.217-2.427,0.465 C8.793,6.78,8.235,7.122,7.679,7.678C7.123,8.234,6.781,8.792,6.525,9.449c-0.248,0.636-0.417,1.363-0.465,2.427 C6.012,12.943,6,13.284,6,16s0.012,3.056,0.06,4.122c0.049,1.065,0.217,1.791,0.465,2.427c0.256,0.658,0.597,1.216,1.153,1.771 c0.556,0.556,1.114,0.899,1.771,1.154c0.636,0.247,1.363,0.416,2.428,0.465C12.943,25.988,13.284,26,16,26 c2.716,0,3.056-0.012,4.123-0.06c1.065-0.049,1.792-0.217,2.428-0.465c0.657-0.255,1.215-0.598,1.77-1.154 c0.556-0.556,0.898-1.114,1.154-1.771c0.246-0.636,0.415-1.363,0.465-2.427C25.987,19.056,26,18.716,26,16s-0.012-3.057-0.06-4.123 c-0.05-1.065-0.219-1.791-0.465-2.427c-0.256-0.658-0.598-1.216-1.154-1.771c-0.556-0.556-1.113-0.898-1.771-1.153 c-0.638-0.247-1.365-0.416-2.429-0.465C19.054,6.012,18.714,6,15.998,6H16.001z M15.104,7.802c0.266,0,0.563,0,0.897,0 c2.67,0,2.987,0.01,4.041,0.057c0.975,0.045,1.504,0.207,1.857,0.344c0.467,0.181,0.799,0.398,1.149,0.748 c0.35,0.35,0.567,0.683,0.748,1.15c0.137,0.352,0.3,0.881,0.344,1.856c0.048,1.054,0.058,1.371,0.058,4.04 c0,2.669-0.01,2.985-0.058,4.04c-0.045,0.975-0.208,1.504-0.344,1.856c-0.181,0.467-0.398,0.799-0.748,1.149 c-0.35,0.35-0.682,0.567-1.149,0.748c-0.352,0.138-0.882,0.3-1.857,0.345c-1.054,0.048-1.371,0.058-4.041,0.058 c-2.67,0-2.987-0.01-4.041-0.058c-0.975-0.045-1.504-0.208-1.857-0.345c-0.467-0.181-0.8-0.398-1.15-0.748 c-0.35-0.35-0.567-0.683-0.748-1.149c-0.137-0.352-0.3-0.881-0.344-1.856c-0.048-1.054-0.058-1.371-0.058-4.041 s0.01-2.985,0.058-4.04c0.045-0.975,0.207-1.504,0.344-1.857c0.181-0.467,0.398-0.8,0.748-1.15c0.35-0.35,0.683-0.567,1.15-0.748 c0.352-0.137,0.882-0.3,1.857-0.345c0.922-0.042,1.28-0.054,3.144-0.056V7.802z M21.339,9.462c-0.662,0-1.2,0.537-1.2,1.2 c0,0.663,0.538,1.2,1.2,1.2c0.663,0,1.2-0.537,1.2-1.2C22.539,10,22.001,9.462,21.339,9.462L21.339,9.462z M16.001,10.865 c-2.836,0-5.135,2.299-5.135,5.135s2.299,5.134,5.135,5.134c2.836,0,5.135-2.298,5.135-5.134S18.837,10.865,16.001,10.865 L16.001,10.865z M16.001,12.667c1.841,0,3.333,1.492,3.333,3.333c0,1.841-1.493,3.333-3.333,3.333c-1.841,0-3.333-1.493-3.333-3.333 C12.667,14.159,14.16,12.667,16.001,12.667L16.001,12.667z"${_scopeId}></path></svg>`);
          } else {
            return [
              (openBlock(), createBlock("svg", {
                height: "28",
                width: "28",
                xmlns: "http://www.w3.org/2000/svg",
                viewBox: "0 0 32 32",
                "enable-background": "new 0 0 32 32",
                "xml:space": "preserve"
              }, [
                createVNode("radialGradient", {
                  id: "SVGID_1_",
                  cx: "-246.536",
                  cy: "264.8975",
                  r: "1",
                  gradientTransform: "matrix(1.941947e-15 -31.7144 -29.4969 -1.806164e-15 7822.1538 -7784.2769)",
                  gradientUnits: "userSpaceOnUse"
                }, [
                  createVNode("stop", {
                    offset: "0",
                    style: { "stop-color": "rgb(255, 221, 85)" }
                  }),
                  createVNode("stop", {
                    offset: "0.1",
                    style: { "stop-color": "rgb(255, 221, 85)" }
                  }),
                  createVNode("stop", {
                    offset: "0.5",
                    style: { "stop-color": "rgb(255, 84, 62)" }
                  }),
                  createVNode("stop", {
                    offset: "1",
                    style: { "stop-color": "rgb(200, 55, 171)" }
                  })
                ]),
                createVNode("circle", {
                  fill: "url(#SVGID_1_)",
                  cx: "16",
                  cy: "16",
                  r: "16"
                }),
                createVNode("radialGradient", {
                  id: "SVGID_2_",
                  cx: "-219.16",
                  cy: "276.2076",
                  r: "1",
                  gradientTransform: "matrix(2.7825 13.9007 57.2992 -11.4697 -15222.0215 6216.8076)",
                  gradientUnits: "userSpaceOnUse"
                }, [
                  createVNode("stop", {
                    offset: "0",
                    style: { "stop-color": "rgb(55, 113, 200)" }
                  }),
                  createVNode("stop", {
                    offset: "0.128",
                    style: { "stop-color": "rgb(55, 113, 200)" }
                  }),
                  createVNode("stop", {
                    offset: "1",
                    style: { "stop-color": "rgb(102, 0, 255)", "stop-opacity": "0" }
                  })
                ]),
                createVNode("circle", {
                  fill: "url(#SVGID_2_)",
                  cx: "16",
                  cy: "16",
                  r: "16"
                }),
                createVNode("path", {
                  fill: "#FFFFFF",
                  d: "M16.001,6c-2.716,0-3.057,0.012-4.123,0.06c-1.065,0.049-1.791,0.217-2.427,0.465 C8.793,6.78,8.235,7.122,7.679,7.678C7.123,8.234,6.781,8.792,6.525,9.449c-0.248,0.636-0.417,1.363-0.465,2.427 C6.012,12.943,6,13.284,6,16s0.012,3.056,0.06,4.122c0.049,1.065,0.217,1.791,0.465,2.427c0.256,0.658,0.597,1.216,1.153,1.771 c0.556,0.556,1.114,0.899,1.771,1.154c0.636,0.247,1.363,0.416,2.428,0.465C12.943,25.988,13.284,26,16,26 c2.716,0,3.056-0.012,4.123-0.06c1.065-0.049,1.792-0.217,2.428-0.465c0.657-0.255,1.215-0.598,1.77-1.154 c0.556-0.556,0.898-1.114,1.154-1.771c0.246-0.636,0.415-1.363,0.465-2.427C25.987,19.056,26,18.716,26,16s-0.012-3.057-0.06-4.123 c-0.05-1.065-0.219-1.791-0.465-2.427c-0.256-0.658-0.598-1.216-1.154-1.771c-0.556-0.556-1.113-0.898-1.771-1.153 c-0.638-0.247-1.365-0.416-2.429-0.465C19.054,6.012,18.714,6,15.998,6H16.001z M15.104,7.802c0.266,0,0.563,0,0.897,0 c2.67,0,2.987,0.01,4.041,0.057c0.975,0.045,1.504,0.207,1.857,0.344c0.467,0.181,0.799,0.398,1.149,0.748 c0.35,0.35,0.567,0.683,0.748,1.15c0.137,0.352,0.3,0.881,0.344,1.856c0.048,1.054,0.058,1.371,0.058,4.04 c0,2.669-0.01,2.985-0.058,4.04c-0.045,0.975-0.208,1.504-0.344,1.856c-0.181,0.467-0.398,0.799-0.748,1.149 c-0.35,0.35-0.682,0.567-1.149,0.748c-0.352,0.138-0.882,0.3-1.857,0.345c-1.054,0.048-1.371,0.058-4.041,0.058 c-2.67,0-2.987-0.01-4.041-0.058c-0.975-0.045-1.504-0.208-1.857-0.345c-0.467-0.181-0.8-0.398-1.15-0.748 c-0.35-0.35-0.567-0.683-0.748-1.149c-0.137-0.352-0.3-0.881-0.344-1.856c-0.048-1.054-0.058-1.371-0.058-4.041 s0.01-2.985,0.058-4.04c0.045-0.975,0.207-1.504,0.344-1.857c0.181-0.467,0.398-0.8,0.748-1.15c0.35-0.35,0.683-0.567,1.15-0.748 c0.352-0.137,0.882-0.3,1.857-0.345c0.922-0.042,1.28-0.054,3.144-0.056V7.802z M21.339,9.462c-0.662,0-1.2,0.537-1.2,1.2 c0,0.663,0.538,1.2,1.2,1.2c0.663,0,1.2-0.537,1.2-1.2C22.539,10,22.001,9.462,21.339,9.462L21.339,9.462z M16.001,10.865 c-2.836,0-5.135,2.299-5.135,5.135s2.299,5.134,5.135,5.134c2.836,0,5.135-2.298,5.135-5.134S18.837,10.865,16.001,10.865 L16.001,10.865z M16.001,12.667c1.841,0,3.333,1.492,3.333,3.333c0,1.841-1.493,3.333-3.333,3.333c-1.841,0-3.333-1.493-3.333-3.333 C12.667,14.159,14.16,12.667,16.001,12.667L16.001,12.667z"
                })
              ]))
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_NuxtLink, {
        target: "_blank",
        to: "https://www.youtube.com/DhakaProkash"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<svg xmlns="http://www.w3.org/2000/svg" height="28" width="28" viewBox="0 0 32 32" enable-background="new 0 0 32 32" xml:space="preserve"${_scopeId}><path fill="#FF0000" d="M16,0L16,0c8.837,0,16,7.163,16,16l0,0c0,8.837-7.163,16-16,16l0,0C7.163,32,0,24.837,0,16l0,0 C0,7.163,7.163,0,16,0z"${_scopeId}></path><path fill="#FFFFFF" d="M25.543,10.498C26,12.28,26,16,26,16s0,3.72-0.457,5.502c-0.254,0.985-0.997,1.76-1.938,2.022 C21.896,24,16,24,16,24s-5.893,0-7.605-0.476c-0.945-0.266-1.687-1.04-1.938-2.022C6,19.72,6,16,6,16s0-3.72,0.457-5.502 c0.254-0.985,0.997-1.76,1.938-2.022C10.107,8,16,8,16,8s5.896,0,7.605,0.476C24.55,8.742,25.292,9.516,25.543,10.498L25.543,10.498 z M14,19.5l6-3.5l-6-3.5V19.5z"${_scopeId}></path></svg>`);
          } else {
            return [
              (openBlock(), createBlock("svg", {
                xmlns: "http://www.w3.org/2000/svg",
                height: "28",
                width: "28",
                viewBox: "0 0 32 32",
                "enable-background": "new 0 0 32 32",
                "xml:space": "preserve"
              }, [
                createVNode("path", {
                  fill: "#FF0000",
                  d: "M16,0L16,0c8.837,0,16,7.163,16,16l0,0c0,8.837-7.163,16-16,16l0,0C7.163,32,0,24.837,0,16l0,0 C0,7.163,7.163,0,16,0z"
                }),
                createVNode("path", {
                  fill: "#FFFFFF",
                  d: "M25.543,10.498C26,12.28,26,16,26,16s0,3.72-0.457,5.502c-0.254,0.985-0.997,1.76-1.938,2.022 C21.896,24,16,24,16,24s-5.893,0-7.605-0.476c-0.945-0.266-1.687-1.04-1.938-2.022C6,19.72,6,16,6,16s0-3.72,0.457-5.502 c0.254-0.985,0.997-1.76,1.938-2.022C10.107,8,16,8,16,8s5.896,0,7.605,0.476C24.55,8.742,25.292,9.516,25.543,10.498L25.543,10.498 z M14,19.5l6-3.5l-6-3.5V19.5z"
                })
              ]))
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div></div></div>`);
    };
  }
};
const _sfc_setup$8 = _sfc_main$8.setup;
_sfc_main$8.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/MobileHeader/Dropdown.vue");
  return _sfc_setup$8 ? _sfc_setup$8(props, ctx) : void 0;
};
const __nuxt_component_3 = _sfc_main$8;
const _sfc_main$7 = {
  __name: "Top",
  __ssrInlineRender: true,
  setup(__props) {
    const mobileMenuStatus = ref(false);
    const mobileMenuToggle = () => {
      if (mobileMenuStatus.value === true) {
        mobileMenuStatus.value = false;
      } else {
        mobileMenuStatus.value = true;
      }
    };
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Icon = __nuxt_component_0$2;
      const _component_nuxt_img = __nuxt_component_1$1;
      const _component_NuxtLink = __nuxt_component_0$1;
      const _component_MobileHeaderDropdown = __nuxt_component_3;
      _push(`<div${ssrRenderAttrs(_attrs)}><div class="flex justify-between items-center md:hidden shadow-md fixed bg-white top-0 left-0 right-0 px-2 z-[999999]"><div class="flex gap-6 px-2 py-2 items-center justify-center">`);
      if (!unref(mobileMenuStatus)) {
        _push(ssrRenderComponent(_component_Icon, {
          onClick: mobileMenuToggle,
          class: "text-3xl cursor-pointer hover:bg-[#f7f7f7]",
          name: "ic:outline-menu"
        }, null, _parent));
      } else {
        _push(ssrRenderComponent(_component_Icon, {
          name: "material-symbols:close",
          onClick: mobileMenuToggle,
          class: "text-3xl cursor-pointer hover:bg-[#f7f7f7]"
        }, null, _parent));
      }
      _push(ssrRenderComponent(_component_nuxt_img, {
        class: "mx-auto",
        src: "https://www.dhakaprokash24.com/media/common/logo1672518180.png",
        alt: "Dhaka Prokash"
      }, null, _parent));
      _push(`</div><div class="flex gap-3 px-2">`);
      _push(ssrRenderComponent(_component_NuxtLink, {
        class: "border px-2 font-semibold text-blue-700",
        to: "/"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`EN`);
          } else {
            return [
              createTextVNode("EN")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: "/",
        class: "border px-2 font-semibold text-blue-700"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`E-P`);
          } else {
            return [
              createTextVNode("E-P")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div>`);
      _push(ssrRenderComponent(_component_MobileHeaderDropdown, { mobileMenuStatus: unref(mobileMenuStatus) }, null, _parent));
      _push(`</div>`);
    };
  }
};
const _sfc_setup$7 = _sfc_main$7.setup;
_sfc_main$7.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/MobileHeader/Top.vue");
  return _sfc_setup$7 ? _sfc_setup$7(props, ctx) : void 0;
};
const __nuxt_component_6 = _sfc_main$7;
const _sfc_main$6 = {
  __name: "Top",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    const siteConfig = /* @__PURE__ */ useRuntimeConfig();
    const siteSettings = useState(() => [], "$H6dhprm0ng");
    const { data: siteset } = ([__temp, __restore] = withAsyncContext(() => useFetch(`${siteConfig.public.apiUrl}/api/site-setting`, {
      method: "GET"
    }, "$ALorPAjnYT")), __temp = await __temp, __restore(), __temp);
    siteSettings.value = siteset;
    return (_ctx, _push, _parent, _attrs) => {
      const _component_NuxtLink = __nuxt_component_0$1;
      const _component_nuxt_img = __nuxt_component_1$1;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "footerTop grid grid-cols-1 place-items-center md:place-items-start gap-6 md:gap-0 md:flex md:justify-between pb-8" }, _attrs))}><div class="flex flex-col gap-3 text-center md:text-left">`);
      _push(ssrRenderComponent(_component_NuxtLink, { to: "/" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_nuxt_img, {
              class: "mx-auto md:mx-0",
              src: `${unref(siteConfig).public.apiUrl}/media/common/${unref(siteSettings).logo}`,
              width: "220",
              alt: "Dhaka Prokash"
            }, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_nuxt_img, {
                class: "mx-auto md:mx-0",
                src: `${unref(siteConfig).public.apiUrl}/media/common/${unref(siteSettings).logo}`,
                width: "220",
                alt: "Dhaka Prokash"
              }, null, 8, ["src"])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<p class="text-[16px] text-[#2a2a2a]">\u09EF\u09E9, \u0995\u09BE\u099C\u09C0 \u09A8\u099C\u09B0\u09C1\u09B2 \u0987\u09B8\u09B2\u09BE\u09AE \u098F\u09AD\u09BF\u09A8\u09BF\u0989, (\u09B7\u09B7\u09CD\u09A0 \u09A4\u09B2\u09BE)<br>\u0995\u09BE\u09B0\u0993\u09DF\u09BE\u09A8 \u09AC\u09BE\u099C\u09BE\u09B0, \u09A2\u09BE\u0995\u09BE-\u09E7\u09E8\u09E7\u09EB\u0964</p></div><div class="flex flex-col gap-4 text-center md:text-left"><div class="flex flex-col gap-0"><h6 class="text-[#00427A] text-[24px]">\u09A8\u09BF\u0989\u099C\u09B0\u09C1\u09AE</h6>`);
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: "tel:+8809613331010",
        class: "hover:text-[#ff0000] text-[#2a2a2a]"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`+\u09EE\u09EE\u09E6 \u09EF\u09EC\u09E7 \u09E9\u09E9\u09E9 \u09E7\u09E6\u09E7\u09E6`);
          } else {
            return [
              createTextVNode("+\u09EE\u09EE\u09E6 \u09EF\u09EC\u09E7 \u09E9\u09E9\u09E9 \u09E7\u09E6\u09E7\u09E6")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: "mailto:newsroom@dhakaprokash24.com",
        class: "hover:text-[#ff0000] text-[#2a2a2a]"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(` newsroom@dhakaprokash24.com`);
          } else {
            return [
              createTextVNode(" newsroom@dhakaprokash24.com")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div><div class="flex flex-col gap-0"><h6 class="text-[#00427A] text-[24px]">\u09AE\u09BE\u09B0\u09CD\u0995\u09C7\u099F\u09BF\u0982</h6>`);
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: "tel:+8809613332020",
        class: "hover:text-[#ff0000] text-[#2a2a2a]"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`+\u09EE\u09EE\u09E6 \u09EF\u09EC\u09E7 \u09E9\u09E9\u09E9 \u09E8\u09E6\u09E8\u09E6`);
          } else {
            return [
              createTextVNode("+\u09EE\u09EE\u09E6 \u09EF\u09EC\u09E7 \u09E9\u09E9\u09E9 \u09E8\u09E6\u09E8\u09E6")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: "mailto:marketking@dhakaprokash24.com",
        class: "hover:text-[#ff0000] text-[#2a2a2a]"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`marketking@dhakaprokash24.com`);
          } else {
            return [
              createTextVNode("marketking@dhakaprokash24.com")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div><div>`);
      _push(ssrRenderComponent(_component_nuxt_img, {
        src: `${unref(siteConfig).public.apiUrl}/media/common/contact-barcode.png`,
        width: "220",
        alt: "Dhaka Prokash"
      }, null, _parent));
      _push(`</div></div>`);
    };
  }
};
const _sfc_setup$6 = _sfc_main$6.setup;
_sfc_main$6.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Footer/Top.vue");
  return _sfc_setup$6 ? _sfc_setup$6(props, ctx) : void 0;
};
const __nuxt_component_0 = _sfc_main$6;
const _sfc_main$5 = {};
function _sfc_ssrRender$2(_ctx, _push, _parent, _attrs) {
  const _component_NuxtLink = __nuxt_component_0$1;
  _push(`<div${ssrRenderAttrs(mergeProps({ class: "border-t py-6 flex md:flex-row flex-col gap-5 md:gap-0 justify-between" }, _attrs))}><div class="social_media flex flex-col gap-2"><p class="text-center text-sm">\u0985\u09A8\u09C1\u09B8\u09B0\u09A3 \u0995\u09B0\u09C1\u09A8</p><div class="flex gap-6 justify-center">`);
  _push(ssrRenderComponent(_component_NuxtLink, {
    target: "_blank",
    to: "https://www.facebook.com/dhakaprokash24"
  }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`<svg xmlns="http://www.w3.org/2000/svg" height="28" width="28" viewBox="0 0 32 32" enable-background="new 0 0 32 32" xml:space="preserve"${_scopeId}><path fill="#1877F2" d="M16,0L16,0c8.837,0,16,7.163,16,16l0,0c0,8.837-7.163,16-16,16l0,0C7.163,32,0,24.837,0,16l0,0 C0,7.163,7.163,0,16,0z"${_scopeId}></path><path fill="#FFFFFF" d="M18,17.5h2.5l1-4H18v-2c0-1.03,0-2,2-2h1.5V6.14C21.174,6.097,19.943,6,18.643,6C15.928,6,14,7.657,14,10.7 v2.8h-3v4h3V26h4V17.5z"${_scopeId}></path></svg>`);
      } else {
        return [
          (openBlock(), createBlock("svg", {
            xmlns: "http://www.w3.org/2000/svg",
            height: "28",
            width: "28",
            viewBox: "0 0 32 32",
            "enable-background": "new 0 0 32 32",
            "xml:space": "preserve"
          }, [
            createVNode("path", {
              fill: "#1877F2",
              d: "M16,0L16,0c8.837,0,16,7.163,16,16l0,0c0,8.837-7.163,16-16,16l0,0C7.163,32,0,24.837,0,16l0,0 C0,7.163,7.163,0,16,0z"
            }),
            createVNode("path", {
              fill: "#FFFFFF",
              d: "M18,17.5h2.5l1-4H18v-2c0-1.03,0-2,2-2h1.5V6.14C21.174,6.097,19.943,6,18.643,6C15.928,6,14,7.657,14,10.7 v2.8h-3v4h3V26h4V17.5z"
            })
          ]))
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(ssrRenderComponent(_component_NuxtLink, {
    target: "_blank",
    to: "https://twitter.com/dhakaprokash24"
  }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`<svg xmlns="http://www.w3.org/2000/svg" height="28" width="28" viewBox="0 0 32 32" enable-background="new 0 0 32 32" xml:space="preserve"${_scopeId}><path fill="#1DA1F2" d="M16,0L16,0c8.837,0,16,7.163,16,16l0,0c0,8.837-7.163,16-16,16l0,0C7.163,32,0,24.837,0,16l0,0 C0,7.163,7.163,0,16,0z"${_scopeId}></path><path fill="#FFFFFF" d="M26.162,9.656c-0.764,0.338-1.573,0.56-2.402,0.658C24.634,9.791,25.288,8.969,25.6,8 c-0.82,0.488-1.719,0.83-2.656,1.015c-0.629-0.673-1.464-1.12-2.373-1.27c-0.909-0.15-1.843,0.004-2.656,0.439 c-0.813,0.435-1.459,1.126-1.838,1.966c-0.379,0.84-0.47,1.782-0.259,2.679c-1.663-0.083-3.29-0.516-4.775-1.268 c-1.485-0.753-2.795-1.81-3.845-3.102c-0.372,0.638-0.567,1.364-0.566,2.103c0,1.45,0.738,2.731,1.86,3.481 c-0.664-0.021-1.313-0.2-1.894-0.523v0.052c0,0.966,0.334,1.902,0.946,2.649c0.611,0.747,1.463,1.26,2.409,1.452 c-0.616,0.167-1.263,0.192-1.89,0.072c0.267,0.831,0.787,1.558,1.488,2.079c0.701,0.521,1.547,0.81,2.419,0.826 c-0.868,0.681-1.861,1.185-2.923,1.482c-1.062,0.297-2.173,0.382-3.268,0.25c1.912,1.229,4.137,1.882,6.41,1.88 c7.693,0,11.9-6.373,11.9-11.9c0-0.18-0.005-0.362-0.013-0.54c0.819-0.592,1.526-1.325,2.087-2.165L26.162,9.656z"${_scopeId}></path></svg>`);
      } else {
        return [
          (openBlock(), createBlock("svg", {
            xmlns: "http://www.w3.org/2000/svg",
            height: "28",
            width: "28",
            viewBox: "0 0 32 32",
            "enable-background": "new 0 0 32 32",
            "xml:space": "preserve"
          }, [
            createVNode("path", {
              fill: "#1DA1F2",
              d: "M16,0L16,0c8.837,0,16,7.163,16,16l0,0c0,8.837-7.163,16-16,16l0,0C7.163,32,0,24.837,0,16l0,0 C0,7.163,7.163,0,16,0z"
            }),
            createVNode("path", {
              fill: "#FFFFFF",
              d: "M26.162,9.656c-0.764,0.338-1.573,0.56-2.402,0.658C24.634,9.791,25.288,8.969,25.6,8 c-0.82,0.488-1.719,0.83-2.656,1.015c-0.629-0.673-1.464-1.12-2.373-1.27c-0.909-0.15-1.843,0.004-2.656,0.439 c-0.813,0.435-1.459,1.126-1.838,1.966c-0.379,0.84-0.47,1.782-0.259,2.679c-1.663-0.083-3.29-0.516-4.775-1.268 c-1.485-0.753-2.795-1.81-3.845-3.102c-0.372,0.638-0.567,1.364-0.566,2.103c0,1.45,0.738,2.731,1.86,3.481 c-0.664-0.021-1.313-0.2-1.894-0.523v0.052c0,0.966,0.334,1.902,0.946,2.649c0.611,0.747,1.463,1.26,2.409,1.452 c-0.616,0.167-1.263,0.192-1.89,0.072c0.267,0.831,0.787,1.558,1.488,2.079c0.701,0.521,1.547,0.81,2.419,0.826 c-0.868,0.681-1.861,1.185-2.923,1.482c-1.062,0.297-2.173,0.382-3.268,0.25c1.912,1.229,4.137,1.882,6.41,1.88 c7.693,0,11.9-6.373,11.9-11.9c0-0.18-0.005-0.362-0.013-0.54c0.819-0.592,1.526-1.325,2.087-2.165L26.162,9.656z"
            })
          ]))
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(ssrRenderComponent(_component_NuxtLink, {
    target: "_blank",
    to: "https://www.instagram.com/dhakaprokash24/"
  }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`<svg height="28" width="28" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32" enable-background="new 0 0 32 32" xml:space="preserve"${_scopeId}><radialGradient id="SVGID_1_" cx="-246.536" cy="264.8975" r="1" gradientTransform="matrix(1.941947e-15 -31.7144 -29.4969 -1.806164e-15 7822.1538 -7784.2769)" gradientUnits="userSpaceOnUse"${_scopeId}><stop offset="0" style="${ssrRenderStyle({ "stop-color": "rgb(255, 221, 85)" })}"${_scopeId}></stop><stop offset="0.1" style="${ssrRenderStyle({ "stop-color": "rgb(255, 221, 85)" })}"${_scopeId}></stop><stop offset="0.5" style="${ssrRenderStyle({ "stop-color": "rgb(255, 84, 62)" })}"${_scopeId}></stop><stop offset="1" style="${ssrRenderStyle({ "stop-color": "rgb(200, 55, 171)" })}"${_scopeId}></stop></radialGradient><circle fill="url(#SVGID_1_)" cx="16" cy="16" r="16"${_scopeId}></circle><radialGradient id="SVGID_2_" cx="-219.16" cy="276.2076" r="1" gradientTransform="matrix(2.7825 13.9007 57.2992 -11.4697 -15222.0215 6216.8076)" gradientUnits="userSpaceOnUse"${_scopeId}><stop offset="0" style="${ssrRenderStyle({ "stop-color": "rgb(55, 113, 200)" })}"${_scopeId}></stop><stop offset="0.128" style="${ssrRenderStyle({ "stop-color": "rgb(55, 113, 200)" })}"${_scopeId}></stop><stop offset="1" style="${ssrRenderStyle({ "stop-color": "rgb(102, 0, 255)", "stop-opacity": "0" })}"${_scopeId}></stop></radialGradient><circle fill="url(#SVGID_2_)" cx="16" cy="16" r="16"${_scopeId}></circle><path fill="#FFFFFF" d="M16.001,6c-2.716,0-3.057,0.012-4.123,0.06c-1.065,0.049-1.791,0.217-2.427,0.465 C8.793,6.78,8.235,7.122,7.679,7.678C7.123,8.234,6.781,8.792,6.525,9.449c-0.248,0.636-0.417,1.363-0.465,2.427 C6.012,12.943,6,13.284,6,16s0.012,3.056,0.06,4.122c0.049,1.065,0.217,1.791,0.465,2.427c0.256,0.658,0.597,1.216,1.153,1.771 c0.556,0.556,1.114,0.899,1.771,1.154c0.636,0.247,1.363,0.416,2.428,0.465C12.943,25.988,13.284,26,16,26 c2.716,0,3.056-0.012,4.123-0.06c1.065-0.049,1.792-0.217,2.428-0.465c0.657-0.255,1.215-0.598,1.77-1.154 c0.556-0.556,0.898-1.114,1.154-1.771c0.246-0.636,0.415-1.363,0.465-2.427C25.987,19.056,26,18.716,26,16s-0.012-3.057-0.06-4.123 c-0.05-1.065-0.219-1.791-0.465-2.427c-0.256-0.658-0.598-1.216-1.154-1.771c-0.556-0.556-1.113-0.898-1.771-1.153 c-0.638-0.247-1.365-0.416-2.429-0.465C19.054,6.012,18.714,6,15.998,6H16.001z M15.104,7.802c0.266,0,0.563,0,0.897,0 c2.67,0,2.987,0.01,4.041,0.057c0.975,0.045,1.504,0.207,1.857,0.344c0.467,0.181,0.799,0.398,1.149,0.748 c0.35,0.35,0.567,0.683,0.748,1.15c0.137,0.352,0.3,0.881,0.344,1.856c0.048,1.054,0.058,1.371,0.058,4.04 c0,2.669-0.01,2.985-0.058,4.04c-0.045,0.975-0.208,1.504-0.344,1.856c-0.181,0.467-0.398,0.799-0.748,1.149 c-0.35,0.35-0.682,0.567-1.149,0.748c-0.352,0.138-0.882,0.3-1.857,0.345c-1.054,0.048-1.371,0.058-4.041,0.058 c-2.67,0-2.987-0.01-4.041-0.058c-0.975-0.045-1.504-0.208-1.857-0.345c-0.467-0.181-0.8-0.398-1.15-0.748 c-0.35-0.35-0.567-0.683-0.748-1.149c-0.137-0.352-0.3-0.881-0.344-1.856c-0.048-1.054-0.058-1.371-0.058-4.041 s0.01-2.985,0.058-4.04c0.045-0.975,0.207-1.504,0.344-1.857c0.181-0.467,0.398-0.8,0.748-1.15c0.35-0.35,0.683-0.567,1.15-0.748 c0.352-0.137,0.882-0.3,1.857-0.345c0.922-0.042,1.28-0.054,3.144-0.056V7.802z M21.339,9.462c-0.662,0-1.2,0.537-1.2,1.2 c0,0.663,0.538,1.2,1.2,1.2c0.663,0,1.2-0.537,1.2-1.2C22.539,10,22.001,9.462,21.339,9.462L21.339,9.462z M16.001,10.865 c-2.836,0-5.135,2.299-5.135,5.135s2.299,5.134,5.135,5.134c2.836,0,5.135-2.298,5.135-5.134S18.837,10.865,16.001,10.865 L16.001,10.865z M16.001,12.667c1.841,0,3.333,1.492,3.333,3.333c0,1.841-1.493,3.333-3.333,3.333c-1.841,0-3.333-1.493-3.333-3.333 C12.667,14.159,14.16,12.667,16.001,12.667L16.001,12.667z"${_scopeId}></path></svg>`);
      } else {
        return [
          (openBlock(), createBlock("svg", {
            height: "28",
            width: "28",
            xmlns: "http://www.w3.org/2000/svg",
            viewBox: "0 0 32 32",
            "enable-background": "new 0 0 32 32",
            "xml:space": "preserve"
          }, [
            createVNode("radialGradient", {
              id: "SVGID_1_",
              cx: "-246.536",
              cy: "264.8975",
              r: "1",
              gradientTransform: "matrix(1.941947e-15 -31.7144 -29.4969 -1.806164e-15 7822.1538 -7784.2769)",
              gradientUnits: "userSpaceOnUse"
            }, [
              createVNode("stop", {
                offset: "0",
                style: { "stop-color": "rgb(255, 221, 85)" }
              }),
              createVNode("stop", {
                offset: "0.1",
                style: { "stop-color": "rgb(255, 221, 85)" }
              }),
              createVNode("stop", {
                offset: "0.5",
                style: { "stop-color": "rgb(255, 84, 62)" }
              }),
              createVNode("stop", {
                offset: "1",
                style: { "stop-color": "rgb(200, 55, 171)" }
              })
            ]),
            createVNode("circle", {
              fill: "url(#SVGID_1_)",
              cx: "16",
              cy: "16",
              r: "16"
            }),
            createVNode("radialGradient", {
              id: "SVGID_2_",
              cx: "-219.16",
              cy: "276.2076",
              r: "1",
              gradientTransform: "matrix(2.7825 13.9007 57.2992 -11.4697 -15222.0215 6216.8076)",
              gradientUnits: "userSpaceOnUse"
            }, [
              createVNode("stop", {
                offset: "0",
                style: { "stop-color": "rgb(55, 113, 200)" }
              }),
              createVNode("stop", {
                offset: "0.128",
                style: { "stop-color": "rgb(55, 113, 200)" }
              }),
              createVNode("stop", {
                offset: "1",
                style: { "stop-color": "rgb(102, 0, 255)", "stop-opacity": "0" }
              })
            ]),
            createVNode("circle", {
              fill: "url(#SVGID_2_)",
              cx: "16",
              cy: "16",
              r: "16"
            }),
            createVNode("path", {
              fill: "#FFFFFF",
              d: "M16.001,6c-2.716,0-3.057,0.012-4.123,0.06c-1.065,0.049-1.791,0.217-2.427,0.465 C8.793,6.78,8.235,7.122,7.679,7.678C7.123,8.234,6.781,8.792,6.525,9.449c-0.248,0.636-0.417,1.363-0.465,2.427 C6.012,12.943,6,13.284,6,16s0.012,3.056,0.06,4.122c0.049,1.065,0.217,1.791,0.465,2.427c0.256,0.658,0.597,1.216,1.153,1.771 c0.556,0.556,1.114,0.899,1.771,1.154c0.636,0.247,1.363,0.416,2.428,0.465C12.943,25.988,13.284,26,16,26 c2.716,0,3.056-0.012,4.123-0.06c1.065-0.049,1.792-0.217,2.428-0.465c0.657-0.255,1.215-0.598,1.77-1.154 c0.556-0.556,0.898-1.114,1.154-1.771c0.246-0.636,0.415-1.363,0.465-2.427C25.987,19.056,26,18.716,26,16s-0.012-3.057-0.06-4.123 c-0.05-1.065-0.219-1.791-0.465-2.427c-0.256-0.658-0.598-1.216-1.154-1.771c-0.556-0.556-1.113-0.898-1.771-1.153 c-0.638-0.247-1.365-0.416-2.429-0.465C19.054,6.012,18.714,6,15.998,6H16.001z M15.104,7.802c0.266,0,0.563,0,0.897,0 c2.67,0,2.987,0.01,4.041,0.057c0.975,0.045,1.504,0.207,1.857,0.344c0.467,0.181,0.799,0.398,1.149,0.748 c0.35,0.35,0.567,0.683,0.748,1.15c0.137,0.352,0.3,0.881,0.344,1.856c0.048,1.054,0.058,1.371,0.058,4.04 c0,2.669-0.01,2.985-0.058,4.04c-0.045,0.975-0.208,1.504-0.344,1.856c-0.181,0.467-0.398,0.799-0.748,1.149 c-0.35,0.35-0.682,0.567-1.149,0.748c-0.352,0.138-0.882,0.3-1.857,0.345c-1.054,0.048-1.371,0.058-4.041,0.058 c-2.67,0-2.987-0.01-4.041-0.058c-0.975-0.045-1.504-0.208-1.857-0.345c-0.467-0.181-0.8-0.398-1.15-0.748 c-0.35-0.35-0.567-0.683-0.748-1.149c-0.137-0.352-0.3-0.881-0.344-1.856c-0.048-1.054-0.058-1.371-0.058-4.041 s0.01-2.985,0.058-4.04c0.045-0.975,0.207-1.504,0.344-1.857c0.181-0.467,0.398-0.8,0.748-1.15c0.35-0.35,0.683-0.567,1.15-0.748 c0.352-0.137,0.882-0.3,1.857-0.345c0.922-0.042,1.28-0.054,3.144-0.056V7.802z M21.339,9.462c-0.662,0-1.2,0.537-1.2,1.2 c0,0.663,0.538,1.2,1.2,1.2c0.663,0,1.2-0.537,1.2-1.2C22.539,10,22.001,9.462,21.339,9.462L21.339,9.462z M16.001,10.865 c-2.836,0-5.135,2.299-5.135,5.135s2.299,5.134,5.135,5.134c2.836,0,5.135-2.298,5.135-5.134S18.837,10.865,16.001,10.865 L16.001,10.865z M16.001,12.667c1.841,0,3.333,1.492,3.333,3.333c0,1.841-1.493,3.333-3.333,3.333c-1.841,0-3.333-1.493-3.333-3.333 C12.667,14.159,14.16,12.667,16.001,12.667L16.001,12.667z"
            })
          ]))
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(ssrRenderComponent(_component_NuxtLink, {
    target: "_blank",
    to: "https://www.youtube.com/DhakaProkash"
  }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`<svg xmlns="http://www.w3.org/2000/svg" height="28" width="28" viewBox="0 0 32 32" enable-background="new 0 0 32 32" xml:space="preserve"${_scopeId}><path fill="#FF0000" d="M16,0L16,0c8.837,0,16,7.163,16,16l0,0c0,8.837-7.163,16-16,16l0,0C7.163,32,0,24.837,0,16l0,0 C0,7.163,7.163,0,16,0z"${_scopeId}></path><path fill="#FFFFFF" d="M25.543,10.498C26,12.28,26,16,26,16s0,3.72-0.457,5.502c-0.254,0.985-0.997,1.76-1.938,2.022 C21.896,24,16,24,16,24s-5.893,0-7.605-0.476c-0.945-0.266-1.687-1.04-1.938-2.022C6,19.72,6,16,6,16s0-3.72,0.457-5.502 c0.254-0.985,0.997-1.76,1.938-2.022C10.107,8,16,8,16,8s5.896,0,7.605,0.476C24.55,8.742,25.292,9.516,25.543,10.498L25.543,10.498 z M14,19.5l6-3.5l-6-3.5V19.5z"${_scopeId}></path></svg>`);
      } else {
        return [
          (openBlock(), createBlock("svg", {
            xmlns: "http://www.w3.org/2000/svg",
            height: "28",
            width: "28",
            viewBox: "0 0 32 32",
            "enable-background": "new 0 0 32 32",
            "xml:space": "preserve"
          }, [
            createVNode("path", {
              fill: "#FF0000",
              d: "M16,0L16,0c8.837,0,16,7.163,16,16l0,0c0,8.837-7.163,16-16,16l0,0C7.163,32,0,24.837,0,16l0,0 C0,7.163,7.163,0,16,0z"
            }),
            createVNode("path", {
              fill: "#FFFFFF",
              d: "M25.543,10.498C26,12.28,26,16,26,16s0,3.72-0.457,5.502c-0.254,0.985-0.997,1.76-1.938,2.022 C21.896,24,16,24,16,24s-5.893,0-7.605-0.476c-0.945-0.266-1.687-1.04-1.938-2.022C6,19.72,6,16,6,16s0-3.72,0.457-5.502 c0.254-0.985,0.997-1.76,1.938-2.022C10.107,8,16,8,16,8s5.896,0,7.605,0.476C24.55,8.742,25.292,9.516,25.543,10.498L25.543,10.498 z M14,19.5l6-3.5l-6-3.5V19.5z"
            })
          ]))
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</div></div><div class="apps flex flex-col gap-2"><p class="text-center text-sm">\u09AE\u09CB\u09AC\u09BE\u0987\u09B2 \u0985\u09CD\u09AF\u09BE\u09AA\u09B8 \u09A1\u09BE\u0989\u09A8\u09B2\u09CB\u09A1 \u0995\u09B0\u09C1\u09A8</p><div class="flex gap-6 justify-center">`);
  _push(ssrRenderComponent(_component_NuxtLink, {
    to: "#",
    target: "_blank"
  }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`<svg xmlns="http://www.w3.org/2000/svg" width="140" height="40"${_scopeId}><g data-name="Group 4686" transform="translate(-410 -926.5)"${_scopeId}><rect width="140" height="40" data-name="Rectangle 60" rx="2" transform="translate(410 926.5)" fill="#222"${_scopeId}></rect><g data-name="Group 4523" fill="#ccc"${_scopeId}><g data-name="Group 2992"${_scopeId}><text data-name="Android app on" transform="translate(458.735 940.5)" font-size="8" font-family="ArialMT,Arial"${_scopeId}><tspan x="0" y="0"${_scopeId}>Android app on</tspan></text><text data-name="Google Play" transform="translate(458.735 955.5)" font-size="12" font-family="Arial-BoldMT,Arial" font-weight="700"${_scopeId}><tspan x="0" y="0"${_scopeId}>Google Play</tspan></text></g><path d="M446.889 946.07l-9.485-9.511 12.068 6.928-2.583 2.583zM434.928 936a1.671 1.671 0 00-.932 1.517v18.966a1.671 1.671 0 00.932 1.517l11.028-11zm18.274 9.7l-2.531-1.466-2.824 2.772 2.824 2.772 2.583-1.465a1.723 1.723 0 00-.052-2.613zm-15.8 11.75l12.068-6.928-2.581-2.587z" data-name="Path 535"${_scopeId}></path></g></g></svg>`);
      } else {
        return [
          (openBlock(), createBlock("svg", {
            xmlns: "http://www.w3.org/2000/svg",
            width: "140",
            height: "40"
          }, [
            createVNode("g", {
              "data-name": "Group 4686",
              transform: "translate(-410 -926.5)"
            }, [
              createVNode("rect", {
                width: "140",
                height: "40",
                "data-name": "Rectangle 60",
                rx: "2",
                transform: "translate(410 926.5)",
                fill: "#222"
              }),
              createVNode("g", {
                "data-name": "Group 4523",
                fill: "#ccc"
              }, [
                createVNode("g", { "data-name": "Group 2992" }, [
                  createVNode("text", {
                    "data-name": "Android app on",
                    transform: "translate(458.735 940.5)",
                    "font-size": "8",
                    "font-family": "ArialMT,Arial"
                  }, [
                    createVNode("tspan", {
                      x: "0",
                      y: "0"
                    }, "Android app on")
                  ]),
                  createVNode("text", {
                    "data-name": "Google Play",
                    transform: "translate(458.735 955.5)",
                    "font-size": "12",
                    "font-family": "Arial-BoldMT,Arial",
                    "font-weight": "700"
                  }, [
                    createVNode("tspan", {
                      x: "0",
                      y: "0"
                    }, "Google Play")
                  ])
                ]),
                createVNode("path", {
                  d: "M446.889 946.07l-9.485-9.511 12.068 6.928-2.583 2.583zM434.928 936a1.671 1.671 0 00-.932 1.517v18.966a1.671 1.671 0 00.932 1.517l11.028-11zm18.274 9.7l-2.531-1.466-2.824 2.772 2.824 2.772 2.583-1.465a1.723 1.723 0 00-.052-2.613zm-15.8 11.75l12.068-6.928-2.581-2.587z",
                  "data-name": "Path 535"
                })
              ])
            ])
          ]))
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(ssrRenderComponent(_component_NuxtLink, {
    to: "#",
    target: "_blank"
  }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`<svg xmlns="http://www.w3.org/2000/svg" width="140" height="40"${_scopeId}><g data-name="Group 4685" transform="translate(-570 -926.5)"${_scopeId}><rect width="140" height="40" data-name="Rectangle 101" rx="2" transform="translate(570 926.5)" fill="#222"${_scopeId}></rect><g data-name="Group 4524" fill="#ccc"${_scopeId}><text data-name="Available on the" transform="translate(619.279 940.5)" font-size="8" font-family="ArialMT,Arial"${_scopeId}><tspan x="0" y="0"${_scopeId}>Available on the</tspan></text><text data-name="App Store" transform="translate(619.279 955.5)" font-size="12" font-family="Arial-BoldMT,Arial" font-weight="700"${_scopeId}><tspan x="0" y="0"${_scopeId}>App Store</tspan></text><path d="M609.457 945.626a4.585 4.585 0 012.456-4.165 5.279 5.279 0 00-4.16-2.191c-1.744-.137-3.649 1.017-4.347 1.017-.737 0-2.426-.967-3.752-.967-2.741.044-5.654 2.185-5.654 6.542a12.228 12.228 0 00.708 3.988c.628 1.8 2.9 6.223 5.265 6.149 1.238-.029 2.112-.879 3.723-.879 1.562 0 2.372.879 3.752.879 2.387-.034 4.44-4.052 5.04-5.859a4.869 4.869 0 01-3.031-4.514zm-2.78-8.065a4.627 4.627 0 001.179-3.561 5.211 5.211 0 00-3.335 1.714 4.7 4.7 0 00-1.257 3.532 4.123 4.123 0 003.413-1.685z" data-name="Path 536"${_scopeId}></path></g></g></svg>`);
      } else {
        return [
          (openBlock(), createBlock("svg", {
            xmlns: "http://www.w3.org/2000/svg",
            width: "140",
            height: "40"
          }, [
            createVNode("g", {
              "data-name": "Group 4685",
              transform: "translate(-570 -926.5)"
            }, [
              createVNode("rect", {
                width: "140",
                height: "40",
                "data-name": "Rectangle 101",
                rx: "2",
                transform: "translate(570 926.5)",
                fill: "#222"
              }),
              createVNode("g", {
                "data-name": "Group 4524",
                fill: "#ccc"
              }, [
                createVNode("text", {
                  "data-name": "Available on the",
                  transform: "translate(619.279 940.5)",
                  "font-size": "8",
                  "font-family": "ArialMT,Arial"
                }, [
                  createVNode("tspan", {
                    x: "0",
                    y: "0"
                  }, "Available on the")
                ]),
                createVNode("text", {
                  "data-name": "App Store",
                  transform: "translate(619.279 955.5)",
                  "font-size": "12",
                  "font-family": "Arial-BoldMT,Arial",
                  "font-weight": "700"
                }, [
                  createVNode("tspan", {
                    x: "0",
                    y: "0"
                  }, "App Store")
                ]),
                createVNode("path", {
                  d: "M609.457 945.626a4.585 4.585 0 012.456-4.165 5.279 5.279 0 00-4.16-2.191c-1.744-.137-3.649 1.017-4.347 1.017-.737 0-2.426-.967-3.752-.967-2.741.044-5.654 2.185-5.654 6.542a12.228 12.228 0 00.708 3.988c.628 1.8 2.9 6.223 5.265 6.149 1.238-.029 2.112-.879 3.723-.879 1.562 0 2.372.879 3.752.879 2.387-.034 4.44-4.052 5.04-5.859a4.869 4.869 0 01-3.031-4.514zm-2.78-8.065a4.627 4.627 0 001.179-3.561 5.211 5.211 0 00-3.335 1.714 4.7 4.7 0 00-1.257 3.532 4.123 4.123 0 003.413-1.685z",
                  "data-name": "Path 536"
                })
              ])
            ])
          ]))
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</div></div></div>`);
}
const _sfc_setup$5 = _sfc_main$5.setup;
_sfc_main$5.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Footer/Middle.vue");
  return _sfc_setup$5 ? _sfc_setup$5(props, ctx) : void 0;
};
const __nuxt_component_1 = /* @__PURE__ */ _export_sfc(_sfc_main$5, [["ssrRender", _sfc_ssrRender$2]]);
const _sfc_main$4 = {};
function _sfc_ssrRender$1(_ctx, _push, _parent, _attrs) {
  const _component_NuxtLink = __nuxt_component_0$1;
  _push(`<div${ssrRenderAttrs(mergeProps({ class: "footer-bottom" }, _attrs))} data-v-36b60ab6><div class="md:flex justify-center gap-3 hidden text-[#595959] text-xs border-t border-b py-3" data-v-36b60ab6>`);
  _push(ssrRenderComponent(_component_NuxtLink, { to: "/" }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`\u09A2\u09BE\u0995\u09BE \u09AA\u09CD\u09B0\u0995\u09BE\u09B6`);
      } else {
        return [
          createTextVNode("\u09A2\u09BE\u0995\u09BE \u09AA\u09CD\u09B0\u0995\u09BE\u09B6")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(ssrRenderComponent(_component_NuxtLink, { to: "/" }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`\u09AC\u09BF\u099C\u09CD\u099E\u09BE\u09AA\u09A8`);
      } else {
        return [
          createTextVNode("\u09AC\u09BF\u099C\u09CD\u099E\u09BE\u09AA\u09A8")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(ssrRenderComponent(_component_NuxtLink, { to: "/" }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`\u09B8\u09BE\u09B0\u09CD\u0995\u09C1\u09B2\u09C7\u09B6\u09A8`);
      } else {
        return [
          createTextVNode("\u09B8\u09BE\u09B0\u09CD\u0995\u09C1\u09B2\u09C7\u09B6\u09A8")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(ssrRenderComponent(_component_NuxtLink, { to: "/" }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`\u09B6\u09B0\u09CD\u09A4\u09BE\u09AC\u09B2\u09BF \u0993 \u09A8\u09C0\u09A4\u09BF\u09AE\u09BE\u09B2\u09BE`);
      } else {
        return [
          createTextVNode("\u09B6\u09B0\u09CD\u09A4\u09BE\u09AC\u09B2\u09BF \u0993 \u09A8\u09C0\u09A4\u09BF\u09AE\u09BE\u09B2\u09BE")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(ssrRenderComponent(_component_NuxtLink, { to: "/" }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`\u0997\u09CB\u09AA\u09A8\u09C0\u09DF\u09A4\u09BE \u09A8\u09C0\u09A4\u09BF`);
      } else {
        return [
          createTextVNode("\u0997\u09CB\u09AA\u09A8\u09C0\u09DF\u09A4\u09BE \u09A8\u09C0\u09A4\u09BF")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(ssrRenderComponent(_component_NuxtLink, { to: "/" }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`\u09AF\u09CB\u0997\u09BE\u09AF\u09CB\u0997`);
      } else {
        return [
          createTextVNode("\u09AF\u09CB\u0997\u09BE\u09AF\u09CB\u0997")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</div><div class="md:hidden justify-center gap-3 grid grid-cols-3 text-center px-4 text-[#595959] text-xs border-t border-b py-3" data-v-36b60ab6>`);
  _push(ssrRenderComponent(_component_NuxtLink, { to: "/" }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`\u09A2\u09BE\u0995\u09BE \u09AA\u09CD\u09B0\u0995\u09BE\u09B6`);
      } else {
        return [
          createTextVNode("\u09A2\u09BE\u0995\u09BE \u09AA\u09CD\u09B0\u0995\u09BE\u09B6")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(ssrRenderComponent(_component_NuxtLink, { to: "/" }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`\u09AC\u09BF\u099C\u09CD\u099E\u09BE\u09AA\u09A8`);
      } else {
        return [
          createTextVNode("\u09AC\u09BF\u099C\u09CD\u099E\u09BE\u09AA\u09A8")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(ssrRenderComponent(_component_NuxtLink, { to: "/" }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`\u09B8\u09BE\u09B0\u09CD\u0995\u09C1\u09B2\u09C7\u09B6\u09A8`);
      } else {
        return [
          createTextVNode("\u09B8\u09BE\u09B0\u09CD\u0995\u09C1\u09B2\u09C7\u09B6\u09A8")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(ssrRenderComponent(_component_NuxtLink, { to: "/" }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`\u09B6\u09B0\u09CD\u09A4\u09BE\u09AC\u09B2\u09BF \u0993 \u09A8\u09C0\u09A4\u09BF\u09AE\u09BE\u09B2\u09BE`);
      } else {
        return [
          createTextVNode("\u09B6\u09B0\u09CD\u09A4\u09BE\u09AC\u09B2\u09BF \u0993 \u09A8\u09C0\u09A4\u09BF\u09AE\u09BE\u09B2\u09BE")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(ssrRenderComponent(_component_NuxtLink, { to: "/" }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`\u0997\u09CB\u09AA\u09A8\u09C0\u09DF\u09A4\u09BE \u09A8\u09C0\u09A4\u09BF`);
      } else {
        return [
          createTextVNode("\u0997\u09CB\u09AA\u09A8\u09C0\u09DF\u09A4\u09BE \u09A8\u09C0\u09A4\u09BF")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(ssrRenderComponent(_component_NuxtLink, { to: "/" }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`\u09AF\u09CB\u0997\u09BE\u09AF\u09CB\u0997`);
      } else {
        return [
          createTextVNode("\u09AF\u09CB\u0997\u09BE\u09AF\u09CB\u0997")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</div><div class="footer-copyright flex justify-center items-center text-[12px] py-3" data-v-36b60ab6><div class="copyright text-[#595959]" data-v-36b60ab6>\u09B8\u09CD\u09AC\u09A4\u09CD\u09AC \xA9 \u09E8\u09E6\u09E8\u09E9 \u09A2\u09BE\u0995\u09BE \u09AA\u09CD\u09B0\u0995\u09BE\u09B6</div><div class="Editor text-[#595959]" data-v-36b60ab6>\u09B8\u09AE\u09CD\u09AA\u09BE\u09A6\u0995 \u0993 \u09AA\u09CD\u09B0\u0995\u09BE\u09B6\u0995: \u09A2\u09BE\u0995\u09BE \u09AA\u09CD\u09B0\u0995\u09BE\u09B6</div></div></div>`);
}
const _sfc_setup$4 = _sfc_main$4.setup;
_sfc_main$4.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Footer/Bottom.vue");
  return _sfc_setup$4 ? _sfc_setup$4(props, ctx) : void 0;
};
const __nuxt_component_2 = /* @__PURE__ */ _export_sfc(_sfc_main$4, [["ssrRender", _sfc_ssrRender$1], ["__scopeId", "data-v-36b60ab6"]]);
const _sfc_main$3 = {};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs) {
  const _component_FooterTop = __nuxt_component_0;
  const _component_FooterMiddle = __nuxt_component_1;
  const _component_FooterBottom = __nuxt_component_2;
  _push(`<div${ssrRenderAttrs(mergeProps({ class: "max-w-[1280px] mx-auto px-4 md:px-2" }, _attrs))}><div class="main-footer py-8 border-t mt-10">`);
  _push(ssrRenderComponent(_component_FooterTop, null, null, _parent));
  _push(ssrRenderComponent(_component_FooterMiddle, null, null, _parent));
  _push(ssrRenderComponent(_component_FooterBottom, null, null, _parent));
  _push(`</div></div>`);
}
const _sfc_setup$3 = _sfc_main$3.setup;
_sfc_main$3.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Footer/Content.vue");
  return _sfc_setup$3 ? _sfc_setup$3(props, ctx) : void 0;
};
const __nuxt_component_7 = /* @__PURE__ */ _export_sfc(_sfc_main$3, [["ssrRender", _sfc_ssrRender]]);
const _sfc_main$2 = {
  __name: "FooterStickyAds",
  __ssrInlineRender: true,
  props: ["adsBottomStatus", "footerAds"],
  setup(__props) {
    const siteurl = siteUrlState();
    const bottomAdsBox = ref(false);
    return (_ctx, _push, _parent, _attrs) => {
      var _a, _b, _c, _d, _e;
      const _component_Icon = __nuxt_component_0$2;
      _push(`<div${ssrRenderAttrs(mergeProps({
        class: `${unref(bottomAdsBox) ? "-bottom-[98px] left-0 right-0" : "bottom-0 left-0 right-0"} fixed duration-700`
      }, _attrs))}><div class="bg-[#eee] h-[100px] flex flex-col justify-center items-center relative"><div class="bg-[#eee] w-8 h-8 px-2 absolute right-0 -top-6 rounded-l-lg cursor-pointer">`);
      _push(ssrRenderComponent(_component_Icon, { name: "material-symbols:close" }, null, _parent));
      _push(`</div>`);
      if (((_a = __props.footerAds) == null ? void 0 : _a.status) === 1) {
        _push(`<div class="ad-container py-2 border-b"><div class="ad-section bg-[#f7f7f7]">`);
        if (((_b = __props.footerAds) == null ? void 0 : _b.type) === 3) {
          _push(`<a${ssrRenderAttr("href", (_c = __props.footerAds) == null ? void 0 : _c.external_link)} target="_blank" rel="nofollow"><img class="mx-auto"${ssrRenderAttr("src", `${unref(siteurl).site_url}/media/advertisement/${(_d = __props.footerAds) == null ? void 0 : _d.desktop_image_path}`)} alt="Footer Ad"></a>`);
        } else {
          _push(`<div>${(_e = __props.footerAds) == null ? void 0 : _e.code}</div>`);
        }
        _push(`</div></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div>`);
    };
  }
};
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Ads/Desktop/Common/FooterStickyAds.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const __nuxt_component_8 = _sfc_main$2;
const _sfc_main$1 = {
  __name: "SiteBlock",
  __ssrInlineRender: true,
  props: ["siteblockAds"],
  setup(__props) {
    const globalPopupStatus = globalPopupState();
    const siteurl = siteUrlState();
    return (_ctx, _push, _parent, _attrs) => {
      var _a, _b, _c, _d;
      const _component_Icon = __nuxt_component_0$2;
      _push(`<div${ssrRenderAttrs(mergeProps({
        class: `${unref(globalPopupStatus) ? "fixed items-center justify-center inset-0 flex flex-col" : "hidden"}}  bg-black bg-opacity-25 z-[9999999px]`
      }, _attrs))}><div class="${ssrRenderClass(`${unref(globalPopupStatus) ? "relative top-0" : "relative -top-32"}  px-2 duration-300 globalPopup`)}"><div class="absolute right-2 cursor-pointer bg-red-700 h-7 rounded-full bottom-0 -top-4">`);
      _push(ssrRenderComponent(_component_Icon, {
        name: "material-symbols:close",
        class: "text-3xl px-1 text-white"
      }, null, _parent));
      _push(`</div>`);
      if (((_a = __props.siteblockAds) == null ? void 0 : _a.type) === 3) {
        _push(`<a${ssrRenderAttr("href", (_b = __props.siteblockAds) == null ? void 0 : _b.external_link)} target="_blank" rel="nofollow"><img class="mx-auto"${ssrRenderAttr("src", `${unref(siteurl).site_url}/media/advertisement/${(_c = __props.siteblockAds) == null ? void 0 : _c.desktop_image_path}`)} alt="Header Ad"></a>`);
      } else {
        _push(`<div>${(_d = __props.siteblockAds) == null ? void 0 : _d.code}</div>`);
      }
      _push(`</div></div>`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Ads/Desktop/Common/SiteBlock.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_9 = _sfc_main$1;
const useDevice = () => {
  return useNuxtApp().$device;
};
const _sfc_main = {
  __name: "default",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    const DsiteConfig = /* @__PURE__ */ useRuntimeConfig();
    const dsiteSetting = useState(() => [], "$VbeGLRT2Wl");
    const { data: dsiteSet } = ([__temp, __restore] = withAsyncContext(() => useFetch(`${DsiteConfig.public.apiUrl}/api/site-setting`, {
      method: "GET"
    }, "$tCuQFpvscL")), __temp = await __temp, __restore(), __temp);
    dsiteSetting.value = dsiteSet;
    useHead({
      bodyAttrs: {
        id: "bodyWrapper"
      },
      link: [
        {
          rel: "icon",
          type: "image/png",
          href: DsiteConfig.public.apiUrl + "/media/common/favicon.png"
        }
      ],
      script: [
        {
          src: "https://platform-api.sharethis.com/js/sharethis.js#property=651137566b9a9300123b73f3&product=inline-share-buttons",
          async: "true",
          tagPosition: "head"
        }
      ]
    });
    useDevice();
    ref(0);
    ref(0);
    const LogoHeaderScollUp = ref(false);
    const scrollDown = ref(false);
    ref(120);
    singlePageStickyState();
    const catConfig = /* @__PURE__ */ useRuntimeConfig();
    const allCategory = allCategoryState();
    const { data: cats } = ([__temp, __restore] = withAsyncContext(() => useFetch(`${catConfig.public.apiUrl}/api/allcat`, {
      method: "GET"
    }, "$R6HNUXBsds")), __temp = await __temp, __restore(), __temp);
    allCategory.value = cats;
    const topBannerAd = useState(() => "", "$iBiuDkobYM");
    const { data: topbA } = ([__temp, __restore] = withAsyncContext(() => useFetch("/api/adsmanagement/getads", {
      method: "POST",
      body: {
        page: 1,
        position: 1
      }
    }, "$QSvt0EPaFS")), __temp = await __temp, __restore(), __temp);
    topBannerAd.value = topbA.value;
    const footerAds = useState(() => "", "$Mun6pptLNi");
    const { data: fAds } = ([__temp, __restore] = withAsyncContext(() => useFetch("/api/adsmanagement/getads", {
      method: "POST",
      body: {
        page: 1,
        position: 3
      }
    }, "$Ixp80ImJZn")), __temp = await __temp, __restore(), __temp);
    footerAds.value = fAds.value;
    const siteblockAds = useState(() => "", "$9w2ObN2Usx");
    const { data: sbAds } = ([__temp, __restore] = withAsyncContext(() => useFetch("/api/adsmanagement/getads", {
      method: "POST",
      body: {
        page: 1,
        position: 4
      }
    }, "$2QTTDhcj6H")), __temp = await __temp, __restore(), __temp);
    siteblockAds.value = sbAds.value;
    return (_ctx, _push, _parent, _attrs) => {
      var _a, _b, _c;
      const _component_Head = Head;
      const _component_Title = Title;
      const _component_Meta = Meta;
      const _component_AdsDesktopCommonHeaderBannerTop = __nuxt_component_3$2;
      const _component_HeaderTop = __nuxt_component_4;
      const _component_HeaderTopMenu = __nuxt_component_5;
      const _component_MobileHeaderTop = __nuxt_component_6;
      const _component_FooterContent = __nuxt_component_7;
      const _component_AdsDesktopCommonFooterStickyAds = __nuxt_component_8;
      const _component_AdsDesktopCommonSiteBlock = __nuxt_component_9;
      _push(`<!--[--><div>`);
      _push(ssrRenderComponent(_component_Head, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_Title, null, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                var _a2, _b2;
                if (_push3) {
                  _push3(`${ssrInterpolate((_a2 = unref(dsiteSetting)) == null ? void 0 : _a2.title)}`);
                } else {
                  return [
                    createTextVNode(toDisplayString((_b2 = unref(dsiteSetting)) == null ? void 0 : _b2.title), 1)
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_Meta, {
              name: "description",
              content: "\u09A2\u09BE\u0995\u09BE \u09AA\u09CD\u09B0\u0995\u09BE\u09B6 \u09AC\u09BE\u0982\u09B2\u09BE\u09A6\u09C7\u09B6\u09B8\u09B9 \u09AC\u09BF\u09B6\u09CD\u09AC\u09C7\u09B0 \u09B8\u09B0\u09CD\u09AC\u09B6\u09C7\u09B7 \u09B8\u0982\u09AC\u09BE\u09A6 \u09B6\u09BF\u09B0\u09CB\u09A8\u09BE\u09AE, \u09AA\u09CD\u09B0\u09A4\u09BF\u09AC\u09C7\u09A6\u09A8, \u09AC\u09BF\u09B6\u09CD\u09B2\u09C7\u09B7\u09A3, \u0996\u09C7\u09B2\u09BE, \u09AC\u09BF\u09A8\u09CB\u09A6\u09A8, \u099A\u09BE\u0995\u09B0\u09BF, \u09B0\u09BE\u099C\u09A8\u09C0\u09A4\u09BF \u0993 \u09AC\u09BE\u09A3\u09BF\u099C\u09CD\u09AF\u09C7\u09B0 \u09AC\u09BE\u0982\u09B2\u09BE \u09A8\u09BF\u0989\u099C \u09AA\u09DC\u09A4\u09C7 \u09AD\u09BF\u099C\u09BF\u099F \u0995\u09B0\u09C1\u09A8\u0964"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_Meta, {
              name: "Developed By",
              content: "Dhaka Prokash Developer"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_Meta, {
              name: "keywords",
              content: "Dhaka Prokash, bangla news, current News, bangla newspaper, bangladesh newspaper, online paper, bangladeshi newspaper, bangla news paper, bangladesh newspapers, newspaper, all bangla news paper, bd news paper, news paper, bangladesh news paper, daily, bangla newspaper, daily news paper, bangladeshi news paper, bangla paper, all bangla newspaper, bangladesh news, daily newspaper, \u0985\u09A8\u09B2\u09BE\u0987\u09A8, \u09AA\u09A4\u09CD\u09B0\u09BF\u0995\u09BE, \u09AC\u09BE\u0982\u09B2\u09BE\u09A6\u09C7\u09B6, \u0986\u099C\u0995\u09C7\u09B0 \u09AA\u09A4\u09CD\u09B0\u09BF\u0995\u09BE, \u0986\u09A8\u09CD\u09A4\u09B0\u09CD\u099C\u09BE\u09A4\u09BF\u0995, \u0985\u09B0\u09CD\u09A5\u09A8\u09C0\u09A4\u09BF, \u0996\u09C7\u09B2\u09BE, \u09AC\u09BF\u09A8\u09CB\u09A6\u09A8, \u09AB\u09BF\u099A\u09BE\u09B0, \u09AC\u09BF\u099C\u09CD\u099E\u09BE\u09A8 \u0993 \u09AA\u09CD\u09B0\u09AF\u09C1\u0995\u09CD\u09A4\u09BF, \u099A\u09B2\u099A\u09CD\u099A\u09BF\u09A4\u09CD\u09B0, \u09A2\u09BE\u09B2\u09BF\u0989\u09A1, \u09AC\u09B2\u09BF\u0989\u09A1, \u09B9\u09B2\u09BF\u0989\u09A1, \u09AC\u09BE\u0982\u09B2\u09BE \u0997\u09BE\u09A8, \u09AE\u099E\u09CD\u099A, \u099F\u09C7\u09B2\u09BF\u09AD\u09BF\u09B6\u09A8, \u09A8\u0995\u09B6\u09BE, \u09B0\u09B8+\u0986\u09B2\u09CB, \u099B\u09C1\u099F\u09BF\u09B0 \u09A6\u09BF\u09A8\u09C7, \u0985\u09A7\u09C1\u09A8\u09BE, \u09B8\u09CD\u09AC\u09AA\u09CD\u09A8 \u09A8\u09BF\u09AF\u09BC\u09C7, \u0986\u09A8\u09A8\u09CD\u09A6, \u0985\u09A8\u09CD\u09AF \u0986\u09B2\u09CB, \u09B8\u09BE\u09B9\u09BF\u09A4\u09CD\u09AF, \u0997\u09CB\u09B2\u09CD\u09B2\u09BE\u099B\u09C1\u099F, \u09AA\u09CD\u09B0\u099C\u09A8\u09CD\u09AE \u09A1\u099F \u0995\u09AE, \u09AC\u09A8\u09CD\u09A7\u09C1\u09B8\u09AD\u09BE,\u0995\u09AE\u09CD\u09AA\u09BF\u0989\u099F\u09BE\u09B0, \u09AE\u09CB\u09AC\u09BE\u0987\u09B2 \u09AB\u09CB\u09A8, \u0985\u099F\u09CB\u09AE\u09CB\u09AC\u09BE\u0987\u09B2, \u09AE\u09B9\u09BE\u0995\u09BE\u09B6, \u0997\u09C7\u09AE\u09B8, \u09AE\u09BE\u09B2\u09CD\u099F\u09BF\u09AE\u09BF\u09A1\u09BF\u09AF\u09BC\u09BE, \u09B0\u09BE\u099C\u09A8\u09C0\u09A4\u09BF, \u09B8\u09B0\u0995\u09BE\u09B0, \u0985\u09AA\u09B0\u09BE\u09A7, \u09A6\u09C1\u09B0\u09CD\u09A8\u09C0\u09A4\u09BF, \u0986\u0987\u09A8 \u0993 \u09AC\u09BF\u099A\u09BE\u09B0, \u09AA\u09B0\u09BF\u09AC\u09C7\u09B6, \u09A6\u09C1\u09B0\u09CD\u0998\u099F\u09A8\u09BE, \u09B8\u0982\u09B8\u09A6, \u09B0\u09BE\u099C\u09A7\u09BE\u09A8\u09C0, \u09B6\u09C7\u09AF\u09BC\u09BE\u09B0 \u09AC\u09BE\u099C\u09BE\u09B0, \u09AC\u09BE\u09A3\u09BF\u099C\u09CD\u09AF, \u09AA\u09CB\u09B6\u09BE\u0995 \u09B6\u09BF\u09B2\u09CD\u09AA, \u0995\u09CD\u09B0\u09BF\u0995\u09C7\u099F, \u09AB\u09C1\u099F\u09AC\u09B2, \u09B2\u09BE\u0987\u09AD \u09B8\u09CD\u0995\u09CB\u09B0"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_Meta, {
              name: "distribution",
              content: "Global"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_Meta, {
              property: "og:type",
              content: "website"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_Meta, {
              property: "og:site_name",
              content: "\u09A2\u09BE\u0995\u09BE \u09AA\u09CD\u09B0\u0995\u09BE\u09B6"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_Meta, {
              property: "og:title",
              content: "\u09A2\u09BE\u0995\u09BE \u09AA\u09CD\u09B0\u0995\u09BE\u09B6 | \u09AC\u09BE\u0982\u09B2\u09BE \u09A8\u09BF\u0989\u099C \u09AA\u09C7\u09AA\u09BE\u09B0"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_Meta, {
              property: "og:description",
              content: "\u09A2\u09BE\u0995\u09BE \u09AA\u09CD\u09B0\u0995\u09BE\u09B6 \u09AC\u09BE\u0982\u09B2\u09BE\u09A6\u09C7\u09B6\u09B8\u09B9 \u09AC\u09BF\u09B6\u09CD\u09AC\u09C7\u09B0 \u09B8\u09B0\u09CD\u09AC\u09B6\u09C7\u09B7 \u09B8\u0982\u09AC\u09BE\u09A6 \u09B6\u09BF\u09B0\u09CB\u09A8\u09BE\u09AE, \u09AA\u09CD\u09B0\u09A4\u09BF\u09AC\u09C7\u09A6\u09A8, \u09AC\u09BF\u09B6\u09CD\u09B2\u09C7\u09B7\u09A3, \u0996\u09C7\u09B2\u09BE, \u09AC\u09BF\u09A8\u09CB\u09A6\u09A8, \u099A\u09BE\u0995\u09B0\u09BF, \u09B0\u09BE\u099C\u09A8\u09C0\u09A4\u09BF \u0993 \u09AC\u09BE\u09A3\u09BF\u099C\u09CD\u09AF\u09C7\u09B0 \u09AC\u09BE\u0982\u09B2\u09BE \u09A8\u09BF\u0989\u099C \u09AA\u09DC\u09A4\u09C7 \u09AD\u09BF\u099C\u09BF\u099F \u0995\u09B0\u09C1\u09A8\u0964"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_Meta, {
              name: "twitter:title",
              content: "\u09A2\u09BE\u0995\u09BE \u09AA\u09CD\u09B0\u0995\u09BE\u09B6 | \u09AC\u09BE\u0982\u09B2\u09BE \u09A8\u09BF\u0989\u099C \u09AA\u09C7\u09AA\u09BE\u09B0"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_Meta, {
              name: "twitter:description",
              content: "\u09A2\u09BE\u0995\u09BE \u09AA\u09CD\u09B0\u0995\u09BE\u09B6 \u09AC\u09BE\u0982\u09B2\u09BE\u09A6\u09C7\u09B6\u09B8\u09B9 \u09AC\u09BF\u09B6\u09CD\u09AC\u09C7\u09B0 \u09B8\u09B0\u09CD\u09AC\u09B6\u09C7\u09B7 \u09B8\u0982\u09AC\u09BE\u09A6 \u09B6\u09BF\u09B0\u09CB\u09A8\u09BE\u09AE, \u09AA\u09CD\u09B0\u09A4\u09BF\u09AC\u09C7\u09A6\u09A8, \u09AC\u09BF\u09B6\u09CD\u09B2\u09C7\u09B7\u09A3, \u0996\u09C7\u09B2\u09BE, \u09AC\u09BF\u09A8\u09CB\u09A6\u09A8, \u099A\u09BE\u0995\u09B0\u09BF, \u09B0\u09BE\u099C\u09A8\u09C0\u09A4\u09BF \u0993 \u09AC\u09BE\u09A3\u09BF\u099C\u09CD\u09AF\u09C7\u09B0 \u09AC\u09BE\u0982\u09B2\u09BE \u09A8\u09BF\u0989\u099C \u09AA\u09DC\u09A4\u09C7 \u09AD\u09BF\u099C\u09BF\u099F \u0995\u09B0\u09C1\u09A8\u0964"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_Meta, {
              name: "twitter:card",
              content: "summary_large_image"
            }, null, _parent2, _scopeId));
            _push2(`<meta name="twitter:domain" content="https://www.dhakaprokash24.com"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_Meta, {
              name: "twitter:site",
              content: "@dhakaprokash24"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_Meta, {
              name: "twitter:creator",
              content: "\u09A2\u09BE\u0995\u09BE \u09AA\u09CD\u09B0\u0995\u09BE\u09B6 | \u09AC\u09BE\u0982\u09B2\u09BE \u09A8\u09BF\u0989\u099C \u09AA\u09C7\u09AA\u09BE\u09B0"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_Meta, {
              property: "fb:app_id",
              content: "270848064771492"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_Meta, {
              property: "fb:pages",
              content: "100063660752112"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_Meta, {
              name: "googlebot",
              content: "index, follow"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_Meta, {
              name: "robots",
              content: "index, follow"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_Meta, {
              content: "ALL",
              name: "robots"
            }, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_Title, null, {
                default: withCtx(() => {
                  var _a2;
                  return [
                    createTextVNode(toDisplayString((_a2 = unref(dsiteSetting)) == null ? void 0 : _a2.title), 1)
                  ];
                }),
                _: 1
              }),
              createVNode(_component_Meta, {
                name: "description",
                content: "\u09A2\u09BE\u0995\u09BE \u09AA\u09CD\u09B0\u0995\u09BE\u09B6 \u09AC\u09BE\u0982\u09B2\u09BE\u09A6\u09C7\u09B6\u09B8\u09B9 \u09AC\u09BF\u09B6\u09CD\u09AC\u09C7\u09B0 \u09B8\u09B0\u09CD\u09AC\u09B6\u09C7\u09B7 \u09B8\u0982\u09AC\u09BE\u09A6 \u09B6\u09BF\u09B0\u09CB\u09A8\u09BE\u09AE, \u09AA\u09CD\u09B0\u09A4\u09BF\u09AC\u09C7\u09A6\u09A8, \u09AC\u09BF\u09B6\u09CD\u09B2\u09C7\u09B7\u09A3, \u0996\u09C7\u09B2\u09BE, \u09AC\u09BF\u09A8\u09CB\u09A6\u09A8, \u099A\u09BE\u0995\u09B0\u09BF, \u09B0\u09BE\u099C\u09A8\u09C0\u09A4\u09BF \u0993 \u09AC\u09BE\u09A3\u09BF\u099C\u09CD\u09AF\u09C7\u09B0 \u09AC\u09BE\u0982\u09B2\u09BE \u09A8\u09BF\u0989\u099C \u09AA\u09DC\u09A4\u09C7 \u09AD\u09BF\u099C\u09BF\u099F \u0995\u09B0\u09C1\u09A8\u0964"
              }),
              createVNode(_component_Meta, {
                name: "Developed By",
                content: "Dhaka Prokash Developer"
              }),
              createVNode(_component_Meta, {
                name: "keywords",
                content: "Dhaka Prokash, bangla news, current News, bangla newspaper, bangladesh newspaper, online paper, bangladeshi newspaper, bangla news paper, bangladesh newspapers, newspaper, all bangla news paper, bd news paper, news paper, bangladesh news paper, daily, bangla newspaper, daily news paper, bangladeshi news paper, bangla paper, all bangla newspaper, bangladesh news, daily newspaper, \u0985\u09A8\u09B2\u09BE\u0987\u09A8, \u09AA\u09A4\u09CD\u09B0\u09BF\u0995\u09BE, \u09AC\u09BE\u0982\u09B2\u09BE\u09A6\u09C7\u09B6, \u0986\u099C\u0995\u09C7\u09B0 \u09AA\u09A4\u09CD\u09B0\u09BF\u0995\u09BE, \u0986\u09A8\u09CD\u09A4\u09B0\u09CD\u099C\u09BE\u09A4\u09BF\u0995, \u0985\u09B0\u09CD\u09A5\u09A8\u09C0\u09A4\u09BF, \u0996\u09C7\u09B2\u09BE, \u09AC\u09BF\u09A8\u09CB\u09A6\u09A8, \u09AB\u09BF\u099A\u09BE\u09B0, \u09AC\u09BF\u099C\u09CD\u099E\u09BE\u09A8 \u0993 \u09AA\u09CD\u09B0\u09AF\u09C1\u0995\u09CD\u09A4\u09BF, \u099A\u09B2\u099A\u09CD\u099A\u09BF\u09A4\u09CD\u09B0, \u09A2\u09BE\u09B2\u09BF\u0989\u09A1, \u09AC\u09B2\u09BF\u0989\u09A1, \u09B9\u09B2\u09BF\u0989\u09A1, \u09AC\u09BE\u0982\u09B2\u09BE \u0997\u09BE\u09A8, \u09AE\u099E\u09CD\u099A, \u099F\u09C7\u09B2\u09BF\u09AD\u09BF\u09B6\u09A8, \u09A8\u0995\u09B6\u09BE, \u09B0\u09B8+\u0986\u09B2\u09CB, \u099B\u09C1\u099F\u09BF\u09B0 \u09A6\u09BF\u09A8\u09C7, \u0985\u09A7\u09C1\u09A8\u09BE, \u09B8\u09CD\u09AC\u09AA\u09CD\u09A8 \u09A8\u09BF\u09AF\u09BC\u09C7, \u0986\u09A8\u09A8\u09CD\u09A6, \u0985\u09A8\u09CD\u09AF \u0986\u09B2\u09CB, \u09B8\u09BE\u09B9\u09BF\u09A4\u09CD\u09AF, \u0997\u09CB\u09B2\u09CD\u09B2\u09BE\u099B\u09C1\u099F, \u09AA\u09CD\u09B0\u099C\u09A8\u09CD\u09AE \u09A1\u099F \u0995\u09AE, \u09AC\u09A8\u09CD\u09A7\u09C1\u09B8\u09AD\u09BE,\u0995\u09AE\u09CD\u09AA\u09BF\u0989\u099F\u09BE\u09B0, \u09AE\u09CB\u09AC\u09BE\u0987\u09B2 \u09AB\u09CB\u09A8, \u0985\u099F\u09CB\u09AE\u09CB\u09AC\u09BE\u0987\u09B2, \u09AE\u09B9\u09BE\u0995\u09BE\u09B6, \u0997\u09C7\u09AE\u09B8, \u09AE\u09BE\u09B2\u09CD\u099F\u09BF\u09AE\u09BF\u09A1\u09BF\u09AF\u09BC\u09BE, \u09B0\u09BE\u099C\u09A8\u09C0\u09A4\u09BF, \u09B8\u09B0\u0995\u09BE\u09B0, \u0985\u09AA\u09B0\u09BE\u09A7, \u09A6\u09C1\u09B0\u09CD\u09A8\u09C0\u09A4\u09BF, \u0986\u0987\u09A8 \u0993 \u09AC\u09BF\u099A\u09BE\u09B0, \u09AA\u09B0\u09BF\u09AC\u09C7\u09B6, \u09A6\u09C1\u09B0\u09CD\u0998\u099F\u09A8\u09BE, \u09B8\u0982\u09B8\u09A6, \u09B0\u09BE\u099C\u09A7\u09BE\u09A8\u09C0, \u09B6\u09C7\u09AF\u09BC\u09BE\u09B0 \u09AC\u09BE\u099C\u09BE\u09B0, \u09AC\u09BE\u09A3\u09BF\u099C\u09CD\u09AF, \u09AA\u09CB\u09B6\u09BE\u0995 \u09B6\u09BF\u09B2\u09CD\u09AA, \u0995\u09CD\u09B0\u09BF\u0995\u09C7\u099F, \u09AB\u09C1\u099F\u09AC\u09B2, \u09B2\u09BE\u0987\u09AD \u09B8\u09CD\u0995\u09CB\u09B0"
              }),
              createVNode(_component_Meta, {
                name: "distribution",
                content: "Global"
              }),
              createVNode(_component_Meta, {
                property: "og:type",
                content: "website"
              }),
              createVNode(_component_Meta, {
                property: "og:site_name",
                content: "\u09A2\u09BE\u0995\u09BE \u09AA\u09CD\u09B0\u0995\u09BE\u09B6"
              }),
              createVNode(_component_Meta, {
                property: "og:title",
                content: "\u09A2\u09BE\u0995\u09BE \u09AA\u09CD\u09B0\u0995\u09BE\u09B6 | \u09AC\u09BE\u0982\u09B2\u09BE \u09A8\u09BF\u0989\u099C \u09AA\u09C7\u09AA\u09BE\u09B0"
              }),
              createVNode(_component_Meta, {
                property: "og:description",
                content: "\u09A2\u09BE\u0995\u09BE \u09AA\u09CD\u09B0\u0995\u09BE\u09B6 \u09AC\u09BE\u0982\u09B2\u09BE\u09A6\u09C7\u09B6\u09B8\u09B9 \u09AC\u09BF\u09B6\u09CD\u09AC\u09C7\u09B0 \u09B8\u09B0\u09CD\u09AC\u09B6\u09C7\u09B7 \u09B8\u0982\u09AC\u09BE\u09A6 \u09B6\u09BF\u09B0\u09CB\u09A8\u09BE\u09AE, \u09AA\u09CD\u09B0\u09A4\u09BF\u09AC\u09C7\u09A6\u09A8, \u09AC\u09BF\u09B6\u09CD\u09B2\u09C7\u09B7\u09A3, \u0996\u09C7\u09B2\u09BE, \u09AC\u09BF\u09A8\u09CB\u09A6\u09A8, \u099A\u09BE\u0995\u09B0\u09BF, \u09B0\u09BE\u099C\u09A8\u09C0\u09A4\u09BF \u0993 \u09AC\u09BE\u09A3\u09BF\u099C\u09CD\u09AF\u09C7\u09B0 \u09AC\u09BE\u0982\u09B2\u09BE \u09A8\u09BF\u0989\u099C \u09AA\u09DC\u09A4\u09C7 \u09AD\u09BF\u099C\u09BF\u099F \u0995\u09B0\u09C1\u09A8\u0964"
              }),
              createVNode(_component_Meta, {
                name: "twitter:title",
                content: "\u09A2\u09BE\u0995\u09BE \u09AA\u09CD\u09B0\u0995\u09BE\u09B6 | \u09AC\u09BE\u0982\u09B2\u09BE \u09A8\u09BF\u0989\u099C \u09AA\u09C7\u09AA\u09BE\u09B0"
              }),
              createVNode(_component_Meta, {
                name: "twitter:description",
                content: "\u09A2\u09BE\u0995\u09BE \u09AA\u09CD\u09B0\u0995\u09BE\u09B6 \u09AC\u09BE\u0982\u09B2\u09BE\u09A6\u09C7\u09B6\u09B8\u09B9 \u09AC\u09BF\u09B6\u09CD\u09AC\u09C7\u09B0 \u09B8\u09B0\u09CD\u09AC\u09B6\u09C7\u09B7 \u09B8\u0982\u09AC\u09BE\u09A6 \u09B6\u09BF\u09B0\u09CB\u09A8\u09BE\u09AE, \u09AA\u09CD\u09B0\u09A4\u09BF\u09AC\u09C7\u09A6\u09A8, \u09AC\u09BF\u09B6\u09CD\u09B2\u09C7\u09B7\u09A3, \u0996\u09C7\u09B2\u09BE, \u09AC\u09BF\u09A8\u09CB\u09A6\u09A8, \u099A\u09BE\u0995\u09B0\u09BF, \u09B0\u09BE\u099C\u09A8\u09C0\u09A4\u09BF \u0993 \u09AC\u09BE\u09A3\u09BF\u099C\u09CD\u09AF\u09C7\u09B0 \u09AC\u09BE\u0982\u09B2\u09BE \u09A8\u09BF\u0989\u099C \u09AA\u09DC\u09A4\u09C7 \u09AD\u09BF\u099C\u09BF\u099F \u0995\u09B0\u09C1\u09A8\u0964"
              }),
              createVNode(_component_Meta, {
                name: "twitter:card",
                content: "summary_large_image"
              }),
              createVNode("meta", {
                name: "twitter:domain",
                content: "https://www.dhakaprokash24.com"
              }),
              createVNode(_component_Meta, {
                name: "twitter:site",
                content: "@dhakaprokash24"
              }),
              createVNode(_component_Meta, {
                name: "twitter:creator",
                content: "\u09A2\u09BE\u0995\u09BE \u09AA\u09CD\u09B0\u0995\u09BE\u09B6 | \u09AC\u09BE\u0982\u09B2\u09BE \u09A8\u09BF\u0989\u099C \u09AA\u09C7\u09AA\u09BE\u09B0"
              }),
              createVNode(_component_Meta, {
                property: "fb:app_id",
                content: "270848064771492"
              }),
              createVNode(_component_Meta, {
                property: "fb:pages",
                content: "100063660752112"
              }),
              createVNode(_component_Meta, {
                name: "googlebot",
                content: "index, follow"
              }),
              createVNode(_component_Meta, {
                name: "robots",
                content: "index, follow"
              }),
              createVNode(_component_Meta, {
                content: "ALL",
                name: "robots"
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      if (((_a = unref(topBannerAd)) == null ? void 0 : _a.status) === 1) {
        _push(ssrRenderComponent(_component_AdsDesktopCommonHeaderBannerTop, { topBannerAd: unref(topBannerAd) }, null, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(`<div class="${ssrRenderClass(`logoHeader duration-300 z-50`)}">`);
      _push(ssrRenderComponent(_component_HeaderTop, {
        scrollDown: unref(scrollDown),
        LogoHeaderScollUp: unref(LogoHeaderScollUp)
      }, null, _parent));
      _push(ssrRenderComponent(_component_HeaderTopMenu, { scrollDown: unref(scrollDown) }, null, _parent));
      _push(`</div>`);
      _push(ssrRenderComponent(_component_MobileHeaderTop, null, null, _parent));
      _push(`<div class="main-container duration-900 mt-4 md:mt-0">`);
      ssrRenderSlot(_ctx.$slots, "default", {}, null, _push, _parent);
      _push(ssrRenderComponent(_component_FooterContent, null, null, _parent));
      _push(`</div>`);
      if (((_b = unref(footerAds)) == null ? void 0 : _b.status) === 1) {
        _push(ssrRenderComponent(_component_AdsDesktopCommonFooterStickyAds, { footerAds: unref(footerAds) }, null, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(`</div>`);
      if (((_c = unref(siteblockAds)) == null ? void 0 : _c.status) === 1) {
        _push(ssrRenderComponent(_component_AdsDesktopCommonSiteBlock, { siteblockAds: unref(siteblockAds) }, null, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("layouts/default.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=default-873fbb67.mjs.map
