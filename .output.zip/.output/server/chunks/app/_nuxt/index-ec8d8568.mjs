import { H as Head, T as Title } from './components-5bc40629.mjs';
import { u as useImage, s as siteUrlState, a as singlePageStickyState, b as useFetch, _ as __nuxt_component_1 } from './state-7a7e2860.mjs';
import { computed, ref, withAsyncContext, mergeProps, withCtx, unref, createTextVNode, toDisplayString, createVNode, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent, ssrInterpolate, ssrRenderList, ssrRenderClass, ssrRenderAttr } from 'vue/server-renderer';
import { _ as __nuxt_component_0 } from './nuxt-link-c659c711.mjs';
import { _ as __nuxt_component_4 } from './client-only-0841c2aa.mjs';
import { _ as __nuxt_component_6$1 } from './Tabs-8fde547c.mjs';
import { _ as _export_sfc, u as useRoute } from '../server.mjs';
import { u as useState } from './state-b54abad0.mjs';
import './index-6a088328.mjs';
import '@unhead/shared';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'ipx';
import 'unhead';
import 'vue-router';

const _sfc_main$5 = {
  __name: "Top",
  __ssrInlineRender: true,
  props: ["categoryTopAds"],
  setup(__props) {
    const data = __props;
    const siteurl = siteUrlState();
    return (_ctx, _push, _parent, _attrs) => {
      var _a, _b, _c, _d, _e;
      if (((_a = data == null ? void 0 : data.categoryTopAds) == null ? void 0 : _a.status) === 1) {
        _push(`<div${ssrRenderAttrs(mergeProps({ class: "ad-container" }, _attrs))}><div class="ad-section bg-[#f7f7f7]">`);
        if (((_b = data == null ? void 0 : data.categoryTopAds) == null ? void 0 : _b.type) === 3) {
          _push(`<a${ssrRenderAttr("href", (_c = data == null ? void 0 : data.categoryTopAds) == null ? void 0 : _c.external_link)} target="_blank" rel="nofollow"><img class="mx-auto"${ssrRenderAttr("src", `${unref(siteurl).site_url}/media/advertisement/${(_d = data == null ? void 0 : data.categoryTopAds) == null ? void 0 : _d.desktop_image_path}`)} alt="Header Ad"></a>`);
        } else {
          _push(`<div>${(_e = data == null ? void 0 : data.categoryTopAds) == null ? void 0 : _e.code}</div>`);
        }
        _push(`</div></div>`);
      } else {
        _push(`<!---->`);
      }
    };
  }
};
const _sfc_setup$5 = _sfc_main$5.setup;
_sfc_main$5.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Ads/Desktop/Category/Top.vue");
  return _sfc_setup$5 ? _sfc_setup$5(props, ctx) : void 0;
};
const __nuxt_component_2 = _sfc_main$5;
const _sfc_main$4 = {
  __name: "Bottom",
  __ssrInlineRender: true,
  props: ["categoryBottomAds"],
  setup(__props) {
    const data = __props;
    const siteurl = siteUrlState();
    return (_ctx, _push, _parent, _attrs) => {
      var _a, _b, _c, _d, _e;
      if (((_a = data == null ? void 0 : data.categoryBottomAds) == null ? void 0 : _a.status) === 1) {
        _push(`<div${ssrRenderAttrs(mergeProps({ class: "ad-container" }, _attrs))}><div class="ad-section bg-[#f7f7f7]">`);
        if (((_b = data == null ? void 0 : data.categoryBottomAds) == null ? void 0 : _b.type) === 3) {
          _push(`<a${ssrRenderAttr("href", (_c = data == null ? void 0 : data.categoryBottomAds) == null ? void 0 : _c.external_link)} target="_blank" rel="nofollow"><img class="mx-auto"${ssrRenderAttr("src", `${unref(siteurl).site_url}/media/advertisement/${(_d = data == null ? void 0 : data.categoryBottomAds) == null ? void 0 : _d.desktop_image_path}`)} alt="Header Ad"></a>`);
        } else {
          _push(`<div>${(_e = data == null ? void 0 : data.categoryBottomAds) == null ? void 0 : _e.code}</div>`);
        }
        _push(`</div></div>`);
      } else {
        _push(`<!---->`);
      }
    };
  }
};
const _sfc_setup$4 = _sfc_main$4.setup;
_sfc_main$4.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Ads/Desktop/Category/Bottom.vue");
  return _sfc_setup$4 ? _sfc_setup$4(props, ctx) : void 0;
};
const __nuxt_component_6 = _sfc_main$4;
const _sfc_main$3 = {
  __name: "RightOne",
  __ssrInlineRender: true,
  props: ["categoryRightOneAds"],
  setup(__props) {
    const data = __props;
    const siteurl = siteUrlState();
    return (_ctx, _push, _parent, _attrs) => {
      var _a, _b, _c, _d, _e;
      if (((_a = data == null ? void 0 : data.categoryRightOneAds) == null ? void 0 : _a.status) === 1) {
        _push(`<div${ssrRenderAttrs(mergeProps({ class: "ad-container" }, _attrs))}><div class="ad-section bg-[#f7f7f7]">`);
        if (((_b = data == null ? void 0 : data.categoryRightOneAds) == null ? void 0 : _b.type) === 3) {
          _push(`<a${ssrRenderAttr("href", (_c = data == null ? void 0 : data.categoryRightOneAds) == null ? void 0 : _c.external_link)} target="_blank" rel="nofollow"><img class="mx-auto"${ssrRenderAttr("src", `${unref(siteurl).site_url}/media/advertisement/${(_d = data == null ? void 0 : data.categoryRightOneAds) == null ? void 0 : _d.desktop_image_path}`)} alt="Header Ad"></a>`);
        } else {
          _push(`<div>${(_e = data == null ? void 0 : data.categoryRightOneAds) == null ? void 0 : _e.code}</div>`);
        }
        _push(`</div></div>`);
      } else {
        _push(`<!---->`);
      }
    };
  }
};
const _sfc_setup$3 = _sfc_main$3.setup;
_sfc_main$3.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Ads/Desktop/Category/RightOne.vue");
  return _sfc_setup$3 ? _sfc_setup$3(props, ctx) : void 0;
};
const __nuxt_component_7 = _sfc_main$3;
const _sfc_main$2 = {
  __name: "RightTwo",
  __ssrInlineRender: true,
  props: ["categoryRightTwoAds"],
  setup(__props) {
    const data = __props;
    const siteurl = siteUrlState();
    return (_ctx, _push, _parent, _attrs) => {
      var _a, _b, _c, _d, _e;
      if (((_a = data == null ? void 0 : data.categoryRightTwoAds) == null ? void 0 : _a.status) === 1) {
        _push(`<div${ssrRenderAttrs(mergeProps({ class: "ad-container" }, _attrs))}><div class="ad-section bg-[#f7f7f7]">`);
        if (((_b = data == null ? void 0 : data.categoryRightTwoAds) == null ? void 0 : _b.type) === 3) {
          _push(`<a${ssrRenderAttr("href", (_c = data == null ? void 0 : data.categoryRightTwoAds) == null ? void 0 : _c.external_link)} target="_blank" rel="nofollow"><img class="mx-auto"${ssrRenderAttr("src", `${unref(siteurl).site_url}/media/advertisement/${(_d = data == null ? void 0 : data.categoryRightTwoAds) == null ? void 0 : _d.desktop_image_path}`)} alt="Header Ad"></a>`);
        } else {
          _push(`<div>${(_e = data == null ? void 0 : data.categoryRightTwoAds) == null ? void 0 : _e.code}</div>`);
        }
        _push(`</div></div>`);
      } else {
        _push(`<!---->`);
      }
    };
  }
};
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Ads/Desktop/Category/RightTwo.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const __nuxt_component_9 = _sfc_main$2;
const _sfc_main$1 = {
  __name: "RightThree",
  __ssrInlineRender: true,
  props: ["categoryRightThreeAds"],
  setup(__props) {
    const data = __props;
    const siteurl = siteUrlState();
    return (_ctx, _push, _parent, _attrs) => {
      var _a, _b, _c, _d, _e;
      if (((_a = data == null ? void 0 : data.categoryRightThreeAds) == null ? void 0 : _a.status) === 1) {
        _push(`<div${ssrRenderAttrs(mergeProps({ class: "ad-container" }, _attrs))}><div class="ad-section bg-[#f7f7f7]">`);
        if (((_b = data == null ? void 0 : data.categoryRightThreeAds) == null ? void 0 : _b.type) === 3) {
          _push(`<a${ssrRenderAttr("href", (_c = data == null ? void 0 : data.categoryRightThreeAds) == null ? void 0 : _c.external_link)} target="_blank" rel="nofollow"><img class="mx-auto"${ssrRenderAttr("src", `${unref(siteurl).site_url}/media/advertisement/${(_d = data == null ? void 0 : data.categoryRightThreeAds) == null ? void 0 : _d.desktop_image_path}`)} alt="Header Ad"></a>`);
        } else {
          _push(`<div>${(_e = data == null ? void 0 : data.categoryRightThreeAds) == null ? void 0 : _e.code}</div>`);
        }
        _push(`</div></div>`);
      } else {
        _push(`<!---->`);
      }
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Ads/Desktop/Category/RightThree.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_10 = _sfc_main$1;
const _sfc_main = {
  __name: "index",
  __ssrInlineRender: true,
  async setup(__props) {
    var _a;
    let __temp, __restore;
    const getDate = new Intl.DateTimeFormat("bn-bd", { year: "numeric", month: "long", day: "numeric", hour: "numeric", minute: "numeric" });
    const postCreatedDate = (date) => {
      if (date) {
        return getDate.format(new Date(date)).replace("\u098F", "|").replace("PM", "\u09AA\u09BF\u098F\u09AE").replace("AM", "\u098F\u098F\u09AE");
      }
    };
    const img = useImage();
    const siteurl = siteUrlState();
    const singlePageSticky = singlePageStickyState();
    const stickyScroll = computed(
      () => singlePageSticky.value
    );
    const cat_slug = useRoute().params.category;
    const category = ref("");
    const categoryContent = useState(() => [], "$bq1mELdm8w");
    const categoryContentExcept = useState(() => [], "$9d9zHT8u01");
    const take = ref(15);
    const { data: catcont } = ([__temp, __restore] = withAsyncContext(() => useFetch("/api/category/categorycontent", {
      method: "POST",
      body: {
        cat_slug,
        take: take.value
      }
    }, "$9dVGstNAy6")), __temp = await __temp, __restore(), __temp);
    categoryContent.value = catcont.value.contents;
    categoryContentExcept.value = catcont.value.contents.slice(5, take.value);
    category.value = (_a = catcont == null ? void 0 : catcont.value) == null ? void 0 : _a.category;
    const categoryTopAds = useState(() => "", "$Nu91HK82Zb");
    const { data: catTpAds } = ([__temp, __restore] = withAsyncContext(() => useFetch("/api/adsmanagement/getads", {
      method: "POST",
      body: {
        page: 3,
        position: 1
      }
    }, "$2VUYUjY8Wx")), __temp = await __temp, __restore(), __temp);
    categoryTopAds.value = catTpAds.value;
    const categoryBottomAds = useState(() => "", "$kBUxusiSKN");
    const { data: catBtmAds } = ([__temp, __restore] = withAsyncContext(() => useFetch("/api/adsmanagement/getads", {
      method: "POST",
      body: {
        page: 3,
        position: 2
      }
    }, "$2r4j3iSZqT")), __temp = await __temp, __restore(), __temp);
    categoryBottomAds.value = catBtmAds.value;
    const categoryRightOneAds = useState(() => "", "$N2qkBu8jjg");
    const { data: catRoneAds } = ([__temp, __restore] = withAsyncContext(() => useFetch("/api/adsmanagement/getads", {
      method: "POST",
      body: {
        page: 3,
        position: 3
      }
    }, "$J1d0K7uT1X")), __temp = await __temp, __restore(), __temp);
    categoryRightOneAds.value = catRoneAds.value;
    const categoryRightTwoAds = useState(() => "", "$TWZlzCZWMt");
    const { data: catRtwoAds } = ([__temp, __restore] = withAsyncContext(() => useFetch("/api/adsmanagement/getads", {
      method: "POST",
      body: {
        page: 3,
        position: 4
      }
    }, "$va9ZbF3cxt")), __temp = await __temp, __restore(), __temp);
    categoryRightTwoAds.value = catRtwoAds.value;
    const categoryRightThreeAds = useState(() => "", "$FY9asGAQOi");
    const { data: catRthreeAds } = ([__temp, __restore] = withAsyncContext(() => useFetch("/api/adsmanagement/getads", {
      method: "POST",
      body: {
        page: 3,
        position: 5
      }
    }, "$ulFZxDOZzJ")), __temp = await __temp, __restore(), __temp);
    categoryRightThreeAds.value = catRthreeAds.value;
    return (_ctx, _push, _parent, _attrs) => {
      var _a2, _b, _c, _d, _e, _f, _g, _h, _i, _j, _k, _l, _m, _n, _o, _p, _q, _r, _s, _t;
      const _component_Head = Head;
      const _component_Title = Title;
      const _component_AdsDesktopCategoryTop = __nuxt_component_2;
      const _component_NuxtLink = __nuxt_component_0;
      const _component_nuxt_img = __nuxt_component_1;
      const _component_ClientOnly = __nuxt_component_4;
      const _component_AdsDesktopCategoryBottom = __nuxt_component_6;
      const _component_AdsDesktopCategoryRightOne = __nuxt_component_7;
      const _component_Tabs = __nuxt_component_6$1;
      const _component_AdsDesktopCategoryRightTwo = __nuxt_component_9;
      const _component_AdsDesktopCategoryRightThree = __nuxt_component_10;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "category-page" }, _attrs))} data-v-12d79d1a>`);
      _push(ssrRenderComponent(_component_Head, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_Title, null, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`${ssrInterpolate(unref(category).cat_name_bn)}`);
                } else {
                  return [
                    createTextVNode(toDisplayString(unref(category).cat_name_bn), 1)
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_Title, null, {
                default: withCtx(() => [
                  createTextVNode(toDisplayString(unref(category).cat_name_bn), 1)
                ]),
                _: 1
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      if (unref(categoryTopAds).status === 1) {
        _push(`<div class="py-4 mt-2 border-b border-t border-b-[#e2e2e2] border-t-[#e2e2e2]" data-v-12d79d1a>`);
        _push(ssrRenderComponent(_component_AdsDesktopCategoryTop, { categoryTopAds: unref(categoryTopAds) }, null, _parent));
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<div class="max-w-[1280px] mx-auto category-content px-4 md:px-2 py-4 relative" data-v-12d79d1a><div class="breadcrump border-b border-b-[#dee2e6] pb-2 mb-5 flex flex-col gap-2 md:gap-4" data-v-12d79d1a><div class="flex gap-1 justify-start items-center" data-v-12d79d1a>`);
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: `/${unref(category).cat_slug}`,
        class: "text-[#3375af] font-semibold"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<h1 class="text-xl md:text-3xl" data-v-12d79d1a${_scopeId}>${ssrInterpolate(unref(category).cat_name_bn)}</h1>`);
          } else {
            return [
              createVNode("h1", { class: "text-xl md:text-3xl" }, toDisplayString(unref(category).cat_name_bn), 1)
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div><div data-v-12d79d1a>`);
      if (((_b = (_a2 = unref(category)) == null ? void 0 : _a2.subcat) == null ? void 0 : _b.length) > 0) {
        _push(`<div class="subcategory flex flex-wrap gap-3" data-v-12d79d1a><!--[-->`);
        ssrRenderList((_c = unref(category)) == null ? void 0 : _c.subcat, (subcategory) => {
          _push(`<div class="subcategoryLink" data-v-12d79d1a>`);
          _push(ssrRenderComponent(_component_NuxtLink, {
            to: `/${unref(category).cat_slug}/${subcategory == null ? void 0 : subcategory.subcat_slug}`,
            class: "text-[000000] font-[600] text-sm md:text-[16px] hover:text-[#3375af]"
          }, {
            default: withCtx((_, _push2, _parent2, _scopeId) => {
              if (_push2) {
                _push2(`${ssrInterpolate(subcategory == null ? void 0 : subcategory.subcat_name_bn)}`);
              } else {
                return [
                  createTextVNode(toDisplayString(subcategory == null ? void 0 : subcategory.subcat_name_bn), 1)
                ];
              }
            }),
            _: 2
          }, _parent));
          _push(`</div>`);
        });
        _push(`<!--]--></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div><div class="grid grid-cols-12 gap-8 md:gap-3" data-v-12d79d1a>`);
      if (((_d = unref(categoryContent)) == null ? void 0 : _d.length) > 1) {
        _push(`<div class="col-span-12 md:col-span-9 md:border-r md:pr-3" data-v-12d79d1a><div class="grid grid-cols-12 border-b border-b-[#dee2e6] pb-4" data-v-12d79d1a><div class="col-span-12 md:col-span-8 md:pr-3 mb-1 md:mb-0" data-v-12d79d1a><div class="lead-post md:h-[328px] group overflow-hidden" data-v-12d79d1a>`);
        _push(ssrRenderComponent(_component_NuxtLink, {
          to: `/category/${(_f = (_e = unref(categoryContent)[0]) == null ? void 0 : _e.category) == null ? void 0 : _f.cat_slug}/${(_g = unref(categoryContent)[0]) == null ? void 0 : _g.content_id}`,
          class: "relative"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            var _a3, _b2, _c2, _d2;
            if (_push2) {
              _push2(ssrRenderComponent(_component_nuxt_img, {
                src: `${unref(siteurl).site_url}/media/content/images/${(_a3 = unref(categoryContent)[0]) == null ? void 0 : _a3.img_bg_path}`,
                class: "mx-auto w-full group-hover:scale-110 duration-300 md:h-full",
                placeholder: unref(img)(`${unref(siteurl).site_url}/logo/placeholder.jpg`)
              }, null, _parent2, _scopeId));
              _push2(`<div class="lead-overly absolute h-full w-full block top-0" data-v-12d79d1a${_scopeId}><h5 class="img-title leading-8 text-white group-hover:text-[#ff0000] text-[18px] md:text-[24px] absolute bottom-4 left-6" data-v-12d79d1a${_scopeId}>${ssrInterpolate((_b2 = unref(categoryContent)[0]) == null ? void 0 : _b2.content_heading)}</h5></div>`);
            } else {
              return [
                createVNode(_component_nuxt_img, {
                  src: `${unref(siteurl).site_url}/media/content/images/${(_c2 = unref(categoryContent)[0]) == null ? void 0 : _c2.img_bg_path}`,
                  class: "mx-auto w-full group-hover:scale-110 duration-300 md:h-full",
                  placeholder: unref(img)(`${unref(siteurl).site_url}/logo/placeholder.jpg`)
                }, null, 8, ["src", "placeholder"]),
                createVNode("div", { class: "lead-overly absolute h-full w-full block top-0" }, [
                  createVNode("h5", { class: "img-title leading-8 text-white group-hover:text-[#ff0000] text-[18px] md:text-[24px] absolute bottom-4 left-6" }, toDisplayString((_d2 = unref(categoryContent)[0]) == null ? void 0 : _d2.content_heading), 1)
                ])
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(`</div></div>`);
        if (unref(categoryContent)[1]) {
          _push(`<div class="col-span-12 md:col-span-4 border-t mt-2 md:mt-0 pt-3 md:pt-0 md:border-t-0 md:pl-3 md:border-l border-l-[#dee2e6]" data-v-12d79d1a>`);
          _push(ssrRenderComponent(_component_NuxtLink, {
            to: `/category/${(_i = (_h = unref(categoryContent)[1]) == null ? void 0 : _h.category) == null ? void 0 : _i.cat_slug}/${(_j = unref(categoryContent)[1]) == null ? void 0 : _j.content_id}`,
            class: "categorypost-2 group"
          }, {
            default: withCtx((_, _push2, _parent2, _scopeId) => {
              var _a3, _b2, _c2, _d2, _e2, _f2;
              if (_push2) {
                _push2(`<div class="cat-feature-image overflow-hidden" data-v-12d79d1a${_scopeId}>`);
                _push2(ssrRenderComponent(_component_nuxt_img, {
                  src: `${unref(siteurl).site_url}/media/content/images/${(_a3 = unref(categoryContent)[1]) == null ? void 0 : _a3.img_bg_path}`,
                  class: "mx-auto w-full group-hover:scale-110 duration-300 h-full",
                  placeholder: unref(img)(`${unref(siteurl).site_url}/logo/placeholder.jpg`)
                }, null, _parent2, _scopeId));
                _push2(`</div><div class="flex flex-col gap-3 mt-2" data-v-12d79d1a${_scopeId}><h3 class="cat-postheading text-xl group-hover:text-[#ff0000] leading-[24px] text-[#121212]" data-v-12d79d1a${_scopeId}>${ssrInterpolate((_b2 = unref(categoryContent)[1]) == null ? void 0 : _b2.content_heading)}</h3>`);
                _push2(ssrRenderComponent(_component_ClientOnly, null, {}, _parent2, _scopeId));
                _push2(`<small class="cat-postdate" data-v-12d79d1a${_scopeId}> \u09AA\u09CD\u09B0\u0995\u09BE\u09B6: ${ssrInterpolate(postCreatedDate((_c2 = unref(categoryContent)[1]) == null ? void 0 : _c2.created_at))}</small></div>`);
              } else {
                return [
                  createVNode("div", { class: "cat-feature-image overflow-hidden" }, [
                    createVNode(_component_nuxt_img, {
                      src: `${unref(siteurl).site_url}/media/content/images/${(_d2 = unref(categoryContent)[1]) == null ? void 0 : _d2.img_bg_path}`,
                      class: "mx-auto w-full group-hover:scale-110 duration-300 h-full",
                      placeholder: unref(img)(`${unref(siteurl).site_url}/logo/placeholder.jpg`)
                    }, null, 8, ["src", "placeholder"])
                  ]),
                  createVNode("div", { class: "flex flex-col gap-3 mt-2" }, [
                    createVNode("h3", { class: "cat-postheading text-xl group-hover:text-[#ff0000] leading-[24px] text-[#121212]" }, toDisplayString((_e2 = unref(categoryContent)[1]) == null ? void 0 : _e2.content_heading), 1),
                    createVNode(_component_ClientOnly, null, {
                      default: withCtx(() => {
                        var _a4;
                        return [
                          createVNode("div", {
                            class: "cat-postdesc text-[15px] font-[300] text-[#555555]",
                            innerHTML: `${(_a4 = unref(categoryContent)[1]) == null ? void 0 : _a4.content_details.substring(0, 155)}...`
                          }, null, 8, ["innerHTML"])
                        ];
                      }),
                      _: 1
                    }),
                    createVNode("small", { class: "cat-postdate" }, " \u09AA\u09CD\u09B0\u0995\u09BE\u09B6: " + toDisplayString(postCreatedDate((_f2 = unref(categoryContent)[1]) == null ? void 0 : _f2.created_at)), 1)
                  ])
                ];
              }
            }),
            _: 1
          }, _parent));
          _push(`</div>`);
        } else {
          _push(`<!---->`);
        }
        _push(`</div>`);
        if (unref(categoryContent)[2]) {
          _push(`<div class="${ssrRenderClass(`grid grid-cols-12 gap-4 md:gap-0 py-4 ${unref(categoryBottomAds).status === 1 ? "" : "border-b border-b-[#dee2e6]"} `)}" data-v-12d79d1a>`);
          _push(ssrRenderComponent(_component_NuxtLink, {
            to: `/category/${(_l = (_k = unref(categoryContent)[2]) == null ? void 0 : _k.category) == null ? void 0 : _l.cat_slug}/${(_m = unref(categoryContent)[2]) == null ? void 0 : _m.content_id}`,
            class: "cat-box group md:pr-3 md:border-r border-r-[#dee2e6] col-span-12 md:col-span-4"
          }, {
            default: withCtx((_, _push2, _parent2, _scopeId) => {
              var _a3, _b2, _c2, _d2, _e2, _f2;
              if (_push2) {
                _push2(`<div class="cat-box-image overflow-hidden" data-v-12d79d1a${_scopeId}>`);
                _push2(ssrRenderComponent(_component_nuxt_img, {
                  src: `${unref(siteurl).site_url}/media/content/images/${(_a3 = unref(categoryContent)[2]) == null ? void 0 : _a3.img_bg_path}`,
                  class: "mx-auto w-full group-hover:scale-110 duration-300 h-full",
                  placeholder: unref(img)(`${unref(siteurl).site_url}/logo/placeholder.jpg`)
                }, null, _parent2, _scopeId));
                _push2(`</div><div class="flex flex-col gap-3 mt-2" data-v-12d79d1a${_scopeId}><h3 class="cat-postheading text-xl group-hover:text-[#ff0000] leading-[24px] text-[#121212]" data-v-12d79d1a${_scopeId}>${ssrInterpolate((_b2 = unref(categoryContent)[2]) == null ? void 0 : _b2.content_heading)}</h3>`);
                _push2(ssrRenderComponent(_component_ClientOnly, null, {}, _parent2, _scopeId));
                _push2(`<small class="cat-postdate" data-v-12d79d1a${_scopeId}> \u09AA\u09CD\u09B0\u0995\u09BE\u09B6: ${ssrInterpolate(postCreatedDate((_c2 = unref(categoryContent)[2]) == null ? void 0 : _c2.created_at))}</small></div>`);
              } else {
                return [
                  createVNode("div", { class: "cat-box-image overflow-hidden" }, [
                    createVNode(_component_nuxt_img, {
                      src: `${unref(siteurl).site_url}/media/content/images/${(_d2 = unref(categoryContent)[2]) == null ? void 0 : _d2.img_bg_path}`,
                      class: "mx-auto w-full group-hover:scale-110 duration-300 h-full",
                      placeholder: unref(img)(`${unref(siteurl).site_url}/logo/placeholder.jpg`)
                    }, null, 8, ["src", "placeholder"])
                  ]),
                  createVNode("div", { class: "flex flex-col gap-3 mt-2" }, [
                    createVNode("h3", { class: "cat-postheading text-xl group-hover:text-[#ff0000] leading-[24px] text-[#121212]" }, toDisplayString((_e2 = unref(categoryContent)[2]) == null ? void 0 : _e2.content_heading), 1),
                    createVNode(_component_ClientOnly, null, {
                      default: withCtx(() => {
                        var _a4;
                        return [
                          createVNode("div", {
                            class: "cat-postdesc text-[15px] font-[300] text-[#555555]",
                            innerHTML: `${(_a4 = unref(categoryContent)[2]) == null ? void 0 : _a4.content_details.substring(0, 155)}...`
                          }, null, 8, ["innerHTML"])
                        ];
                      }),
                      _: 1
                    }),
                    createVNode("small", { class: "cat-postdate" }, " \u09AA\u09CD\u09B0\u0995\u09BE\u09B6: " + toDisplayString(postCreatedDate((_f2 = unref(categoryContent)[2]) == null ? void 0 : _f2.created_at)), 1)
                  ])
                ];
              }
            }),
            _: 1
          }, _parent));
          if (unref(categoryContent)[3]) {
            _push(ssrRenderComponent(_component_NuxtLink, {
              to: `/category/${(_o = (_n = unref(categoryContent)[3]) == null ? void 0 : _n.category) == null ? void 0 : _o.cat_slug}/${(_p = unref(categoryContent)[3]) == null ? void 0 : _p.content_id}`,
              class: "cat-box group md:px-3 md:border-r border-r-[#dee2e6] col-span-12 md:col-span-4"
            }, {
              default: withCtx((_, _push2, _parent2, _scopeId) => {
                var _a3, _b2, _c2, _d2, _e2, _f2;
                if (_push2) {
                  _push2(`<div class="cat-box-image overflow-hidden" data-v-12d79d1a${_scopeId}>`);
                  _push2(ssrRenderComponent(_component_nuxt_img, {
                    src: `${unref(siteurl).site_url}/media/content/images/${(_a3 = unref(categoryContent)[3]) == null ? void 0 : _a3.img_bg_path}`,
                    class: "mx-auto w-full group-hover:scale-110 duration-300 h-full",
                    placeholder: unref(img)(`${unref(siteurl).site_url}/logo/placeholder.jpg`)
                  }, null, _parent2, _scopeId));
                  _push2(`</div><div class="flex flex-col gap-3 mt-2" data-v-12d79d1a${_scopeId}><h3 class="cat-postheading text-xl group-hover:text-[#ff0000] leading-[24px] text-[#121212]" data-v-12d79d1a${_scopeId}>${ssrInterpolate((_b2 = unref(categoryContent)[3]) == null ? void 0 : _b2.content_heading)}</h3>`);
                  _push2(ssrRenderComponent(_component_ClientOnly, null, {}, _parent2, _scopeId));
                  _push2(`<small class="cat-postdate" data-v-12d79d1a${_scopeId}> \u09AA\u09CD\u09B0\u0995\u09BE\u09B6: ${ssrInterpolate(postCreatedDate((_c2 = unref(categoryContent)[3]) == null ? void 0 : _c2.created_at))}</small></div>`);
                } else {
                  return [
                    createVNode("div", { class: "cat-box-image overflow-hidden" }, [
                      createVNode(_component_nuxt_img, {
                        src: `${unref(siteurl).site_url}/media/content/images/${(_d2 = unref(categoryContent)[3]) == null ? void 0 : _d2.img_bg_path}`,
                        class: "mx-auto w-full group-hover:scale-110 duration-300 h-full",
                        placeholder: unref(img)(`${unref(siteurl).site_url}/logo/placeholder.jpg`)
                      }, null, 8, ["src", "placeholder"])
                    ]),
                    createVNode("div", { class: "flex flex-col gap-3 mt-2" }, [
                      createVNode("h3", { class: "cat-postheading text-xl group-hover:text-[#ff0000] leading-[24px] text-[#121212]" }, toDisplayString((_e2 = unref(categoryContent)[3]) == null ? void 0 : _e2.content_heading), 1),
                      createVNode(_component_ClientOnly, null, {
                        default: withCtx(() => {
                          var _a4;
                          return [
                            createVNode("div", {
                              class: "cat-postdesc text-[15px] font-[300] text-[#555555]",
                              innerHTML: `${(_a4 = unref(categoryContent)[3]) == null ? void 0 : _a4.content_details.substring(0, 155)}...`
                            }, null, 8, ["innerHTML"])
                          ];
                        }),
                        _: 1
                      }),
                      createVNode("small", { class: "cat-postdate" }, " \u09AA\u09CD\u09B0\u0995\u09BE\u09B6: " + toDisplayString(postCreatedDate((_f2 = unref(categoryContent)[3]) == null ? void 0 : _f2.created_at)), 1)
                    ])
                  ];
                }
              }),
              _: 1
            }, _parent));
          } else {
            _push(`<!---->`);
          }
          if (unref(categoryContent)[4]) {
            _push(ssrRenderComponent(_component_NuxtLink, {
              to: `/category/${(_r = (_q = unref(categoryContent)[4]) == null ? void 0 : _q.category) == null ? void 0 : _r.cat_slug}/${(_s = unref(categoryContent)[4]) == null ? void 0 : _s.content_id}`,
              class: "cat-box group md:pl-3 col-span-12 md:col-span-4"
            }, {
              default: withCtx((_, _push2, _parent2, _scopeId) => {
                var _a3, _b2, _c2, _d2, _e2, _f2;
                if (_push2) {
                  _push2(`<div class="cat-box-image overflow-hidden" data-v-12d79d1a${_scopeId}>`);
                  _push2(ssrRenderComponent(_component_nuxt_img, {
                    src: `${unref(siteurl).site_url}/media/content/images/${(_a3 = unref(categoryContent)[4]) == null ? void 0 : _a3.img_bg_path}`,
                    class: "mx-auto w-full group-hover:scale-110 duration-300 h-full",
                    placeholder: unref(img)(`${unref(siteurl).site_url}/logo/placeholder.jpg`)
                  }, null, _parent2, _scopeId));
                  _push2(`</div><div class="flex flex-col gap-3 mt-2" data-v-12d79d1a${_scopeId}><h3 class="cat-postheading text-xl group-hover:text-[#ff0000] leading-[24px] text-[#121212]" data-v-12d79d1a${_scopeId}>${ssrInterpolate((_b2 = unref(categoryContent)[4]) == null ? void 0 : _b2.content_heading)}</h3>`);
                  _push2(ssrRenderComponent(_component_ClientOnly, null, {}, _parent2, _scopeId));
                  _push2(`<small class="cat-postdate" data-v-12d79d1a${_scopeId}> \u09AA\u09CD\u09B0\u0995\u09BE\u09B6: ${ssrInterpolate(postCreatedDate((_c2 = unref(categoryContent)[4]) == null ? void 0 : _c2.created_at))}</small></div>`);
                } else {
                  return [
                    createVNode("div", { class: "cat-box-image overflow-hidden" }, [
                      createVNode(_component_nuxt_img, {
                        src: `${unref(siteurl).site_url}/media/content/images/${(_d2 = unref(categoryContent)[4]) == null ? void 0 : _d2.img_bg_path}`,
                        class: "mx-auto w-full group-hover:scale-110 duration-300 h-full",
                        placeholder: unref(img)(`${unref(siteurl).site_url}/logo/placeholder.jpg`)
                      }, null, 8, ["src", "placeholder"])
                    ]),
                    createVNode("div", { class: "flex flex-col gap-3 mt-2" }, [
                      createVNode("h3", { class: "cat-postheading text-xl group-hover:text-[#ff0000] leading-[24px] text-[#121212]" }, toDisplayString((_e2 = unref(categoryContent)[4]) == null ? void 0 : _e2.content_heading), 1),
                      createVNode(_component_ClientOnly, null, {
                        default: withCtx(() => {
                          var _a4;
                          return [
                            createVNode("div", {
                              class: "cat-postdesc text-[15px] font-[300] text-[#555555]",
                              innerHTML: `${(_a4 = unref(categoryContent)[4]) == null ? void 0 : _a4.content_details.substring(0, 155)}...`
                            }, null, 8, ["innerHTML"])
                          ];
                        }),
                        _: 1
                      }),
                      createVNode("small", { class: "cat-postdate" }, " \u09AA\u09CD\u09B0\u0995\u09BE\u09B6: " + toDisplayString(postCreatedDate((_f2 = unref(categoryContent)[4]) == null ? void 0 : _f2.created_at)), 1)
                    ])
                  ];
                }
              }),
              _: 1
            }, _parent));
          } else {
            _push(`<!---->`);
          }
          _push(`<div class="col-span-12 cat-inside-ads" data-v-12d79d1a>`);
          if (unref(categoryBottomAds).status === 1) {
            _push(`<div class="py-4 mt-16 border-b border-t border-b-[#e2e2e2] border-t-[#e2e2e2]" data-v-12d79d1a>`);
            _push(ssrRenderComponent(_component_AdsDesktopCategoryBottom, { categoryBottomAds: unref(categoryBottomAds) }, null, _parent));
            _push(`</div>`);
          } else {
            _push(`<!---->`);
          }
          _push(`</div></div>`);
        } else {
          _push(`<!---->`);
        }
        _push(`<div class="category-post-list grid grid-cols-12 mt-4" data-v-12d79d1a><div class="col-span-2 hidden md:block" data-v-12d79d1a></div><div class="col-span-12 md:col-span-8" data-v-12d79d1a><!--[-->`);
        ssrRenderList(unref(categoryContentExcept), (catPost, cpInx) => {
          var _a3;
          _push(`<div class="cat-post-item py-4 border-b" data-v-12d79d1a>`);
          _push(ssrRenderComponent(_component_NuxtLink, {
            to: `/category/${(_a3 = catPost == null ? void 0 : catPost.category) == null ? void 0 : _a3.cat_slug}/${catPost == null ? void 0 : catPost.content_id}`,
            class: "grid grid-cols-12 gap-3 group"
          }, {
            default: withCtx((_, _push2, _parent2, _scopeId) => {
              if (_push2) {
                _push2(`<h3 class="cat-title col-span-12 text-[20px] group-hover:text-[#ff0000]" data-v-12d79d1a${_scopeId}>${ssrInterpolate(catPost == null ? void 0 : catPost.content_heading)}</h3><div class="col-span-7 flex flex-col gap-3" data-v-12d79d1a${_scopeId}>`);
                _push2(ssrRenderComponent(_component_ClientOnly, null, {}, _parent2, _scopeId));
                _push2(`<span class="post-date flex flex-col gap-1" data-v-12d79d1a${_scopeId}><small class="text-[#555555]" data-v-12d79d1a${_scopeId}>\u0986\u09AA\u09A1\u09C7\u099F: ${ssrInterpolate(postCreatedDate(catPost == null ? void 0 : catPost.updated_at))}</small><small class="text-[#555555]" data-v-12d79d1a${_scopeId}>\u09AA\u09CD\u09B0\u0995\u09BE\u09B6: ${ssrInterpolate(postCreatedDate(catPost == null ? void 0 : catPost.created_at))}</small></span></div><div class="col-span-5 category-post-image overflow-hidden" data-v-12d79d1a${_scopeId}>`);
                _push2(ssrRenderComponent(_component_nuxt_img, {
                  src: `${unref(siteurl).site_url}/media/content/images/${catPost == null ? void 0 : catPost.img_bg_path}`,
                  class: "mx-auto w-full group-hover:scale-110 duration-300",
                  placeholder: unref(img)(`${unref(siteurl).site_url}/logo/placeholder.jpg`)
                }, null, _parent2, _scopeId));
                _push2(`</div>`);
              } else {
                return [
                  createVNode("h3", { class: "cat-title col-span-12 text-[20px] group-hover:text-[#ff0000]" }, toDisplayString(catPost == null ? void 0 : catPost.content_heading), 1),
                  createVNode("div", { class: "col-span-7 flex flex-col gap-3" }, [
                    createVNode(_component_ClientOnly, null, {
                      default: withCtx(() => [
                        createVNode("div", {
                          class: "cat-desc text-[#555555] text-[15px] font-[300]",
                          innerHTML: `${catPost == null ? void 0 : catPost.content_details.substring(0, 160)}...`
                        }, null, 8, ["innerHTML"])
                      ]),
                      _: 2
                    }, 1024),
                    createVNode("span", { class: "post-date flex flex-col gap-1" }, [
                      createVNode("small", { class: "text-[#555555]" }, "\u0986\u09AA\u09A1\u09C7\u099F: " + toDisplayString(postCreatedDate(catPost == null ? void 0 : catPost.updated_at)), 1),
                      createVNode("small", { class: "text-[#555555]" }, "\u09AA\u09CD\u09B0\u0995\u09BE\u09B6: " + toDisplayString(postCreatedDate(catPost == null ? void 0 : catPost.created_at)), 1)
                    ])
                  ]),
                  createVNode("div", { class: "col-span-5 category-post-image overflow-hidden" }, [
                    createVNode(_component_nuxt_img, {
                      src: `${unref(siteurl).site_url}/media/content/images/${catPost == null ? void 0 : catPost.img_bg_path}`,
                      class: "mx-auto w-full group-hover:scale-110 duration-300",
                      placeholder: unref(img)(`${unref(siteurl).site_url}/logo/placeholder.jpg`)
                    }, null, 8, ["src", "placeholder"])
                  ])
                ];
              }
            }),
            _: 2
          }, _parent));
          _push(`</div>`);
        });
        _push(`<!--]--></div><div class="col-span-2 hidden md:block" data-v-12d79d1a></div></div>`);
        if (((_t = unref(categoryContent)) == null ? void 0 : _t.length) > 10) {
          _push(`<div class="flex justify-center items-center" data-v-12d79d1a><button class="border border-[#dee2e6] text-[#3375af] px-8 py-2 rounded-sm mt-5 hover:border-[#3375af]" data-v-12d79d1a><b data-v-12d79d1a>\u0986\u09B0\u0993</b></button></div>`);
        } else {
          _push(`<!---->`);
        }
        _push(`</div>`);
      } else {
        _push(`<div class="col-span-12 md:col-span-9 md:border-r md:pr-3" data-v-12d79d1a><h2 class="text-2xl text-center py-8" data-v-12d79d1a>\u0986\u09AA\u09A8\u09BF \u09AF\u09C7 \u09AC\u09BF\u09B7\u09AF\u09BC\u099F\u09BF \u0985\u09A8\u09C1\u09B8\u09A8\u09CD\u09A7\u09BE\u09A8 \u0995\u09B0\u099B\u09C7\u09A8 \u09A4\u09BE \u0996\u09C1\u099C\u09C7 \u09AA\u09BE\u0993\u09AF\u09BC\u09BE \u09AF\u09BE\u09AF\u09BC\u09A8\u09BF</h2></div>`);
      }
      _push(`<div class="col-span-12 md:col-span-3" data-v-12d79d1a>`);
      if (unref(categoryRightOneAds).status === 1) {
        _push(`<div class="py-4 border-b border-b-[#e2e2e2] mb-3" data-v-12d79d1a>`);
        _push(ssrRenderComponent(_component_AdsDesktopCategoryRightOne, { categoryRightOneAds: unref(categoryRightOneAds) }, null, _parent));
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<div class="${ssrRenderClass(`sticky ${unref(stickyScroll) ? " top-44" : "top-16"} duration-200`)}" data-v-12d79d1a>`);
      _push(ssrRenderComponent(_component_Tabs, null, null, _parent));
      if (unref(categoryRightTwoAds).status === 1) {
        _push(`<div class="py-4 border-b border-b-[#e2e2e2] border-t border-t-[#e2e2e2] mt-4" data-v-12d79d1a>`);
        _push(ssrRenderComponent(_component_AdsDesktopCategoryRightTwo, { categoryRightTwoAds: unref(categoryRightTwoAds) }, null, _parent));
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      if (unref(categoryRightThreeAds).status === 1) {
        _push(`<div class="py-4 border-b border-b-[#e2e2e2] border-t border-t-[#e2e2e2] mt-4" data-v-12d79d1a>`);
        _push(ssrRenderComponent(_component_AdsDesktopCategoryRightThree, { categoryRightThreeAds: unref(categoryRightThreeAds) }, null, _parent));
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div></div>`);
      if (unref(categoryBottomAds).status === 1) {
        _push(`<div class="py-4 mt-16 border-b border-t border-b-[#e2e2e2] border-t-[#e2e2e2]" data-v-12d79d1a>`);
        _push(ssrRenderComponent(_component_AdsDesktopCategoryBottom, { categoryBottomAds: unref(categoryBottomAds) }, null, _parent));
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/[category]/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const index = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-12d79d1a"]]);

export { index as default };
//# sourceMappingURL=index-ec8d8568.mjs.map
