const latest_vue_vue_type_style_index_0_scoped_2438688d_lang = '.subcategory .subcategoryLink[data-v-2438688d]:not(:last-child):after{background:#3375af;border-radius:100%;content:"";display:inline-block;height:7px;margin-bottom:3px;margin-left:10px;width:7px}.cat-box[data-v-2438688d]:last-child{border-right:0!important}.lead-overly[data-v-2438688d]{background:linear-gradient(180deg,hsla(0,0%,100%,0) 0,rgba(53,50,50,.9) 75%,#000)}';

const latestStyles_327c082a = [latest_vue_vue_type_style_index_0_scoped_2438688d_lang, latest_vue_vue_type_style_index_0_scoped_2438688d_lang];

export { latestStyles_327c082a as default };
//# sourceMappingURL=latest-styles.327c082a.mjs.map
