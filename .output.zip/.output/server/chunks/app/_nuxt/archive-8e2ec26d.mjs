import { H as Head, T as Title } from './components-5bc40629.mjs';
import __nuxt_component_0 from './Icon-ec29c746.mjs';
import { _ as __nuxt_component_0$1 } from './nuxt-link-c659c711.mjs';
import { _ as __nuxt_component_4 } from './client-only-0841c2aa.mjs';
import { u as useImage, s as siteUrlState, a as singlePageStickyState, b as useFetch, _ as __nuxt_component_1 } from './state-7a7e2860.mjs';
import { ref, computed, withAsyncContext, mergeProps, withCtx, createTextVNode, createVNode, unref, toDisplayString, useSSRContext } from 'vue';
import { u as useState } from './state-b54abad0.mjs';
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderAttr, ssrRenderList, ssrInterpolate, ssrRenderClass } from 'vue/server-renderer';
import { _ as _imports_0 } from './bar-ads-359c1719.mjs';
import './index-6a088328.mjs';
import '../server.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'ipx';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import './config-a9056531.mjs';
import '@iconify/vue/dist/offline';
import '@iconify/vue';
import '../../handlers/renderer.mjs';
import 'vue-bundle-renderer/runtime';
import 'devalue';
import '@unhead/ssr';

const _sfc_main = {
  __name: "archive",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    const img = useImage();
    const siteurl = siteUrlState();
    ref(/* @__PURE__ */ new Date());
    ref([
      {
        key: "today",
        highlight: {
          color: "#284f81",
          fillMode: "solid"
        }
      }
    ]);
    const singlePageSticky = singlePageStickyState();
    const stickyScroll = computed(
      () => singlePageSticky.value
    );
    const getDate = new Intl.DateTimeFormat("bn-bd", { year: "numeric", month: "long", day: "numeric", hour: "numeric", minute: "numeric" });
    const postCreatedDate = (date) => {
      return getDate.format(new Date(date)).replace("\u098F", "|").replace("PM", "\u09AA\u09BF\u098F\u09AE").replace("AM", "\u098F\u098F\u09AE");
    };
    ref(true);
    ref(false);
    const archiveContents = useState(() => [], "$uMkJzPXCFg");
    const take = ref(10);
    const { data: arcvCon } = ([__temp, __restore] = withAsyncContext(() => useFetch("/api/archive/getarchive", {
      method: "POST",
      body: {
        date: "",
        take: take.value
      }
    }, "$rMSvMzy0xX")), __temp = await __temp, __restore(), __temp);
    archiveContents.value = arcvCon;
    return (_ctx, _push, _parent, _attrs) => {
      var _a, _b;
      const _component_Head = Head;
      const _component_Title = Title;
      const _component_Icon = __nuxt_component_0;
      const _component_NuxtLink = __nuxt_component_0$1;
      const _component_ClientOnly = __nuxt_component_4;
      const _component_nuxt_img = __nuxt_component_1;
      const _component_client_only = __nuxt_component_4;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "category-page" }, _attrs))}>`);
      _push(ssrRenderComponent(_component_Head, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_Title, null, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`\u0986\u09B0\u09CD\u0995\u09BE\u0987\u09AD`);
                } else {
                  return [
                    createTextVNode("\u0986\u09B0\u09CD\u0995\u09BE\u0987\u09AD")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_Title, null, {
                default: withCtx(() => [
                  createTextVNode("\u0986\u09B0\u09CD\u0995\u09BE\u0987\u09AD")
                ]),
                _: 1
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<div class="category-ads-section border-b border-b-[#dee2e6] py-4"><div class="bg-[#f7f7f7]"><a target="_blank" href="/"><img class="mx-auto"${ssrRenderAttr("src", _imports_0)} alt=""></a></div></div><div class="max-w-[1280px] mx-auto category-content px-4 md:px-2 py-4 relative"><div class="breadcrump border-b border-b-[#dee2e6] pb-2 mb-5 flex flex-col gap-2 md:gap-4"><div class="tag-title md:py-6 flex gap-3 items-center">`);
      _push(ssrRenderComponent(_component_Icon, {
        name: "ri:archive-2-fill",
        class: "text-[#3375af] text-3xl"
      }, null, _parent));
      _push(`<h1 class="text-xl md:text-3xl text-[#3375af] font-semibold">\u0986\u09B0\u09CD\u0995\u09BE\u0987\u09AD</h1></div></div><div class="grid grid-cols-12 gap-8 md:gap-3"><div class="col-span-12 md:col-span-9 md:border-r md:pr-3"><div class="category-post-list grid grid-cols-12"><div class="col-span-2 hidden md:block"></div><div class="col-span-12 md:col-span-8">`);
      if (((_a = unref(archiveContents)) == null ? void 0 : _a.length) > 0) {
        _push(`<!--[-->`);
        ssrRenderList(unref(archiveContents), (archiveContent, cpInx) => {
          var _a2;
          _push(`<div class="cat-post-item py-4 border-b">`);
          _push(ssrRenderComponent(_component_NuxtLink, {
            to: `/category/${(_a2 = archiveContent == null ? void 0 : archiveContent.category) == null ? void 0 : _a2.cat_slug}/${archiveContent == null ? void 0 : archiveContent.content_id}`,
            class: "grid grid-cols-12 gap-3 group"
          }, {
            default: withCtx((_, _push2, _parent2, _scopeId) => {
              if (_push2) {
                _push2(`<h3 class="cat-title col-span-12 text-[20px] group-hover:text-[#ff0000]"${_scopeId}>${ssrInterpolate(archiveContent == null ? void 0 : archiveContent.content_heading)}</h3><div class="col-span-7 flex flex-col gap-3"${_scopeId}>`);
                _push2(ssrRenderComponent(_component_ClientOnly, null, {}, _parent2, _scopeId));
                _push2(`<span class="post-date flex flex-col gap-1"${_scopeId}><small class="text-[#555555]"${_scopeId}>\u0986\u09AA\u09A1\u09C7\u099F: ${ssrInterpolate(postCreatedDate(archiveContent == null ? void 0 : archiveContent.updated_at))}</small><small class="text-[#555555]"${_scopeId}>\u09AA\u09CD\u09B0\u0995\u09BE\u09B6: ${ssrInterpolate(postCreatedDate(archiveContent == null ? void 0 : archiveContent.created_at))}</small></span></div><div class="col-span-5 category-post-image overflow-hidden"${_scopeId}>`);
                _push2(ssrRenderComponent(_component_nuxt_img, {
                  src: `${unref(siteurl).site_url}/media/content/images/${archiveContent == null ? void 0 : archiveContent.img_bg_path}`,
                  class: "mx-auto w-full group-hover:scale-110 duration-300",
                  placeholder: unref(img)(`${unref(siteurl).site_url}/logo/placeholder.jpg`)
                }, null, _parent2, _scopeId));
                _push2(`</div>`);
              } else {
                return [
                  createVNode("h3", { class: "cat-title col-span-12 text-[20px] group-hover:text-[#ff0000]" }, toDisplayString(archiveContent == null ? void 0 : archiveContent.content_heading), 1),
                  createVNode("div", { class: "col-span-7 flex flex-col gap-3" }, [
                    createVNode(_component_ClientOnly, null, {
                      default: withCtx(() => [
                        createVNode("div", {
                          class: "cat-desc text-[#555555] text-[15px] font-[300]",
                          innerHTML: archiveContent == null ? void 0 : archiveContent.content_details.substring(0, 160)
                        }, null, 8, ["innerHTML"])
                      ]),
                      _: 2
                    }, 1024),
                    createVNode("span", { class: "post-date flex flex-col gap-1" }, [
                      createVNode("small", { class: "text-[#555555]" }, "\u0986\u09AA\u09A1\u09C7\u099F: " + toDisplayString(postCreatedDate(archiveContent == null ? void 0 : archiveContent.updated_at)), 1),
                      createVNode("small", { class: "text-[#555555]" }, "\u09AA\u09CD\u09B0\u0995\u09BE\u09B6: " + toDisplayString(postCreatedDate(archiveContent == null ? void 0 : archiveContent.created_at)), 1)
                    ])
                  ]),
                  createVNode("div", { class: "col-span-5 category-post-image overflow-hidden" }, [
                    createVNode(_component_nuxt_img, {
                      src: `${unref(siteurl).site_url}/media/content/images/${archiveContent == null ? void 0 : archiveContent.img_bg_path}`,
                      class: "mx-auto w-full group-hover:scale-110 duration-300",
                      placeholder: unref(img)(`${unref(siteurl).site_url}/logo/placeholder.jpg`)
                    }, null, 8, ["src", "placeholder"])
                  ])
                ];
              }
            }),
            _: 2
          }, _parent));
          _push(`</div>`);
        });
        _push(`<!--]-->`);
      } else {
        _push(`<div><h2 class="text-4xl">\u0995\u09CB\u09A8\u09CB \u09A4\u09A5\u09CD\u09AF \u09AA\u09BE\u0993\u09AF\u09BC\u09BE \u09AF\u09BE\u09AF\u09BC\u09A8\u09BF</h2></div>`);
      }
      _push(`</div><div class="col-span-2 hidden md:block"></div></div>`);
      if (((_b = unref(archiveContents)) == null ? void 0 : _b.length) > 0) {
        _push(`<div class="flex justify-center items-center"><button class="border border-[#dee2e6] text-[#3375af] px-8 py-2 rounded-sm mt-5 hover:border-[#3375af]"><b>\u0986\u09B0\u0993</b></button></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div><div class="col-span-12 md:col-span-3"><div class="${ssrRenderClass(`sticky ${unref(stickyScroll) ? " top-44" : "top-16"}`)}">`);
      _push(ssrRenderComponent(_component_client_only, null, {}, _parent));
      _push(`</div></div></div></div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/archive.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=archive-8e2ec26d.mjs.map
