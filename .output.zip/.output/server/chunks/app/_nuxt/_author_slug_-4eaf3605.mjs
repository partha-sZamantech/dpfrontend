import { H as Head, T as Title } from './components-5bc40629.mjs';
import __nuxt_component_0 from './Icon-ec29c746.mjs';
import { _ as __nuxt_component_0$1 } from './nuxt-link-c659c711.mjs';
import { _ as __nuxt_component_4 } from './client-only-0841c2aa.mjs';
import { u as useImage, s as siteUrlState, a as singlePageStickyState, b as useFetch, _ as __nuxt_component_1 } from './state-7a7e2860.mjs';
import { _ as __nuxt_component_6 } from './Tabs-8fde547c.mjs';
import { computed, ref, withAsyncContext, mergeProps, withCtx, unref, createTextVNode, toDisplayString, createVNode, useSSRContext } from 'vue';
import { u as useRoute } from '../server.mjs';
import { u as useState } from './state-b54abad0.mjs';
import { ssrRenderAttrs, ssrRenderComponent, ssrInterpolate, ssrRenderAttr, ssrRenderList } from 'vue/server-renderer';
import { _ as _imports_0 } from './bar-ads-359c1719.mjs';
import './index-6a088328.mjs';
import '@unhead/shared';
import './config-a9056531.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'ipx';
import '@iconify/vue/dist/offline';
import '@iconify/vue';
import 'unhead';
import 'vue-router';
import '../../handlers/renderer.mjs';
import 'vue-bundle-renderer/runtime';
import 'devalue';
import '@unhead/ssr';

const _sfc_main = {
  __name: "[author_slug]",
  __ssrInlineRender: true,
  async setup(__props) {
    var _a, _b;
    let __temp, __restore;
    const img = useImage();
    const siteurl = siteUrlState();
    const singlePageSticky = singlePageStickyState();
    const stickyScroll = computed(
      () => singlePageSticky.value
    );
    const author_slug = useRoute().params.author_slug;
    const getDate = new Intl.DateTimeFormat("bn-bd", { year: "numeric", month: "long", day: "numeric", hour: "numeric", minute: "numeric" });
    const postCreatedDate = (date) => {
      if (date) {
        return getDate.format(new Date(date)).replace("\u098F", "|").replace("PM", "\u09AA\u09BF\u098F\u09AE").replace("AM", "\u098F\u098F\u09AE");
      }
    };
    const author = ref(null);
    const authorContents = useState(() => [], "$qDaGhrNcky");
    const take = ref(10);
    const { data: authorcont } = ([__temp, __restore] = withAsyncContext(() => useFetch("/api/author/getauthorcontent", {
      method: "POST",
      body: {
        author_slug,
        take: take.value
      }
    }, "$P9HYg5par4")), __temp = await __temp, __restore(), __temp);
    authorContents.value = (_a = authorcont == null ? void 0 : authorcont.value) == null ? void 0 : _a.content;
    author.value = (_b = authorcont == null ? void 0 : authorcont.value) == null ? void 0 : _b.author;
    return (_ctx, _push, _parent, _attrs) => {
      var _a2, _b2;
      const _component_Head = Head;
      const _component_Title = Title;
      const _component_Icon = __nuxt_component_0;
      const _component_NuxtLink = __nuxt_component_0$1;
      const _component_ClientOnly = __nuxt_component_4;
      const _component_nuxt_img = __nuxt_component_1;
      const _component_Tabs = __nuxt_component_6;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "category-page" }, _attrs))}>`);
      _push(ssrRenderComponent(_component_Head, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_Title, null, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                var _a3, _b3;
                if (_push3) {
                  _push3(`${ssrInterpolate((_a3 = unref(author)) == null ? void 0 : _a3.author_name_bn)}`);
                } else {
                  return [
                    createTextVNode(toDisplayString((_b3 = unref(author)) == null ? void 0 : _b3.author_name_bn), 1)
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_Title, null, {
                default: withCtx(() => {
                  var _a3;
                  return [
                    createTextVNode(toDisplayString((_a3 = unref(author)) == null ? void 0 : _a3.author_name_bn), 1)
                  ];
                }),
                _: 1
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<div class="category-ads-section border-b border-b-[#dee2e6] py-4"><div class="bg-[#f7f7f7]"><a target="_blank" href="/"><img class="mx-auto"${ssrRenderAttr("src", _imports_0)} alt=""></a></div></div><div class="max-w-[1280px] mx-auto category-content px-4 md:px-2 py-4 relative"><div class="breadcrump border-b border-b-[#dee2e6] pb-2 mb-5 flex flex-col gap-2 md:gap-4"><div class="tag-title md:py-6 flex gap-3 items-center">`);
      _push(ssrRenderComponent(_component_Icon, {
        name: "mdi:fountain-pen-tip",
        class: "text-[#3375af] text-4xl"
      }, null, _parent));
      _push(`<h1 class="text-xl md:text-3xl text-[#3375af] font-semibold">${ssrInterpolate((_a2 = unref(author)) == null ? void 0 : _a2.author_name_bn)}</h1></div></div><div class="grid grid-cols-12 gap-8 md:gap-3"><div class="col-span-12 md:col-span-9 md:border-r md:pr-3"><div class="category-post-list grid grid-cols-12"><div class="col-span-2 hidden md:block"></div><div class="col-span-12 md:col-span-8"><!--[-->`);
      ssrRenderList(unref(authorContents), (authorContent, autInx) => {
        var _a3;
        _push(`<div class="cat-post-item py-4 border-b">`);
        _push(ssrRenderComponent(_component_NuxtLink, {
          to: `/category/${(_a3 = authorContent == null ? void 0 : authorContent.category) == null ? void 0 : _a3.cat_slug}/${authorContent == null ? void 0 : authorContent.content_id}`,
          class: "grid grid-cols-12 gap-3 group"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<h3 class="cat-title col-span-12 text-[20px] group-hover:text-[#ff0000]"${_scopeId}>${ssrInterpolate(authorContent == null ? void 0 : authorContent.content_heading)}</h3><div class="col-span-7 flex flex-col gap-3"${_scopeId}>`);
              _push2(ssrRenderComponent(_component_ClientOnly, null, {}, _parent2, _scopeId));
              _push2(`<span class="post-date flex flex-col gap-1"${_scopeId}><small class="text-[#555555]"${_scopeId}>\u0986\u09AA\u09A1\u09C7\u099F: ${ssrInterpolate(postCreatedDate(authorContent == null ? void 0 : authorContent.updated_at))}</small><small class="text-[#555555]"${_scopeId}>\u09AA\u09CD\u09B0\u0995\u09BE\u09B6: ${ssrInterpolate(postCreatedDate(authorContent == null ? void 0 : authorContent.created_at))}</small></span></div><div class="col-span-5 category-post-image overflow-hidden"${_scopeId}>`);
              _push2(ssrRenderComponent(_component_nuxt_img, {
                src: `${unref(siteurl).site_url}/media/content/images/${authorContent == null ? void 0 : authorContent.img_bg_path}`,
                class: "mx-auto w-full group-hover:scale-110 duration-300",
                placeholder: unref(img)(`${unref(siteurl).site_url}/logo/placeholder.jpg`)
              }, null, _parent2, _scopeId));
              _push2(`</div>`);
            } else {
              return [
                createVNode("h3", { class: "cat-title col-span-12 text-[20px] group-hover:text-[#ff0000]" }, toDisplayString(authorContent == null ? void 0 : authorContent.content_heading), 1),
                createVNode("div", { class: "col-span-7 flex flex-col gap-3" }, [
                  createVNode(_component_ClientOnly, null, {
                    default: withCtx(() => [
                      createVNode("div", {
                        class: "cat-desc text-[#555555] text-[15px] font-[300]",
                        innerHTML: `${authorContent == null ? void 0 : authorContent.content_details.substring(0, 160)}...`
                      }, null, 8, ["innerHTML"])
                    ]),
                    _: 2
                  }, 1024),
                  createVNode("span", { class: "post-date flex flex-col gap-1" }, [
                    createVNode("small", { class: "text-[#555555]" }, "\u0986\u09AA\u09A1\u09C7\u099F: " + toDisplayString(postCreatedDate(authorContent == null ? void 0 : authorContent.updated_at)), 1),
                    createVNode("small", { class: "text-[#555555]" }, "\u09AA\u09CD\u09B0\u0995\u09BE\u09B6: " + toDisplayString(postCreatedDate(authorContent == null ? void 0 : authorContent.created_at)), 1)
                  ])
                ]),
                createVNode("div", { class: "col-span-5 category-post-image overflow-hidden" }, [
                  createVNode(_component_nuxt_img, {
                    src: `${unref(siteurl).site_url}/media/content/images/${authorContent == null ? void 0 : authorContent.img_bg_path}`,
                    class: "mx-auto w-full group-hover:scale-110 duration-300",
                    placeholder: unref(img)(`${unref(siteurl).site_url}/logo/placeholder.jpg`)
                  }, null, 8, ["src", "placeholder"])
                ])
              ];
            }
          }),
          _: 2
        }, _parent));
        _push(`</div>`);
      });
      _push(`<!--]--></div><div class="col-span-2 hidden md:block"></div></div>`);
      if (((_b2 = unref(authorContents)) == null ? void 0 : _b2.length) > 9) {
        _push(`<div class="flex justify-center items-center"><button class="border border-[#dee2e6] text-[#3375af] px-8 py-2 rounded-sm mt-5 hover:border-[#3375af]"><b>\u0986\u09B0\u0993</b></button></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div><div class="col-span-12 md:col-span-3">`);
      _push(ssrRenderComponent(_component_Tabs, {
        class: `sticky ${unref(stickyScroll) ? " top-44" : "top-16"}`
      }, null, _parent));
      _push(`</div></div></div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/author/[author_slug].vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=_author_slug_-4eaf3605.mjs.map
