const _content_id__vue_vue_type_style_index_0_scoped_d0382835_lang = "p[data-v-d0382835]{line-height:1.7!important}";

const _content_id_Styles_5c955b43 = [_content_id__vue_vue_type_style_index_0_scoped_d0382835_lang, _content_id__vue_vue_type_style_index_0_scoped_d0382835_lang];

export { _content_id_Styles_5c955b43 as default };
//# sourceMappingURL=_content_id_-styles.5c955b43.mjs.map
