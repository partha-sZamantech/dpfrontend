import { _ as __nuxt_component_0 } from './nuxt-link-c659c711.mjs';
import { u as useImage, s as siteUrlState, b as useFetch } from './state-7a7e2860.mjs';
import { ref, withAsyncContext, mergeProps, unref, withCtx, createVNode, toDisplayString, useSSRContext } from 'vue';
import { u as useState } from './state-b54abad0.mjs';
import { ssrRenderAttrs, ssrRenderClass, ssrRenderList, ssrRenderComponent, ssrInterpolate } from 'vue/server-renderer';
import { _ as _export_sfc } from '../server.mjs';

const _sfc_main = {
  __name: "Tabs",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    useImage();
    const isActiveStatus = ref(false);
    siteUrlState();
    const latestposts = useState(() => [], "$qHeAee1wJg");
    const { data: latpost } = ([__temp, __restore] = withAsyncContext(() => useFetch(`/api/home/latestposts`, {
      method: "GET"
    }, "$HYbTZNIgJJ")), __temp = await __temp, __restore(), __temp);
    latestposts.value = latpost;
    const popularposts = useState(() => [], "$eX8t0iPnZ2");
    const { data: hplpost } = ([__temp, __restore] = withAsyncContext(() => useFetch(`/api/home/popularposts`, {
      method: "GET"
    }, "$c3MRShq0uh")), __temp = await __temp, __restore(), __temp);
    popularposts.value = hplpost;
    const toBn = (n) => n.replace(/\d/g, (d) => "\u09E6\u09E7\u09E8\u09E9\u09EA\u09EB\u09EC\u09ED\u09EE\u09EF"[d]);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_NuxtLink = __nuxt_component_0;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "home-post-tabs" }, _attrs))} data-v-8248e33c><div class="grid grid-cols-2 text-[17px] text-center border-b border-b-[#0000006b]" data-v-8248e33c>`);
      if (unref(isActiveStatus) === false) {
        _push(`<div class="${ssrRenderClass(` border-b-2 border-b-[#3375af]`)}" data-v-8248e33c><b data-v-8248e33c>\u09B8\u09B0\u09CD\u09AC\u09B6\u09C7\u09B7</b></div>`);
      } else {
        _push(`<div class="${ssrRenderClass(`hover:border-b-[#3375af]  cursor-pointer`)}" data-v-8248e33c><b data-v-8248e33c>\u09B8\u09B0\u09CD\u09AC\u09B6\u09C7\u09B7</b></div>`);
      }
      if (unref(isActiveStatus) === true) {
        _push(`<div class="${ssrRenderClass(`border-b-2 border-b-[#3375af]  py-1`)}" data-v-8248e33c><b data-v-8248e33c>\u09B8\u09B0\u09CD\u09AC\u09BE\u09A7\u09BF\u0995 \u09AA\u09A0\u09BF\u09A4</b></div>`);
      } else {
        _push(`<div class="${ssrRenderClass(`hover:border-b-[#3375af] cursor-pointer py-1`)}" data-v-8248e33c><b data-v-8248e33c>\u09B8\u09B0\u09CD\u09AC\u09BE\u09A7\u09BF\u0995 \u09AA\u09A0\u09BF\u09A4</b></div>`);
      }
      _push(`</div>`);
      if (unref(isActiveStatus) === false) {
        _push(`<div class="latest-post px-1 h-[430px] overflow-y-auto mt-2" data-v-8248e33c><!--[-->`);
        ssrRenderList(unref(latestposts), (latstpost, Linx) => {
          var _a;
          _push(ssrRenderComponent(_component_NuxtLink, {
            to: `/category/${(_a = latstpost == null ? void 0 : latstpost.category) == null ? void 0 : _a.cat_slug}/${latstpost == null ? void 0 : latstpost.content_id}`,
            class: "latest-post-loop py-3 flex gap-2 border-b border-b-[#e2e2e2] group",
            key: latstpost == null ? void 0 : latstpost.content_id
          }, {
            default: withCtx((_, _push2, _parent2, _scopeId) => {
              if (_push2) {
                _push2(`<span class="number-count text-[26px] text-[#949494]" data-v-8248e33c${_scopeId}><b data-v-8248e33c${_scopeId}>${ssrInterpolate(toBn(`${Linx + 1}`))}.</b></span><h4 class="text-[20px] group-hover:text-[#ff0000] text-[#121212] leading-6" data-v-8248e33c${_scopeId}>${ssrInterpolate(latstpost == null ? void 0 : latstpost.content_heading)}</h4>`);
              } else {
                return [
                  createVNode("span", { class: "number-count text-[26px] text-[#949494]" }, [
                    createVNode("b", null, toDisplayString(toBn(`${Linx + 1}`)) + ".", 1)
                  ]),
                  createVNode("h4", { class: "text-[20px] group-hover:text-[#ff0000] text-[#121212] leading-6" }, toDisplayString(latstpost == null ? void 0 : latstpost.content_heading), 1)
                ];
              }
            }),
            _: 2
          }, _parent));
        });
        _push(`<!--]--></div>`);
      } else {
        _push(`<div class="latest-post px-1 h-[430px] overflow-y-auto mt-2" data-v-8248e33c><!--[-->`);
        ssrRenderList(unref(popularposts), (poplarpost, Pinx) => {
          var _a;
          _push(ssrRenderComponent(_component_NuxtLink, {
            to: `/category/${(_a = poplarpost == null ? void 0 : poplarpost.category) == null ? void 0 : _a.cat_slug}/${poplarpost == null ? void 0 : poplarpost.content_id}`,
            class: "latest-post-loop py-3 flex gap-2 border-b border-b-[#e2e2e2] group",
            key: poplarpost == null ? void 0 : poplarpost.content_id
          }, {
            default: withCtx((_, _push2, _parent2, _scopeId) => {
              if (_push2) {
                _push2(`<span class="number-count text-[26px] text-[#949494]" data-v-8248e33c${_scopeId}><b data-v-8248e33c${_scopeId}>${ssrInterpolate(toBn(`${Pinx + 1}`))}.</b></span><h4 class="text-[20px] group-hover:text-[#ff0000] text-[#121212] leading-6" data-v-8248e33c${_scopeId}>${ssrInterpolate(poplarpost == null ? void 0 : poplarpost.content_heading)}</h4>`);
              } else {
                return [
                  createVNode("span", { class: "number-count text-[26px] text-[#949494]" }, [
                    createVNode("b", null, toDisplayString(toBn(`${Pinx + 1}`)) + ".", 1)
                  ]),
                  createVNode("h4", { class: "text-[20px] group-hover:text-[#ff0000] text-[#121212] leading-6" }, toDisplayString(poplarpost == null ? void 0 : poplarpost.content_heading), 1)
                ];
              }
            }),
            _: 2
          }, _parent));
        });
        _push(`<!--]--></div>`);
      }
      _push(`</div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Tabs.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const __nuxt_component_6 = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-8248e33c"]]);

export { __nuxt_component_6 as _ };
//# sourceMappingURL=Tabs-8fde547c.mjs.map
