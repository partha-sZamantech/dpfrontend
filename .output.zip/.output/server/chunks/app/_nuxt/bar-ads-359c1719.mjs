import { p as publicAssetsURL } from '../../handlers/renderer.mjs';

const _imports_0 = "" + publicAssetsURL("assets/img/bar-ads.gif");

export { _imports_0 as _ };
//# sourceMappingURL=bar-ads-359c1719.mjs.map
