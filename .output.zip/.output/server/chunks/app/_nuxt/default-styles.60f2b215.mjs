const DesktopSideMenu_vue_vue_type_style_index_0_scoped_9480f5c6_lang = "[data-v-9480f5c6]::-webkit-scrollbar{width:10px}[data-v-9480f5c6]::-webkit-scrollbar-track{background:#fff}[data-v-9480f5c6]::-webkit-scrollbar-thumb{background:#c9c3c3;border-radius:5px}[data-v-9480f5c6]::-webkit-scrollbar-thumb:hover{background:#bdb8b8}";

const HeaderTopMenu_vue_vue_type_style_index_0_scoped_4d516d5c_lang = ".router-link-active[data-v-4d516d5c]{background-color:#284f81;border-bottom:2px solid #fff}";

const Bottom_vue_vue_type_style_index_0_scoped_36b60ab6_lang = '.footer-bottom a[data-v-36b60ab6]:after{color:#ccc;content:"\\2022";font-size:20px;padding-left:6px;padding-top:4px}.copyright[data-v-36b60ab6]:after{content:"|";display:inline-block;padding-left:7px;padding-right:7px}.footer-bottom a[data-v-36b60ab6]:last-child:after{content:""}';

const defaultStyles_60f2b215 = [DesktopSideMenu_vue_vue_type_style_index_0_scoped_9480f5c6_lang, HeaderTopMenu_vue_vue_type_style_index_0_scoped_4d516d5c_lang, Bottom_vue_vue_type_style_index_0_scoped_36b60ab6_lang];

export { defaultStyles_60f2b215 as default };
//# sourceMappingURL=default-styles.60f2b215.mjs.map
