const client_manifest = {
  "Tabs.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "Tabs.5a2ef5c0.css",
    "src": "Tabs.css"
  },
  "_Tabs.ff47f975.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "Tabs.5a2ef5c0.css"
    ],
    "file": "Tabs.ff47f975.js",
    "imports": [
      "_nuxt-link.d02788a2.js",
      "_state.c48472a6.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_state.ef023967.js"
    ]
  },
  "Tabs.5a2ef5c0.css": {
    "file": "Tabs.5a2ef5c0.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_bar-ads.7ba90135.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "bar-ads.7ba90135.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_client-only.2f9174c4.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "client-only.2f9174c4.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_components.03621c65.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "components.03621c65.js",
    "imports": [
      "_vue.f36acd1f.94f9b2dd.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_nuxt-link.d02788a2.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "nuxt-link.d02788a2.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_state.c48472a6.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "state.c48472a6.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_vue.f36acd1f.94f9b2dd.js",
      "_state.ef023967.js"
    ]
  },
  "_state.ef023967.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "state.ef023967.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_vue.f36acd1f.94f9b2dd.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "vue.f36acd1f.94f9b2dd.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "layouts/default.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "default.dbf1d9ac.css",
    "src": "layouts/default.css"
  },
  "layouts/default.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "default.34795353.js",
    "imports": [
      "_components.03621c65.js",
      "_state.c48472a6.js",
      "node_modules/nuxt/dist/app/entry.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_nuxt-link.d02788a2.js",
      "_state.ef023967.js",
      "_vue.f36acd1f.94f9b2dd.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/default.vue"
  },
  "default.dbf1d9ac.css": {
    "file": "default.dbf1d9ac.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-404.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "error-404.7fc72018.css",
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-404.css"
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "error-404.c3684056.js",
    "imports": [
      "_nuxt-link.d02788a2.js",
      "_vue.f36acd1f.94f9b2dd.js",
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue"
  },
  "error-404.7fc72018.css": {
    "file": "error-404.7fc72018.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-500.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "error-500.c5df6088.css",
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-500.css"
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "error-500.305eb6f6.js",
    "imports": [
      "_vue.f36acd1f.94f9b2dd.js",
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue"
  },
  "error-500.c5df6088.css": {
    "file": "error-500.c5df6088.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "node_modules/nuxt-icon/dist/runtime/Icon.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "Icon.6f5d80f8.css",
    "src": "node_modules/nuxt-icon/dist/runtime/Icon.css"
  },
  "node_modules/nuxt-icon/dist/runtime/Icon.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "Icon.37dfdcc1.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_state.ef023967.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/nuxt-icon/dist/runtime/Icon.vue"
  },
  "Icon.6f5d80f8.css": {
    "file": "Icon.6f5d80f8.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "node_modules/nuxt-icon/dist/runtime/IconCSS.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "IconCSS.fe0874d9.css",
    "src": "node_modules/nuxt-icon/dist/runtime/IconCSS.css"
  },
  "node_modules/nuxt-icon/dist/runtime/IconCSS.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "IconCSS.f03cee09.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/nuxt-icon/dist/runtime/IconCSS.vue"
  },
  "IconCSS.fe0874d9.css": {
    "file": "IconCSS.fe0874d9.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "node_modules/nuxt/dist/app/entry.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "dynamicImports": [
      "layouts/default.vue",
      "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue",
      "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue"
    ],
    "file": "entry.4662ce49.js",
    "isEntry": true,
    "src": "node_modules/nuxt/dist/app/entry.js",
    "_globalCSS": true
  },
  "pages/[category]/[subcategory]/index.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "index.45d6b8b8.css",
    "src": "pages/[category]/[subcategory]/index.css"
  },
  "pages/[category]/[subcategory]/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "index.44699d7e.js",
    "imports": [
      "_components.03621c65.js",
      "_nuxt-link.d02788a2.js",
      "_state.c48472a6.js",
      "_client-only.2f9174c4.js",
      "_Tabs.ff47f975.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_state.ef023967.js",
      "_bar-ads.7ba90135.js",
      "_vue.f36acd1f.94f9b2dd.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/[category]/[subcategory]/index.vue"
  },
  "index.45d6b8b8.css": {
    "file": "index.45d6b8b8.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/[category]/index.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "index.3a024c4c.css",
    "src": "pages/[category]/index.css"
  },
  "pages/[category]/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "index.27fb3f0f.js",
    "imports": [
      "_components.03621c65.js",
      "_state.c48472a6.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_nuxt-link.d02788a2.js",
      "_client-only.2f9174c4.js",
      "_Tabs.ff47f975.js",
      "_state.ef023967.js",
      "_vue.f36acd1f.94f9b2dd.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/[category]/index.vue"
  },
  "index.3a024c4c.css": {
    "file": "index.3a024c4c.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/archive.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "archive.999a233d.js",
    "imports": [
      "_components.03621c65.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_client-only.2f9174c4.js",
      "_state.c48472a6.js",
      "_nuxt-link.d02788a2.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_state.ef023967.js",
      "_bar-ads.7ba90135.js",
      "_vue.f36acd1f.94f9b2dd.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/archive.vue"
  },
  "pages/author/[author_slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_author_slug_.7c4783db.js",
    "imports": [
      "_components.03621c65.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_client-only.2f9174c4.js",
      "_state.c48472a6.js",
      "_nuxt-link.d02788a2.js",
      "_Tabs.ff47f975.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_state.ef023967.js",
      "_bar-ads.7ba90135.js",
      "_vue.f36acd1f.94f9b2dd.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/author/[author_slug].vue"
  },
  "pages/category/[category_slug]/[content_id].css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "_content_id_.b8646196.css",
    "src": "pages/category/[category_slug]/[content_id].css"
  },
  "pages/category/[category_slug]/[content_id].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "_content_id_.55679b4c.js",
    "imports": [
      "_components.03621c65.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_nuxt-link.d02788a2.js",
      "_state.c48472a6.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_client-only.2f9174c4.js",
      "_state.ef023967.js",
      "_vue.f36acd1f.94f9b2dd.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/category/[category_slug]/[content_id].vue"
  },
  "_content_id_.b8646196.css": {
    "file": "_content_id_.b8646196.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/collection/latest.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "latest.ef3537af.css",
    "src": "pages/collection/latest.css"
  },
  "pages/collection/latest.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "latest.357bd981.js",
    "imports": [
      "_components.03621c65.js",
      "_nuxt-link.d02788a2.js",
      "_state.c48472a6.js",
      "_client-only.2f9174c4.js",
      "_Tabs.ff47f975.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_state.ef023967.js",
      "_bar-ads.7ba90135.js",
      "_vue.f36acd1f.94f9b2dd.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/collection/latest.vue"
  },
  "latest.ef3537af.css": {
    "file": "latest.ef3537af.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/index.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "index.90f96eed.css",
    "src": "pages/index.css"
  },
  "pages/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "index.c9841979.js",
    "imports": [
      "_state.c48472a6.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_nuxt-link.d02788a2.js",
      "_client-only.2f9174c4.js",
      "_state.ef023967.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_vue.f36acd1f.94f9b2dd.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/index.vue"
  },
  "index.90f96eed.css": {
    "file": "index.90f96eed.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/photo.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "photo.b33d6d91.js",
    "imports": [
      "_components.03621c65.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_vue.f36acd1f.94f9b2dd.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/photo.vue"
  },
  "pages/photo/[album_slug]/[photo_id].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_photo_id_.60e7e131.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/photo/[album_slug]/[photo_id].vue"
  },
  "pages/topic/[tag_slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_tag_slug_.6117b45e.js",
    "imports": [
      "_components.03621c65.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_client-only.2f9174c4.js",
      "_state.c48472a6.js",
      "_nuxt-link.d02788a2.js",
      "_Tabs.ff47f975.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_state.ef023967.js",
      "_bar-ads.7ba90135.js",
      "_vue.f36acd1f.94f9b2dd.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/topic/[tag_slug].vue"
  }
};

export { client_manifest as default };
//# sourceMappingURL=client.manifest.mjs.map
