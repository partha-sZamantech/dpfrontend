import { d as defineEventHandler, u as useRuntimeConfig } from './nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'ipx';

const homegallery_get = defineEventHandler(async (event) => {
  const config = useRuntimeConfig();
  const data = await $fetch(`${config.public.apiUrl}/api/homegallery`, {
    method: "GET"
  });
  return data;
});

export { homegallery_get as default };
//# sourceMappingURL=homegallery.get.mjs.map
