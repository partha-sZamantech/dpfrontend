import { d as defineEventHandler, u as useRuntimeConfig, r as readBody } from './nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'ipx';

const getauthorcontent_post = defineEventHandler(async (event) => {
  const config = useRuntimeConfig();
  const getBody = await readBody(event);
  const data = await $fetch(`${config.public.apiUrl}/api/author/contents`, {
    method: "POST",
    body: {
      take: getBody == null ? void 0 : getBody.take,
      author_slug: getBody == null ? void 0 : getBody.author_slug
    }
  });
  return data;
});

export { getauthorcontent_post as default };
//# sourceMappingURL=getauthorcontent.post.mjs.map
