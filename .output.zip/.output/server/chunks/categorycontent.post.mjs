import { d as defineEventHandler, u as useRuntimeConfig, r as readBody } from './nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'ipx';

const categorycontent_post = defineEventHandler(async (event) => {
  const config = useRuntimeConfig();
  const getBody = await readBody(event);
  const data = await $fetch(`${config.public.apiUrl}/api/catcontent/${getBody == null ? void 0 : getBody.cat_slug}/${getBody == null ? void 0 : getBody.take}`, {
    method: "GET"
  });
  return data;
});

export { categorycontent_post as default };
//# sourceMappingURL=categorycontent.post.mjs.map
