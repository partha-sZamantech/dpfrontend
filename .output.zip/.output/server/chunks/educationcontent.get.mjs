import { d as defineEventHandler, u as useRuntimeConfig } from './nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'ipx';

const educationcontent_get = defineEventHandler(async (event) => {
  const config = useRuntimeConfig();
  const data = await $fetch(`${config.public.apiUrl}/api/educationcontent`, {
    method: "GET"
  });
  return data;
});

export { educationcontent_get as default };
//# sourceMappingURL=educationcontent.get.mjs.map
