import { d as defineEventHandler, u as useRuntimeConfig, r as readBody } from './nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'ipx';

const getarchive_post = defineEventHandler(async (event) => {
  const config = useRuntimeConfig();
  const getBody = await readBody(event);
  const data = await $fetch(`${config.public.apiUrl}/api/archive/post/get`, {
    method: "POST",
    body: {
      date: getBody == null ? void 0 : getBody.date,
      take: getBody == null ? void 0 : getBody.take
    }
  });
  return data;
});

export { getarchive_post as default };
//# sourceMappingURL=getarchive.post.mjs.map
