import { d as defineEventHandler, u as useRuntimeConfig } from './nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'ipx';

const artscontent_get = defineEventHandler(async (event) => {
  const config = useRuntimeConfig();
  const data = await $fetch(`${config.public.apiUrl}/api/artscontent`, {
    method: "GET"
  });
  return data;
});

export { artscontent_get as default };
//# sourceMappingURL=artscontent.get.mjs.map
