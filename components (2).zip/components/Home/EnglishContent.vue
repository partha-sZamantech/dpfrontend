<template>
    <div class="max-w-[1280px] mx-auto px-4 md:px-4 py-6 md:py-10">
        <div class="category-header border-b-4 border-b-[#3375af]">
            <NuxtLink to="/" class="flex gap-3 items-center">
                <span class="w-3 h-3 bg-[#3375af]"></span>
                <h2 class="text-[#3375af] text-[18px] font-semibold">ENGLISH</h2>
            </NuxtLink>
        </div>
 
        <div class=" grid grid-cols-12 gap-6 mt-4">
            <div class=" col-span-12 md:col-span-4">
                <div class="flex flex-col gap-3">
                    <NuxtLink to="/" class="grid grid-cols-2 gap-2 group">
                        <div class=" overflow-hidden">
                            <nuxt-img loading="lazy"
                                :src="`${siteUrl?.site_url}/media/content/images/2023October/SM/gaja-2-20231008122635.jpg`"
                                class="mx-auto w-full group-hover:scale-110 duration-300"
                                :placeholder="img(`${siteUrl?.site_url}/logo/placeholder.jpg`)" />
                        </div>
                        <div class="flex flex-col gap-2">
                            <h4 class="text-base text-black group-hover:text-[#ff0000] font-semibold">Level playing field will ensure in
                            KCC polls: CEC</h4>
                            <!-- <p class="text-sm text-black mt-1 flex gap-1 items-center">
                                <Icon name="ph:alarm-bold" />
                                <span>
                                    {{ postCreatedDate(leftsport?.created_at) }}
                                </span>
                            </p> -->
                        </div>
                    </NuxtLink>
                    <NuxtLink to="/" class="grid grid-cols-2 gap-2 group">
                        <div class=" overflow-hidden">
                            <nuxt-img loading="lazy"
                                :src="`${siteUrl?.site_url}/media/content/images/2023October/SM/gaja-2-20231008122635.jpg`"
                                class="mx-auto w-full group-hover:scale-110 duration-300"
                                :placeholder="img(`${siteUrl?.site_url}/logo/placeholder.jpg`)" />
                        </div>
                        <div class="flex flex-col gap-2">
                            <h4 class="text-base text-black group-hover:text-[#ff0000] font-semibold">Level playing field will ensure in
                            KCC polls: CEC</h4>
                            <!-- <p class="text-sm text-black mt-1 flex gap-1 items-center">
                                <Icon name="ph:alarm-bold" />
                                <span>
                                    {{ postCreatedDate(leftsport?.created_at) }}
                                </span>
                            </p> -->
                        </div>
                    </NuxtLink>
                    <NuxtLink to="/" class="grid grid-cols-2 gap-2 group">
                        <div class=" overflow-hidden">
                            <nuxt-img loading="lazy"
                                :src="`${siteUrl?.site_url}/media/content/images/2023October/SM/gaja-2-20231008122635.jpg`"
                                class="mx-auto w-full group-hover:scale-110 duration-300"
                                :placeholder="img(`${siteUrl?.site_url}/logo/placeholder.jpg`)" />
                        </div>
                        <div class="flex flex-col gap-2">
                            <h4 class="text-base text-black group-hover:text-[#ff0000] font-semibold">Level playing field will ensure in
                            KCC polls: CEC</h4>
                            <!-- <p class="text-sm text-black mt-1 flex gap-1 items-center">
                                <Icon name="ph:alarm-bold" />
                                <span>
                                    {{ postCreatedDate(leftsport?.created_at) }}
                                </span>
                            </p> -->
                        </div>
                    </NuxtLink>
                </div>
            </div>
            <div class="col-span-12 md:col-span-4">
                <NuxtLink to="/" class="flex flex-col gap-2 group">
                    <div class=" overflow-hidden">
                        <nuxt-img loading="lazy"
                            :src="`${siteUrl?.site_url}/media/content/images/2023October/SM/gaja-2-20231008122635.jpg`"
                            class="mx-auto w-full group-hover:scale-110 duration-300"
                            :placeholder="img(`${siteUrl?.site_url}/logo/placeholder.jpg`)" />
                    </div>
                    <div class="flex flex-col">
                        <h3 class="text-[25px] group-hover:text-[#ff0000] font-semibold">Level playing field will ensure in
                            KCC polls: CEC</h3>
                        <p class="text-base font-[300] text-black">Power supply situation is again getting worse with the decrease in generation and rising mercury level </p>
                        <!-- <p class="text-sm text-black mt-1 flex gap-1 items-center">
                            <Icon name="ph:alarm-bold" />
                            <span>
                                {{ postCreatedDate(sportscontent[0]?.created_at) }}
                            </span>
                        </p> -->
                    </div>
                </NuxtLink>
            </div>
            <div class="col-span-12 md:col-span-4">
                <div class="flex flex-col gap-3">
                    <NuxtLink to="/" class="grid grid-cols-2 gap-2 group">
                        <div class="flex flex-col gap-2">
                            <h3 class="text-base group-hover:text-[#ff0000] font-semibold"> Level playing field will ensure
                                in KCC polls: CEC</h3>
                            <!-- <p class="text-sm text-black mt-1 flex gap-1 items-center">
                                <Icon name="ph:alarm-bold" />
                                <span>
                                    {{ postCreatedDate(rtsport?.created_at) }}
                                </span>
                            </p> -->
                        </div>
                        <div class=" overflow-hidden">
                            <nuxt-img loading="lazy"
                                :src="`${siteUrl?.site_url}/media/content/images/2023October/SM/gaja-2-20231008122635.jpg`"
                                class="mx-auto w-full group-hover:scale-110 duration-300"
                                :placeholder="img(`${siteUrl?.site_url}/logo/placeholder.jpg`)" />
                        </div>
                    </NuxtLink>
                    <NuxtLink to="/" class="grid grid-cols-2 gap-2 group">
                        <div class="flex flex-col gap-2">
                            <h3 class="text-base group-hover:text-[#ff0000] font-semibold"> Level playing field will ensure
                                in KCC polls: CEC</h3>
                            <!-- <p class="text-sm text-black mt-1 flex gap-1 items-center">
                                <Icon name="ph:alarm-bold" />
                                <span>
                                    {{ postCreatedDate(rtsport?.created_at) }}
                                </span>
                            </p> -->
                        </div>
                        <div class=" overflow-hidden">
                            <nuxt-img loading="lazy"
                                :src="`${siteUrl?.site_url}/media/content/images/2023October/SM/gaja-2-20231008122635.jpg`"
                                class="mx-auto w-full group-hover:scale-110 duration-300"
                                :placeholder="img(`${siteUrl?.site_url}/logo/placeholder.jpg`)" />
                        </div>
                    </NuxtLink>
                    <NuxtLink to="/" class="grid grid-cols-2 gap-2 group">
                        <div class="flex flex-col gap-2">
                            <h3 class="text-base group-hover:text-[#ff0000] font-semibold"> Level playing field will ensure
                                in KCC polls: CEC</h3>
                            <!-- <p class="text-sm text-black mt-1 flex gap-1 items-center">
                                <Icon name="ph:alarm-bold" />
                                <span>
                                    {{ postCreatedDate(rtsport?.created_at) }}
                                </span>
                            </p> -->
                        </div>
                        <div class=" overflow-hidden">
                            <nuxt-img loading="lazy"
                                :src="`${siteUrl?.site_url}/media/content/images/2023October/SM/gaja-2-20231008122635.jpg`"
                                class="mx-auto w-full group-hover:scale-110 duration-300"
                                :placeholder="img(`${siteUrl?.site_url}/logo/placeholder.jpg`)" />
                        </div>
                    </NuxtLink>
                </div>
            </div>
        </div>
    </div>
</template>

<script setup>
const img = useImage()
const siteUrl = siteUrlState()
</script>

<style lang="scss" scoped></style>