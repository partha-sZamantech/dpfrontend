<template>
    <div class="errorNotfound">
        <Head>
            <Title>404 Not Found | ঢাকাপ্রকাশ</Title>
        </Head>
         <Errorpage />
    </div>
</template>

<script setup>
</script>

<style lang="scss" scoped>

</style>