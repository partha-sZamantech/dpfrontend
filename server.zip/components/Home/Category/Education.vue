<template>
    <div class="home-education-category " v-if="educationcontents?.length > 0">
        <div class="category-header border-b-[3px] group border-b-[#3375af] my-3">
            <NuxtLink :to="`/${educationcontents[0]?.cat_slug}`" class="flex gap-3 items-center">
                <span class="w-3 h-3 bg-[#3375af]"></span>
                <h2 class="text-[#3375af] text-[18px] group-hover:text-[#65a1d6] font-semibold">শিক্ষা</h2>
            </NuxtLink>
        </div>
        <div class="home-int-c-content flex flex-col gap-3">
            <!-- International Feature Content -->
            <NuxtLink
                :to="getPostUrl(educationcontents[0]?.cat_slug, educationcontents[0]?.subcat_slug, educationcontents[0]?.content_type, educationcontents[0]?.content_id)"
                class="flex flex-col gap-2 group border-b pb-1">
                <div class=" overflow-hidden">
                    <nuxt-img loading="lazy"
                        :src="`${siteurl.site_url}/media/content/images/${educationcontents[0]?.img_bg_path}`"
                        class="mx-auto w-full group-hover:scale-110 duration-300"
                        :placeholder="img(`${siteurl?.site_url}/logo/placeholder.jpg`)" />
                </div>
                <h3 class="text-[19px] text-black font-semibold group-hover:text-[#ff0000]">
                    {{ educationcontents[0]?.content_heading }}
                </h3>
                <p class="text-sm text-black flex gap-1 items-center">
                    <Icon name="ph:alarm-bold" />
                    <span>
                        {{ postCreatedDate(educationcontents[0]?.created_at) }}
                    </span>
                </p>
            </NuxtLink>
            <!--/ International Feature Content -->

            <div class="h-p-c-excpt flex flex-col">
                <!-- Loop Item -->
                <NuxtLink
                    :to="getPostUrl(educationcontent?.cat_slug, educationcontent?.subcat_slug, educationcontent?.content_type, educationcontent?.content_id)"
                    class=" border-b py-3" v-for="educationcontent in educationcontents.slice(1, 8)"
                    :key="educationcontent.content_id">
                    <h4 class="text-base text-black font-semibold hover:text-[#ff0000] leading-tight">{{
                        educationcontent?.content_heading }}</h4>
                </NuxtLink>
                <!--/ Loop Item -->


            </div>

        </div>
    </div>
</template>

<script setup>
import { postCreatedDate, getPostUrl } from '~/lib/helpers';
const img = useImage()
const siteurl = siteUrlState()
// ======== Arts Content =============== //
const educationcontents = useState(() => [])
const { data: heducation } = await useFetch("/api/prismaapi/home/education", {
    method: 'GET',
    // cache: 'force-cache',
})
educationcontents.value = heducation
// ======== Arts Content =============== //


</script>

<style lang="scss" scoped></style>