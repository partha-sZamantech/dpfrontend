<template>
    <div class="py-4">
        <iframe
            src="https://www.facebook.com/plugins/page.php?href=https%3A%2F%2Fwww.facebook.com%2Fdhakaprokash24&amp;tabs=timeline&amp;width=300&amp;height=130&amp;small_header=false&amp;adapt_container_width=true&amp;hide_cover=false&amp;show_facepile=true&amp;appId"
            width="300" height="130" style="border:none;overflow:hidden" scrolling="no" frameborder="0"
            allowfullscreen="true" allow="autoplay; clipboard-write; encrypted-media; picture-in-picture; web-share"
            data-gtm-yt-inspected-6="true"></iframe>
    </div>
</template>

<script setup>

</script>
