<template>
    <div class=" h-96 flex flex-col gap-8 items-center justify-center">
        <div class="flex flex-col gap-2 items-center justify-center">
            <h2 class="text-4xl font-semibold">404 - Not Found</h2>
            <p class="text-2xl">অনুসন্ধানকৃত তথ্য পাওয়া যায়নি</p>
        </div>

        <NuxtLink to="/collection/latest" class="text-base font-semibold">সর্বশেষ খবর জানতে এখানে চাপুন</NuxtLink>
    </div>
</template>

<script setup>

</script>

<style lang="scss" scoped></style>