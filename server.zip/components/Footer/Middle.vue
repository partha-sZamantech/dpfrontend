<template>
    <div class=" border-t py-6 flex md:flex-row flex-col gap-5 md:gap-0 justify-between">
        <div class="social_media flex flex-col gap-2">
            <p class="text-center text-sm">অনুসরণ করুন</p>
            <div class="flex gap-4 justify-center">

                <NuxtLink target="_blank" to="https://www.facebook.com/dhakaprokash24">
                    <svg xmlns="http://www.w3.org/2000/svg" height="28" width="28" viewBox="0 0 32 32"
                        enable-background="new 0 0 32 32" xml:space="preserve">
                        <path fill="#1877F2"
                            d="M16,0L16,0c8.837,0,16,7.163,16,16l0,0c0,8.837-7.163,16-16,16l0,0C7.163,32,0,24.837,0,16l0,0 C0,7.163,7.163,0,16,0z">
                        </path>
                        <path fill="#FFFFFF"
                            d="M18,17.5h2.5l1-4H18v-2c0-1.03,0-2,2-2h1.5V6.14C21.174,6.097,19.943,6,18.643,6C15.928,6,14,7.657,14,10.7 v2.8h-3v4h3V26h4V17.5z">
                        </path>
                    </svg>
                </NuxtLink>
                <NuxtLink target="_blank" to="https://twitter.com/dhakaprokash24">
                    <img src="/assets/img/social/x.svg" width="28" height="28" alt="instagram" />
                </NuxtLink>
                <NuxtLink target="_blank" to="https://www.instagram.com/dhakaprokash24/">
                    <img src="/assets/img/social/instagram.png" width="28" height="28" alt="instagram" />
                </NuxtLink>

                <NuxtLink target="_blank" to="https://www.youtube.com/DhakaProkash">
                    <svg xmlns="http://www.w3.org/2000/svg" height="28" width="28" viewBox="0 0 32 32"
                        enable-background="new 0 0 32 32" xml:space="preserve">
                        <path fill="#FF0000"
                            d="M16,0L16,0c8.837,0,16,7.163,16,16l0,0c0,8.837-7.163,16-16,16l0,0C7.163,32,0,24.837,0,16l0,0 C0,7.163,7.163,0,16,0z">
                        </path>
                        <path fill="#FFFFFF"
                            d="M25.543,10.498C26,12.28,26,16,26,16s0,3.72-0.457,5.502c-0.254,0.985-0.997,1.76-1.938,2.022 C21.896,24,16,24,16,24s-5.893,0-7.605-0.476c-0.945-0.266-1.687-1.04-1.938-2.022C6,19.72,6,16,6,16s0-3.72,0.457-5.502 c0.254-0.985,0.997-1.76,1.938-2.022C10.107,8,16,8,16,8s5.896,0,7.605,0.476C24.55,8.742,25.292,9.516,25.543,10.498L25.543,10.498 z M14,19.5l6-3.5l-6-3.5V19.5z">
                        </path>
                    </svg>
                </NuxtLink>
            </div>
        </div>
        <div class="apps flex flex-col gap-2">
            <p class="text-center text-sm">মোবাইল অ্যাপস ডাউনলোড করুন</p>
            <div class="flex gap-6 justify-center">
                <NuxtLink to="#" target="_blank">
                    <svg xmlns="http://www.w3.org/2000/svg" width="140" height="40">
                        <g data-name="Group 4686" transform="translate(-410 -926.5)">
                            <rect width="140" height="40" data-name="Rectangle 60" rx="2" transform="translate(410 926.5)"
                                fill="#222"></rect>
                            <g data-name="Group 4523" fill="#ccc">
                                <g data-name="Group 2992">
                                    <text data-name="Android app on" transform="translate(458.735 940.5)" font-size="8"
                                        font-family="ArialMT,Arial">
                                        <tspan x="0" y="0">Android app on</tspan>
                                    </text>
                                    <text data-name="Google Play" transform="translate(458.735 955.5)" font-size="12"
                                        font-family="Arial-BoldMT,Arial" font-weight="700">
                                        <tspan x="0" y="0">Google Play</tspan>
                                    </text>
                                </g>
                                <path
                                    d="M446.889 946.07l-9.485-9.511 12.068 6.928-2.583 2.583zM434.928 936a1.671 1.671 0 00-.932 1.517v18.966a1.671 1.671 0 00.932 1.517l11.028-11zm18.274 9.7l-2.531-1.466-2.824 2.772 2.824 2.772 2.583-1.465a1.723 1.723 0 00-.052-2.613zm-15.8 11.75l12.068-6.928-2.581-2.587z"
                                    data-name="Path 535"></path>
                            </g>
                        </g>
                    </svg>
                </NuxtLink>
                <NuxtLink to="#" target="_blank">
                    <svg xmlns="http://www.w3.org/2000/svg" width="140" height="40">
                        <g data-name="Group 4685" transform="translate(-570 -926.5)">
                            <rect width="140" height="40" data-name="Rectangle 101" rx="2" transform="translate(570 926.5)"
                                fill="#222"></rect>
                            <g data-name="Group 4524" fill="#ccc">
                                <text data-name="Available on the" transform="translate(619.279 940.5)" font-size="8"
                                    font-family="ArialMT,Arial">
                                    <tspan x="0" y="0">Available on the</tspan>
                                </text>
                                <text data-name="App Store" transform="translate(619.279 955.5)" font-size="12"
                                    font-family="Arial-BoldMT,Arial" font-weight="700">
                                    <tspan x="0" y="0">App Store</tspan>
                                </text>
                                <path
                                    d="M609.457 945.626a4.585 4.585 0 012.456-4.165 5.279 5.279 0 00-4.16-2.191c-1.744-.137-3.649 1.017-4.347 1.017-.737 0-2.426-.967-3.752-.967-2.741.044-5.654 2.185-5.654 6.542a12.228 12.228 0 00.708 3.988c.628 1.8 2.9 6.223 5.265 6.149 1.238-.029 2.112-.879 3.723-.879 1.562 0 2.372.879 3.752.879 2.387-.034 4.44-4.052 5.04-5.859a4.869 4.869 0 01-3.031-4.514zm-2.78-8.065a4.627 4.627 0 001.179-3.561 5.211 5.211 0 00-3.335 1.714 4.7 4.7 0 00-1.257 3.532 4.123 4.123 0 003.413-1.685z"
                                    data-name="Path 536"></path>
                            </g>
                        </g>
                    </svg>
                </NuxtLink>
            </div>
        </div>
    </div>
</template>

<script setup>

</script>

<style lang="scss" scoped></style>