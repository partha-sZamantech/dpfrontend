<template>
    <div class="footer-mainContainer">
        <div class="bg-[#e4e4e4]">
            <div class=" max-w-[1280px] mx-auto px-4 md:px-2">
                <div class="main-footer pt-10">
                    <FooterTop />
                    <!-- <FooterMiddle /> -->
                </div>
            </div>
        </div>
        <FooterBottom />
    </div>
</template>

<script setup>

</script>

<style lang="scss" scoped></style>