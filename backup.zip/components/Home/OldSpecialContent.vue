<template>
    <div>
        <!-- Start Special Content Area 1 -->
        <div class=" grid grid-cols-12 py-4 md:border-t md:border-t-[#e2e2e2] md:border-b md:border-b-[#e2e2e2]">
            <div class=" col-span-12 md:col-span-6 md:border-r md:border-r-[#e2e2e2]">
                <!-- Special Content Position 1 -->
                <NuxtLink to="/" class=" group">
                    <div class="grid grid-cols-12 gap-2 md:pr-2">
                        <div class="col-span-12 md:col-span-8 overflow-hidden">
                            <nuxt-img src="https://www.dhakaprokash24.com/media/content/images/2023October/nobel-20231005171906.jpg" class="mx-auto w-full group-hover:scale-110 duration-300"
                                :placeholder="img('https://www.dhakaprokash24.com/media/common/logo1672518180.png', { height: 300 })" />
                        </div>
                        <div class=" col-span-12 md:col-span-4">
                            <div class="flex flex-col gap-2 px-2">
                                <h2 class="text-[#121212] text-[18px] font-[600] group-hover:text-blue-700">দেশের নিট
                                    রিজার্ভ এখন ১৮ বিলিয়ন ডলারের
                                    নিচে: জাহিদ
                                    হোসেন</h2>
                                <p class="text-[#555555] text-[16px]">দেশের সামষ্টিক অর্থনৈতিক অস্থিতিশীলতার পেছনে বহিস্থ
                                    কারণের
                                    সঙ্গে দেশীয় কারণও আছে বলে মনে করেন জাহিদ হোসেন।</p>
                            </div>
                        </div>
                    </div>
                </NuxtLink>
                <!-- Special Content Position 1 -->
            </div>

            <div class=" col-span-12 md:col-span-6">
                <div class="grid grid-flow-row md:grid-cols-2 gap-2">
                    <div class="md:px-2 md:border-r md:border-r-[#e2e2e2]">
                        <!-- Special Content Position 2 -->
                        <NuxtLink to="/" class="group">
                            <div class="flex flex-col">
                                <div class=" w-full md:w-[295px] md:h-[165px] overflow-hidden">
                                    <nuxt-img src="https://www.dhakaprokash24.com/media/content/images/2023October/nobel-20231005171906.jpg" class="mx-auto w-full group-hover:scale-110 duration-300"
                                :placeholder="img('https://www.dhakaprokash24.com/media/common/logo1672518180.png', { height: 300 })" />
                                </div>
                                <h2 class="text-[#121212] text-[18px] font-[600] py-2 group-hover:text-blue-700">দেশের নিট
                                    রিজার্ভ এখন ১৮ বিলিয়ন
                                    ডলারের নিচে: জাহিদ
                                    হোসেন</h2>
                                <!-- <p class="text-[#555555] text-[16px]">দেশের সামষ্টিক অর্থনৈতিক অস্থিতিশীলতার পেছনে বহিস্থ
                                    কারণের
                                    সঙ্গে দেশীয় </p> -->
                            </div>
                        </NuxtLink>
                        <!-- Special Content Position 2 -->
                    </div>
                    <!-- Ads Home Right 1-->
                    <div>
                        <NuxtLink to="/">
                            <nuxt-img src="https://www.dhakaprokash24.com/media/content/images/2023October/nobel-20231005171906.jpg" class="mx-auto w-full"
                                 />
                        </NuxtLink>
                    </div>
                    <!-- Ads Home Right 1-->
                </div>
            </div>
        </div>
        <!-- End Special Content Area 1 -->

        <!-- Start Special Content Area 2 -->
        <div class=" grid grid-cols-12 gap-2 py-4 md:border-b md:border-b-[#e2e2e2]">
            <div class=" col-span-12 md:col-span-3 md:border-r md:border-r-[#e2e2e2] md:px-4">
                <div class="flex flex-col gap-2 group">
                    <NuxtLink to="/">
                        <h2 class="text-[#121212] text-[18px] font-[600] group-hover:text-blue-700 mb-2">দেশের নিট রিজার্ভ
                            এখন ১৮
                            বিলিয়ন ডলারের
                            নিচে: জাহিদ
                            হোসেন</h2>
                        <p class="text-[#555555] text-[16px]">দেশের সামষ্টিক অর্থনৈতিক অস্থিতিশীলতার পেছনে বহিস্থ
                            কারণে সঙ্গে দেশীয় কারণও আছে বলে মনে করেন জাহিদ হোসেন। কারণে সঙ্গে দেশীয় কারণও আছে বলে মনে করেন
                            জাহিদ হোসেন। কারণে সঙ্গে দেশীয় কারণও আছে বলে মনে করেন জাহিদ হোসেন।</p>
                    </NuxtLink>
                </div>
            </div>
            <div class=" col-span-12 md:col-span-3 md:border-r md:border-r-[#e2e2e2] md:px-4">
                <div class="flex flex-col gap-2 group">
                    <NuxtLink to="/">
                        <h2 class="text-[#121212] text-[18px] font-[600] group-hover:text-blue-700 mb-2">দেশের নিট রিজার্ভ
                            এখন ১৮
                            বিলিয়ন ডলারের
                            নিচে: জাহিদ
                            হোসেন</h2>
                        <p class="text-[#555555] text-[16px]">দেশের সামষ্টিক অর্থনৈতিক অস্থিতিশীলতার পেছনে বহিস্থ
                            কারণে সঙ্গে দেশীয় কারণও আছে বলে মনে করেন জাহিদ হোসেন। কারণে সঙ্গে দেশীয় কারণও আছে বলে মনে করেন
                            জাহিদ হোসেন। কারণে সঙ্গে দেশীয় কারণও আছে বলে মনে করেন জাহিদ হোসেন।</p>
                    </NuxtLink>
                </div>
            </div>
            <div class=" col-span-12 md:col-span-3 md:border-r md:border-r-[#e2e2e2] md:px-4">
                <div class="flex flex-col gap-2 group">
                    <NuxtLink to="/">
                        <h2 class="text-[#121212] text-[18px] font-[600] group-hover:text-blue-700 mb-2">দেশের নিট রিজার্ভ
                            এখন ১৮
                            বিলিয়ন ডলারের
                            নিচে: জাহিদ
                            হোসেন</h2>
                        <p class="text-[#555555] text-[16px]">দেশের সামষ্টিক অর্থনৈতিক অস্থিতিশীলতার পেছনে বহিস্থ
                            কারণে সঙ্গে দেশীয় কারণও আছে বলে মনে করেন জাহিদ হোসেন। কারণে সঙ্গে দেশীয় কারণও আছে বলে মনে করেন
                            জাহিদ হোসেন। কারণে সঙ্গে দেশীয় কারণও আছে বলে মনে করেন জাহিদ হোসেন।</p>
                    </NuxtLink>
                </div>
            </div>
            <div class=" col-span-12 md:col-span-3">
                <div class="flex flex-col gap-2 group md:px-4">
                    <NuxtLink to="/">
                        <h2 class="text-[#121212] text-[18px] font-[600] group-hover:text-blue-700 mb-2">দেশের নিট রিজার্ভ
                            এখন ১৮
                            বিলিয়ন ডলারের
                            নিচে: জাহিদ
                            হোসেন</h2>
                        <p class="text-[#555555] text-[16px]">দেশের সামষ্টিক অর্থনৈতিক অস্থিতিশীলতার পেছনে বহিস্থ
                            কারণে সঙ্গে দেশীয় কারণও আছে বলে মনে করেন জাহিদ হোসেন। কারণে সঙ্গে দেশীয় কারণও আছে বলে মনে করেন
                            জাহিদ হোসেন। কারণে সঙ্গে দেশীয় কারণও আছে বলে মনে করেন জাহিদ হোসেন।</p>
                    </NuxtLink>
                </div>
            </div>
        </div>
        <!-- End Special Content Area 2 -->

        <!-- Start Special Content Area 3 -->
        <div class=" grid grid-cols-12 py-4 border-b border-b-[#e2e2e2]">
            <div class="col-span-12 md:col-span-3 md:px-2 md:border-r md:border-r-[#e2e2e2]">
                <div class="flex flex-col gap-2 group overflow-hidden">
                    <NuxtLink to="/">
                        <nuxt-img src="https://www.dhakaprokash24.com/media/content/images/2023October/nobel-20231005171906.jpg" class="mx-auto w-full group-hover:scale-105 duration-300"
                                :placeholder="img('https://www.dhakaprokash24.com/media/common/logo1672518180.png', { height: 300 })" />
                        <h2 class="text-[#121212] text-[18px] font-[600] group-hover:text-blue-700 mt-2">দেশের নিট রিজার্ভ
                            এখন ১৮
                            বিলিয়ন ডলারের
                            নিচে: জাহিদ
                            হোসেন</h2>
                    </NuxtLink>
                </div>
            </div>
            <div class="col-span-12 md:col-span-3 md:px-2 md:border-r md:border-r-[#e2e2e2]">
                <div class="flex flex-col gap-2 group overflow-hidden">
                    <NuxtLink to="/">
                        <nuxt-img src="https://www.dhakaprokash24.com/media/content/images/2023October/nobel-20231005171906.jpg" class="mx-auto w-full group-hover:scale-105 duration-300"
                                :placeholder="img('https://www.dhakaprokash24.com/media/common/logo1672518180.png', { height: 300 })" />
                        <h2 class="text-[#121212] text-[18px] font-[600] group-hover:text-blue-700 mt-2">দেশের নিট রিজার্ভ
                            এখন ১৮
                            বিলিয়ন ডলারের
                            নিচে: জাহিদ
                            হোসেন</h2>
                    </NuxtLink>
                </div>
            </div>
            <div class="col-span-12 md:col-span-3 md:px-2 md:border-r md:border-r-[#e2e2e2]">
                <div class="flex flex-col gap-2 group overflow-hidden">
                    <NuxtLink to="/">
                        <nuxt-img src="https://www.dhakaprokash24.com/media/content/images/2023October/nobel-20231005171906.jpg" class="mx-auto w-full group-hover:scale-105 duration-300"
                                :placeholder="img('https://www.dhakaprokash24.com/media/common/logo1672518180.png', { height: 300 })" />
                        <h2 class="text-[#121212] text-[18px] font-[600] group-hover:text-blue-700 mt-2">দেশের নিট রিজার্ভ
                            এখন ১৮
                            বিলিয়ন ডলারের
                            নিচে: জাহিদ
                            হোসেন</h2>
                    </NuxtLink>
                </div>
            </div>
            <div class="col-span-12 md:col-span-3 md:px-2">
                <div class="flex flex-col gap-2 group overflow-hidden">
                    <NuxtLink to="/">
                        <nuxt-img src="https://www.dhakaprokash24.com/media/content/images/2023October/nobel-20231005171906.jpg" class="mx-auto w-full group-hover:scale-105 duration-300"
                                :placeholder="img('https://www.dhakaprokash24.com/media/common/logo1672518180.png', { height: 300 })" />
                        <h2 class="text-[#121212] text-[18px] font-[600] group-hover:text-blue-700 mt-2">দেশের নিট রিজার্ভ
                            এখন ১৮
                            বিলিয়ন ডলারের
                            নিচে: জাহিদ
                            হোসেন</h2>
                    </NuxtLink>
                </div>
            </div>
        </div>
        <!-- End Special Content Area 3 -->



        <!-- Start Special Content Area 4 -->
        <div class=" grid grid-cols-12 gap-2 py-4 border-b border-b-[#e2e2e2]">
            <div class="col-span-12 md:col-span-9 mt-4">
                <div class=" grid md:grid-cols-3 gap-4 border-b">
                    <!-- Loop Item -->
                    <div class=" h-28">
                        <NuxtLink to="/" class=" group">
                            <div class="grid grid-cols-2 gap-2 border-r border-r-[#e2e2e2]">
                                <div class="overflow-hidden">
                                    <nuxt-img src="https://www.dhakaprokash24.com/media/content/images/2023October/nobel-20231005171906.jpg" class="mx-auto w-full group-hover:scale-110 duration-300"
                                :placeholder="img('https://www.dhakaprokash24.com/media/common/logo1672518180.png', { height: 300 })" />
                                </div>
                                <div class="">
                                    <div class="flex flex-col gap-2 px-2">
                                        <h2 class="text-[#121212] text-[14px] font-[600] group-hover:text-blue-700">দেশের
                                            নিট
                                            রিজার্ভ এখন ১৮ বিলিয়ন ডলারের
                                            নিচে: জাহিদ
                                            হোসেন</h2>

                                    </div>
                                </div>
                            </div>
                        </NuxtLink>
                    </div>
                     <!-- Loop Item -->
                 <!-- Loop Item -->
                    <div class=" h-28">
                        <NuxtLink to="/" class=" group">
                            <div class="grid grid-cols-2 gap-2 border-r border-r-[#e2e2e2]">
                                <div class="overflow-hidden">
                                    <nuxt-img src="https://www.dhakaprokash24.com/media/content/images/2023October/nobel-20231005171906.jpg" class="mx-auto w-full group-hover:scale-110 duration-300"
                                :placeholder="img('https://www.dhakaprokash24.com/media/common/logo1672518180.png', { height: 300 })" />
                                </div>
                                <div class="">
                                    <div class="flex flex-col gap-2 px-2">
                                        <h2 class="text-[#121212] text-[14px] font-[600] group-hover:text-blue-700">দেশের
                                            নিট
                                            রিজার্ভ এখন ১৮ বিলিয়ন ডলারের
                                            নিচে: জাহিদ
                                            হোসেন</h2>

                                    </div>
                                </div>
                            </div>
                        </NuxtLink>
                    </div>
                     <!-- Loop Item -->
                     <!-- Loop Item -->
                     <div class=" h-28">
                        <NuxtLink to="/" class=" group">
                            <div class="grid grid-cols-2 gap-2 border-r border-r-[#e2e2e2]">
                                <div class="overflow-hidden">
                                    <nuxt-img src="https://www.dhakaprokash24.com/media/content/images/2023October/nobel-20231005171906.jpg" class="mx-auto w-full group-hover:scale-110 duration-300"
                                :placeholder="img('https://www.dhakaprokash24.com/media/common/logo1672518180.png', { height: 300 })" />
                                </div>
                                <div class="">
                                    <div class="flex flex-col gap-2 px-2">
                                        <h2 class="text-[#121212] text-[14px] font-[600] group-hover:text-blue-700">দেশের
                                            নিট
                                            রিজার্ভ এখন ১৮ বিলিয়ন ডলারের
                                            নিচে: জাহিদ
                                            হোসেন</h2>
                                    </div>
                                </div>
                            </div>
                        </NuxtLink>
                    </div>
                </div>
                <div class=" grid md:grid-cols-3 gap-4 pt-6">
                    <!-- Start Loop Item -->
                    <div class=" h-28">
                        <NuxtLink to="/" class=" group">
                            <div class="grid grid-cols-2 gap-2 border-r border-r-[#e2e2e2]">
                                <div class="overflow-hidden">
                                    <nuxt-img src="https://www.dhakaprokash24.com/media/content/images/2023October/nobel-20231005171906.jpg" class="mx-auto w-full group-hover:scale-110 duration-300"
                                :placeholder="img('https://www.dhakaprokash24.com/media/common/logo1672518180.png', { height: 300 })" />
                                </div>
                                <div class="">
                                    <div class="flex flex-col gap-2 px-2">
                                        <h2 class="text-[#121212] text-[14px] font-[600] group-hover:text-blue-700">দেশের
                                            নিট
                                            রিজার্ভ এখন ১৮ বিলিয়ন ডলারের
                                            নিচে: জাহিদ
                                            হোসেন</h2>

                                    </div>
                                </div>
                            </div>
                        </NuxtLink>
                    </div>
                     <!-- End Loop Item -->
                     <!-- Start Loop Item -->
                     <div class=" h-28">
                        <NuxtLink to="/" class=" group">
                            <div class="grid grid-cols-2 gap-2 border-r border-r-[#e2e2e2]">
                                <div class="overflow-hidden">
                                    <nuxt-img src="https://www.dhakaprokash24.com/media/content/images/2023October/nobel-20231005171906.jpg" class="mx-auto w-full group-hover:scale-110 duration-300"
                                :placeholder="img('https://www.dhakaprokash24.com/media/common/logo1672518180.png', { height: 300 })" />
                                </div>
                                <div class="">
                                    <div class="flex flex-col gap-2 px-2">
                                        <h2 class="text-[#121212] text-[14px] font-[600] group-hover:text-blue-700">দেশের
                                            নিট
                                            রিজার্ভ এখন ১৮ বিলিয়ন ডলারের
                                            নিচে: জাহিদ
                                            হোসেন</h2>

                                    </div>
                                </div>
                            </div>
                        </NuxtLink>
                    </div>
                     <!-- End Loop Item -->
                     <!-- Start Loop Item -->
                     <div class=" h-28">
                        <NuxtLink to="/" class=" group">
                            <div class="grid grid-cols-2 gap-2 border-r border-r-[#e2e2e2]">
                                <div class="overflow-hidden">
                                    <nuxt-img src="https://www.dhakaprokash24.com/media/content/images/2023October/nobel-20231005171906.jpg" class="mx-auto w-full group-hover:scale-110 duration-300"
                                :placeholder="img('https://www.dhakaprokash24.com/media/common/logo1672518180.png', { height: 300 })" />
                                </div>
                                <div class="">
                                    <div class="flex flex-col gap-2 px-2">
                                        <h2 class="text-[#121212] text-[14px] font-[600] group-hover:text-blue-700">দেশের
                                            নিট
                                            রিজার্ভ এখন ১৮ বিলিয়ন ডলারের
                                            নিচে: জাহিদ
                                            হোসেন</h2>

                                    </div>
                                </div>
                            </div>
                        </NuxtLink>
                    </div>
                     <!-- End Loop Item -->
                </div>
            </div>
            <div class="col-span-12 md:col-span-3">
                <!-- Ads Home Right 1-->
                <div>
                    <NuxtLink to="/">
                        <nuxt-img src="https://www.dhakaprokash24.com/media/content/images/2023October/nobel-20231005171906.jpg" class="mx-auto w-full" />
                    </NuxtLink>
                </div>
                <!-- Ads Home Right 1-->
            </div>
        </div>
        <!-- End Special Content Area 4 -->




    </div>
</template>

<script setup>
const img = useImage()
</script>

<style lang="scss" scoped></style>